# mdstack::theme

> **API reference:** [English version](../../doc/manuals/en/mdtheme.md)
> This German documentation covers concepts and usage scenarios.
> For exact signatures and options refer to the English version.


> Version 0.1

## Zweck

`mdstack::theme` stellt gemeinsame Farbthemes und Typografie-Einstellungen
für alle mdstack-Renderer bereit:

- **mdstack::viewer** (Tk-Widget) -- Farben für Text-Tags
- **mdstack::html** (HTML-Renderer) -- via `toCSS`
- **mdstack::pdf** (PDF-Renderer) -- via `toPdfOpts`

Ein Theme einmal definieren, drei Renderer profitieren.

---

## Abhängigkeiten

- Tcl 8.6+
- Kein `package require` für andere mdstack-Module nötig

---

## Öffentliche API

### Themes abfragen

```tcl
mdstack::theme::names       ;# --> dunkel hell solarized
mdstack::theme::current     ;# --> hell
mdstack::theme::activate dunkel
```

### Einzelnen Farbwert abfragen

```tcl
mdstack::theme::color bg    ;# --> #ffffff  (aktuelles Theme)
mdstack::theme::get hell bg ;# --> #ffffff  (benanntes Theme)
mdstack::theme::get hell font_size ;# --> 11  (Typografie)
```

### Theme-Dict abfragen

```tcl
set th [mdstack::theme::theme hell]
dict get $th link    ;# --> #0066cc
```

### Für HTML-Renderer

```tcl
package require mdstack::theme 0.1
package require mdstack::html  0.1

# Theme als vollstaendiges CSS
set html [mdstack::html::render $ast -theme hell]

# Theme als Basis + eigene Overrides (kombiniert)
set html [mdstack::html::render $ast -theme hell -css custom.css]
```

`toCSS` liefert einen vollstaendigen CSS-String mit allen
Farben und Typografie-Werten des Themes.

Wenn zusaetzlich `-css` angegeben wird, wird die externe Datei
**hinter** dem Theme-CSS eingefuegt. Spaetere CSS-Regeln gewinnen --
so koennen gezielt einzelne Eigenschaften ueberschrieben werden:

```css
/* custom.css -- nur die Abweichungen vom Theme */
body { font-size: 14pt; }
h1   { color: #cc0000; }
```

### Für PDF-Renderer

```tcl
package require mdstack::theme 0.1
package require mdstack::pdf   0.2

mdstack::pdf::export $ast output.pdf -theme hell
```

`toPdfOpts` liefert ein Dict mit PDF-relevanten Werten:
`fontsize`, `margin`, `colorLink`, `colorCode`.

### Für Tk-Viewer

```tcl
package require mdstack::theme  0.1
package require mdstack::viewer 0.3

mdstack::theme::activate dunkel
mdstack::theme::applyToViewer .viewer
```

---

## Verfügbare Themes

| Name | Beschreibung |
|------|-------------|
| `hell` | Helles Standard-Theme (weiß, Helvetica) |
| `dunkel` | Dunkles Theme (Catppuccin Mocha) |
| `solarized` | Solarized Light |

---

## Typografie-Defaults

Alle Themes teilen diese Typografie-Defaults (überschreibbar im Theme-Dict):

| Schlüssel | Standard | Beschreibung |
|-----------|----------|-------------|
| `font_body` | Georgia, serif | Brottext-Font |
| `font_heading` | Helvetica, Arial | Überschriften-Font |
| `font_mono` | Courier New | Monospace-Font |
| `font_size` | `11` | Basis-Schriftgröße in pt |
| `line_spacing` | `1.4` | Zeilenabstand-Faktor |
| `margin_page` | `50` | Seitenrand in pt (PDF) |
| `max_width_px` | `860` | Maximale Breite in px (HTML) |

---

## Eigenes Theme hinzufügen

```tcl
set mdstack::theme::themes(mein) {
    name   "Mein Theme"
    bg     "#fafafa"
    fg     "#111111"
    link   "#cc0000"
    # ... alle Pflicht-Schlüssel wie in 'hell' ...
    font_size  12
    margin_page 60
}
mdstack::theme::activate mein
```

---

## Farb-Schlüssel (Auswahl)

| Schlüssel | Verwendung |
|-----------|------------|
| `bg` | Hintergrund |
| `fg` | Vordergrund (Text) |
| `bg_alt` | Alternativer Hintergrund (Zebrastreifen) |
| `link` | Hyperlink-Farbe |
| `code_bg` | Code-Block-Hintergrund |
| `code_inline_bg` | Inline-Code-Hintergrund |
| `quote_fg` | Blockquote-Text |
| `quote_bg` | Blockquote-Hintergrund |
| `table_header_bg` | Tabellen-Header-Hintergrund |
| `span_cmd` | TIP-700 `.cmd`-Farbe |
| `span_arg` | TIP-700 `.arg`-Farbe |

---

## Changelog

### 0.1.1 (2026-03-14)

- `-theme` + `-css` kombinierbar in `mdstack::html`: Theme als Basis,
  externe Datei als Overrides (mdstack::theme selbst unveraendert,
  Kombinations-Logik liegt in `mdstack::html::render`)

### 0.1 (2026-03-14)

- Initiale Version (Umbenennung/Erweiterung von mdstack::theme für Tk-Viewer)
- `toCSS` -- Theme -> CSS-String für mdstack::html
- `toPdfOpts` -- Theme -> Dict für mdstack::pdf
- `get name key` -- Wert mit Typografie-Fallback
- Typografie-Defaults für font, size, margin, spacing

## Siehe auch

- [mdstack::html](mdhtml.md) -- HTML-Renderer
- [mdstack::pdf](mdpdf.md) -- PDF-Renderer
- [mdstack::viewer](mdviewer.md) -- Tk-Viewer
