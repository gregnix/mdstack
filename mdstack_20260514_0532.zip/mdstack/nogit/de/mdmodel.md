# mdstack::model

> **API reference:** [English version](../../doc/manuals/en/mdmodel.md)
> This German documentation covers concepts and usage scenarios.
> For exact signatures and options refer to the English version.


## Zweck

`mdstack::model` stellt ein **semantisches Dokumentmodell** für Markdown bereit.

Es sitzt **zwischen Parser und Viewer**:

```
Markdown → mdstack::parser (AST) → mdstack::model (Dokumentmodell) → mdstack::viewer
```

Das Modul:
- interpretiert das AST semantisch
- stellt strukturierte Informationen bereit
- ist **GUI-unabhängig**

`mdstack::model` ist die zentrale Stelle für:
- Inhaltsverzeichnisse
- Suche
- Querverweise
- Analyse von Dokumenten

---

## Typische Einsatzszenarien

- Erzeugen eines Inhaltsverzeichnisses (TOC)
- Volltext- oder Abschnittssuche
- Analyse von Überschriften und Anchors
- Grundlage für Navigation in Viewern
- Verarbeitung von Markdown außerhalb einer GUI

---

## Abhängigkeiten

- Tcl ≥ 8.6
- mdstack::parser 0.2

Keine Tk-Abhängigkeit.

---

## Dokumentmodell (Überblick)

Ein Dokumentmodell ist ein `dict`, das enthält:

- `ast` – das ursprüngliche AST
- `headings` – Liste aller Überschriften
- `anchors` – Dictionary (anchor → heading)
- `type` – immer "mdstack::model"
- `version` – Modell-Version (aktuell: 1)

Das exakte Format ist in  
`docs/technical/EDIT-MODEL-v1.md` beschrieben.

---

## Öffentliche API

### `mdstack::model::new ast`

Erzeugt ein Dokumentmodell aus einem AST.

```tcl
set ast [mdstack::parser::parse $markdown]
set doc [mdstack::model::new $ast]
```

#### Rückgabewert

* Dokumentmodell (`dict`)

---

### `mdstack::model::ast docModel`

Gibt das zugrundeliegende AST zurück.

```tcl
set ast [mdstack::model::ast $doc]
```

---

### `mdstack::model::toc docModel`

Erzeugt ein Inhaltsverzeichnis.

```tcl
set toc [mdstack::model::toc $doc]
```

Rückgabewert:

* Liste von TOC-Einträgen (jeder Eintrag: `level`, `text`, `anchor`)

**Hinweis:** `toc` gibt die gleichen Daten wie `headings` zurück.

---

### `mdstack::model::headings docModel`

Gibt alle Überschriften zurück.

```tcl
set h [mdstack::model::headings $doc]
```

Rückgabewert:

* Liste von Überschriften-Dicts mit:
  * `level` – Überschriftenebene (1-6)
  * `text` – Überschriftentext
  * `anchor` – Anchor-ID für Sprungmarken

---

### `mdstack::model::anchors docModel`

Gibt ein Dictionary aller Anchors zurück.

```tcl
set anchors [mdstack::model::anchors $doc]
```

Rückgabewert:

* Dictionary: `anchor → heading-dict`

Nützlich für:
- Schnelle Anchor-Lookup
- Navigation zu bestimmten Überschriften
- Validierung von internen Links

---

### `mdstack::model::find docModel pattern`

Durchsucht das Dokument nach einem Regexp-Pattern.

```tcl
set hits [mdstack::model::find $doc "Begriff"]
```

Rückgabewert:

* Liste von gefundenen Blöcken (AST-Blöcke, die das Pattern enthalten)

**Hinweis:** Sucht in:
- Überschriften
- Absätzen
- Code-Blöcken
- Listen

---

### `mdstack::model::meta docModel`

Gibt Metadaten aus dem AST zurück.

```tcl
set meta [mdstack::model::meta $doc]
```

Rückgabewert:

* Metadaten-Dict (aus dem AST)

---

## Fehlerbehandlung

* mdstack::model wirft **Tcl-Fehler** bei ungültigem AST
* AST muss Format "document" mit Version 1 haben
* Fehler werden nicht im Modell gesammelt

---

## Typische Fehler

* AST manuell verändern
  → AST ist read-only
* mdstack::model mit GUI-Logik vermischen
  → mdstack::model ist rein logisch
* Modellstruktur fest einbauen
  → nur über API zugreifen
* `find` mit zu komplexen Regexp-Patterns
  → kann langsam werden bei großen Dokumenten

---

## Zusammenspiel mit anderen Modulen

| Modul       | Rolle                   |
| ----------- | ----------------------- |
| mdstack     | Orchestrierung          |
| mdstack::parser    | Syntax → AST            |
| mdstack::model     | AST → Bedeutung         |
| mdstack::viewer    | Bedeutung → Darstellung |
| mdstack::text      | Editor-Widget           |

---

## Beispiel: TOC erstellen

```tcl
set ast [mdstack::parser::parse $markdown]
set doc [mdstack::model::new $ast]
set headings [mdstack::model::headings $doc]

foreach h $headings {
    set level [dict get $h level]
    set text [dict get $h text]
    set anchor [dict get $h anchor]
    puts "[string repeat "  " [expr {$level - 1}]]$text ($anchor)"
}
```

---

## Beispiel: Suche

```tcl
set ast [mdstack::parser::parse $markdown]
set doc [mdstack::model::new $ast]
set results [mdstack::model::find $doc "wichtig"]

puts "Gefunden: [llength $results] Stellen"
foreach block $results {
    puts "Block-Typ: [dict get $block type]"
}
```

---

## Nicht-Ziele

* Kein Rendering
* Kein Editieren
* Keine UI
* Kein Dateizugriff
* Keine Link-Extraktion (nur über AST möglich)

Diese Aufgaben liegen außerhalb von mdmodel.
