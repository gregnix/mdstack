# mdstack::stacknoteskit

> **API reference:** [English version](../../doc/manuals/en/mdstacknoteskit.md)
> This German documentation covers concepts and usage scenarios.
> For exact signatures and options refer to the English version.


## Zweck

Adapter zwischen **noteskit** (Notiz-Verwaltung) und **mdstack** (Editor-Orchestrator).

Ermöglicht die Integration von noteskit-Notizen in mdstack-basierte Anwendungen.

---

## Architektur

```
┌─────────────────────────────────────────────────────┐
│                    Anwendung                        │
└─────────────────────────────────────────────────────┘
         │                         │
         ▼                         ▼
┌─────────────────┐     ┌─────────────────────────────┐
│    noteskit     │     │         mdstack             │
│  (CRUD/Storage) │     │  (Editor/Preview/Stack)     │
└─────────────────┘     └─────────────────────────────┘
         │                         │
         └────────┬────────────────┘
                  ▼
         ┌─────────────────┐
         │ mdstack::stacknoteskit│
         │    (Adapter)    │
         └─────────────────┘
```

---

## Verwendung

```tcl
package require noteskit 0.1
package require mdstack 0.1
package require mdstack::stacknoteskit 0.1

# 1. noteskit initialisieren
noteskit::init sqlite -db notes.db

# 2. mdstack Editor-API setzen
mdstack::setEditorAPI \
    -getText  [list $editor get] \
    -setText  [list $editor set] \
    -clear    [list $editor clear]

# 3. Notiz laden
mdstack::stacknoteskit::loadNote $noteId

# 4. Änderungen speichern
mdstack::stacknoteskit::saveCurrent
```

---

## API

### Laden

#### `mdstack::stacknoteskit::loadNote id`

Lädt eine Notiz aus noteskit und pusht sie in mdstack.

```tcl
set note [mdstack::stacknoteskit::loadNote "12345"]
```

#### `mdstack::stacknoteskit::loadCurrent`

Lädt die aktuelle noteskit-Notiz in mdstack.

```tcl
noteskit::load $someId
mdstack::stacknoteskit::loadCurrent
```

---

### Speichern

#### `mdstack::stacknoteskit::saveCurrent`

Speichert den aktuellen mdstack-Text zurück in noteskit.

```tcl
mdstack::stacknoteskit::saveCurrent
```

#### `mdstack::stacknoteskit::syncFromEditor`

Synchronisiert Editor-Text in noteskit::currentNote (ohne zu speichern).

```tcl
mdstack::stacknoteskit::syncFromEditor
```

---

### Erstellen/Löschen

#### `mdstack::stacknoteskit::newNote ?title?`

Erstellt eine neue Notiz und pusht sie in mdstack.

```tcl
set note [mdstack::stacknoteskit::newNote "Meine Notiz"]
```

#### `mdstack::stacknoteskit::deleteCurrent`

Löscht die aktuelle Notiz aus noteskit und mdstack.

```tcl
mdstack::stacknoteskit::deleteCurrent
```

---

### Callbacks

#### `mdstack::stacknoteskit::onSave callback`

Callback nach dem Speichern.

```tcl
mdstack::stacknoteskit::onSave {id title} {
    puts "Gespeichert: $title ($id)"
}
```

#### `mdstack::stacknoteskit::onLoad callback`

Callback nach dem Laden.

```tcl
mdstack::stacknoteskit::onLoad {id title} {
    puts "Geladen: $title"
    set ::windowTitle $title
}
```

---

### Hilfsfunktionen

#### `mdstack::stacknoteskit::listNotes ?filter?`

Liste aller Notizen mit Stack-Status.

```tcl
set notes [mdstack::stacknoteskit::listNotes]
# -> {id ... title ... modified ... inStack 1} ...
```

#### `mdstack::stacknoteskit::isCurrentModified`

Prüft ob aktuelle Notiz geändert wurde.

```tcl
if {[mdstack::stacknoteskit::isCurrentModified]} {
    # Warnung anzeigen
}
```

#### `mdstack::stacknoteskit::currentNoteId`

ID der aktuellen Notiz.

#### `mdstack::stacknoteskit::currentNoteTitle`

Titel der aktuellen Notiz.

---

## Typisches Pattern

```tcl
# Notiz auswählen
proc onSelectNote {id} {
    # Änderungen prüfen
    if {[mdstack::stacknoteskit::isCurrentModified]} {
        set answer [tk_messageBox -type yesnocancel ...]
        if {$answer eq "yes"} {
            mdstack::stacknoteskit::saveCurrent
        } elseif {$answer eq "cancel"} {
            return
        }
    }
    
    # Notiz laden
    mdstack::stacknoteskit::loadNote $id
}

# Speichern
proc onSave {} {
    mdstack::stacknoteskit::saveCurrent
}

# Neue Notiz
proc onNew {} {
    mdstack::stacknoteskit::newNote "Unbenannt"
}
```

---

## Integration mit mdstack Callbacks

```tcl
# mdstack onsave → noteskit speichern
mdstack::onsave {
    mdstack::stacknoteskit::saveCurrent
}

# Oder automatisch:
mdstack::stacknoteskit::setupCallbacks
```

---

## Demo

```bash
wish demo/demo-mdstacknoteskit.tcl
```

---

## Abhängigkeiten

- noteskit 0.1
- mdstack 0.1
