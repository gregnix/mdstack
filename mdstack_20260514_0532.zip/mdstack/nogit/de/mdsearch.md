# mdstack::search

> **API reference:** [English version](../../doc/manuals/en/mdsearch.md)
> This German documentation covers concepts and usage scenarios.
> For exact signatures and options refer to the English version.


## Zweck

`mdstack::search` bietet **Volltext-Suche** im mdviewer-Widget mit Treffer-Hervorhebung
und Vorwärts-/Rückwärts-Navigation.

Das Modul:
- sucht direkt im Tk-Text-Widget des Viewers
- hebt Treffer farbig hervor
- merkt sich den aktuellen Treffer pro Widget
- ist **zustandslos** gegenüber dem Dokument (kein Re-Parse nötig)

---

## Abhängigkeiten

- Tcl/Tk ≥ 8.6
- `mdstack::viewer 0.3`

---

## Öffentliche API

### `mdstack::search::find viewerPath pattern`

Sucht `pattern` im Viewer und hebt alle Treffer hervor.
Setzt den aktuellen Treffer auf den ersten.

```tcl
set n [mdstack::search::find .v "Tcl"]
puts "$n Treffer gefunden"
```

**Rückgabewert:** Anzahl der Treffer (Integer)

Die Suche ist **case-insensitive**.

---

### `mdstack::search::next viewerPath`

Springt zum nächsten Treffer (wrap-around am Ende).

```tcl
mdstack::search::next .v
```

---

### `mdstack::search::prev viewerPath`

Springt zum vorherigen Treffer (wrap-around am Anfang).

```tcl
mdstack::search::prev .v
```

---

### `mdstack::search::clearHighlight viewerPath`

Entfernt alle Hervorhebungen.

```tcl
mdstack::search::clearHighlight .v
```

---

### `mdstack::search::count viewerPath`

Gibt die Anzahl der aktuellen Treffer zurück.

```tcl
set total [mdstack::search::count .v]
```

---

### `mdstack::search::current viewerPath`

Gibt den Index des aktuellen Treffers zurück (1-basiert, 0 = kein Treffer).

```tcl
set idx [mdstack::search::current .v]
puts "$idx von [mdstack::search::count .v]"
```

---

## Tags

| Tag | Farbe | Bedeutung |
|-----|-------|-----------|
| `searchmatch` | Gelb (`#FFEB3B`) | Alle Treffer |
| `searchcurrent` | Orange (`#FF9800`) | Aktueller Treffer |

---

## Vollständiges Beispiel

```tcl
package require mdstack::viewer 0.3
package require mdstack::search 0.1

set v [mdstack::viewer::create .v]
pack $v -fill both -expand 1

# Suchleiste
ttk::entry .search -textvariable searchVar
ttk::button .go -text "Suchen" -command {
    set n [mdstack::search::find $v $searchVar]
    .status configure -text "$n Treffer"
}
ttk::button .next -text "▶" -command {mdstack::search::next $v}
ttk::button .prev -text "◀" -command {mdstack::search::prev $v}

# Status anzeigen
proc updateStatus {} {
    global v
    set cur [mdstack::search::current $v]
    set tot [mdstack::search::count $v]
    .status configure -text "$cur / $tot"
}
```

---

## Nicht-Ziele

- Kein Regex-Suche (nur Literal-Suche)
- Kein Ersetzen
- Keine Suche über mehrere Dokumente
