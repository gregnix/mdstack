# mdstack::editorkit

> **API reference:** [English version](../../doc/manuals/en/mdeditorkit.md)
> This German documentation covers concepts and usage scenarios.
> For exact signatures and options refer to the English version.


> ⚠️ **Legacy-Modul** - Für neue Projekte wird `mdstack` + `mdstack::text` + `mdstack::viewer` empfohlen.

## Zweck

`mdstack::editorkit` ist ein **Editor-Subsystem** für Markdown mit Live-Preview.

Es kombiniert:
- `mdeditor` (Editieren)
- `mdstack::parser` (Markdown → AST)
- `mdstack::model` (Dokumentmodell)
- `mdstack::viewer` (Rendering)

und stellt daraus **eine konsistente Edit-/Preview-Pipeline** bereit.

`mdstack::editorkit` ist **kein vollständiger Editor** und **keine Anwendung**.

---

## Typische Einsatzszenarien

- Edit + Preview in einer Anwendung
- Markdown-Editor als Teil einer Fach-GUI
- Vorbereitung für Migration von Alt-Viewern (z. B. mdhelp)
- Testumgebung für Parser / Renderer

---

## Abhängigkeiten

- Tcl/Tk ≥ 8.6
- mdstack::parser 0.2
- mdstack::model 0.1
- mdstack::viewer 0.3
- mdeditor 0.1

---

## Öffentliche API

### `mdstack::editorkit::create path ?options?`

Erzeugt ein Editor-Subsystem (Split-View).

```tcl
set kit [mdstack::editorkit::create .kit]
pack $kit -fill both -expand 1
```

#### Optionen

* `-debounce ms`
  Verzögerung zwischen Editieren und Re-Parse (Standard: 300)
* `-mode edit|preview|split`
* `-onerror cmdPrefix`
* `-onchange cmdPrefix`
* `-onlink cmdPrefix` (wird an mdstack::viewer weitergereicht)

---

### `mdstack::editorkit::settext path markdown`

Setzt den Markdown-Text und triggert sofortiges Parsing.

```tcl
mdstack::editorkit::settext $kit "# Title\n\nText"
```

---

### `mdstack::editorkit::gettext path`

Gibt den aktuellen Markdown-Text zurück.

---

### `mdstack::editorkit::setmode path edit|preview|split`

Schaltet die Darstellung um.

```tcl
mdstack::editorkit::setmode $kit split
```

---

### `mdstack::editorkit::mode path`

Gibt den aktuellen Modus zurück.

---

### `mdstack::editorkit::model path`

Gibt das **Edit-Model v1** zurück (via mdeditor).

Typischer Inhalt:

* text
* dirty
* cursor
* selection

---

### `mdstack::editorkit::setmodel path editModelDict`

Setzt den Editorzustand (z. B. für Undo/Restore).

---

### `mdstack::editorkit::getdocmodel path`

Gibt das **mdmodel-Dokumentmodell** zurück.

Damit möglich:

```tcl
set doc [mdstack::editorkit::getdocmodel $kit]
set toc [mdstack::model::toc $doc]
set hits [mdstack::model::find $doc "Text"]
```

---

## Fehlerbehandlung

* Parser-Fehler werden **abgefangen**
* Preview bleibt auf dem **letzten gültigen Stand**
* Fehler werden über `-onerror` gemeldet
* Editor bleibt immer bedienbar

---

## Typische Fehler

* `package require` ohne Master-pkgIndex
  → `auto_path` falsch gesetzt
* Zu kleines `-debounce` bei großen Dateien
* Logik im App-Code, die direkt mdstack::parser aufruft
  → gehört nicht in Anwendungen

---

## Nicht-Ziele

* Kein Dateimanagement
* Kein Projekt-/Workspace-Handling
* Keine Such-UI
* Kein Publishing

Diese Dinge gehören **in Anwendungen**, nicht in mdeditorkit.
