# docir-md (Markdown → DocIR)

**Verschoben.** Das Modul `docir::mdSource` lebt seit Mai 2026 nicht mehr in
mdstack. Es wurde umbenannt zu `docir::mdSource` (Naming-Konvention:
Quellen heißen `docir::FORMATSource`) und ins zentrale
[docir-Repository](../../../docir/) verschoben.

## Wo finde ich das Modul jetzt?

- Modul: `docir/mdSource-0.1.tm` im docir-Repo unter `lib/tm/`
- Doku: `docir/doc/{de,en}/docir-spec.md` für die Format-Spec
- Cookbook: `docir/doc/{de,en}/cookbook.md` für Beispiele

## Wie nutze ich es aus mdstack?

mdstack lädt das Modul jetzt via `lib/docir-loader.tcl`:

```tcl
source -encoding utf-8 [file join $projectRoot lib docir-loader.tcl]
package require docir::mdSource

# Funktion ist im selben Namespace wie früher:
set ir [::docir::md::fromAst $ast]
```

## Warum die Verschiebung?

- DocIR wurde groß und eigenständig genug für ein eigenes Repo
- Naming-Konflikt: man-viewer hatte ein `docir::mdSource` als SENKE
  (DocIR → Markdown), mdstack hatte ein `docir::mdSource` als QUELLE.
  Klare Konvention im docir-Repo: `docir-FORMAT` (Senke) vs
  `docir::FORMATSource` (Quelle).
- Code-Duplikation eliminiert (war 1:1-Kopie zwischen den Repos)

Siehe [`docir/CHANGES.md`](../../../docir/CHANGES.md) für die Migration.
