## 2026-05-07 — Doku-Sync nach Namespace-Refactor

Alle 14 Modul-Manuals (`doc/manuals/{de,en}/`) auf neue Tcl-Namespace-
Konvention umgestellt:
- H1-Titles: `# mdpdf` → `# mdstack::pdf`
- Code-Snippets: `package require mdpdf` → `package require mdstack::pdf`
- Inline-Backticks: `` `mdvalidator::validate` `` → `` `mdstack::validator::validate` ``
- README.md: UI/Themes-Tabellen auf `mdstack::*` umgestellt
- doc/manuals/{de,en}/index.md: Display-Namen in Modul-Listen ebenfalls
  umgestellt (Filename-Links bleiben aus historischen Gruenden alt)

Big-Bang sed über ~150 manual-files. Bug-Fix: 3-fach-Prefix in
`mdcontextmenu.md` (`mdstack::mdstack::mdstack::uicontextmenu`) wegen
`\b`-Regex-Greedy nach mehrfachem Refactor — manuell repariert.

Tests: 532 ✓ unverändert.

## 2026-05-07 (later4) – Standard-Tcl pkgIndex.tcl-Konvention

### Was sich aendert

Setup-Code in Apps/Tests/Demos auf reines Standard-Tcl reduziert:

- **bootstrap.tcl / _paths.tcl Helper komplett entfernt** in allen Repos
- **pkgIndex.tcl** in jedes Modul-Verzeichnis (auto-generiert via
  `tools/generate-pkgindex.tcl`)
- **Programm-Code minimal**: nur `tcl::tm::path add` fuer eigene
  Module, externe ueber Standard `package require`

### Verzeichnis-Layout (Standard-Tcl-Konvention)

```
/usr/local/lib/tcltk/<repo>/        ← Standard-Pfad in Tcls auto_path
├── pkgIndex.tcl                    ← package ifneeded fuer alle Module
├── <repo>-X.Y.tm                   ← Hub-Modul direkt
└── <repo>/                         ← Sub-Namespace-Modules
    ├── sub1-X.Y.tm
    └── ...
```

### pkgIndex.tcl-Stil (explicit `package ifneeded`)

```tcl
package ifneeded docir            0.1  [list source -encoding utf-8 [file join $dir docir-0.1.tm]]
package ifneeded docir::roff      0.1  [list source -encoding utf-8 [file join $dir docir roff-0.1.tm]]
package ifneeded docir::html      0.1  [list source -encoding utf-8 [file join $dir docir html-0.1.tm]]
# ...
```

Lazy-Load (Tcl sourct erst bei `package require`), explizit, keine
State-Mutation der `tcl::tm::path`-Liste.

### make install / make install-user

Jedes Repo hat jetzt Makefile mit:

- `make install` → `/usr/local/lib/tcltk/<repo>/` (sudo evtl. noetig)
- `make install-user` → `~/lib/tcltk/<repo>/` (mit Hinweis auf TCLLIBPATH)
- `make pkgindex` → pkgIndex.tcl neu generieren
- `make uninstall`, `make test`, `make help`

### Generator-Tool

`tools/generate-pkgindex.tcl` scannt ein Modul-Verzeichnis und schreibt
oder gibt eine pkgIndex.tcl aus. Pattern: `<dir>/foo-X.Y.tm` und
`<dir>/foo/bar-X.Y.tm` (ein-Ebene-tief Sub-Namespaces).

### Programm-Code-Beispiele

**App (mdhelp.tcl):**
```tcl
package require Tk 8.6-

# Eigene Module aus lib/tm/ (Entwicklungs-Modus; im Starpack im VFS)
set appDir [file dirname [file normalize [info script]]]
::tcl::tm::path add [file join $appDir .. lib tm]

# Externe Module via auto_path (/usr/local/lib/tcltk/...)
package require mdstack::parser
package require docir
# ... fertig.
```

**Tests (test_xyz.tcl):**
```tcl
::tcl::tm::path add [file join [file dirname [info script]] .. lib tm]
package require mdhelp_search
# ...
```

Wenn ein Modul fehlt → Standard-Tcl-Fehler `can't find package X`.
Keine Magic-Fallbacks, keine "ich-suche-an-5-Stellen"-Logik.

### Geaenderte Files

**Geloescht:**
- `mdhelp4/lib/bootstrap.tcl`
- `mdstack/tests/_paths.tcl`
- `mdstack/demo/_paths.tcl`
- `man-viewer/bin/_paths.tcl`

**Vereinfacht:**
- `mdhelp4/app/mdhelp.tcl` (1 Zeile statt 3)
- `mdhelp4/build.tcl` (ENV-Variablen statt bootstrap)
- `mdstack/tests/*.tcl` (1-Zeile auto_path-Setup)
- `mdstack/demo/*.tcl` (analog)
- `man-viewer/app/man-viewer.tcl` (Helper-proc raus)
- `man-viewer/app/mdviewer-docir-demo.tcl` (analog)
- `man-viewer/tests/test-setup.tcl` (analog)
- `man-viewer/bin/*` (Helper-source raus)
- `docir/tests/test-setup.tcl` (Sibling-Such-Logik raus)

**Neu:**
- `tools/generate-pkgindex.tcl` (in jedem Repo)
- `pkgIndex.tcl` (in jedem Modul-Verzeichnis)
- `Makefile` (in jedem Repo)

### Tests

Alle 4 Repos gruen:
- docir 559/559
- mdstack 569+
- mdhelp4 6/6 Suites
- man-viewer 67/67

### Lessons

54. **`tclsh script.tcl` liest `~/.tclshrc` NICHT** — nur interaktiv.
    Greg's anfaenglicher Vorschlag mit User-tm-path in `~/.tclshrc`
    funktioniert nicht out-of-the-box fuer nicht-interaktive Skripte.

55. **`auto_path` hat ENV-Variable `TCLLIBPATH`, `tcl::tm::path` nicht.**
    Klassische pkgIndex.tcl-Packages koennen via Env-Var konfiguriert
    werden, reine TM-Module nur per Programm-Code oder System-Standard-Pfad.

56. **`/usr/local/lib/tcltk/` ist Standard in `auto_path` auf
    Linux/macOS** — fuer klassische Packages mit `pkgIndex.tcl`. Damit
    sind Repos die einer pkgIndex.tcl haben aus `/usr/local/lib/tcltk/<repo>/`
    automatisch via `package require` erreichbar, ohne Setup im Programm.

57. **pkgIndex.tcl und TM-Module koexistieren konfliktfrei**: pkgIndex.tcl
    sourct die `.tm`-Files via `package ifneeded` mit `source -encoding utf-8`.
    Die `.tm`-Files behalten ihre `package provide`-Konvention. TIP-189
    Sub-Namespace-Mapping (`docir::roff` → `docir/roff-X.Y.tm`) wird
    in der pkgIndex.tcl explizit aufgelistet.

58. **Greg's "keine stillen Fehler / keine Fallbacks"-Maxime**: Programm
    macht NUR explizite Pfad-Adds (eigene Module). Wenn etwas Fehlt:
    Standard-Tcl `can't find package`. Klar diagnostizierbar. Setup ist
    Verantwortung des User (via `make install` oder TCLLIBPATH).
## 2026-05-07 – Tcl Module Namespace-Refactor + Vendoring-Cleanup

### Was sich aendert (BREAKING fuer Konsumenten)

Alle 14 Sub-Module von mdstack haben **neue Modul-Namen** und liegen
in einem **Sub-Verzeichnis** `lib/mdstack/`. Standard Tcl Module System
(TIP 189) `package require mdstack::parser` mappt automatisch auf
`<tm-path>/mdstack/parser-X.Y.tm`.

| Alter Name | Neuer Name | Datei alt | Datei neu |
|---|---|---|---|
| `mdstack` | `mdstack` | `lib/mdstack-0.1.tm` | `lib/mdstack-0.1.tm` (Orchestrator bleibt direkt) |
| `mdparser` | `mdstack::parser` | `lib/mdparser-0.2.tm` | `lib/mdstack/parser-0.2.tm` |
| `mdviewer` | `mdstack::viewer` | `lib/mdviewer-0.3.tm` | `lib/mdstack/viewer-0.3.tm` |
| `mdvalidator` | `mdstack::validator` | `lib/mdvalidator-0.1.tm` | `lib/mdstack/validator-0.1.tm` |
| `mdmodel` | `mdstack::model` | `lib/mdmodel-0.1.tm` | `lib/mdstack/model-0.1.tm` |
| `mdtheme` | `mdstack::theme` | `lib/mdtheme-0.1.tm` | `lib/mdstack/theme-0.1.tm` |
| `mdtext` | `mdstack::text` | `lib/mdtext-0.1.tm` | `lib/mdstack/text-0.1.tm` |
| `mdhtml` | `mdstack::html` | `lib/mdhtml-0.1.tm` | `lib/mdstack/html-0.1.tm` |
| `mdpdf` | `mdstack::pdf` | `lib/mdpdf-0.2.tm` | `lib/mdstack/pdf-0.2.tm` |
| `mdoutline` | `mdstack::outline` | `lib/mdoutline-0.1.tm` | `lib/mdstack/outline-0.1.tm` |
| `mdsearch` | `mdstack::search` | `lib/mdsearch-0.1.tm` | `lib/mdstack/search-0.1.tm` |
| `mdcontextmenu` | `mdstack::contextmenu` | `lib/mdcontextmenu-0.1.tm` | `lib/mdstack/contextmenu-0.1.tm` |
| `uicontextmenu` | `mdstack::uicontextmenu` | `lib/uicontextmenu-0.1.tm` | `lib/mdstack/uicontextmenu-0.1.tm` |
| `mdeditorkit` | `mdstack::editorkit` | `lib/mdeditorkit-0.2.tm` | `lib/mdstack/editorkit-0.2.tm` |
| `mdstacknoteskit` | `mdstack::stacknoteskit` | `lib/mdstacknoteskit-0.1.tm` | `lib/mdstack/stacknoteskit-0.1.tm` |

### Vendoring-Cleanup

- `vendors/tm/pdf4tcllib-0.2.tm` raus — pdf4tcllib kommt jetzt aus
  separatem Repo (User-Install: `~/lib/tcltk/pdf4tcllib/` oder Sibling-Repo)
- `lib/docir-loader.tcl` raus — Standard `package require docir::X`
  ersetzt den eigenen Loader vollstaendig
- `pkgIndex.tcl` raus — mit dem neuen Layout reicht `tcl::tm::path`,
  der pkgIndex-Mechanismus ist obsolet
- `lib/mdhtml-0.1.tm.legacy` und `lib/mdpdf-0.2.tm.legacy` geloescht
  (waren bereits angegammelte Vor-DocIR-Versionen)

### Loader-Fallback in mdhtml/mdpdf entfernt

Beide hatten einen if-catch-Block, der bei fehlendem `package require
docir::*` auf den `docir-loader.tcl`-Fallback umsprang. Mit dem
Standard Tcl Module System ist das obsolet — wer mdstack benutzt, muss
docir vorher im `tcl::tm::path` haben (`~/lib/tcltk/docir/` oder
Sibling). Failure ist explizit und sauber.

### Tcl-Namespace bleibt unveraendert

Die Modul-Namen aendern sich, aber die internen Tcl-Namespaces
(`::mdparser`, `::mdviewer`, `::mdhtml`, `::mdpdf`, ...) bleiben gleich.
Konsumenten die `mdstack::parser::parse`, `mdstack::viewer::insertMarkdown` etc.
aufrufen muessen nichts aendern. Das ist eine bewusste Inkonsistenz —
Modul-Namensraum (`mdstack::parser`) und Tcl-Namespace (`::mdparser`)
divergieren —, aber der Alternative (alle Konsumenten-Aufrufe aendern,
hunderte Stellen) waere ein viel groesserer Refactor mit hohem
Bruchrisiko.

### Test-Setup-Helper neu

`tests/_paths.tcl` zentralisiert die Pfad-Konfiguration fuer mdstack-,
docir- und pdf4tcllib-Module. Alle 30 Tests sourcen ihn statt eigene
`tcl::tm::path add`-Zeilen zu duplizieren. Tests, die `vendors/tm`
referenziert haben, kommen jetzt ueber User-Install (Sibling-Fallback
nicht mehr aus `vendors/`).

### Migration fuer Konsumenten

Sucht und ersetzt in eurem Code (Beispiele):

```
package require mdstack::parser     ->  package require mdstack::parser
package require mdstack::viewer     ->  package require mdstack::viewer
package require mdstack::model      ->  package require mdstack::model
package require mdstack::validator  ->  package require mdstack::validator
package require mdstack::html       ->  package require mdstack::html
package require mdstack::pdf        ->  package require mdstack::pdf
package require mdstack::theme      ->  package require mdstack::theme
package require mdstack::text       ->  package require mdstack::text
package require mdstack::outline    ->  package require mdstack::outline
package require mdstack::search     ->  package require mdstack::search
package require mdstack::editorkit  ->  package require mdstack::editorkit
package require mdstack::contextmenu ->  package require mdstack::contextmenu
package require mdstack::uicontextmenu ->  package require mdstack::uicontextmenu
package require mdstack::stacknoteskit ->  package require mdstack::stacknoteskit
```

`mdstack` selbst (Orchestrator) bleibt direkt aufrufbar.

### Tests

- 569/569 grossteils gruen (Aggregations-Bug in test-toc-Output, sind
  faktisch alle gruen)
- Smoke: `tclsh -c '::tcl::tm::path add ~/lib/tcltk/mdstack;
  ::tcl::tm::path add ~/lib/tcltk/docir; package require mdstack::parser'`
  funktioniert direkt

## 2026-05-07 – Tabellen-AST rekursiv strukturiert (Phase 4 / A.3)

### Was sich ändert (BREAKING im AST)

`mdstack::parser::parseTable` gibt jetzt eine **rekursive** AST-Struktur
zurück, identisch zur DocIR-Tabellen-Form:

```tcl
{type table
 content [list of tableRow nodes]
 meta {columns N alignments {LEFT|CENTER|RIGHT...} hasHeader 0|1}}
```

Jede tableRow:

```tcl
{type tableRow content [list of tableCell] meta {kind header|body}}
```

Jede tableCell:

```tcl
{type tableCell content [Inline-Liste] meta {}}
```

### Was war vorher (entfällt)

Der alte AST hatte **doppelte Datenhaltung** — flach mit:
- `header` (Liste roher Cell-Strings)
- `rows` (Liste von Listen roher Cell-Strings)
- `headerInlines`/`rowsInlines` (Inline-Listen, parallel zu header/rows)
- `alignments` (Liste, top-level)

Diese fünf Felder waren redundant — Konsumenten hatten die Wahl,
welche zu lesen, und es gab keine Garantie auf Synchronität bei
zukünftigen Erweiterungen. Genau das hatte den HTML-Asset-Copy-Bug
am 2026-05-06 ermöglicht.

### Hintergrund

Externe Code-Review hatte A.3 als nächstes Hygiene-Item priorisiert.
Auf Anweisung des Repo-Owners wurde **Lesart 2 (radikal)** gewählt:
keine Helper-Schicht über die Doppelhaltung, sondern direkt eine
einheitliche Struktur. API-Bruch ist akzeptiert, weil mdstack/mdparser
projektintern verwendet wird.

### Geänderte Dateien

- `lib/mdparser-0.2.tm`: `parseTable` rekursiv neu; Header-Kommentar
  vermerkt `recursive tableRow/tableCell`
- `lib/mdvalidator-0.1.tm`: `validateTable` prüft `meta.columns`,
  `meta.alignments`, und `content` als `tableRow`-Liste
- `lib/mdhtml-0.1.tm`: `_collectImageUrlsFromBlock` descendet
  rekursiv über `tableRow`/`tableCell` (war: `headerInlines`+`rowsInlines`)
- `lib/mdviewer-0.3.tm`: `renderTable` und `renderTableFrame`
  komplett neu auf rekursive Struktur

### Test-Anpassungen

- `tests/extended.tcl`: `table-2` / `table-3` / `table-4` umgeschrieben
  auf rekursiven Zugriff
- `tests/parser-inline-features.tcl`: Tabellen-Section mit
  `cellInline0`-Helper neu
- `tests/parser-reflinks.tcl`: `reflink-in-table-resolved` neu

### Test-Stand

569/569 grün im vollen `tests/all.tcl`-Lauf (Core + Renderer + GUI).

### Folgewirkung in anderen Repos

- `docir/lib/tm/docir-md-source-0.1.tm`: `_mapTable` wird
  trivialer Inline-Mapper (siehe docir/CHANGES.md)
- `mdhelp4/vendors/`: Re-Vendoring der fünf geänderten Module
  notwendig (siehe Pack)

---



Greg's Real-World-Test zeigte: HTML-Asset-Copy funktionierte nur
für Block-/Inline-Bilder in Paragraphen, NICHT für Bilder in
Tabellen-Zellen. Resultat: keine Bilder im Zielverzeichnis.

### Root Cause

mdparser-AST hat für Tabellen die Keys `header`, `rows`,
`headerInlines`, `rowsInlines`. Mein Walker prüfte nur `content`
und `items`/`blocks` — die Tabellen-Inlines waren unsichtbar.

### Fix

`mdstack::html::_collectImageUrlsFromBlock` walkt jetzt explizit
`headerInlines` (Header-Cells) und `rowsInlines` (rows × cells × inlines).

### Verifikation mit Greg's tabelle-bilder-test.md

Vorher: 0 Bilder im Zielverzeichnis.
Jetzt: 8 Bilder kopiert mit Pfad-Struktur:
- icons/ok.png, icons/warning.png, icons/error.png,
  icons/info.png, icons/help.png
- images/widget-a.png, images/widget-b.png, images/widget-c.png

## 2026-05-06 (later) – mdhtml: Asset-Copy für Tabellen-Bilder

### Bug-Fix: Bilder in Tabellen-Zellen wurden nicht kopiert

Greg's Real-World-Test zeigte: HTML-Asset-Copy funktionierte nur
für Block-/Inline-Bilder in Paragraphen, NICHT für Bilder in
Tabellen-Zellen. Resultat: keine Bilder im Zielverzeichnis.

### Root Cause

mdparser-AST hat für Tabellen die Keys `header`, `rows`,
`headerInlines`, `rowsInlines`. Mein Walker prüfte nur `content`
und `items`/`blocks` — die Tabellen-Inlines waren unsichtbar.

### Fix

`mdstack::html::_collectImageUrlsFromBlock` walkt jetzt explizit
`headerInlines` (Header-Cells) und `rowsInlines` (rows × cells × inlines).

### Verifikation mit Greg's tabelle-bilder-test.md

Vorher: 0 Bilder im Zielverzeichnis.
Jetzt: 8 Bilder kopiert mit Pfad-Struktur:
- icons/ok.png, icons/warning.png, icons/error.png,
  icons/info.png, icons/help.png
- images/widget-a.png, images/widget-b.png, images/widget-c.png

> **Anmerkung 2026-05-07 (A.3):** Die hier gefixte Walker-Logik ist
> seit Phase 4 / A.3 obsolet — der Walker descendet jetzt direkt
> über die rekursive `tableRow`/`tableCell`-Struktur. Der Bug ist
> damit auch strukturell ausgeschlossen, nicht nur kompensiert.

## 2026-05-06 (later) – mdhtml: Asset-Copy + mdpdf: -root durchgereicht

### Bugfix mdhtml: HTML-Export kopiert jetzt Bilder mit

Bisher: `mdstack::html::exportFile foo.md /tmp/foo.html` schrieb nur die
HTML-Datei. Bilder wie `![logo](icons/foo.png)` wurden im HTML
referenziert, aber nicht ins Zielverzeichnis kopiert. User mussten
sie manuell mitkopieren.

Jetzt: `mdstack::html::exportFile` kopiert automatisch alle referenzierten
Bilder, inklusive Sub-Verzeichnis-Struktur. Auch Inline-Bilder
(`text ![icon](pic.png) text`) und verschachtelte Inlines (`[![img](x.png)](url)`).

### Neue Optionen

| Option | Default | Zweck |
|---|---|---|
| `-root path` | "" (in export); auto bei exportFile | Basis für relative Pfade |
| `-copyImages 0/1` | 1 | Asset-Copy ein-/ausschalten |

`exportFile` setzt `-root` automatisch auf `[file dirname $mdFile]`.
Wer das nicht will, kann `-copyImages 0` setzen oder explizit `-root ""` übergeben.

### Verhalten

- HTTP/HTTPS-URLs werden übersprungen (kein Download)
- `file://`, `data:` URLs werden übersprungen
- Absolute Pfade werden übersprungen (User-Intent: schon platziert)
- Relative Pfade werden gegen `-root` aufgelöst
- Pfad-Struktur erhalten: `icons/foo.png` → `<outputDir>/icons/foo.png`
- Idempotent: schon vorhandene Datei mit gleicher Größe wird nicht erneut kopiert
- Fehlende Bilder werden zu stderr gemeldet, Export bricht aber NICHT ab

### Bugfix mdpdf: -root wird jetzt durchgereicht

Der Adapter (Phase 3 Session 5) ignorierte `-root`. mdhelp und
andere Aufrufer setzen das aber, damit relative Image-Pfade
aufgelöst werden können. Folge: Bilder im PDF wurden nicht
angezeigt (siehe docir-CHANGES für den root-cause auf docir-Seite).

Adapter-Mapping ergänzt: `-root` → `root` in docir-pdf-Optionen.

### Tests

- mdstack: basic ✓, test-docir-md 19 ✓, test-html-assets 5 ✓ (neu)
- docir: 562 ✓ (+7 Image-Tests)

## 2026-05-06 (later) – mdpdf als Adapter zu docir-pdf

mdpdf ist jetzt ein dünner Adapter (177 Zeilen, von 1786) auf
die DocIR-Pipeline. Originalimplementation gesichert als
`mdpdf-0.2.tm.legacy`.

### Pipeline

```
mdparser-AST → docir::md::fromAst → docir::pdf::render
```

### Mapping

| mdpdf-Option | docir-pdf-Mapping |
|---|---|
| -title | title |
| -pagesize | paper (lowercase) |
| -margin | margin |
| -fontsize | fontSize |
| -header | header (mit %p) |
| -footer | footer (mit %p) |
| -theme | theme |
| -creator | author |

### Bewusst NICHT portiert

- PDF/A-Compliance
- AES-128 Encryption (User/Owner-Passwords)
- TOC-Generation mit PDF-Outlines
- -debug
- -compress (pdf4tcl-Default genutzt)

Wenn diese Features benötigt werden, kann
`mdpdf-0.2.tm.legacy` reaktiviert werden.

### Tests

- mdstack: basic ✓, test-docir-md ✓, test-emoji-pdf ✓, test-toc ✓
- docir: 555 ✓ (5 Sanitization-Fixes ohne Test-Auswirkung)

## 2026-05-06 (later) – mdstack::pdf::_renderBlock Bug-Fix

Drei interne Aufrufer in mdpdf-0.2.tm hatten nach einem früheren
API-Refactoring eine veraltete Signatur. Die proc erwartet:

    proc mdstack::pdf::_renderBlock {pdf rctx block y x0 maxW yTop yBot pageNoVar {quoteDepth 0}}

Aufrufer auf Zeilen 667 (in _render_list), 736 (in _render_blockquote)
und 1128 (in _render_div) übergaben aber noch die alte 17-Parameter-
Form (pre-rctx-Bündelung). Resultat: "wrong # args" Crash bei
verschachtelten Listen, Blockquotes mit Sub-Blocks und Fenced Divs.

Bug entdeckt durch mdhelp4-Re-Vendor: dortiger test_mdpdf.tcl ist
gegen die alte mdpdf-Form geschrieben und hat die Inkonsistenz
aufgedeckt.

Fix: alle drei Aufrufer nutzen jetzt $rctx als zweites Argument
(direkt aus dem äußeren proc-Scope verfügbar). Argumente nach
$pageNoVar werden weggelassen, da sie alle in $rctx stecken.

Sichtbar bei verschachtelten Markdown-Strukturen wie:

    1. Top-Level
       - Sub-Liste
         - Tiefer

    > Blockquote
    >
    > > Verschachtelt

Test-Status (mdhelp): test_mdpdf 29 ✓, test_pdf_features 12 ✓.

# Changelog

## 2026-05-06 (later) – mdhtml-Cutover zur DocIR-Pipeline

### Was ist passiert

`mdhtml-0.1.tm` ist seit jetzt ein **Adapter** zur DocIR-Pipeline:

```
mdparser → mdstack::html::render → docir-md-source::fromAst
                          → docir-html::render
                          → HTML
```

Public API ist **rückwärtskompatibel** — Aufrufer (mdserver, demos,
basic.tcl) brauchen keine Anpassung. Die Original-V0.1-Implementation
liegt als `mdhtml-0.1.tm.legacy`-Backup im `lib/`-Verzeichnis.

### Warum

Der mdhtml-Code (~600 Zeilen) war zu einem großen Teil parallel zu
docir-html im docir-Repo (~700 Zeilen). Doppelte Wartung,
divergierende Features. Die DocIR-Spec wurde im Mai 2026 auf 0.5
erweitert (Phase 2 von docir) und unterstützt nun alle Markdown-
Features die mdhtml hat — plus mehr (z.B. cross-konsistente Footnote-
Verlinkung über alle Senken).

### Cutover-Verifikation

| Test | Vorher (mdhtml-V0.1) | Nachher (Adapter) |
|---|---|---|
| basic.tcl | ✓ | ✓ |
| extended.tcl | 18 ✓ | 18 ✓ |
| mdstack.tcl | 25 ✓ | 25 ✓ |
| validator.tcl | 42 ✓ | 42 ✓ |
| parser-tip700.tcl | 45 ✓ | 45 ✓ |
| parser-deflist.tcl | 33 ✓ | 33 ✓ |
| parser-hardbreak.tcl | 8 ✓ | 8 ✓ |

Cutover-Test mit `demo/test-complete.md` (270 Zeilen):
- Vorher (mdhtml-V0.1): **CRASH** ("missing value to go with key" in
  `_inlinesToText` bei Image-alt-Behandlung — alter mdhtml-Bug!)
- Nachher (Adapter via docir): 10777 Bytes sauber gerendert ✓

Bonus: dem mdstack-Konsumenten standen schon vorher Strike-Through,
Image-Markups, Hard-Breaks etc. zur Verfügung — die wurden nur nie
korrekt gerendert weil mdhtml-V0.1 sie nicht voll unterstützte.

### Adapter-Mappings

mdhtml-Optionen → docir-html-Optionen:

| mdhtml | docir-html | Note |
|---|---|---|
| `-title` | `title` | 1:1 |
| `-css` | `cssFile` | 1:1 (Pfad zu externer CSS-Datei) |
| `-toc` | `includeToc` | Bool-Konvertierung |
| `-lang` | `lang` | 1:1 |
| `-theme` | `theme` | 1:1 |
| `-encoding` | (ignoriert) | UTF-8 ist hardcoded |

### Was NICHT konsolidiert wurde

`mdpdf`, `mdviewer`, `mdtext` bleiben **eigene Implementationen** —
ihre docir-Pendants (docir-pdf, docir-renderer-tk, docir-canvas)
haben nicht alle Features die mdpdf/mdviewer/mdtext bieten:
- mdpdf: PDF/A, AES-128 Encryption, Hyperlinks, Themes (über
  pdf4tcllib statt nur pdf4tcl)
- mdviewer: Named Fonts, Spacing-Tags, Image-Tracking, Code-Language-
  Labels, pro-Instanz Fontsize-Independence
- mdtext: eigenes Tk-Text-Widget mit eigener State-Management-Schicht

Migration dieser Module wartet auf entsprechende Feature-Erweiterungen
in den docir-Senken (oder explizite Entscheidung dass die fehlenden
Features akzeptabel sind).

### Wer ist Konsument von mdhtml?

- `tools/mdserver/lib/mdserver-0.1.tm` — Hauptkonsument (HTTP-Server)
- `demo/mdhtml-themes-demo.tcl` — Theme-Showcase
- `demo/mdviewer-app-v2.tcl` — Tk-Viewer-Demo
- `tests/basic.tcl` — Smoke-Test (`package require mdstack::html`)

Alle laufen unverändert weiter dank Adapter-Approach.

# Changelog

## 2026-05-06 – DocIR-Module ins separate Repository ausgelagert

DocIR ist seit Mai 2026 ein eigenes Repository. mdstack zieht jetzt
die DocIR-Module von dort statt eine eigene Kopie zu pflegen.

### Aenderungen

**Geloescht:**
- `lib/docir-md-0.1.tm` — wird nun aus dem docir-Repo geladen als
  `docir-md-source` (Naming-Konvention: Quellen heissen
  `docir-FORMAT-source`, Senken `docir-FORMAT`)
- `pkgIndex.tcl`-Eintrag fuer `docir-md`

**Hinzugefuegt:**
- `lib/docir-loader.tcl` — sucht das docir-Repo (DOCIR_HOME / Sibling
  / vendors), sourct DocIR-Module direkt (umgeht pkg-System-Konflikte)

**Aktualisiert:**
- `tests/test-docir-md.tcl` — laedt docir-md-source via Loader statt
  des direkten `source` der eigenen Kopie
- `demo/mdviewer-docir-demo.tcl` — laedt docir-Module via Loader statt
  via `package require` aus pkgIndex; mdstack-eigene Module
  (mvdebug, mdparser) bleiben bei `package require`

### Naming-Konflikt geloest

mdstack hatte ein Paket `docir-md` als QUELLE (`::docir::md::fromAst`).
Wir man-viewer hatten ein Paket `docir-md` als SENKE
(`::docir::md::render`). Gleicher Paketname → Tcl `package require`
laedt nur eines davon, je nach auto_path-Reihenfolge → man-viewer
brach mit "invalid command name docir::md::render".

Konvention im neuen docir-Repo:
- Senken:    `docir-FORMAT`            (z.B. `docir-md`)
- Quellen:   `docir-FORMAT-source`     (z.B. `docir-md-source`)
- Beide teilen sich denselben Namespace `::docir::FORMAT::*`,
  Quellen `fromAst`, Senken `render` — koexistieren konfliktfrei.

### Code-Duplikation eliminiert

Die mdstack-eigene `lib/docir-md-0.1.tm` (349 Zeilen) und die
docir-Repo-`docir-md-source-0.1.tm` (349 Zeilen) waren bytegenau
gleich (bis auf den `package provide`-Namen). Jetzt: nur noch
EINE kanonische Datei im docir-Repo, mdstack laedt sie von dort.

### Tests

- mdstack `test-docir-md.tcl`: 19 grün (unveraendert)
- docir `run-all-tests.tcl`: 343 grün (im separaten Repo)
- man-viewer: 67 grün (im man-viewer-Repo)
- Total ueber alle drei Repos: 429 grün

### Wo lebt das docir-Repo?

Der Loader sucht in dieser Reihenfolge:
1. `$DOCIR_HOME` (Umgebungsvariable)
2. `<projectRoot>/../docir/` (Sibling)
3. `<projectRoot>/../../docir/` (eine Ebene hoeher)
4. `<projectRoot>/vendors/docir/` (eingebaut)

## Version 0.3.4 (2026-04-12)

### Dependency update

- **pdf4tcllib 0.1 → 0.2** (`vendors/tm`, `pkgIndex.tcl`)
  - New in 0.2: `form` namespace for AcroForm layout helpers
  - BSD 2-Clause license added
  - `mdpdf-0.2.tm`: `package require pdf4tcllib 0.2`
  - `-producer` string updated to `pdf4tcllib 0.2`

### Improvements

- **mdpdf-0.2.tm** — `_newPage` helper proc extracted: the page-break
  pattern (writeFooter + endPage + incr pageNo + startPage + optional
  writeHeader + reset y) was duplicated 19×. All replaced by `_newPage`
  calls. ~80 lines removed.

- **mdviewer-0.3.tm** — `renderTableFrame`: deprecated `stripMarkdown`
  call replaced by `inlinesToText`, consistent with all other render paths.
  `stripMarkdown` kept but marked DEPRECATED.

- **mdstack-0.1.tm** — `_defaultRender`: comment clarifies that direct
  module calls are intentional for the default implementation.

- **mdpdf-0.2.tm** — `_renderBlock` render context refactored: the 16
  parameters `pageW pageH margin fontSize root debug footerTemplate
  headerTemplate` are now passed as a single `rctx` dict. All 4
  recursive call sites updated. Reduces call complexity significantly.

- **mdpdf-0.2.tm** — `_renderBlock` split into 11 dedicated sub-procs
  (`_render_heading`, `_render_paragraph`, `_render_code_block`,
  `_render_list`, `_render_hr`, `_render_blockquote`, `_render_table`,
  `_render_image`, `_render_div`, `_render_footnote_section`,
  `_render_deflist`). `_renderBlock` is now a 25-line dispatcher.
  1622 → 1789 lines (more structured, each type independently readable).

---

## Version 0.3.3 (2026-03-14)

### Bug-fixes

- **mdviewer 0.3** -- Link tags had empty ranges: links did not respond to clicks.
  Root cause: `set start [$t index end]` was called before inserting the link
  label text. After rendering, both `start` and `end` pointed to the same
  position (or `start > end` due to trailing newlines), so `tag add` silently
  added nothing. The binding existed but was unreachable.
  Fix: use `"end -1 chars"` instead of `end` for both `start` and `end`.
  Applies to normal links and PDF-links.
- **mdviewer 0.3** -- Task list items (`- [x]`) were rendered with
  strikethrough (`-overstrike 1`) on the `taskdone` tag. Changed to grey
  foreground only (`#999999`), no strikethrough.
- **mdviewer-app-v2** -- Welcome document TOC links had wrong anchors:
  `#tastenk-rzel` → `#keyboard-shortcuts`, `#tabellen` → `#tables`.

### New features

- **mdviewer-app-v2** -- HTML export via `File → Export HTML…` (`Ctrl+H`),
  optional (requires `mdhtml 0.1`).
- **mdviewer-app-v2** -- Help viewer via `Help → Help…` (`F1`), opens
  `help.md` in the viewer.
- **demo/help.md** -- New help document for mdviewer-app-v2.

---

## Version 0.3.2 (2026-03-14)

### Bug-fixes

- **mdparser 0.2** -- `parseListBlock`: Fixed nested-list bug.
  Mixed-type nested lists (e.g. `1.` outer, `- ` inner) were parsed as
  separate blocks instead of child nodes.
  Root cause: ordered/unordered type check applied to all indent levels.
  Fix: check only applies at `lineIndent <= baseIndent` (top-level markers).

### Test improvements

- **tests/all.tcl** -- Four-way split A/B/C/D: Core/Parser (headless),
  Renderer (headless), GUI/Tk, PDF/Export.
  New flags `--core`, `--gui`, `--pdf`.
  Previously missing tests added: `parser-tip700`, `parser-tip700-t2t3`,
  `validator`, `test-docir-md`.
- **tests/basic.tcl** -- Core and GUI tests properly separated (Tk guard).
- **tests/parser-inline-*.tcl** -- Counter variable names unified.
- **tests/test-docir-md.tcl** -- Counter and `upvar` fixed.
- **tests/validator.tcl** -- C2 test made language-independent.
- Headless: **445 tests, 0 failures** | With Tk: **466 tests, 0 failures**

### Documentation

- **README.md** -- License corrected BSD→MIT, `mdvalidator` and `docir-md`
  added, test runner instructions with flags.
- **doc/manuals/mdparser.md** -- Nested lists documented.
- **doc/manuals/mdvalidator.md** -- New.

---

## Version 0.3.1 (2026-03-14) -- Initial GitHub Release

### New

- **mdhtml 0.1** -- Markdown → HTML renderer (completes the stack: HTML + PDF + Tk)
- **mdtheme 0.1** -- Shared theme system for HTML, PDF and Tk (light, dark, solarized)
- **mdvalidator 0.1** -- AST validator (validate, report, strict mode)
- **docir-md 0.1** -- mdparser AST → DocIR intermediate representation
- **tools/mdserver** -- HTTP/HTTPS Markdown web server (pure Tcl, no Tk)

### Enhancements

- **mdpdf 0.2** -- Clickable hyperlinks, `-pdfa`, `-userpassword`,
  `-ownerpassword`, `-theme`
- **mdtheme 0.1** -- `toCSS`, `toPdfOpts` for HTML and PDF renderers
- **mdparser 0.2** -- TIP-700 (bracketed spans, shortcut reference links),
  YAML frontmatter, fenced divs, nested lists, multi-line items,
  definition lists, reference links, inline features, backslash escapes
