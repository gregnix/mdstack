# Handbücher (Deutsch)

> **Hinweis (Mai 2026):** Module-Namen wurden auf `mdstack::*` Schema
> umgestellt (z.B. `mdstack::parser` statt `mdparser`). Dateinamen der
> Manuals bleiben aus historischen Gründen — der Inhalt ist aktuell.

## Core / Parser

| Modul | Beschreibung |
|-------|-------------|
| [mdstack::parser](mdparser.md) | Markdown → AST Parser |
| [mdstack::validator](mdvalidator.md) | AST-Validator |
| [mdstack::model](mdmodel.md) | Semantisches Dokumentmodell |
| [docir-md](docir-md.md) | _verschoben_ ins [docir-Repo](../../../docir/) als `docir::mdSource` |

## Renderer

| Modul | Beschreibung |
|-------|-------------|
| [mdstack::html](mdhtml.md) | Markdown → HTML |
| [mdstack::pdf](mdpdf.md) | Markdown → PDF |
| [mdstack::theme](mdtheme.md) | Theme-System (HTML, PDF, Tk) |
| [pdf4tcllib](pdf4tcllib.md) | PDF-Hilfs-Bibliothek |

## GUI / Tk

| Modul | Beschreibung |
|-------|-------------|
| [mdstack::viewer](mdviewer.md) | Markdown-Viewer (Tk Text-Widget) |
| [mdstack::text](mdtext.md) | Editor-Widget |
| [mdstack::search](mdsearch.md) | Volltext-Suche im Viewer |
| [mdstack::outline](mdoutline.md) | Überschriften-Struktur-Panel |
| [mdstack::contextmenu](mdcontextmenu.md) | Kontextmenü |

## Stack / Integration

| Modul | Beschreibung |
|-------|-------------|
| [mdstack](mdstack.md) | Stack-Orchestrator |
| [mdstack::stacknoteskit](mdstacknoteskit.md) | Notes-Kit Integration |
| [mdhelp_pdf](mdhelp_pdf.md) | PDF-Hilfe-Export |

## Legacy

| Modul | Beschreibung |
|-------|-------------|
| [mdstack::editor (legacy)](mdeditor.md) | Editor-Widget (Legacy) |
| [mdstack::editorkit](mdeditorkit.md) | Editor-Kit (Legacy) |
| [mdstack::editwidget (legacy)](mdeditwidget.md) | Edit-Widget (Legacy) |

## Sonstiges

| Datei | Beschreibung |
|-------|-------------|
| [_TEMPLATE](_TEMPLATE.md) | Vorlage für neue Manuals |
