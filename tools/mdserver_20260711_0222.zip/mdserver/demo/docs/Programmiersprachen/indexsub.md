

<!-- mdindexgen:begin -->
 - [Powershell](Powershell/index.md)
 - [Tcl/Tk Wissensbasis](tcltk/index.md)
<!-- mdindexgen:end -->
