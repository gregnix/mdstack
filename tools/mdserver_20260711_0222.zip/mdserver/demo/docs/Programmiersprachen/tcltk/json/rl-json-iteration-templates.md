# rl_json - Iteration und Templates

*Stand: 2026-04-29*

## Iteration über JSON-Daten

rl_json bietet vier Iterations-Befehle, die sich in ihrem Rueckgabetyp
unterscheiden:

| Befehl | Rückgabe | Entspricht |
|--------|-----------|------------|
| `json foreach` | (keiner) | Tcl `foreach` |
| `json lmap` | Tcl-Liste | Tcl `lmap` |
| `json amap` | JSON-Array | - |
| `json omap` | JSON-Object | - |

---

## json foreach

Iteriert über Arrays und Objekte ohne Rückgabewert.

### Array durchlaufen

```tcl
set colors {["rot", "gruen", "blau"]}

json foreach color $colors {
    puts "Farbe: $color"
}
# Farbe: rot
# Farbe: gruen
# Farbe: blau
```

Die Iterationsvariable enthält den **Tcl-Wert** (nicht JSON).

### Objekt durchlaufen

Bei Objekten werden zwei Variablen benötigt: Key und Value.

```tcl
set scores {{"Alice": 100, "Bob": 85, "Carol": 92}}

json foreach {name score} $scores {
    puts "$name hat $score Punkte"
}
# Alice hat 100 Punkte
# Bob hat 85 Punkte
# Carol hat 92 Punkte
```

### Mehrere Quellen gleichzeitig

```tcl
set names  {["Alice", "Bob", "Carol"]}
set scores {[100, 85, 92]}

json foreach name $names score $scores {
    puts "$name: $score"
}
```

### Verschachtelte Objekte

Bei verschachtelten Strukturen enthält die Variable ein JSON-Fragment:

```tcl
set people {[
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25}
]}

json foreach person $people {
    puts "[json get $person name] ist [json get $person age] Jahre alt"
}
```

---

## json lmap

Wie `foreach`, aber sammelt Ergebnisse in einer **Tcl-Liste**.

```tcl
set numbers {[1, 2, 3, 4, 5]}

set doubled [json lmap x $numbers {
    expr {$x * 2}
}]
# doubled = 2 4 6 8 10 (Tcl-Liste)
```

### Filtern mit continue

`continue` überspringt ein Element, `break` beendet die Iteration:

```tcl
set numbers {[1, 2, 3, 4, 5, 6]}

# Nur gerade Zahlen
set even [json lmap x $numbers {
    if {$x % 2 != 0} continue
    set x
}]
# even = 2 4 6
```

### Transformation mit Extraktion

```tcl
set people {[
    {"name": "Alice", "score": 95},
    {"name": "Bob", "score": 78},
    {"name": "Carol", "score": 88}
]}

# Nur Namen extrahieren
set names [json lmap p $people {
    json get $p name
}]
# names = Alice Bob Carol

# Gefiltert: nur Score > 80
set topNames [json lmap p $people {
    if {[json get $p score] <= 80} continue
    json get $p name
}]
# topNames = Alice Carol
```

---

## json amap

Wie `lmap`, aber das Ergebnis ist ein **JSON-Array**. Wenn der
Rückgabewert einer Iteration ein gueltiger JSON-Wert ist, wird
er direkt übernommen. Andernfalls wird er als JSON-String eingefügt.

```tcl
set numbers {[10, 20, 30]}

set result [json amap x $numbers {
    json object \
        original [list number $x] \
        doubled  [list number [expr {$x * 2}]]
}]
# [{"original":10,"doubled":20},{"original":20,"doubled":40},{"original":30,"doubled":60}]
```

### Array transformieren

```tcl
set names {["alice", "bob", "carol"]}

# Grossbuchstaben als JSON-Array
set upper [json amap name $names {
    json string [string toupper $name]
}]
# ["ALICE","BOB","CAROL"]
```

### Filtern

```tcl
set items {[
    {"name": "A", "active": true},
    {"name": "B", "active": false},
    {"name": "C", "active": true}
]}

set activeOnly [json amap item $items {
    if {![json get $item active]} continue
    set item
}]
# [{"name":"A","active":true},{"name":"C","active":true}]
```

---

## json omap

Erstellt ein **JSON-Object** aus Iterationen. Jede Iteration muss
ein Dictionary (oder eine Liste mit gerader Elementanzahl) zurückgeben.

```tcl
set items {[
    {"id": "a", "value": 1},
    {"id": "b", "value": 2},
    {"id": "c", "value": 3}
]}

set indexed [json omap item $items {
    set key [json get $item id]
    set val [json get $item value]
    list $key [list number [expr {$val * 10}]]
}]
# {"a":10,"b":20,"c":30}
```

### Array in Lookup-Objekt umwandeln

```tcl
set users {[
    {"id": 1, "name": "Alice"},
    {"id": 2, "name": "Bob"}
]}

set byId [json omap u $users {
    list [json get $u id] [json extract $u]
}]
# {"1":{"id":1,"name":"Alice"},"2":{"id":2,"name":"Bob"}}
```

---

## Templates

Templates sind der effizienteste Weg, JSON in rl_json zu erzeugen.
Ein Template ist ein gueltiges JSON-Dokument mit Platzhaltern, die
beim Aufruf von `json template` durch Werte ersetzt werden.

### Template-Platzhalter

| Platzhalter | Typ | Beschreibung |
|-------------|-----|-------------|
| `~S:name` | String | Wert als JSON-String |
| `~N:name` | Number | Wert als JSON-Zahl |
| `~B:name` | Boolean | Wert als JSON-Boolean |
| `~J:name` | JSON | Wert als JSON-Fragment (unverändert) |
| `~T:name` | Template | Wert als Template (rekursive Substitution) |
| `~L:text` | Literal | Kein Platzhalter, Text ab 4. Zeichen wird literal übernommen |

### Grundsyntax

Templates können Werte aus einem **Dictionary** oder aus
**Variablen im aktuellen Scope** beziehen.

```tcl
# Variante 1: Mit Dictionary
set tmpl {{"name": "~S:user", "age": "~N:years"}}

set result [json template $tmpl {user "Max" years 30}]
# {"name":"Max","age":30}

# Variante 2: Aus Variablen
set user "Max"
set years 30

set result [json template $tmpl]
# {"name":"Max","age":30}
```

### Typen im Detail

```tcl
set tmpl {
    {
        "text":   "~S:val",
        "zahl":   "~N:val",
        "bool":   "~B:val",
        "raw":    "~J:jsonVal",
        "literal":"~L:~S:das ist kein Platzhalter"
    }
}

set val "42"
set jsonVal {{"nested": true}}

set result [json template $tmpl]
# text = "42" (String)
# zahl = 42 (Number)
# bool = true (Boolean, weil "42" truthy)
# raw = {"nested":true} (eingefuegtes JSON)
# literal = "~S:das ist kein Platzhalter" (wortwertlich)
```

### Fehlende Werte werden null

Wenn eine referenzierte Variable oder ein Dict-Key nicht existiert,
wird `null` eingesetzt:

```tcl
set tmpl {{"name": "~S:name", "email": "~S:email"}}

set result [json template $tmpl {name "Tom"}]
# {"name":"Tom","email":null}
```

### Rekursive Templates mit ~T

`~T:name` fügt nicht nur ein JSON-Fragment ein, sondern führt
die Template-Substitution rekursiv auf dem eingefügten Fragment aus:

```tcl
set outer {
    {
        "titel": "~S:titel",
        "inhalt": "~T:innerTmpl"
    }
}

set titel "Mein Dokument"
set innerTmpl {{"autor": "~S:autor", "datum": "~S:datum"}}
set autor "Max"
set datum "2025-01-15"

set result [json template $outer]
# {"titel":"Mein Dokument","inhalt":{"autor":"Max","datum":"2025-01-15"}}
```

Der Unterschied zu `~J`: Bei `~J` wird das Fragment wortwertlich eingefügt,
bei `~T` werden Platzhalter im Fragment ebenfalls aufgelöst.

---

## Templates in der Praxis

### Batch-Erzeugung

Templates sind besonders effizient bei wiederholter Verwendung, weil
rl_json die Struktur intern cached:

```tcl
set tmpl {{"id": "~N:id", "name": "~S:name", "score": "~N:score"}}

set results {[]}
foreach record $dataList {
    lassign $record id name score
    json set results end+1 [json template $tmpl]
}
```

### SQL-Ergebnisse zu JSON

```tcl
set tmpl {
    {
        "id":     "~N:rowid",
        "name":   "~S:name",
        "active": "~B:active",
        "url":    "~S:url"
    }
}

set arr {[]}
db eval {SELECT rowid, name, active, url FROM items} {
    # Fehlende Werte (NULL) -> unset, damit Template null einsetzt
    if {$url eq ""} {unset url}
    json set arr end+1 [json template $tmpl]
}

puts [json pretty $arr]
```

### Konfigurationsdateien erzeugen

```tcl
set configTmpl {
    {
        "app": {
            "name":    "~S:appName",
            "version": "~S:appVersion",
            "debug":   "~B:debugMode"
        },
        "database": {
            "host": "~S:dbHost",
            "port": "~N:dbPort",
            "name": "~S:dbName"
        }
    }
}

set appName "MyApp"
set appVersion "1.2.3"
set debugMode 0
set dbHost "localhost"
set dbPort 5432
set dbName "production"

set config [json template $configTmpl]
saveJson "config.json" $config
```

### API-Request-Body

```tcl
set requestTmpl {
    {
        "method": "~S:method",
        "params": "~J:params",
        "id":     "~N:requestId"
    }
}

proc apiCall {method paramsJson} {
    variable requestId
    incr requestId

    set body [json template $requestTmpl [dict create \
        method    $method \
        params    $paramsJson \
        requestId $requestId \
    ]]

    return [json normalize $body]
}
```

---

## Performance-Hinweise

### Templates vs json object

Für repetitive Erzeugung sind Templates 2-4x schneller als
`json object`, weil die JSON-Struktur nur einmal geparst wird:

```tcl
# Langsamer (Struktur wird jedes Mal neu aufgebaut):
for {set i 0} {$i < 1000} {incr i} {
    set obj [json object val [list number $i]]
}

# Schneller (Template wird gecached):
set tmpl {{"val": "~N:i"}}
for {set i 0} {$i < 1000} {incr i} {
    set obj [json template $tmpl]
}
```

### json get mit Cache

Wenn derselbe JSON-Wert mehrfach gelesen wird, ist der zweite
Zugriff deutlich schneller, weil die interne Repräsentation
bereits existiert (kein erneutes Parsen):

```tcl
# Erster Zugriff: parst den String
set name [json get $bigDoc user name]

# Zweiter Zugriff auf dasselbe Objekt: cached
set age [json get $bigDoc user age]
```

---

## Zusammenfassung

### Iteration

| Befehl | Sammelt | Rückgabe |
|--------|---------|-----------|
| `json foreach` | nein | keiner |
| `json lmap` | ja | Tcl-Liste |
| `json amap` | ja | JSON-Array |
| `json omap` | ja | JSON-Object |

### Template-Platzhalter

| Prefix | Typ | Fehlender Wert |
|--------|-----|----------------|
| `~S:` | String | null |
| `~N:` | Number | null |
| `~B:` | Boolean | null |
| `~J:` | JSON (woertlich) | null |
| `~T:` | Template (rekursiv) | null |
| `~L:` | Literal | (kein Platzhalter) |

## Siehe auch

- [rl_json Grundlagen](rl-json-grundlagen.md)
- [rl_json erstellen und manipulieren](rl-json-erstellen-manipulieren.md)
- [rl_json Praxisrezepte](rl-json-praxis.md)
