# rl_json - Erstellen und Manipulieren

*Stand: 2026-04-29*

## JSON-Werte erzeugen

### Primitive Typen

```tcl
package require rl_json
namespace import rl_json::json

# String
json string "Hallo Welt"           ;# "Hallo Welt"
json string "Zeile 1\nZeile 2"    ;# "Zeile 1\nZeile 2"

# Number
json number 42                     ;# 42
json number 3.14                   ;# 3.14
json number 1.5e10                 ;# 15000000000.0

# Boolean (akzeptiert alle Tcl-Formen)
json boolean true                  ;# true
json boolean 1                     ;# true
json boolean yes                   ;# true
json boolean false                 ;# false
json boolean 0                     ;# false
json boolean no                    ;# false
```

Null, true und false sind direkt als JSON-Literale verwendbar:

```tcl
json set doc key null
json set doc key true
json set doc key false
```

---

## Objekte erstellen: json object

Die Syntax ist `json object key {type wert} ...`. Jeder Wert ist eine
zweielementige Liste aus Typname und Wert.

### Einfaches Objekt

```tcl
set person [json object \
    name   {string "Max"} \
    age    {number 30} \
    active {boolean true} \
]
# {"name":"Max","age":30,"active":true}
```

### Mit null-Werten

```tcl
set data [json object \
    value {string "test"} \
    empty {null} \
]
# {"value":"test","empty":null}
```

### Verschachtelte Objekte

Für verschachtelte JSON-Objekte wird der Typ `json` verwendet:

```tcl
set address [json object \
    street {string "Hauptstr."} \
    number {number 42} \
    city   {string "Berlin"} \
]

set person [json object \
    name    {string "Maria"} \
    age     {number 28} \
    address [list json $address] \
]
# {"name":"Maria","age":28,"address":{"street":"Hauptstr.","number":42,"city":"Berlin"}}
```

**Wichtig:** `[list json $address]` -- nicht vergessen! Ohne `list json`
wird das Objekt als String eingefügt statt als JSON-Fragment.

### Häufiger Fehler

```tcl
# FALSCH - address wird als String eingefügt:
json object address $addressObj

# FALSCH - Typ fehlt die Klammern:
json object name string "Tom"

# RICHTIG:
json object address [list json $addressObj]
json object name {string "Tom"}
```

---

## Arrays erstellen: json array

Die Syntax ist `json array {type wert} ...`.

```tcl
# String-Array
set fruits [json array \
    {string "Apfel"} \
    {string "Banane"} \
    {string "Orange"} \
]
# ["Apfel","Banane","Orange"]

# Gemischte Typen
set mixed [json array \
    {string "text"} \
    {number 42} \
    {boolean true} \
    {null} \
]
# ["text",42,true,null]

# Leeres Array
json array                 ;# []
```

### Array von Objekten

```tcl
set p1 [json object name {string "Tom"} score {number 100}]
set p2 [json object name {string "Lisa"} score {number 150}]

set people [json array \
    [list json $p1] \
    [list json $p2] \
]
# [{"name":"Tom","score":100},{"name":"Lisa","score":150}]
```

---

## Werte ändern: json set

`json set` arbeitet auf einer **Variablen** (nicht auf einem Wert).
Der erste Parameter ist der Variablenname, nicht der Inhalt.

### Werte ändern und hinzufügen

```tcl
set doc {{"foo": 1}}

# Wert ändern
json set doc foo [json number 42]
# {"foo":42}

# Neuen Key hinzufügen
json set doc bar [json string "neu"]
# {"foo":42,"bar":"neu"}
```

### Verschachtelte Pfade

Nicht existierende Zwischenstufen werden automatisch als Objekte angelegt:

```tcl
set doc {{"foo": 1}}

json set doc level1 level2 level3 [json string "tief"]
# {"foo":1,"level1":{"level2":{"level3":"tief"}}}
```

### Array-Manipulation

```tcl
set doc {{"items": []}}

# Am Ende anfügen
json set doc items end+1 [json string "erstes"]
json set doc items end+1 [json string "zweites"]
# {"items":["erstes","zweites"]}

# Am Anfang einfügen
json set doc items -1 [json string "ganz vorne"]
# {"items":["ganz vorne","erstes","zweites"]}

# An bestimmter Position
json set doc items 1 [json string "dazwischen"]
# {"items":["ganz vorne","dazwischen","erstes","zweites"]}
```

### Array-Indizes für json set

| Index | Wirkung |
|-------|---------|
| `0`, `1`, `2` | Ersetzt Element an Position |
| `end` | Ersetzt letztes Element |
| `end+1` | Hängt am Ende an |
| `-1` | Fügt vor erstem Element ein |

**Achtung:** `json set arr 0 ...` bei einem Array mit 3 Elementen
**ersetzt** das erste Element. `json set arr end+1 ...` **fügt hinzu**.

---

## Werte entfernen: json unset

```tcl
# Aus Objekt
set data {{"a": 1, "b": 2, "c": 3}}
json unset data b
# {"a":1,"c":3}

# Aus Array (Elemente ruecken nach)
set arr {["a", "b", "c", "d"]}
json unset arr 1
# ["a","c","d"]

# Verschachtelt
set doc {{"config": {"debug": true, "verbose": false}}}
json unset doc config verbose
# {"config":{"debug":true}}
```

---

## Praxismuster

### Objekt schrittweise aufbauen

```tcl
set result {{}}

json set result name    [json string $userName]
json set result email   [json string $userEmail]
json set result created [json string [clock format [clock seconds] -format "%Y-%m-%d"]]

if {$phone ne ""} {
    json set result phone [json string $phone]
}
```

### Liste zu JSON-Array

```tcl
proc listToJsonArray {tclList} {
    set arr {[]}
    foreach item $tclList {
        json set arr end+1 [json string $item]
    }
    return $arr
}

set colors {rot gruen blau}
set jsonColors [listToJsonArray $colors]
# ["rot","gruen","blau"]
```

### Dict zu JSON-Object

```tcl
proc dictToJson {d} {
    set obj {{}}
    dict for {key val} $d {
        json set obj $key [json string $val]
    }
    return $obj
}

set config [dict create host localhost port 8080 debug true]
set jsonConfig [dictToJson $config]
# {"host":"localhost","port":"8080","debug":"true"}
```

### JSON-Datei lesen und schreiben

```tcl
proc loadJson {filename} {
    set h [open $filename rb]
    try {
        return [json decode [read $h]]
    } finally {
        close $h
    }
}

proc saveJson {filename jsonValue} {
    set h [open $filename wb]
    try {
        puts $h [json pretty $jsonValue]
    } finally {
        close $h
    }
}

# Verwendung
set config [loadJson "config.json"]
json set config version [json string "2.0"]
saveJson "config.json" $config
```

### Merge zweier JSON-Objekte

```tcl
proc jsonMerge {base overlay} {
    foreach key [json keys $overlay] {
        json set base $key [json extract $overlay $key]
    }
    return $base
}

set defaults {{"debug": false, "port": 8080, "host": "localhost"}}
set user     {{"debug": true, "port": 9090}}

set merged [jsonMerge $defaults $user]
# {"debug":true,"port":9090,"host":"localhost"}
```

---

## Zusammenfassung

### Erzeugen

| Befehl | Beispiel | Ergebnis |
|--------|----------|----------|
| `json string` | `json string "Hallo"` | `"Hallo"` |
| `json number` | `json number 42` | `42` |
| `json boolean` | `json boolean yes` | `true` |
| `json object` | `json object k {string "v"}` | `{"k":"v"}` |
| `json array` | `json array {number 1} {number 2}` | `[1,2]` |

### Manipulieren

| Befehl | Wirkung |
|--------|---------|
| `json set var key val` | Wert setzen/ändern |
| `json set var items end+1 val` | An Array anfügen |
| `json unset var key` | Wert entfernen |

### Typ-Annotationen für json object / json array

| Typ | Beschreibung |
|-----|-------------|
| `{string "text"}` | JSON-String |
| `{number 42}` | JSON-Number |
| `{boolean true}` | JSON-Boolean |
| `{null}` | JSON-Null |
| `[list json $fragment]` | Eingebettetes JSON |

## Siehe auch

- [rl_json Grundlagen](rl-json-grundlagen.md)
- [rl_json Iteration und Templates](rl-json-iteration-templates.md)
- [rl_json Praxisrezepte](rl-json-praxis.md)
