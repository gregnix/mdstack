# rl_json - Praxisrezepte

*Stand: 2026-04-29*

Fertige Muster für häufige Aufgaben mit rl_json.

## Datei-Operationen

### JSON-Datei lesen

```tcl
proc loadJson {filename} {
    set h [open $filename rb]
    try {
        return [json decode [read $h]]
    } finally {
        close $h
    }
}

set config [loadJson "config.json"]
puts [json get $config version]
```

### JSON-Datei schreiben (formatiert)

```tcl
proc saveJson {filename jsonValue {indent "    "}} {
    set h [open $filename wb]
    try {
        puts $h [json pretty -indent $indent $jsonValue]
    } finally {
        close $h
    }
}

set data [json object name {string "Test"} version {string "1.0"}]
saveJson "output.json" $data
```

### JSON-Datei aktualisieren

```tcl
proc updateJsonFile {filename script} {
    set json [loadJson $filename]
    set json [uplevel 1 [list apply [list {json} $script] $json]]
    saveJson $filename $json
    return $json
}

# Verwendung
updateJsonFile "config.json" {
    json set json version [json string "2.0"]
    json set json updated [json string [clock format [clock seconds]]]
    return $json
}
```

---

## Konfiguration

### Settings mit Defaults

```tcl
proc loadSettings {filename defaults} {
    if {[file exists $filename]} {
        set saved [loadJson $filename]
        # Defaults mit gespeicherten Werten überlagern
        foreach key [json keys $saved] {
            json set defaults $key [json extract $saved $key]
        }
    }
    return $defaults
}

set defaults [json template {
    {
        "window": {"width": 800, "height": 600},
        "font":   {"family": "TkDefaultFont", "size": 11},
        "recent": [],
        "debug":  false
    }
}]

set settings [loadSettings "settings.json" $defaults]
```

### Einstellung sicher lesen

```tcl
proc getSetting {settings args} {
    set default [lindex $args end]
    set path [lrange $args 0 end-1]
    return [json get -default $default $settings {*}$path]
}

# Verwendung
set width [getSetting $settings window width 800]
set debug [getSetting $settings debug false]
```

### Recent Files verwalten

```tcl
proc addRecentFile {settingsVar filename {maxEntries 10}} {
    upvar 1 $settingsVar settings

    # Bestehende Liste holen
    set recent {[]}
    catch {set recent [json extract $settings recent]}

    # Duplikat entfernen falls vorhanden
    set newRecent {[]}
    json foreach entry $recent {
        if {$entry ne $filename} {
            json set newRecent end+1 [json string $entry]
        }
    }

    # Am Anfang einfügen
    json set newRecent -1 [json string $filename]

    # Auf Maximum kürzen
    while {[json length $newRecent] > $maxEntries} {
        json unset newRecent end
    }

    json set settings recent $newRecent
}
```

---

## REST API

### GET-Request

```tcl
package require http
package require tls
http::register https 443 [list ::tls::socket -autoservername true]

proc apiGet {url {headers {}}} {
    set token [http::geturl $url -headers $headers]
    try {
        set code [http::ncode $token]
        if {$code != 200} {
            error "HTTP $code: [http::data $token]"
        }
        return [json get [http::data $token]]
    } finally {
        http::cleanup $token
    }
}
```

### POST-Request mit JSON-Body

```tcl
proc apiPost {url jsonBody {headers {}}} {
    set body [json normalize $jsonBody]
    lappend headers Content-Type application/json

    set token [http::geturl $url \
        -method POST \
        -headers $headers \
        -query $body]

    try {
        set code [http::ncode $token]
        set data [http::data $token]
        if {$code < 200 || $code >= 300} {
            error "HTTP $code: $data"
        }
        return [json get $data]
    } finally {
        http::cleanup $token
    }
}

# Verwendung
set body [json template {
    {
        "username": "~S:user",
        "email":    "~S:email"
    }
} {user "max" email "max@example.com"}]

set result [apiPost "https://api.example.com/users" $body]
```

### Paginierte API

```tcl
proc fetchAll {baseUrl {pageSize 100}} {
    set all {[]}
    set page 1

    while {1} {
        set url "${baseUrl}?page=${page}&per_page=${pageSize}"
        set response [apiGet $url]
        set items [dict get $response items]

        if {[json length $items] == 0} break

        json foreach item $items {
            json set all end+1 $item
        }

        if {[json length $items] < $pageSize} break
        incr page
    }

    return $all
}
```

---

## Daten-Transformation

### CSV zu JSON

```tcl
proc csvToJson {csvData {separator ","}} {
    set lines [split $csvData \n]
    set headers [split [lindex $lines 0] $separator]
    set result {[]}

    foreach line [lrange $lines 1 end] {
        if {[string trim $line] eq ""} continue
        set values [split $line $separator]
        set obj {{}}
        foreach h $headers v $values {
            set h [string trim $h]
            set v [string trim $v]
            if {[string is integer -strict $v]} {
                json set obj $h [json number $v]
            } elseif {[string is double -strict $v]} {
                json set obj $h [json number $v]
            } else {
                json set obj $h [json string $v]
            }
        }
        json set result end+1 $obj
    }

    return $result
}
```

### JSON zu CSV

```tcl
proc jsonToCsv {jsonArray {separator ","}} {
    set keys [json keys [json extract $jsonArray 0]]
    set lines [list [join $keys $separator]]

    json foreach row $jsonArray {
        set values {}
        foreach key $keys {
            set val [json get -default "" $row $key]
            # Quoten falls Separator oder Newline enthalten
            if {[string match "*\[$separator\n\"]*" $val]} {
                set val "\"[string map {\" \"\"} $val]\""
            }
            lappend values $val
        }
        lappend lines [join $values $separator]
    }

    return [join $lines \n]
}
```

### Flatten / Unflatten

```tcl
# {"a": {"b": {"c": 1}}} -> {"a.b.c": 1}
proc jsonFlatten {jsonVal {prefix ""}} {
    set result {{}}
    foreach key [json keys $jsonVal] {
        set fullKey [expr {$prefix ne "" ? "${prefix}.${key}" : $key}]
        set type [json type $jsonVal $key]
        if {$type eq "object"} {
            set sub [jsonFlatten [json extract $jsonVal $key] $fullKey]
            foreach subKey [json keys $sub] {
                json set result $subKey [json extract $sub $subKey]
            }
        } else {
            json set result $fullKey [json extract $jsonVal $key]
        }
    }
    return $result
}

# {"a.b.c": 1} -> {"a": {"b": {"c": 1}}}
proc jsonUnflatten {flatJson {separator "."}} {
    set result {{}}
    foreach key [json keys $flatJson] {
        set path [split $key $separator]
        json set result {*}$path [json extract $flatJson $key]
    }
    return $result
}
```

---

## Filtern und Suchen

### Array filtern

```tcl
proc jsonFilter {jsonArray script} {
    set result {[]}
    json foreach item $jsonArray {
        if {[uplevel 1 [list apply [list {item} $script] $item]]} {
            json set result end+1 $item
        }
    }
    return $result
}

# Verwendung
set active [jsonFilter $users {
    json get $item active
}]

set adults [jsonFilter $people {
    expr {[json get $item age] >= 18}
}]
```

### Wert in verschachtelter Struktur suchen

```tcl
proc jsonFind {jsonVal key} {
    set results {}
    set type [json type $jsonVal]

    if {$type eq "object"} {
        foreach k [json keys $jsonVal] {
            if {$k eq $key} {
                lappend results [json extract $jsonVal $k]
            }
            lappend results {*}[jsonFind [json extract $jsonVal $k] $key]
        }
    } elseif {$type eq "array"} {
        json foreach item $jsonVal {
            lappend results {*}[jsonFind $item $key]
        }
    }

    return $results
}

# Alle "name"-Werte finden, egal wie tief verschachtelt
set names [jsonFind $complexDoc "name"]
```

---

## SQLite-Integration

### Tabelle zu JSON exportieren

```tcl
proc tableToJson {db tableName} {
    set result {[]}
    $db eval "SELECT * FROM $tableName" row {
        set obj {{}}
        foreach col $row(*) {
            if {$row($col) eq ""} {
                json set obj $col null
            } elseif {[string is integer -strict $row($col)]} {
                json set obj $col [json number $row($col)]
            } elseif {[string is double -strict $row($col)]} {
                json set obj $col [json number $row($col)]
            } else {
                json set obj $col [json string $row($col)]
            }
        }
        json set result end+1 $obj
    }
    return $result
}

set usersJson [tableToJson db users]
saveJson "users-export.json" $usersJson
```

### JSON in Tabelle importieren

```tcl
proc jsonToTable {db tableName jsonArray} {
    set keys [json keys [json extract $jsonArray 0]]
    set cols [join $keys ", "]
    set placeholders [join [lmap k $keys {set _ "\$$k"}] ", "]
    set sql "INSERT INTO $tableName ($cols) VALUES ($placeholders)"

    $db transaction {
        json foreach row $jsonArray {
            foreach k $keys {
                set $k [json get -default "" $row $k]
            }
            $db eval $sql
        }
    }
}
```

---

## GUI-Integration

### Treeview mit JSON füllen

```tcl
proc fillTreeview {tree jsonArray columns} {
    $tree delete [$tree children {}]

    json foreach item $jsonArray {
        set values {}
        foreach col $columns {
            lappend values [json get -default "" $item $col]
        }
        $tree insert {} end -values $values
    }
}

# Verwendung
ttk::treeview .tree -columns {name age city} -show headings
.tree heading name -text "Name"
.tree heading age  -text "Alter"
.tree heading city -text "Stadt"

set data {[
    {"name": "Alice", "age": 30, "city": "Berlin"},
    {"name": "Bob",   "age": 25, "city": "Hamburg"}
]}

fillTreeview .tree $data {name age city}
```

### Fensterposition speichern und wiederherstellen

```tcl
proc saveWindowState {win settingsVar} {
    upvar 1 $settingsVar settings
    json set settings window [json object \
        geometry {string [wm geometry $win]} \
        zoomed   {boolean [expr {[wm state $win] eq "zoomed"}]} \
    ]
}

proc restoreWindowState {win settings} {
    if {[json exists $settings window]} {
        set geom [json get -default "" $settings window geometry]
        if {$geom ne ""} {
            wm geometry $win $geom
        }
        if {[json get -default false $settings window zoomed]} {
            wm state $win zoomed
        }
    }
}
```

---

## Fehlerbehandlung

### Sichere JSON-Verarbeitung

```tcl
proc safeJsonGet {jsonVal args} {
    try {
        return [json get $jsonVal {*}$args]
    } on error {msg} {
        return ""
    }
}

proc safeJsonLoad {filename} {
    if {![file exists $filename]} {
        return {{}}
    }
    try {
        return [loadJson $filename]
    } on error {msg} {
        puts stderr "JSON-Fehler in $filename: $msg"
        return {{}}
    }
}
```

### Validierung vor Verarbeitung

```tcl
proc processApiResponse {response} {
    if {![json valid $response]} {
        error "Ungültige JSON-Antwort"
    }

    set type [json type $response]
    if {$type ne "object"} {
        error "Erwarte JSON-Objekt, erhalten: $type"
    }

    if {[json exists $response error]} {
        error "API-Fehler: [json get $response error message]"
    }

    return [json get $response data]
}
```

---

## Häufige Stolpersteine

### 1. json exists und null

```tcl
set data {{"value": null}}

# FALSCH - gibt 0 zurück, obwohl der Key existiert!
if {[json exists $data value]} { ... }

# RICHTIG - prüfen ob der Key vorhanden ist
if {"value" in [json keys $data]} { ... }
```

### 2. Verschachtelung vergessen

```tcl
set inner [json object x {number 1}]

# FALSCH - inner wird als String eingefügt
json object data $inner

# RICHTIG
json object data [list json $inner]
```

### 3. json set braucht Variablennamen

```tcl
set doc {{"x": 1}}

# FALSCH - übergibt den Wert, nicht den Namen
json set $doc x [json number 2]

# RICHTIG - übergibt den Variablennamen
json set doc x [json number 2]
```

### 4. Zahlen vs Strings

```tcl
set port "8080"

# Erzeugt "port": "8080" (String!)
json object port [list string $port]

# Erzeugt "port": 8080 (Zahl)
json object port [list number $port]

# Mit Template: ~S vs ~N kontrolliert den Typ
json template {{"port": "~N:port"}}
```

### 5. Leeres Array und leeres Objekt

```tcl
# Leeres Array
set arr {[]}

# Leeres Objekt
set obj {{}}

# FALSCH - das ist ein leerer String, kein JSON
set wrong ""
json get $wrong    ;# Error!
```

---

## Zusammenfassung

### Dateien

| Muster | Funktion |
|--------|----------|
| `loadJson` | JSON-Datei sicher lesen |
| `saveJson` | JSON-Datei formatiert schreiben |
| `updateJsonFile` | Lesen, ändern, schreiben |

### Transformation

| Muster | Funktion |
|--------|----------|
| `csvToJson` | CSV-Daten in JSON-Array |
| `jsonToCsv` | JSON-Array in CSV |
| `jsonFlatten` | Verschachtelung auflösen |
| `jsonFilter` | Array nach Kriterium filtern |
| `jsonFind` | Rekursiv nach Key suchen |

### Integration

| Muster | Funktion |
|--------|----------|
| `tableToJson` | SQLite-Tabelle exportieren |
| `jsonToTable` | JSON in SQLite importieren |
| `fillTreeview` | Treeview aus JSON befüllen |
| `saveWindowState` | Fensterposition sichern |

## Siehe auch

- [rl_json Grundlagen](rl-json-grundlagen.md)
- [rl_json erstellen und manipulieren](rl-json-erstellen-manipulieren.md)
- [rl_json Iteration und Templates](rl-json-iteration-templates.md)

## Quellen

- rl_json GitHub: https://github.com/RubyLane/rl_json
- Lizenz: BSD (wie Tcl Core)
