# rl_json - Grundlagen

*Stand: 2026-04-29*

## Übersicht

rl_json ist ein hochperformanter JSON-Parser für Tcl, der von Ruby Lane
entwickelt wird. Er behandelt JSON als nativen Tcl-Datentyp -- ähnlich wie
`dict` für Dictionaries arbeitet, arbeitet `json` direkt auf JSON-Werten.
Die C-Implementierung macht ihn deutlich schneller als reine Tcl-Lösungen.

### Installation und Import

```tcl
package require rl_json

# Namespace importieren für kuerzere Syntax
namespace import rl_json::json
```

Ohne Import muss jeder Aufruf vollqualifiziert erfolgen:
`rl_json::json get $data key`. Mit Import reicht `json get $data key`.

---

## JSON-Typen

rl_json unterstützt alle sechs JSON-Typen:

| JSON-Typ | Tcl-Entsprechung | Beispiel |
|----------|-------------------|----------|
| string | String | `"Hallo"` |
| number | Integer oder Double | `42`, `3.14` |
| boolean | Boolean | `true`, `false` |
| null | (kein Aequivalent) | `null` |
| object | Dict | `{"a": 1, "b": 2}` |
| array | Liste | `[1, 2, 3]` |

Den Typ eines JSON-Wertes ermitteln:

```tcl
set data {{"name": "Tom", "age": 30, "items": [1,2], "valid": true, "x": null}}

json type $data            ;# object
json type $data name       ;# string
json type $data age        ;# number
json type $data items      ;# array
json type $data valid      ;# boolean
json type $data x          ;# null
```

---

## Werte lesen: json get

`json get` extrahiert Werte und konvertiert sie in native Tcl-Typen
(String, Zahl, Liste, Dict).

### Einfacher Zugriff

```tcl
set data {{"name": "Max", "age": 30, "city": "Berlin"}}

# Einzelne Werte
json get $data name        ;# Max
json get $data age         ;# 30

# Gesamtes Objekt als Dict
json get $data
# name Max age 30 city Berlin
```

### Verschachtelte Pfade

Pfade funktionieren wie bei `dict`, zusätzlich mit Array-Indizes:

```tcl
set data {
    {
        "company": {
            "name": "TechCorp",
            "employees": [
                {"name": "Alice", "role": "Dev"},
                {"name": "Bob", "role": "Manager"}
            ]
        }
    }
}

json get $data company name                ;# TechCorp
json get $data company employees 0 name    ;# Alice
json get $data company employees end name  ;# Bob
json get $data company employees end-1 name ;# Alice
```

### Array-Indizes

| Index | Bedeutung |
|-------|-----------|
| `0`, `1`, `2` | Normaler Index |
| `end` | Letztes Element |
| `end-1`, `end-2` | Von hinten zählen |

### Default-Werte

Wenn ein Pfad nicht existiert, wirft `json get` einen Fehler.
Mit `-default` lässt sich das vermeiden:

```tcl
set data {{"name": "Tom"}}

json get $data name                           ;# Tom
json get -default "Unbekannt" $data nachname  ;# Unbekannt

# Statt:
if {[json exists $data nachname]} {
    set val [json get $data nachname]
} else {
    set val "Unbekannt"
}

# Besser:
set val [json get -default "Unbekannt" $data nachname]
```

---

## JSON-Fragmente: json extract

`json extract` gibt den Wert als JSON zurück, nicht als Tcl-Typ.
Das ist wichtig, wenn JSON-Daten weitergereicht werden sollen.

```tcl
set data {{"value": "hello", "count": 42}}

json get $data value       ;# hello      (Tcl String)
json extract $data value   ;# "hello"    (JSON String, mit Anführungszeichen)

json get $data count       ;# 42         (Tcl Integer)
json extract $data count   ;# 42         (JSON Number)
```

### Wann extract statt get?

```tcl
# Fragment in anderes JSON einbauen:
set fragment [json extract $source path to data]
json set target newKey $fragment
```

Verwenden Sie `json get`, wenn Sie mit dem Wert in Tcl weiterarbeiten.
Verwenden Sie `json extract`, wenn der Wert als JSON weitergegeben wird.

---

## Existenz prüfen

### json exists

Prüft, ob ein Pfad existiert:

```tcl
set data {{"name": "Tom", "age": null}}

json exists $data name     ;# 1
json exists $data email    ;# 0
json exists $data age      ;# 0  (!)
```

**Achtung:** `json exists` gibt `0` zurück, wenn der Wert `null` ist!
Das ist ein häufiger Stolperstein.

### json isnull

Prüft explizit auf `null`:

```tcl
set data {{"name": "Tom", "age": null}}

json isnull $data name     ;# 0
json isnull $data age      ;# 1
json isnull $data email    ;# Error! (Pfad existiert nicht)
```

### Vollständige Prüfung

```tcl
# Existiert der Key (auch wenn null)?
proc jsonKeyExists {jsonVal args} {
    set path $args
    # Prüfen ob der Key im Parent-Objekt vorhanden ist
    if {[llength $path] == 0} {
        return 1
    }
    set parentPath [lrange $path 0 end-1]
    set key [lindex $path end]
    if {[llength $parentPath] > 0} {
        set parent [json extract $jsonVal {*}$parentPath]
    } else {
        set parent $jsonVal
    }
    return [expr {$key in [json keys $parent]}]
}
```

---

## Länge und Schlüssel

### json length

```tcl
# Array-Länge
json length {[1, 2, 3, 4, 5]}           ;# 5

# Anzahl Keys in Object
json length {{"a": 1, "b": 2, "c": 3}}  ;# 3

# String-Länge
json length [json string "Hallo"]        ;# 5

# Verschachtelt
set data {{"items": [10, 20, 30]}}
json length $data items                  ;# 3
```

### json keys

```tcl
set person {{"name": "Tom", "age": 30, "city": "Berlin"}}

json keys $person    ;# name age city

# Verschachtelt
set data {{"config": {"debug": true, "verbose": false}}}
json keys $data config    ;# debug verbose
```

---

## Formatierung und Validierung

### json normalize

Entfernt optionalen Whitespace:

```tcl
set messy {  { "foo" :  "bar" ,  "baz" : 42  }  }
json normalize $messy
# {"foo":"bar","baz":42}
```

### json pretty

Formatiert JSON für Ausgabe und Debugging:

```tcl
set compact {{"name":"Tom","items":[1,2,3],"nested":{"a":1}}}

puts [json pretty $compact]
# {
#     "name": "Tom",
#     "items": [
#         1,
#         2,
#         3
#     ],
#     "nested": {
#         "a": 1
#     }
# }

# Eigene Einrueckung
puts [json pretty -indent "  " $compact]
```

### json valid

```tcl
json valid {{"ok": true}}     ;# 1
json valid {{"broken": }}     ;# 0

# Mit Fehlerdetails
if {![json valid -details err {{"x":}}]} {
    puts "Fehler: [dict get $err errmsg]"
    puts "Position: [dict get $err char_ofs]"
}

# Kommentare erlauben (rl_json Extension)
set withComments {
    {
        // Kommentar
        "value": 42 /* Block-Kommentar */
    }
}
json valid -extensions {comments} $withComments  ;# 1
json valid $withComments                         ;# 0
```

### json decode

Dekodiert binäre Bytes in einen JSON-String. Nützlich für Dateien
und Netzwerkdaten mit unbekanntem oder explizitem Encoding:

```tcl
proc loadJson {filename} {
    set h [open $filename rb]
    try {
        return [json decode [read $h]]
    } finally {
        close $h
    }
}

# Mit explizitem Encoding (z.B. aus HTTP-Header)
json decode $bytes utf-16le
```

---

## Zusammenfassung

| Befehl | Zweck | Rückgabe |
|--------|-------|-----------|
| `json get` | Wert lesen | Tcl-Typ |
| `json extract` | JSON-Fragment lesen | JSON |
| `json exists` | Pfad vorhanden? (null = false!) | Boolean |
| `json isnull` | Wert ist null? | Boolean |
| `json type` | Typ ermitteln | string/number/boolean/null/object/array |
| `json length` | Länge/Anzahl | Integer |
| `json keys` | Object-Schlüssel | Liste |
| `json normalize` | Whitespace entfernen | JSON |
| `json pretty` | Formatiert ausgeben | String |
| `json valid` | Validieren | Boolean |
| `json decode` | Bytes dekodieren | JSON-String |

## Siehe auch

- [rl_json erstellen und manipulieren](rl-json-erstellen-manipulieren.md)
- [rl_json Iteration und Templates](rl-json-iteration-templates.md)
- [rl_json Praxisrezepte](rl-json-praxis.md)

## Quellen

- rl_json GitHub: https://github.com/RubyLane/rl_json
- Lizenz: BSD (wie Tcl Core)
