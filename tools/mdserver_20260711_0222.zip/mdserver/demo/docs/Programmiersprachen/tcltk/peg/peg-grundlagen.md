# PEG -- Parsing Expression Grammars

*Stand: 2026-05-29*

**Parsing Expression Grammars** (PEG) sind eine 2004 von Bryan Ford
formalisierte Familie von Grammatiken, die wie eine Mischung aus
regulären Ausdrücken und kontextfreien Grammatiken aussehen, sich aber
fundamental anders verhalten: **deterministisch**, **erkennungsbasiert**
und **gierig**. Dieser Artikel erklärt den Kern; praktische Patterns
stehen in [peg-grammatik-patterns.md](peg-grammatik-patterns.md),
die konkrete Tcl-Implementierung in
[peg-tcllib.md](peg-tcllib.md).

## Grundidee

Eine PEG-Grammatik **erkennt** Eingaben -- sie beschreibt nicht eine
Sprache als Menge aller Sätze (wie CFG), sondern einen **Algorithmus**,
der entscheidet, ob ein Eingabestring zur Sprache gehört und wie er
strukturiert ist.

```peg
# Klassische Arithmetik-Grammatik (linksassoziativ)
Expression <- Term (('+' / '-') Term)*
Term       <- Factor (('*' / '/') Factor)*
Factor     <- Number / '(' Expression ')'
Number     <- [0-9]+
```

Jede Regel hat die Form `Name <- Expression`. Die Pfeil-Schreibweise
unterscheidet PEG-Regeln optisch von CFG-Produktionen (`Name :=` oder
`Name ->`).

## Syntax-Elemente

| Element | Bedeutung |
|---|---|
| `e1 e2` | Sequenz: erst `e1`, dann `e2`. |
| `e1 / e2` | **Geordnete** Alternative: erst `e1` versuchen, nur bei Fehlschlag `e2`. |
| `e*` | Null oder mehr Wiederholungen (gierig). |
| `e+` | Eins oder mehr (gierig). |
| `e?` | Optional. |
| `&e` | Positives Lookahead -- prüft, konsumiert aber **nicht**. |
| `!e` | Negatives Lookahead -- erfolgreich, wenn `e` **nicht** matcht. |
| `(...)` | Gruppierung. |
| `'foo'`, `"foo"` | Terminale Literale. |
| `[a-z]` | Zeichenklasse (wie in Regex). |
| `.` | Beliebiges einzelnes Zeichen. |
| `# Kommentar` | Bis Zeilenende (in den meisten PEG-Tools). |

```peg
# Beispiele zur Syntax
Greeting <- ('Hi' / 'Hello') ' ' Name '!'?
Number   <- '-'? [0-9]+ ('.' [0-9]+)?
Word     <- ![0-9] [a-zA-Z_] [a-zA-Z_0-9]*
```

## Die drei Eigenschaften, die PEG ausmachen

### 1. Geordnete Alternative (`/`)

In CFG bedeutet `A | B`: beide Alternativen sind gleichwertig, der
Parser darf raten oder backtracken. In PEG bedeutet `A / B`:

- Erst `A` probieren.
- Wenn `A` matcht: **fertig**. `B` wird **nie** versucht, auch wenn
  später die gesamte Regel scheitert.
- Nur wenn `A` fehlschlägt, wird `B` probiert.

Konsequenz: **PEG kennt keine Mehrdeutigkeit**. Eine Eingabe hat genau
einen Parse-Baum (oder keinen).

```peg
# Klassischer Stolperstein: Reihenfolge der Alternative ist wichtig
Keyword <- 'if' / 'ifelse'
# 'ifelse' wird NIE matchen -- 'if' matcht zuerst, der Parser nimmt's,
# der Rest 'else' bleibt liegen.

# Richtig: laengere Variante zuerst
Keyword <- 'ifelse' / 'if'
```

### 2. Greedy und ohne Backtracking nach Erfolg

`e*` und `e+` sind **maximal gierig**: sie konsumieren so viel wie
möglich, und **geben es nicht wieder her**, auch wenn die Gesamtregel
dadurch scheitert.

```peg
# Wirkt harmlos:
Phrase <- [a-z]+ 'end'

# Wendet man's auf "fooend" an, scheitert es:
# [a-z]+ konsumiert "fooend" KOMPLETT.
# Dann scheitert 'end', weil die Eingabe leer ist.
# [a-z]+ gibt das 'e','n','d' NICHT zurueck.

# Loesung: Lookahead einbauen
Phrase <- ([a-z] !'end')* [a-z] 'end'
# oder Wort-Begrenzung explizit:
Phrase <- ([a-z] &(!'end'))* 'end'
```

Im Vergleich zu Regex-Engines mit Backtracking (PCRE, JavaScript-Regex,
Python `re`) ist das ungewohnt -- ist aber **schneller** und
**vorhersehbarer**: PEG-Parser laufen in linearer Zeit (mit
Memoisierung, Packrat-Parsing), Regex-Engines können im schlimmsten
Fall exponentiell explodieren.

### 3. Lookahead ohne Konsum

`&e` und `!e` prüfen die Eingabe ohne sie zu konsumieren:

```peg
# Identifier, aber kein Keyword
Identifier <- !Keyword [a-zA-Z_] [a-zA-Z_0-9]*

# Match bis vor einem Terminator
Body <- (!Terminator .)*

# Doppel-Lookahead: nur wenn Foo gefolgt von Bar
FooThenBar <- 'Foo' &Bar
```

Lookahead macht PEG **mächtiger** als kontextfreie Grammatiken: Sprachen
wie `a^n b^n c^n` (gleich viele a, b, c hintereinander) sind nicht
kontextfrei, aber per PEG ausdrückbar.

## Vergleich: PEG vs. Regex vs. CFG

| | Regex | CFG (yacc/bison) | PEG |
|---|---|---|---|
| Geschachtelte Strukturen | nein | ja | ja |
| Klammerbalance | nein | ja | ja |
| Alternative | `\|` (ungeordnet) | `\|` (ungeordnet) | `/` (geordnet) |
| Mehrdeutigkeit | -- | ja (Konflikte) | nein |
| Linksrekursion direkt | -- | ja | nein (Umschreibung nötig) |
| Backtracking | engine-abhängig | nein (LALR) | nein (nach `/`-Erfolg) |
| Worst-case-Komplexität | exponentiell (RE-DoS) | linear | linear (mit Packrat) |
| Lookahead | begrenzt | nein | ja (`&` und `!`) |

**Faustregel zur Wahl:**

- Einfaches Pattern-Matching, eine Zeile, keine Schachtelung → **Regex**.
- Standardisierte Sprache mit existierendem Parser-Generator
  (Java, SQL, …) → **CFG** (yacc, bison, ANTLR).
- Eigene kleine DSL, JSON-artiges Format, Konfigurationssyntax,
  Ausdrücke → **PEG**. Besonders gut, wenn man die Grammatik selbst
  erfindet und nicht mit Mehrdeutigkeit kämpfen möchte.

## Linksrekursion: die wichtigste Einschränkung

Direkte Linksrekursion (`E <- E '+' T`) führt in PEG zu **unendlicher
Rekursion**:

```peg
# FALSCH: terminiert nie
Expression <- Expression '+' Term / Term
```

Der Parser ruft `Expression` rekursiv auf, bevor er irgendein Zeichen
konsumiert hat -- Stack overflow.

**Standardlösung:** in iterative Form umschreiben.

```peg
# RICHTIG: iterativ, linksassoziativ
Expression <- Term ('+' Term)*
```

Das ergibt für `1 + 2 + 3` einen flachen Parse-Baum, nicht den klassisch
linksassoziativen `((1+2)+3)`-Baum. Die **Linksassoziativität bei der
Auswertung** wird im AST-Schritt hergestellt -- siehe
[peg-ast.md](peg-ast.md).

Indirekte Linksrekursion (zwei Regeln, die sich zyklisch links
aufrufen) ist genauso verboten und genauso umschreibbar. Moderne
PEG-Tools (z.B. Python's PEG-Parser seit 3.9) unterstützen
Linksrekursion durch spezielle Algorithmen; `pt::pgen` in tcllib tut
das **nicht** -- dort muss man immer umschreiben.

## Ein vollständiges Mini-Beispiel

```peg
# Rechner-Grammatik, mit Whitespace und Klammern
Calc       <- Spacing Expression Spacing !.
Expression <- Term (Spacing ('+' / '-') Spacing Term)*
Term       <- Factor (Spacing ('*' / '/') Spacing Factor)*
Factor     <- Number / '(' Spacing Expression Spacing ')'
Number     <- '-'? [0-9]+ ('.' [0-9]+)?
Spacing    <- [ \t\n]*
```

Beachte:

- **`!.`** am Ende von `Calc`: erzwingt, dass die ganze Eingabe
  konsumiert wurde. `!.` heißt "kein weiteres Zeichen". Ohne das würde
  z.B. `1+2 xxx` erfolgreich parsen (nur `1+2`), das Trailing-`xxx`
  einfach ignoriert.
- **`Spacing`** explizit zwischen Tokens -- PEG hat keinen impliziten
  Lexer.
- **Linksrekursion vermieden** durch `Term (… Term)*`-Pattern.

## Packrat-Parsing und Memoisierung

Naive Implementierungen von PEG sind im schlimmsten Fall exponentiell,
weil dieselbe Position mehrfach probiert werden kann. **Packrat-Parser**
memoisieren das Ergebnis jeder Regel an jeder Eingabeposition: Speicher
in O(n·rules), Zeit in O(n).

Praktisch ist das Memory-Tradeoff oft akzeptabel; bei sehr großen
Eingaben kann Memoisierung selektiv abgeschaltet werden. `pt::pgen`
generiert Parser **ohne** Packrat-Memoisierung, was für die typischen
DSL-Größen (Konfigurationen, Ausdrücke) völlig ausreicht.

## Häufige Fehler (Kurzübersicht)

1. **Alternative falsch geordnet** -- längere Variante muss zuerst
   kommen (`'ifelse' / 'if'`, nicht umgekehrt).
2. **Gierige Wiederholung verschluckt zu viel** -- mit Lookahead
   begrenzen (`(!Terminator .)*`).
3. **Direkte Linksrekursion** -- iterativ umschreiben.
4. **Fehlendes `!.`** am Grammatik-Ende -- Eingabe wird nur zum Teil
   konsumiert, Rest still ignoriert.
5. **Vergessener Spacing** -- PEG hat keinen impliziten Lexer; jede
   Stelle, an der Whitespace stehen kann, muss in der Grammatik stehen.
6. **Verwechslung Sequenz vs. Alternative** -- `A B` ist Sequenz (beide
   nacheinander), `A / B` ist Alternative.
7. **Keyword/Identifier-Konflikt** -- ohne Lookahead matcht `Keyword
   'if'` auch das `if` in `iframe`. Lösung: `'if' !IdentChar`.

## Siehe auch

- [peg-landschaft.md](peg-landschaft.md) -- wo PEG zwischen anderen
  Parser-Generatoren steht (Yeti, Lemon, ANTLR, hand-geschrieben).
- [peg-grammatik-patterns.md](peg-grammatik-patterns.md) -- praktische
  Patterns: Whitespace, Operator-Precedence, Linksrekursion umschreiben,
  Listen, Strings mit Escapes.
- [peg-tcllib.md](peg-tcllib.md) -- konkrete Nutzung mit `pt::pgen`
  aus tcllib (Generator, Backends, Parse-Tree-Format).
- [peg-ast.md](peg-ast.md) -- vom Parse-Tree zum normalisierten AST.

## Referenzen

- Bryan Ford, *Parsing Expression Grammars: A Recognition-Based
  Syntactic Foundation*, POPL 2004 -- die Ursprungs-Arbeit.
- Bryan Ford, *Packrat Parsing: Simple, Powerful, Lazy, Linear Time*,
  ICFP 2002 -- der Memoisierungs-Trick, der PEG praktikabel macht.
- Tcl Parser Tools (tcllib): `pt`-Package -- siehe `peg-tcllib.md`.
