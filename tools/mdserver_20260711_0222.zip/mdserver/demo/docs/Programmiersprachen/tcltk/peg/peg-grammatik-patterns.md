# PEG -- Grammatik-Patterns

*Stand: 2026-05-29*

Praktische Patterns zum Schreiben von PEG-Grammatiken. Dieser Artikel
setzt voraus, dass die Grundsyntax aus
[peg-grundlagen.md](peg-grundlagen.md) bekannt ist.

## Whitespace und Kommentare

PEG hat **keinen impliziten Lexer**. Whitespace muss explizit in der
Grammatik stehen, an jeder Stelle, wo er erlaubt sein soll.

### Variante 1: Explizit per Regel

```peg
Calc       <- Spacing Expression EOI
Expression <- Term (Spacing AddOp Spacing Term)*
Term       <- Factor (Spacing MulOp Spacing Factor)*
Factor     <- Number / '(' Spacing Expression Spacing ')'

Spacing    <- (Whitespace / Comment)*
Whitespace <- [ \t\r\n]
Comment    <- '#' (!EOL .)* EOL
EOL        <- '\r\n' / '\n' / '\r'
EOI        <- !.
```

`Spacing` deckt sowohl Whitespace als auch Kommentare ab. Vorteil:
zentraler Punkt für "hier darf Leerraum stehen". Nachteil: an jeder
Token-Grenze explizit anwenden.

### Variante 2: Tokens mit eingebautem Spacing

```peg
# Jeder Terminal-Token konsumiert seinen nachfolgenden Spacing selbst
Number   <- [0-9]+ Spacing
LParen   <- '(' Spacing
RParen   <- ')' Spacing
Plus     <- '+' Spacing

Expression <- Term (Plus Term)*
```

Klarer aber redundanter. Welche Variante besser ist, hängt davon ab,
wie viele Terminale die Grammatik hat. Bei wenigen Tokens (Rechner)
ist Variante 1 lesbarer; bei vielen Schlüsselwörtern (DSL mit `if`,
`while`, `let`, …) ist Variante 2 kompakter.

### Kommentar-Patterns

```peg
# Zeilenkommentar bis Zeilenende
LineComment  <- '#' (!EOL .)* EOL

# C-Stil-Blockkommentar (nicht geschachtelt)
BlockComment <- '/*' (!'*/' .)* '*/'

# Geschachtelter Blockkommentar (rekursiv)
NestedComment <- '/*' (NestedComment / (!'/*' !'*/' .))* '*/'
```

Der **negative Lookahead** `(!'*/' .)*` ist der Standard-Idiomatik für
"alles bis zur Schluss-Sequenz". Ohne den Lookahead würde `.` auch
das `*/` selbst konsumieren.

## Operator-Precedence per Schichtung

Klassischer Trick: Eine Schicht pro Präzedenzstufe, jede Schicht ruft
die nächstniedrigere.

```peg
# Logisch (niedrigste Bindung) -> Vergleich -> Add -> Mul -> Unary -> Atom

Or        <- And ('||' And)*
And       <- Comparison ('&&' Comparison)*
Comparison <- AddExpr (('=='/'!='/'<='/'>='/'<'/'>') AddExpr)?
AddExpr   <- MulExpr (('+'/'-') MulExpr)*
MulExpr   <- Unary (('*'/'/'/'%') Unary)*
Unary     <- ('-'/'!') Unary / Atom
Atom      <- Number / Ident / '(' Or ')'
```

Linksassoziative Operatoren: `(Op Operand)*`-Schleife.
Rechtsassoziative Operatoren (z.B. `**`, Zuweisung): rekursiver Aufruf
am Ende.

```peg
# Linksassoziativ: 1-2-3 == (1-2)-3
AddExpr <- MulExpr (('+' / '-') MulExpr)*

# Rechtsassoziativ: a=b=c == a=(b=c)
Assign  <- Ident '=' Assign / Or
```

Beachte die Reihenfolge in der Rechtsassoziativ-Variante: Die
rekursive Alternative muss **zuerst** stehen, sonst wird sie nie
versucht (geordnete Alternative -- siehe Grundlagen-Artikel).

## Linksrekursion umschreiben

PEG erlaubt keine direkte Linksrekursion. Drei Standard-Umschreibungen:

### Iterative Form (am gängigsten)

```peg
# CFG:  E -> E '+' T | T
# PEG:
Expr <- Term ('+' Term)*
```

Erzeugt eine flache Liste, die im AST-Schritt linksassoziativ
ausgewertet wird.

### Sequenz mit optionalem Rest

```peg
# CFG:  L -> L ',' Item | Item
# PEG:
List <- Item (',' Item)*
```

### Indirekte Linksrekursion auflösen

```peg
# Beide rufen sich gegenseitig links:
# A -> B 'x'
# B -> A 'y'
# Das ist genauso verboten wie direkte Linksrekursion.

# Auflösung: in eine gemeinsame iterative Form bringen oder
# das Grammatik-Design ueberdenken (oft Zeichen eines Modell-Problems).
```

## Identifier vs. Keyword

Ein klassischer Konflikt: `if` ist Keyword, aber `iframe` ist
Identifier. Naiv:

```peg
# FALSCH: matcht 'if' in 'iframe' und kommt durcheinander
Keyword    <- 'if' / 'while' / 'return'
Identifier <- [a-zA-Z_] [a-zA-Z_0-9]*
Statement  <- Keyword / Identifier
```

Lösung: **negativer Lookahead auf das nächste Zeichen.**

```peg
# Keyword nur, wenn DANACH kein Identifier-Zeichen folgt
Keyword    <- ('if' / 'while' / 'return') !IdentChar
Identifier <- !Keyword IdentStart IdentChar*

IdentStart <- [a-zA-Z_]
IdentChar  <- [a-zA-Z_0-9]
```

Jetzt schlägt `Keyword` auf `iframe` fehl (`!IdentChar` matcht nicht,
weil `r` ein IdentChar ist), und `Identifier` kommt zum Zug.

Das `!Keyword` in `Identifier` ist ein weiterer Wächter, damit `if` für
sich allein **nicht** als Identifier durchgeht.

## Number-, String- und Identifier-Literale

### Zahl mit Vorzeichen und Dezimalpunkt

```peg
Number    <- '-'? Integer ('.' Digit+)? Exponent?
Integer   <- '0' / [1-9] Digit*
Digit     <- [0-9]
Exponent  <- ('e' / 'E') ('+' / '-')? Digit+
```

Die Reihenfolge `'0' / [1-9] Digit*` verhindert führende Nullen (außer
für `0` selbst). Wer das nicht braucht: `Integer <- Digit+`.

### String mit Escape-Sequenzen

```peg
String <- '"' (Escape / NonEscape)* '"'

Escape    <- '\\' ('"' / '\\' / 'n' / 't' / 'r' / 'u' Hex Hex Hex Hex)
NonEscape <- !('"' / '\\') .
Hex       <- [0-9a-fA-F]
```

Das `NonEscape <- !('"' / '\\') .` ist das Standard-Pattern für "ein
beliebiges Zeichen, aber nicht diese hier". Beachte das `.` am Ende --
ohne das würde der negative Lookahead nichts konsumieren.

### Identifier

```peg
Identifier <- !Keyword IdentStart IdentChar*
IdentStart <- [a-zA-Z_]
IdentChar  <- [a-zA-Z_0-9]
```

Für Unicode-Identifier (wer das braucht) muss man die Zeichenklassen
entsprechend erweitern -- in PEG meist über explizite
Code-Point-Bereiche oder eine Hilfsregel im Generator.

## Listen mit Separator

### Mit erzwungenem Element zwischen Trennern

```peg
# Mindestens ein Element
List <- Item (',' Item)*

# Komma-optional am Ende erlaubt:
List <- Item (',' Item)* ','?

# Komma am ANFANG (selten, aber kommt vor):
List <- ',' Item / Item (',' Item)*
```

### Leerlisten erlauben

```peg
# Liste darf leer sein
List <- (Item (',' Item)*)?
```

### Trailing Separator vs. obligatorischer Abschluss

JSON-Arrays erlauben kein trailing Comma:

```peg
JsonArray <- '[' Spacing (Element (',' Spacing Element)*)? Spacing ']'
```

Manche DSLs wollen es ausdrücklich:

```peg
ArrayLit  <- '[' Spacing Items? ']'
Items     <- Element (',' Spacing Element)* ','? Spacing
```

## Optionaler Block, dessen Inhalt Pflicht ist

```peg
# Block in Klammern; Klammern optional, aber wenn da, dann mit Inhalt
Block <- '{' Spacing Statements '}' / Statement

# Optionaler else-Zweig
IfStmt <- 'if' Cond Then ('else' Else)?
```

## Mehrzeilige Strukturen mit klarem Abschluss

```peg
# Heredoc-artig: <<TAG ... TAG
Heredoc   <- '<<' Tag EOL Body EndTag
Tag       <- [A-Z]+
Body      <- (!EndTag .)*
EndTag    <- EOL Tag EOL    # gleicher Tag wie oeffnend -- zur Laufzeit pruefen
```

PEG kann den Tag-Match zur Generationszeit nicht erzwingen (das ist
kontextsensitiv). Klassische Praxis: parsen mit generischem Tag,
Gleichheit im AST-Walk prüfen.

## Lookahead-Tricks

### "Bis hier, aber nicht inklusive"

```peg
Body <- (!Terminator .)*
```

Konsumiert beliebige Zeichen, solange `Terminator` nicht ansteht.
`Terminator` wird **nicht** konsumiert -- die Folgeregel sieht ihn.

### "Nur wenn danach X kommt"

```peg
# Funktion: Aufruf ist Ident gefolgt von '('. Variable ist Ident ohne '('.
Call     <- Identifier &'('
VarRef   <- Identifier !'('
Primary  <- Call '(' Args ')' / VarRef
```

### Reihenfolge bei Alternative-Mehrdeutigkeit

```peg
# Floatpunkt-Zahl vs. Integer: laenger zuerst
Number <- Float / Integer
Float  <- [0-9]+ '.' [0-9]+
Integer <- [0-9]+
```

Wäre `Integer` zuerst, würde es bei `3.14` nur `3` matchen, das `.14`
bliebe übrig und scheiterte. Die geordnete Alternative bedeutet:
**längere/spezifischere Variante zuerst**, immer.

## Capture-Konventionen

Verschiedene PEG-Tools (pegjs, Lua-LPeg, `pt::pgen`) haben eigene
Capture-Syntax (`< … >`, `{}`, Funktion-Tags). In `pt::pgen` erzeugen
**alle** benannten Regeln Knoten im Parse-Tree; man steuert die Form
nicht in der Grammatik, sondern beim AST-Walk
(siehe [peg-ast.md](peg-ast.md)).

Eine generische Konvention zur Übersicht (nicht tcllib-spezifisch):

```peg
# Schicht 1: Roh-Grammatik mit ALLEN Regeln benannt
Expression <- Term (Op Term)*
Op         <- '+' / '-'
Term       <- Number
Number     <- [0-9]+
```

Daraus baut der AST-Walk:

```
{Add
   {Number 12}
   {Number 7}
   {Number 3}}
```

statt der naiven Parse-Tree-Form:

```
{Expression
   {Term {Number 12}}
   {Op +}
   {Term {Number 7}}
   {Op -}
   {Term {Number 3}}}
```

## Fehlertoleranz und Diagnose

PEG-Parser scheitern bei der **ersten** Regel, die nicht matcht.
Diagnose-Output kommt nicht automatisch -- man muss ihn einbauen.

### Synchronisationspunkt nach Fehler

```peg
# Statement-Liste, die einzelne kaputte Statements ueberspringt
Stmts     <- (Stmt / BadStmt)*
Stmt      <- ValidStmt
BadStmt   <- (!StmtTerminator .)* StmtTerminator   # bis zum naechsten ';' weg
```

Das ist eine grobe "panic-mode recovery". Echte Fehlermeldungs-Qualität
braucht hand-geschriebene Logik im Walk -- automatisch geht es nicht.

### Pflicht-Tokens markieren

Manche PEG-Tools haben `~` oder `^` als "ab hier kein Backtracking
mehr". `pt::pgen` hat das **nicht**. Workaround: Pflicht-Regel
trotzdem matchen, später im AST eine Validation.

## Häufige Fehler (Kurzübersicht)

1. **Vergessenes `Spacing`** zwischen Tokens -- Whitespace ist nicht
   implizit.
2. **`(!X .)*` mit vergessenem `.`** -- der Lookahead `!X` konsumiert
   nichts; ohne `.` verhungert die Schleife.
3. **Alternative falsch geordnet** -- spezifischere/längere Variante
   zuerst. `Float / Integer`, nicht umgekehrt.
4. **Keyword ohne Boundary** -- `'if'` matcht in `iframe`. Mit
   `!IdentChar` absichern.
5. **Greedy verschluckt Abschluss** -- `'/*' .* '*/'` matcht zu viel;
   `(!'*/' .)*` ist das richtige Pattern.
6. **Linksrekursion** -- iterativ umschreiben.
7. **Kein `!.`** am Grammatik-Ende -- Trailing-Müll wird stillschweigend
   akzeptiert.
8. **Rechtsassoziativ falsch geschrieben** -- die rekursive Alternative
   muss **vor** der Basisform stehen: `Ident '=' Assign / Or`, nicht
   umgekehrt.

## Praxis-Muster

### Grammatik schichtweise aufbauen

Erst Lexikalisches (Number, String, Ident, Spacing), dann Atome, dann
Operator-Precedence-Schichten, am Schluss die Top-Regel mit `!.`. Jede
Schicht testbar machen, bevor die nächste dazukommt.

### Tests pro Regel

Eine Test-Eingabe pro Regel, die nur **diese** Regel triggert. Erst
wenn `Number`, `String`, `Ident` einzeln gehen, dann `Atom`, dann
`Expression`. Spart Stunden Debugging.

### Pretty-Print des Parse-Trees

Vor dem AST-Walk den rohen Parse-Tree formatiert ausgeben. Tcl:
`set tree [$parser parset $src]; puts [::tcl::Indent $tree]` (oder
selbstgeschriebener Indent). Zeigt sofort, ob die Grammatik anders
strukturiert als gedacht.

### Grammatik-Tools, nicht Texteditor

Generierte Parser sind groß. Grammatik selbst klein und versioniert.
Wer per Hand am generierten Parser editiert, hat verloren.

## Siehe auch

- [peg-landschaft.md](peg-landschaft.md) -- Vergleich zu anderen
  Parser-Generator-Werkzeugen.
- [peg-grundlagen.md](peg-grundlagen.md) -- Was ist PEG, Syntax,
  Vergleich zu Regex/CFG.
- [peg-tcllib.md](peg-tcllib.md) -- konkrete Nutzung mit `pt::pgen`
  aus tcllib.
- [peg-ast.md](peg-ast.md) -- vom Parse-Tree zum normalisierten AST.
- [regexp-und-regsub.md](../Tcl/regexp-und-regsub.md) -- für
  Fälle, in denen Regex ausreicht.
