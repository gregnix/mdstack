# PEG -- Vom Parse-Tree zum AST

*Stand: 2026-05-29*

Ein PEG-Parser liefert einen **Parse-Tree**: 1:1-Abbild der
Grammatik-Regeln. Was Programme tatsächlich verarbeiten wollen, ist
ein **AST** (Abstract Syntax Tree): semantisch normalisiert, redundante
Hülle entfernt, Operator-Knoten statt flacher Listen. Dieser Artikel
zeigt, wie man von ersterem zum letzteren kommt.

Voraussetzung: Parse-Tree-Format aus
[peg-tcllib.md](peg-tcllib.md), Grammatik-Patterns aus
[peg-grammatik-patterns.md](peg-grammatik-patterns.md).

## Parse-Tree vs. AST -- der Unterschied

Beispiel: `1 + 2 - 3` mit der iterativen Add-Regel
`Expression <- Term (('+' / '-') Term)*`.

Parse-Tree (so liefert es der Generator):

```
{Expression 0 9
   {Term 0 1 {Number 0 1}}
   {Term 4 5 {Number 4 5}}
   {Term 8 9 {Number 8 9}}}
```

Beachte: Das `+` und das `-` sind **weg**. Die Term-Wrapper sind **da**,
aber strukturell nutzlos. Drei Werte (1, 2, 3) auf gleicher Ebene --
welche Operation zwischen welchen?

Mehrere Probleme auf einmal:

1. **Operator-Information verloren** -- `+` und `-` werden nicht
   unterschieden.
2. **Term-Wrapper redundant** -- jedes Term enthält genau ein Number.
3. **Flach statt links-assoziativ** -- für Auswertung muss `(1+2)-3`
   draus werden, nicht eine 3-Element-Liste.

Der gewünschte AST:

```
{Sub
   {Add
      {Num 1}
      {Num 2}}
   {Num 3}}
```

Strukturell linksassoziativ, Operatoren typisiert, Wrapper weg.

## Strategie: Walker, der den Tree normalisiert

Standard-Pattern: Eine Walker-Klasse mit einer Methode pro Regel,
die rekursiv den Tree durchläuft und neue Knoten baut.

```tcl
oo::class create AstBuilder {
    variable Src    ;# der Quelltext, fuer Substring-Extraktion

    constructor {source} { set Src $source }

    method build {node} {
        lassign $node tag begin end
        set children [lrange $node 3 end]
        my Visit_$tag $begin $end $children
    }

    # Eine Visit-Methode pro Regel
    method Visit_Expression {begin end children} {
        # erstes Kind ist erster Term, weitere abwechselnd (Op,Term)
        # ... siehe naechster Abschnitt
    }

    method Visit_Number {begin end children} {
        # Wert aus dem Source-Substring lesen
        return [list Num [string range $Src $begin $end]]
    }
}
```

Das Pattern: `Visit_<RuleName>` als Methoden-Namens-Konvention,
`build` als Dispatcher. Tcl's `unknown` oder `forward` würde auch
gehen, aber explizite Methoden sind leichter zu debuggen.

## Pattern 1: Unwrap einer 1-Kind-Regel

Wenn eine Regel **genau ein Kind** hat und keine eigene Semantik, kann
sie unwrapped werden.

```peg
Term <- Factor
```

Im Parse-Tree erscheint `{Term ... {Factor ...}}`. Im AST will man
direkt das `Factor`-Ergebnis.

```tcl
method Visit_Term {begin end children} {
    # Term wrappt nur ein einzelnes Factor -- transparent durchreichen
    return [my build [lindex $children 0]]
}
```

Tritt sehr oft auf -- die Operator-Precedence-Schichten der Grammatik
führen zu vielen Einzel-Kind-Wrappern, wenn der Operator nicht gebraucht
wird.

## Pattern 2: Operator-Sequenz zu links-assoziativem Baum

Das wichtigste AST-Pattern überhaupt. Aus
`Term (Op Term)*` einen left-fold bauen:

```tcl
method Visit_Expression {begin end children} {
    # Erstes Kind: erster Term
    set result [my build [lindex $children 0]]

    # Restliche Kinder paarweise: (Op, Term), (Op, Term), ...
    # ABER: im Parse-Tree von pt::pgen sind Operatoren oft NICHT
    # als Knoten enthalten (siehe peg-tcllib.md). Wir muessen sie
    # entweder als Regeln benennen ODER aus dem Source-Substring lesen.

    foreach {opNode termNode} [lrange $children 1 end] {
        lassign $opNode opTag opBegin opEnd
        set op [string range $Src $opBegin $opEnd]
        set right [my build $termNode]
        switch -- $op {
            "+" { set result [list Add $result $right] }
            "-" { set result [list Sub $result $right] }
            default { error "unknown op: $op" }
        }
    }
    return $result
}
```

Dazu muss die Grammatik den Operator als **eigene Regel** haben (damit
er im Parse-Tree erscheint):

```peg
Expression <- Term (AddOp Term)*;
AddOp      <- '+' / '-';
Term       <- ... ;
```

Ohne benannte `AddOp`-Regel kommt der Operator nicht im Tree an -- dann
müsste man ihn aus dem Source-Substring zwischen den Terms lesen, was
unsauber ist.

## Pattern 3: Listen flachklopfen

```peg
List <- Item (',' Item)*;
```

Parse-Tree (mit `Item` als benannter Regel, `,` als Literal):

```
{List 0 9
   {Item 0 1}
   {Item 3 4}
   {Item 6 7}}
```

Direkt flach -- gut so. Walker:

```tcl
method Visit_List {begin end children} {
    set items {}
    foreach c $children {
        lappend items [my build $c]
    }
    return [list ListAst {*}$items]
}
```

Wenn der Operator **doch** als Knoten in den Kindern auftaucht (weil
als Regel benannt), muss man die Komma-Knoten filtern:

```tcl
method Visit_List {begin end children} {
    set items {}
    foreach c $children {
        lassign $c tag _b _e
        if {$tag eq "Item"} {
            lappend items [my build $c]
        }
        # Comma-Knoten ignoriert
    }
    return [list ListAst {*}$items]
}
```

## Pattern 4: Terminale aus dem Source-String extrahieren

PEG-Regeln, die nur Zeichen matchen (`Number <- [0-9]+`), erscheinen
im Tree als `{Number begin end}` **ohne Kinder**. Den Wert muss man
aus dem Source-String lesen:

```tcl
method Visit_Number {begin end children} {
    set lexeme [string range $Src $begin $end]
    if {[string match {*.*} $lexeme]} {
        return [list Num [expr {double($lexeme)}]]
    } else {
        return [list Num [expr {int($lexeme)}]]
    }
}

method Visit_Identifier {begin end children} {
    return [list Ident [string range $Src $begin $end]]
}
```

Beachte das `inklusiv-inklusiv`-Format von begin/end: `string range`
arbeitet genauso (im Gegensatz zu Python's exclusive-end-Konvention).

## Pattern 5: Klammer-Ausdrücke transparent

```peg
Factor <- Number / '(' Expression ')';
```

Mit Klammern bekommt man im Tree `{Factor ... {Expression ...}}`.
Die Klammern selbst sind Literale und nicht im Tree. Walker:

```tcl
method Visit_Factor {begin end children} {
    # Egal ob Number oder geklammerter Expression: das einzige Kind
    # ist der Wert -- durchreichen.
    return [my build [lindex $children 0]]
}
```

## Pattern 6: Rechtsassoziativ

```peg
Assign <- Ident '=' Assign / Or;
```

Bei `a = b = c` ergibt das geschachtelt nach rechts. Walker:

```tcl
method Visit_Assign {begin end children} {
    # Wenn 2 Kinder: links Ident, rechts wieder Assign
    # Wenn 1 Kind:   nur Or (kein Zuweisungs-Operator vorhanden)
    if {[llength $children] == 1} {
        return [my build [lindex $children 0]]
    }
    set lhs [my build [lindex $children 0]]
    set rhs [my build [lindex $children 1]]
    return [list Assign $lhs $rhs]
}
```

Die Kinder kommen schon richtig geschachtelt aus dem Parser; man muss
nichts umsortieren.

## Pattern 7: Optionale Elemente

```peg
IfStmt <- 'if' Cond Then ('else' Else)?;
```

Im Parse-Tree erscheint das optionale `Else` nur, wenn da. Walker:

```tcl
method Visit_IfStmt {begin end children} {
    # Erstes Kind: Cond. Zweites: Then. Drittes optional: Else.
    set cond [my build [lindex $children 0]]
    set then [my build [lindex $children 1]]
    if {[llength $children] >= 3} {
        set els [my build [lindex $children 2]]
        return [list If $cond $then $els]
    }
    return [list If $cond $then]
}
```

## Vollständiges Beispiel: Rechner-AST

Grammatik:

```peg
PEG calc (Calc)

Calc       <- Spacing Expression Spacing EOI;
Expression <- Term (Spacing AddOp Spacing Term)*;
Term       <- Factor (Spacing MulOp Spacing Factor)*;
Factor     <- Number / '(' Spacing Expression Spacing ')';
AddOp      <- '+' / '-';
MulOp      <- '*' / '/';
Number     <- <ddigit>+ ('.' <ddigit>+)?;
Spacing    <- (' ' / '\t' / '\n' / '\r')*;
EOI        <- !.;

END;
```

Walker:

```tcl
oo::class create CalcAst {
    variable Src

    constructor {source} { set Src $source }

    method build {node} {
        lassign $node tag begin end
        set children [lrange $node 3 end]
        return [my Visit_$tag $begin $end $children]
    }

    method Visit_Calc {begin end children} {
        # Calc wrappt nur Expression -- durchreichen
        return [my build [lindex $children 0]]
    }

    method Visit_Expression {begin end children} {
        set result [my build [lindex $children 0]]
        foreach {opNode termNode} [lrange $children 1 end] {
            set op [my OpFromNode $opNode]
            set right [my build $termNode]
            set tag [expr {$op eq "+" ? "Add" : "Sub"}]
            set result [list $tag $result $right]
        }
        return $result
    }

    method Visit_Term {begin end children} {
        set result [my build [lindex $children 0]]
        foreach {opNode factorNode} [lrange $children 1 end] {
            set op [my OpFromNode $opNode]
            set right [my build $factorNode]
            set tag [expr {$op eq "*" ? "Mul" : "Div"}]
            set result [list $tag $result $right]
        }
        return $result
    }

    method Visit_Factor {begin end children} {
        return [my build [lindex $children 0]]
    }

    method Visit_Number {begin end children} {
        set lexeme [string range $Src $begin $end]
        if {[string match {*.*} $lexeme]} {
            return [list Num [expr {double($lexeme)}]]
        }
        return [list Num [expr {int($lexeme)}]]
    }

    method Visit_AddOp {begin end children} {
        return [string range $Src $begin $end]
    }
    method Visit_MulOp {begin end children} {
        return [string range $Src $begin $end]
    }

    # Hilfsroutine: Operator-Zeichen aus AddOp/MulOp-Knoten ziehen
    method OpFromNode {node} {
        lassign $node _ begin end
        return [string range $Src $begin $end]
    }
}
```

Benutzung:

```tcl
package require calc

set src "1 + 2 * 3 - 4"
set p [CalcParser new]
set tree [$p parset $src]
$p destroy

set ast [[CalcAst new $src] build $tree]
puts $ast
# -> {Sub {Add {Num 1} {Mul {Num 2} {Num 3}}} {Num 4}}
```

Linksassoziativ (`-` bindet weniger als `+/-`, aber `+` und `-` sind
gleich-präzedent und werden links-assoziativ verkettet), Operator-Knoten
typisiert, Klartext-Werte als Zahlen.

## Häufige Fehler (Kurzübersicht)

1. **Inverted nesting** -- klassischer Bug: bei iterativer
   Operator-Auswertung den Akkumulator falsch herum zusammenbauen
   (`{Op right left}` statt `{Op left right}`), oder den Akkumulator
   nicht durch die Schleife reichen. Linksassoziativ ist
   `acc op right`-Pattern, nicht `right op acc`.
2. **Operator-Information verloren** -- wenn der Operator im
   Parse-Tree nicht als eigener Knoten auftaucht (kein benannter Regel),
   landet man beim Source-Substring-Lesen. Lieber explizit als Regel:
   `AddOp <- '+' / '-';`.
3. **Wrapper-Knoten nicht unwrapped** -- der AST behält jeden
   Term/Factor/Expression-Wrapper. Macht den AST riesig und Auswertung
   mühsam. Konsequent `Visit_X` als Durchreich-Methode bei 1-Kind-Regeln.
4. **`begin`/`end` als exclusive-end interpretiert** -- in `pt::pgen`
   sind beide inklusiv. `string range $src $begin $end` liefert genau
   den Match-String.
5. **Whitespace-/Spacing-Knoten nicht gefiltert** -- wenn `Spacing` als
   benannte Regel im Tree erscheint, muss der Walker das überspringen,
   sonst gibt's leere AST-Knoten. Praxis: `Spacing` nicht im
   Children-Filter auftauchen lassen, oder explizit ignorieren.
6. **Rechtsassoziativ vs. linksassoziativ vertauscht** -- klassisch
   verwechselt bei Pow/Assign. Test: `2 ** 3 ** 4` muss `2 ** (3 ** 4)`
   ergeben (rechts), `2 - 3 - 4` muss `(2 - 3) - 4` ergeben (links).
7. **Lazy default-Argument-Bindung** in Visit-Methoden -- die typische
   Tcl-Falle (`[lambda ...]` bei Closures), bei Walker-Klassen aber
   nicht relevant, da Methoden explizit sind.

## Praxis-Muster

### Walker testbar machen

```tcl
test ast-add {Simple addition} {
    set src "1 + 2"
    set p [CalcParser new]
    set tree [$p parset $src]
    $p destroy
    [CalcAst new $src] build $tree
} -result {Add {Num 1} {Num 2}}

test ast-assoc {Left-associative subtraction} {
    set src "10 - 3 - 4"
    set p [CalcParser new]
    set tree [$p parset $src]
    $p destroy
    [CalcAst new $src] build $tree
} -result {Sub {Sub {Num 10} {Num 3}} {Num 4}}
```

Pro Regel mindestens ein Test. Den AST als Tcl-Liste vergleichen ist
trivial.

### AST evaluieren

Sobald der AST stimmt, ist die Auswertung ein simpler Visitor:

```tcl
oo::class create CalcEval {
    method eval {node} {
        lassign $node tag
        my Eval_$tag {*}[lrange $node 1 end]
    }

    method Eval_Num {value} { return $value }
    method Eval_Add {l r}   { return [expr {[my eval $l] + [my eval $r]}] }
    method Eval_Sub {l r}   { return [expr {[my eval $l] - [my eval $r]}] }
    method Eval_Mul {l r}   { return [expr {[my eval $l] * [my eval $r]}] }
    method Eval_Div {l r}   {
        set right [my eval $r]
        if {$right == 0} { error "division by zero" }
        return [expr {[my eval $l] / double($right)}]
    }
}

set v [[CalcEval new] eval $ast]
```

Klar getrennte Phasen: **Parse → AST → Eval**. Jede Phase einzeln
debuggbar und testbar.

### AST-Format konventionalisieren

Empfehlung: Knoten als `{TYPE args...}` mit fester Konvention:

- Erstes Element: Tag (Klein- oder Großschreibung konsistent).
- Restliche Elemente: typabhängig, aber pro Tag fest.

Beispiele:

```tcl
{Num 42}
{Ident foo}
{Add {Num 1} {Num 2}}
{Call funcname {Args {Num 1} {Num 2}}}
{If condition then else}
```

Optional ein Source-Range als zweites Element für Fehlerdiagnose:

```tcl
{Num {0 1} 42}
{Add {0 5} {Num {0 1} 1} {Num {4 5} 2}}
```

Macht Lookups langsamer und Tests mühsam -- nur einbauen, wenn
Fehlermeldungen mit Position wirklich gebraucht werden.

## Siehe auch

- [peg-landschaft.md](peg-landschaft.md) -- die Werkzeug-Landschaft
  rund um PEG.
- [peg-grundlagen.md](peg-grundlagen.md) -- die PEG-Syntax.
- [peg-grammatik-patterns.md](peg-grammatik-patterns.md) -- Patterns für
  die Grammatik selbst.
- [peg-tcllib.md](peg-tcllib.md) -- `pt::pgen` und Parse-Tree-Format.
- [tcloo.md](../Tcl/tcloo.md) -- das OO-System, das Walker-Klassen
  typisch nutzen.

## Referenzen

- `pt::ast` in tcllib (Helper für AST-Manipulation) -- für komplexere
  Walks; im einfachen Fall reicht die selbstgeschriebene Walker-Klasse.
- Ford/Adams, *PEG-based transformer patterns* -- die zugrundeliegenden
  AST-Idiome stammen aus der allgemeinen Compiler-Literatur.
