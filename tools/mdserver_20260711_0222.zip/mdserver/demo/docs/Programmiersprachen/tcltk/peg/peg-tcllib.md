# PEG -- `pt::pgen` aus tcllib

*Stand: 2026-05-29*

`pt::pgen` ist der **PEG-Parser-Generator** aus tcllib (Tcl Library).
Eingabe: eine PEG-Grammatik. Ausgabe: eine Tcl-Klasse, die diese
Grammatik parst. Dieser Artikel zeigt den praktischen Workflow. Die
Grammatik-Syntax selbst steht in
[peg-grundlagen.md](peg-grundlagen.md), die Patterns in
[peg-grammatik-patterns.md](peg-grammatik-patterns.md).

## Das `pt`-Paketfamilie -- Überblick

Tcllib bringt eine ganze Familie von "Parser Tools" mit, alle unter dem
`pt::*`-Namespace:

| Paket | Zweck |
|---|---|
| `pt::pgen` | **Der Generator**: Grammatik → Tcl-Parser-Klasse. |
| `pt::peg` | In-Memory-Repräsentation einer PEG-Grammatik. |
| `pt::peg::from::peg` | Parser für PEG-Quelltext selbst (Bootstrapping). |
| `pt::peg::to::tclparam` | Generiert Tcl-Parser-Code. |
| `pt::ast` | AST-Knoten-Helper (siehe [peg-ast.md](peg-ast.md)). |
| `pt::rde` | "Runtime Data Engine" -- Laufzeit-Basis der generierten Parser. |

Im Alltag braucht man **`pt::pgen`** zum Generieren und **`pt::rde`**
indirekt (wird automatisch geladen). Der Rest ist Innenleben oder für
fortgeschrittene Anwendungen.

```tcl
package require pt::pgen
```

## Grammatik-Syntax in `pt::pgen`

`pt::pgen` versteht eine konkrete PEG-Syntax mit ein paar
tcllib-spezifischen Konventionen:

```peg
PEG calc (Calc)

Calc       <- Spacing Expression Spacing EOI    ;
Expression <- Term (Spacing AddOp Spacing Term)*;
Term       <- Factor (Spacing MulOp Spacing Factor)*;
Factor     <- Number / '(' Spacing Expression Spacing ')';
AddOp      <- '+' / '-';
MulOp      <- '*' / '/';
Number     <- <ddigit>+ ('.' <ddigit>+)?;
Spacing    <- (' ' / '\t' / '\n' / '\r')*;
EOI        <- !.;

END;
```

Besonderheiten gegenüber generischer PEG:

- **Header-Zeile**: `PEG <name> (<startSymbol>)`. Der Startsymbol-Name
  muss eine der definierten Regeln sein.
- **Regel-Trennung**: jede Regel endet mit Semikolon `;`.
- **Block-Ende**: das ganze Grammatik-Skript endet mit `END;`.
- **Vordefinierte Zeichenklassen** in spitzen Klammern:
  `<ddigit>` (Dezimalziffer), `<alpha>`, `<alnum>`, `<wordchar>`,
  `<lower>`, `<upper>`, `<space>`, `<punct>`, … (entspricht den
  POSIX-Klassen). Eigene Klassen weiter mit `[...]`.
- **String-Literale**: `'...'` und `"..."` -- in der Praxis austauschbar.

## Workflow: Grammatik → Parser-Klasse

### Schritt 1: Grammatik in Datei

```peg
# calc.peg
PEG calc (Calc)

Calc       <- Spacing Expression Spacing EOI;
Expression <- Term (Spacing AddOp Spacing Term)*;
Term       <- Factor (Spacing MulOp Spacing Factor)*;
Factor     <- Number / '(' Spacing Expression Spacing ')';
AddOp      <- '+' / '-';
MulOp      <- '*' / '/';
Number     <- <ddigit>+ ('.' <ddigit>+)?;
Spacing    <- (' ' / '\t' / '\n' / '\r')*;
EOI        <- !.;

END;
```

### Schritt 2: Generieren

```tcl
package require pt::pgen

set fd [open calc.peg r]
set grammar [read $fd]
close $fd

set parserCode [pt::pgen peg $grammar oo \
    -class CalcParser -package calc -version 0.1]

set fd [open calc-0.1.tm w]
puts $fd $parserCode
close $fd
```

`pt::pgen` nimmt vier Hauptargumente:

| Argument | Bedeutung |
|---|---|
| `peg` | Eingabeformat (immer `peg` für PEG-Quelltext). |
| `$grammar` | Der Grammatik-String. |
| `oo` oder `snit` | **Backend** (siehe unten). |
| Optionen | `-class`, `-package`, `-version`. |

### Schritt 3: Parser benutzen

```tcl
package require calc 0.1
set p [CalcParser new]
set tree [$p parset "1 + 2 * (3 - 4)"]
$p destroy

puts $tree
```

Output (gekürzt):

```
{Calc 0 17
   {Expression 0 17
      {Term 0 1
         {Number 0 1}}
      {AddOp 2 2}
      {Term 4 17
         {Number 4 5}
         {MulOp 6 6}
         {Factor 8 17
            {Expression 9 16
               {Term 9 10 {Number 9 10}}
               {AddOp 11 11}
               {Term 13 16 {Number 13 14}}}}}}}
```

Jeder Knoten ist eine Tcl-Liste: `{NAME BEGIN END child1 child2 ...}`.
`BEGIN`/`END` sind Zeichen-Offsets im Quellstring (inklusiv-inklusiv).

## Die zwei Backends: `snit` und `oo`

`pt::pgen` kann zwei verschiedene Klassen-Stile erzeugen:

### `snit`-Backend

```tcl
set code [pt::pgen peg $grammar snit -class CalcParser -package calc -version 0.1]
```

- Basiert auf [snit](https://core.tcl-lang.org/tcllib/doc/trunk/embedded/md/tcllib/files/modules/snit/snit.md),
  Tcl's "Snit Not Incr Tcl"-OO-System.
- Älter, sehr stabil, ausgereift.
- Hat die `snit`-Konventionen: `Class create instname`, `instname method`.
- Performance ist OK, aber spürbar langsamer als `oo`.

### `oo`-Backend

```tcl
set code [pt::pgen peg $grammar oo -class CalcParser -package calc -version 0.1]
```

- Basiert auf **TclOO** (das eingebaute Tcl-OO seit 8.6).
- Moderner, schneller (Bytecode-näher), kleinerer Code-Footprint.
- `Class new` statt `Class create instname` (oder beides möglich).

Praktische Empfehlung: **`oo`-Backend**, außer es gibt explizit
Gründe für `snit` (Legacy-Codebasis, externe Erwartungen).

### Unterschiede im generierten Output

Die Klassenstruktur unterscheidet sich:

```tcl
# oo-Backend
oo::class create CalcParser {
    superclass ::pt::rde::oo
    method parset { text } { ... }
    method parse  { channel } { ... }
}

# snit-Backend
snit::type ::CalcParser {
    component myparser
    method parset { text } { ... }
}
```

Aufruf-Konvention ist nahezu identisch (`parset $text`, `parse $chan`).
Unterschiede sind beim Erweitern: bei `oo` kann man Methoden via
`oo::define` nachladen; bei `snit` nutzt man `snit::macro` oder
Komposition.

## Parser-Methoden

Eine generierte Parser-Klasse hat (mindestens):

| Methode | Beschreibung |
|---|---|
| `parset $string` | Parst einen In-Memory-String, gibt Parse-Tree zurück. |
| `parse $channel` | Parst von einem Tcl-Channel (file, socket, …). |
| `destroy` | Räumt die Instanz auf. |

Bei Parse-Fehlern wirft `parset` einen Tcl-Error mit Position und
erwartetem Token:

```
pt::rde -- parse error: at position 5, expected {... irgendwas ...}
```

Die Fehlermeldungen sind generisch; für gute Diagnose muss man im
AST-Walk Klartext erzeugen.

## Komplettes Mini-Projekt: Rechner

```tcl
# 1) Grammatik
set grammar {
PEG calc (Calc)

Calc       <- Spacing Expression Spacing EOI;
Expression <- Term (Spacing AddOp Spacing Term)*;
Term       <- Factor (Spacing MulOp Spacing Factor)*;
Factor     <- Number / '(' Spacing Expression Spacing ')';
AddOp      <- '+' / '-';
MulOp      <- '*' / '/';
Number     <- <ddigit>+ ('.' <ddigit>+)?;
Spacing    <- (' ' / '\t' / '\n' / '\r')*;
EOI        <- !.;

END;
}

# 2) Parser generieren (zur Laufzeit oder einmalig in eine .tm)
package require pt::pgen
set parserCode [pt::pgen peg $grammar oo \
    -class CalcParser -package calc -version 0.1]

# 3) Einspielen (im Beispiel direkt evaluieren -- in der Praxis in eine Datei)
eval $parserCode

# 4) Benutzen
set p [CalcParser new]
set tree [$p parset "1 + 2 * 3"]
$p destroy

puts $tree
# -> {Calc 0 9 {Expression 0 9
#       {Term 0 1 {Number 0 1}}
#       {AddOp 2 2}
#       {Term 4 9
#          {Number 4 5}
#          {MulOp 6 6}
#          {Number 8 9}}}}
```

Den eigentlichen Wert zu berechnen ist der **AST-Schritt** -- siehe
[peg-ast.md](peg-ast.md).

## Parse-Tree-Format im Detail

```
{RuleName BeginPos EndPos
    {ChildRule BeginPos EndPos ...}
    {ChildRule BeginPos EndPos ...}
    ...}
```

- **RuleName**: Name der PEG-Regel, **als String** (nicht zitiert).
- **BeginPos**, **EndPos**: Zeichenposition (0-basiert, beide
  inklusive). `EndPos = BeginPos - 1` für leere Matches.
- **Kinder**: jedes Kind ist selbst ein Knoten mit derselben Form.
  Terminale erscheinen **nicht** als eigene Knoten -- nur benannte
  Regeln.

### Beispiel: was im Tree erscheint, was nicht

```peg
List <- '[' Spacing Item (Spacing ',' Spacing Item)* Spacing ']';
Item <- <alpha>+;
```

Für `[a, bb, ccc]` ergibt sich:

```
{List 0 13
   {Item 1 1}
   {Item 4 5}
   {Item 8 10}}
```

Die Klammern, Kommas und Spaces sind **weg** -- weil sie keine
benannten Regeln sind, sondern Literale/inline-Klassen. Sie konsumieren
Eingabe, aber tauchen nicht im Tree auf. Das ist meist gewünscht:
weniger Knoten, klarerer AST.

### Konsequenz: zusätzliche Regeln für Struktur

Wenn man **doch** alle Tokens haben will, muss man sie als Regeln
benennen:

```peg
List       <- LBracket Spacing Items Spacing RBracket;
Items      <- Item (Spacing Comma Spacing Item)*;
LBracket   <- '[';
RBracket   <- ']';
Comma      <- ',';
Item       <- <alpha>+;
```

Dann erscheinen `LBracket`, `Comma`, `RBracket` als Knoten im Tree.
Üblicherweise will man das **nicht** -- der AST wird unübersichtlich.

## Praktische Hinweise

### Generierung als Build-Schritt

Den Parser **einmal** generieren und als `.tm`-Modul versionieren, **nicht**
zur Laufzeit `pt::pgen` aufrufen. `pt::pgen` selbst lädt eine Menge
tcllib-Module; das macht den Startup teuer.

```tcl
# build-parser.tcl -- einmaliger Build-Schritt
package require pt::pgen
set fd [open grammar.peg r]
set grammar [read $fd]
close $fd
set code [pt::pgen peg $grammar oo \
    -class MyParser -package myparser -version 0.1]
set fd [open ../mypkg/myparser-0.1.tm w]
puts $fd $code
close $fd
```

Im Projekt-Repo dann nur `myparser-0.1.tm` versioniert, `grammar.peg`
ist die "Quelle", `build-parser.tcl` regeneriert.

### Test-Eingaben separat halten

```tcl
# tests/parser.test
package require myparser

set parser [MyParser new]

test parse-1 {Number} {
    $parser parset "42"
} -match glob -result "*Number 0 1*"

test parse-2 {Expression with parens} {
    $parser parset "(1+2)"
} -match glob -result "*Expression*Number*Number*"

$parser destroy
```

### Debug: Parse-Tree pretty-printen

Der rohe Tree als eine Zeile ist unlesbar. Einfacher Indent-Helper:

```tcl
proc pp-tree {node {indent 0}} {
    lassign $node tag begin end
    set children [lrange $node 3 end]
    puts "[string repeat {  } $indent]$tag \[$begin..$end\]"
    foreach c $children { pp-tree $c [expr {$indent + 1}] }
}

set p [MyParser new]
pp-tree [$p parset $src]
```

## Häufige Fehler (Kurzübersicht)

1. **Vergessenes `END;`** -- Grammatik-Block braucht den Abschluss.
2. **Fehlende Semikolons hinter Regeln** -- `pt::pgen` ist streng.
3. **Startsymbol nicht im Header** -- `PEG name (StartRule)`; das
   Klammern-Element muss eine definierte Regel sein.
4. **Vordefinierte Klassen falsch geschrieben** -- `<ddigit>`,
   **nicht** `<digit>`. tcllib-Konvention.
5. **`pt::pgen` zur Laufzeit aufrufen** statt einmalig zu generieren --
   lädt halb-tcllib, langsamer Startup.
6. **Falsches Backend angenommen** -- `oo` und `snit` haben subtile
   Aufruf-Unterschiede; in der Doku konsistent eines wählen.
7. **Parse-Tree-Format verwechselt** -- erste Position ist `Name`, dann
   zwei Integer (begin, end), dann Kinder. Kein anderes Format.

## Praxis-Muster

### Grammatik in eigenem Repository-Layout

```
repo/
  grammar/
    mygram.peg        # die Quelle
  tools/
    build-parser.tcl  # einmaliger Generator-Aufruf
  mypkg/
    parser-0.1.tm     # generiert -- aber versioniert (Reproduzierbarkeit)
    pkgIndex.tcl
  tests/
    parser.test
```

### Versions-Bump

Wenn die Grammatik sich ändert: Grammar editieren, `tools/build-parser.tcl`
laufen lassen, generierte `.tm` mit neuer Versionsnummer ablegen, alte
löschen. Wie bei normalen Tcl-Modulen (siehe `tm-module.md` im Repo).

### Memoisierung (Packrat) -- nicht im Standard

`pt::pgen`-generierte Parser machen **kein** Packrat-Memoizing. Für
typische DSL-Größen reicht das. Wer es braucht, müsste `pt::rde`
selbst erweitern -- für die meisten Anwendungen nicht nötig.

## Siehe auch

- [peg-landschaft.md](peg-landschaft.md) -- wo `pt::pgen` zwischen
  Yeti, Lemon, ANTLR und hand-geschriebenen Parsern steht.
- [peg-grundlagen.md](peg-grundlagen.md) -- die PEG-Syntax selbst.
- [peg-grammatik-patterns.md](peg-grammatik-patterns.md) --
  Whitespace, Operator-Precedence, Listen, Linksrekursion umschreiben.
- [peg-ast.md](peg-ast.md) -- vom Parse-Tree zum normalisierten AST.
- [tm-module.md](../Tcl/tm-module.md) -- wie man die generierte
  `.tm`-Datei sauber im Modul-Pfad ablegt.
- [tcloo.md](../Tcl/tcloo.md) -- das OO-System hinter dem
  `oo`-Backend.

## Referenzen

- [tcllib `pt`-Paket](https://core.tcl-lang.org/tcllib/doc/trunk/embedded/md/tcllib/files/apps/pt.md)
  -- offizielle Doku zu Parser Tools.
- `pt::pgen` Reference Manual (in tcllib unter `modules/pt/`).
