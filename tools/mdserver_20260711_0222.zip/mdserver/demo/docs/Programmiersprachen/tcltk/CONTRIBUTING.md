# Mitwirkung an mdDoku-tcltk

Diese Detail-Referenz ist eine deutschsprachige API-Sammlung zu
Tcl/Tk-Befehlen und wichtigen Erweiterungen. Korrekturen, Ergänzungen
und neue Artikel sind willkommen.

## Was beigetragen werden kann

### Korrekturen

- Veraltete API-Hinweise (Tcl-Versionen)
- Code-Beispiele die nicht funktionieren
- Tippfehler, sprachliche Glätte
- Umlaut-Inkonsistenzen
- Fehlerhafte Querverweise

### Ergänzungen

- Neue Artikel zu Tcl/Tk-Befehlen oder -APIs
- Plattform-spezifische Hinweise
- Neue Erweiterungen, die in der Tcl-Praxis relevant sind
- Beispiele zu schwierigen API-Stellen

### Was nicht passt

- Lehrbuchartige Tutorial-Texte (dafür gibt es Lehrbuch-Werke)
- Frage-Antwort-Patterns aus konkreten Projekten (das ist Knownhow)
- Werbung für proprietäre Tools
- Sehr nischige Themen ohne Praxis-Bezug

## Charakter-Abgrenzung

mdDoku-tcltk ist eine **API-Referenz**. Die Frage, die jeder Artikel
beantwortet, lautet: **"Wie funktioniert dieser Befehl / dieses
Konzept?"**

Wer dagegen die Frage **"Warum funktioniert mein Code nicht so wie
erwartet?"** beantworten will, sollte ins Knownhow-Werk schreiben.

Wer die Frage **"Wie strukturiere ich meine Anwendung?"** beantwortet,
schreibt in eines der Lehrbücher.

## Stil

mdDoku-tcltk verwendet konsequent:

- **Imperativ und unpersönliche Form**, kein "du" oder "Sie"
- **Kurze, fokussierte Artikel** — ein Artikel = ein Befehl/Thema
- **Direkt nutzbare Code-Beispiele** — keine Pseudocode-Skizzen
- **Echte deutsche Umlaute** (ä, ö, ü) auch in Code-Kommentaren
- **Querverweise** zu verwandten Artikeln

Beispiel für gute Form:

> "`text`-Widget speichert Tags pro Zeichenbereich. Tag-Konfiguration
> über `$w tag configure name -option wert`."

Beispiel für unpassende Form:

> "Wenn du das text-Widget verwendest, kannst du Tags setzen, um
> Bereiche zu markieren..."

## Format

- **Markdown** (CommonMark + GitHub-Tabellen)
- **Code-Blöcke mit Sprach-Hint** (` ```tcl `, ` ```bash `, ` ```c `)
- **Querverweise** als relative Markdown-Links
- **Datums-Stempel** in jedem Artikel: `*Stand: YYYY-MM-DD*` direkt
  unter der H1-Überschrift

## Workflow für Beiträge

1. **Issue eröffnen** für größere Änderungen oder neue Artikel
2. **Pull Request** mit klarer Beschreibung
3. **Eine Sache pro PR** — nicht "Korrektur in 5 Artikeln + neuer Artikel"
   in einem Commit

### Commit-Stil

- Kurze, beschreibende erste Zeile (≤72 Zeichen)
- Bei Bedarf zweiter Absatz mit Begründung

Beispiele:
```
tcltk/Tcl/regexp.md: Tippfehler in Beispiel korrigiert
pdf/pdf4tcl-grundlagen.md: Tcl 9.0-Hinweis ergänzt
nemethi/scrollutil-grundlagen.md: neuer Artikel
```

## Code-Lizenz für Beiträge

Beiträge werden unter den gleichen Bedingungen wie das Hauptwerk
veröffentlicht:

- **Doku-Text:** CC BY-SA 4.0
- **Code-Beispiele:** MIT

Mit dem Pull Request erklären sich Mitwirkende mit dieser
Lizenzierung einverstanden.

## Themen, die noch fehlen

mdDoku-tcltk hat einige Lücken:

- **TLS/SSL** in Tcl (Sockets mit Verschlüsselung)
- **Threading-Patterns** über die Grundlagen hinaus
- **Async-HTTP** (http-Paket im Detail)
- **dde** (Windows Dynamic Data Exchange)
- **Img-Erweiterung** (Bildformate jenseits Tk-Standard)

Beiträge zu diesen Themen sind besonders willkommen.

## Fragen?

Issues sind der richtige Ort für Klärungsfragen.
