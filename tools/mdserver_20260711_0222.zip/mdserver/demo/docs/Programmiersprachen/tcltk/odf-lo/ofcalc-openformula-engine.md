# OpenFormula in Tcl auswerten - ofcalc-Engine: Aufbau & Fallen

*Stand: 2026-06-02*

Wer ODS-Zellen nicht nur **speichert**, sondern auch **ausrechnet**, braucht
eine eigene Auswertungs-Schicht: einen Parser für OpenFormula, einen Evaluator
und einen Recalc über den Abhängigkeitsgraphen. Dieses Dokument sammelt den
Aufbau und die Fallen aus dem Bau der `ofcalc`-Engine (Tcl/TclOO, Parser über
tcllib `pt`), gegengeprüft an einem LibreOffice-Referenzkorpus. Sie alle haben
dieselbe Wurzel:

> **Parsen ≠ auswerten ≠ rechnen wie LibreOffice.**

Eine Formel kann sauber parsen und trotzdem falsch auswerten; oder korrekt
auswerten und sich im LO-Abgleich unterscheiden, weil LO Werte hält, die ofcalc
neu berechnet. Das Dokument ist nach dieser Kette geordnet.

> Geerdet an `ofcalc` 0.1: **791 Funktionsnamen** (750 modern + 41 LO-Legacy),
> Parser aus `grammar/of.peg`, Abgleich gegen **LibreOffice 26.2**.

---

## 0. Drei Schichten - und wer was tut

| Schicht | Aufgabe | Abhängigkeit |
|---------|---------|--------------|
| **odf** | ODF lesen/schreiben; `table:formula` bleibt **String**, Cachewert wird mitgespeichert | keine (Tcl + tdom) |
| **ofcalc** | Parser + Evaluator + Recalc; **Consumer** von ODS-Inhalten | TclOO, tcllib `pt`; optional `odf` |
| **refcorpus** | gemeinsame LO-/OF-Testbasis (Dateien + Expected + Tools) | `odf`, `ofcalc` |

**Wichtig:** `odf` rechnet **nicht**. Es serialisiert die Formel als String und
liest/schreibt den Cachewert. Das Rechnen ist bewusst ausgelagert - es gibt
**keine** zirkuläre Abhängigkeit (`package require ofcalc` steht **nicht** in
`odf`). Integration läuft über den Adapter `ofcalc::odf-adapter` und optional
einen Pfad zum Korpus (`OFCALC_REF_LO`).

---

## 1. Parser-Stack: Grammatik → Parser → AST → Eval

```
grammar/of.peg   --[tools/regen-parser.tcl]-->   parser-0.1.tm   (generiert)
Quelle parsen     -->  Parse-AST  --[ofcalc::ast]-->  Semantik-AST  --[EvalSem]-->  Wert
```

- Die Grammatik liegt projektneutral als PEG vor; der Parser wird **generiert**
  und als Datei `source`d - **nicht** inline `eval`t. (Generierten Code als
  Modul ablegen, regenerieren per Tool, nicht zur Laufzeit zusammenstückeln.)
- Der MVP-Evaluator arbeitet bewusst direkt auf **Grammatik-Namen**
  (`Compare`, `Additive`, `FunCall`, `Reference`) statt auf einer eigenen
  IR-Ebene - pragmatisch, solange keine AST-Transformationen nötig sind.

### Falle: Formel-Strings müssen in Klammern, nicht in Anführungszeichen

Eine OpenFormula-Referenz wie `[.A1]` sieht für Tcl aus wie eine
**Command-Substitution**. In `"…"` wird sie ausgeführt (und scheitert), in
`{…}` bleibt sie wörtlich.

```tcl
# FALSCH: Tcl versucht, [.A1] als Befehl auszuführen
store setFormula B1 "=SUM([.A1:.A10])"

# RICHTIG: geschweifte Klammern -> Formel bleibt wörtlicher String
store setFormula B1 {=SUM([.A1:.A10])}
```

Siehe `tcl-alles-ist-string.md` / `substitution-escaping.md` zur Wurzel des
Problems.

---

## 2. Werte und Typen (`ofcalc::value`)

Werte sind **getaggt**: ein Paar `{kind payload}` (z. B. `{number 42}`,
`{date 46180}`, `{error #DIV/0!}`). Wer den nackten Wert will, muss die Nutzlast
herausziehen - der Tag verschwindet nicht von allein.

```tcl
# =TODAY() liefert keinen blanken Serial, sondern ein getaggtes Paar
set v [eval =TODAY()]      ;# -> {date 46180}
set serial [lindex $v 1]   ;# 46180  (Tag "date" abstreifen)
```

### Falle: Integer ist nicht Boolean

`valueSpec` unterscheidet **Integer** und **Boolean** strikt. Eine Funktion wie
`HOUR`, die `1` zurückgibt, liefert die **Zahl** 1 - **nicht** `true`. Wer im
Test `true`/`false` erwartet, vergleicht falsch.

```tcl
# HOUR(...) -> {number 1}   NICHT  {boolean true}
# Boolean-Funktionen (ISBLANK, AND, …) liefern {boolean …}; getrennt prüfen.
```

### Falle: Fehlerwerte sind Strings

`#DIV/0!`, `#VALUE!`, `#N/A` usw. sind **getaggte String-Werte**
(`{error #DIV/0!}`), keine Tcl-Exceptions. Sie propagieren als Werte durch
verschachtelte Formeln - man fängt sie nicht mit `catch`, man **prüft den Tag**.

---

## 3. Datums- und Zeitmodell

- **Null-Datum** (serial 0) ist standardmäßig **1899-12-30** (LO/Excel-Konvention).
- Die Epoche ist konfigurierbar: `MemoryStore configure -epoch …`; beim
  LO-Vergleich wird sie über `epoch auto` aus dem `NOW`-Cache abgeleitet.
- Feste Fixtures setzen eine **feste Epoche** (reproduzierbar, z. B.
  `2026-05-28T20:08:30`), damit `NOW`/`TODAY`-abhängige Werte stabil sind.

### Falle: führende Null in ISO-Dauern wird als Oktal gelesen

Das ist die teuerste Datums-Falle. Eine ISO-8601-Dauer wie `PT08H` enthält
`08` - und `expr` interpretiert `08` als **Oktalzahl** → `invalid octal number`
(`ARITH DOMAIN`). Nie die rohen Komponenten in `expr` werfen; per `scan`
dezimal **koerzieren**:

```tcl
# FALSCH: expr liest 08/09 als Oktal -> ARITH DOMAIN
set secs [expr {$h*3600 + $m*60 + $s}]

# RICHTIG: scan erzwingt dezimal (mirror von serialFromDateTime)
set secs [expr {3600*[scan $h %d] + 60*[scan $m %d] + [scan $s %f]}]
```

Dieselbe Wurzel wie bei `clock`/Zahlen allgemein - siehe `clock-datetime.md`
und `expr-braces.md`.

---

## 4. Funktions-Dispatch

Aufgelöst wird in fester Reihenfolge, zuletzt die Legacy-Aliase:

```
callFunction  ->  Basis  ->  ext1 … ext12  ->  legacyDispatch
```

| Modul | Funktionen |
|-------|-----------|
| `functions-0.1.tm` | 106 (Basis) |
| `ext1` | 94 |
| `ext2 … ext12` | je 50 |
| `legacy` | 41 (LO-Aliase) |
| **`::ofcalc::functions::names`** | **791** gesamt |

Die LO-Legacy-Aliase (z. B. alte `ORG.OPENOFFICE.*`/Punkt-Namen) schließen die
Namenslücke zu LibreOffice: `lo-gap.test` deckt **506/506** LO-Referenznamen ab.
Funktions-Referenz: `ofcalc/docs/FUNCTIONS.md`.

---

## 5. Recalc und Abhängigkeiten

Der Recalc evaluiert Zellen in **Abhängigkeitsreihenfolge** über den
Graphen (`::ofcalc::recalcSheet`), nicht in Speicherreihenfolge.

### Falle: Formelzellen einzeln auswerten liefert 0

Wer eine Formelzelle isoliert auswertet, deren Eingaben **selbst Formeln** sind,
liest leere Werte. Beispiel: `F7 = SUM([.F3:.F6])`, wobei `F3:F6` ihrerseits
`=SUM(row)` sind. Ohne vorherigen Recalc haben `F3:F6` noch keinen Wert → `F7`
wird **0** statt der Summe.

```tcl
# FALSCH: jede Formel isoliert (skipFormulaCache) auswerten
#   -> F7 liest F3:F6, die noch keinen berechneten Wert haben -> 0

# RICHTIG: erst das ganze Blatt in Abhängigkeitsreihenfolge rechnen
::ofcalc::recalcSheet $store $sheetName $formulas
#   danach Werte lesen / mit LO vergleichen
```

### Falle: `IF` ist lazy

Im Recalc-Pfad wertet `IF` nur den genommenen Zweig aus. Ein Fehler im
**nicht** genommenen Zweig taucht nicht auf - was korrekt ist, aber bei der
Fehlersuche täuscht („warum schlägt der Test nicht an?").

### Offen: echte Iteration / Zirkelbezüge

Zirkelbezüge werden **erkannt** (Detection), aber nicht iterativ gelöst - es
gibt **keinen** Solver. Wer iterative Berechnung braucht, muss sie außerhalb
modellieren.

---

## 6. LibreOffice-Abgleich (refcorpus)

Der Korpus prüft das Zusammenspiel ofcalc ↔ LO. Kern-API im Adapter
`ofcalc::odfadapter`:

| Proc | Zweck |
|------|-------|
| `compareWorkbookToLo` | liefert `pass fail skip mismatches` |
| `compareCorpusFile` / `compareCorpusDir` | Datei- bzw. Verzeichnis-Vergleich |
| `findRefLoDir` | `$env(OFCALC_REF_LO)` + relative Kandidaten (sonst leer → sauberer Skip) |

### Falle: nicht-deterministische Funktionen vergleichen

`NOW`, `TODAY` und die **`RAND`-Familie** (`RAND`, `RAND.NORM`, `RANDOM.ARRAY`)
liefern bei jedem Lauf andere Werte und lassen sich nicht wertgenau vergleichen.
Im Abgleich überspringen statt als Mismatch zählen:

```tcl
if {[regexp {RAND[A-Z0-9._]*\(} [string toupper $formula]]} { incr skip; continue }
# ebenso NOW()/TODAY() ausklammern
```

Ein Recalc, der die Zeichenreihenfolge ändert, verschiebt sonst die
RANDOM-Ziehungen und erzeugt **scheinbare** Mismatches.

### Falle: Fixture ist ofcalc-Cache, nicht echter LO-Stand

Die „extended" Fixture enthält **von ofcalc** geschriebene Cachewerte. Ein
*echter* LO-Abgleich verlangt, dass LibreOffice die Datei **neu speichert**
(Roundtrip per UNO), sonst vergleicht man ofcalc gegen sich selbst.

### Falle: LO 26 lässt per UNO nicht alles zu

Named Ranges und Validierung sind über die UNO-Bridge eingeschränkt; betroffene
Strukturen werden per **XML-Patch** nachgezogen (`odf_patch_lo.py`). Zur
UNO-/CLI-Schiene siehe `libreoffice-steuern-tcl.md`.

---

## 7. Fallen-Kurzübersicht

```
1)  Formel in "…" statt {…}                       -> [.A1] wird als Befehl ausgeführt
2)  getaggten Wert {date N} als blanken Serial benutzt -> [lindex $v 1] vergessen
3)  Integer-Rückgabe als Boolean erwartet (HOUR=1)  -> {number 1} ≠ {boolean true}
4)  Fehlerwert via catch fangen                     -> ist ein {error …}-Wert; Tag prüfen
5)  ISO-Dauer 08H/09M in expr                       -> Oktal-Fehler; scan %d/%f koerzieren
6)  Formelzelle isoliert auswerten                  -> abhängige Formeln = 0; erst recalcSheet
7)  NOW/TODAY/RAND wertgenau vergleichen            -> überspringen (nicht deterministisch)
8)  Fixture-Cache mit echtem LO verwechselt         -> LO muss neu speichern (Roundtrip)
9)  Named Ranges/Validierung rein per UNO erwartet  -> LO 26 eingeschränkt; XML-Patch
10) generierten Parser inline eval'n                -> als .tm source'n, per Tool regenerieren
11) hart verdrahteter Korpus-Pfad                   -> OFCALC_REF_LO/findRefLoDir, sonst Skip
```

---

## 8. Offene Themen

- Volle Semantik **aller** 791 Namen vs. LibreOffice (etliche bewusst Stubs /
  vereinfacht).
- Iterative Berechnung / Zirkelbezüge (Detection vorhanden, kein Solver).
- Array/Spill-Semantik (`FILTER`, dynamische Bereiche).
- Consumer-evaluated Features (Pivot gefüllt, bedingte Formatierung angewandt) -
  passieren interaktiv in LO, nicht im reinen Recalc.
- refcorpus: Expected-Daten für `ref-lo` automatisch extrahieren.

---

## 9. Werkzeuge (`ofcalc/tools/`, refcorpus)

| Skript | Zweck |
|--------|-------|
| `tools/run-all-tests.tcl` (+ Root `run-all-tests.tcl`) | alle Unit-/Regressionstests; findet `../odf` per `OFCALC_ODF` |
| `tools/regen-parser.tcl` | Parser aus `grammar/of.peg` regenerieren |
| `tools/gen-ref-formula-extended.tcl` | „extended" Fixture erzeugen |
| `tools/compare-ref-lo.tcl` | gegen externen LO-Korpus (`OFCALC_REF_LO`) |
| `tools/lo-gap-report.tcl` | LO-Namensliste vs. ofcalc-Funktionen |
| `refcorpus/tools/run-gen-ref-lo.sh` | LO-Referenzdateien per UNO erzeugen |

Kritische Tests: `lo-gap.test`, `lo-legacy.test`, `ref-formula-results.test`,
`ref-lo-corpus.test`, `to-200.test … to-750.test`.

```bash
LC_ALL=C.UTF-8 tclsh run-all-tests.tcl       # ganze Suite (mit OFCALC_ODF=../odf)
tclsh tools/lo-gap-report.tcl                 # Abdeckung der LO-Namen
```

> **Locale-Falle:** Unter einem `iso8859-1`-System (`encoding system`) misslesen
> UTF-8-Quellen mit Sonderzeichen → falsche Test-Fehlschläge. Suite immer mit
> `LC_ALL=C.UTF-8` starten.

---

## Siehe auch

- `libreoffice-steuern-tcl.md` -- soffice/UNO-Schiene, Render/Validierung, Roundtrip
- `odf-erzeugen-fallen.md` -- ODF-Container/Schema/Rendering-Fallen (die Erzeuger-Seite)
- `peg-grundlagen.md` / `peg-tcllib.md` -- PEG-Grammatik und tcllib `pt::*` (der Parser-Unterbau)
- `clock-datetime.md` -- Serial/Epoche, `clock`-Konvertierung
- `tcl-alles-ist-string.md` / `substitution-escaping.md` -- warum `{…}` statt `"…"` bei Formeln
- `expr-braces.md` -- `expr` und die Oktal-Falle bei führenden Nullen

## Referenzen

- [OASIS OpenDocument 1.3, Part 2: OpenFormula](https://docs.oasis-open.org/office/OpenDocument/v1.3/) -- die Formel-Spezifikation
- [tcllib Parser Tools (`pt`)](https://core.tcl-lang.org/tcllib/) -- PEG-Parser-Generator
- [LibreOffice Calc Functions](https://help.libreoffice.org/latest/en-US/text/scalc/01/04060100.html) -- Funktions-Referenz für den Abgleich

---

*Letzte Aktualisierung: 2026-06-02 (Erstanlage; Oktal-Dauer-, Recalc-Ketten- und RAND-Vergleichsfalle aus der 0.1-Stabilisierung).*
