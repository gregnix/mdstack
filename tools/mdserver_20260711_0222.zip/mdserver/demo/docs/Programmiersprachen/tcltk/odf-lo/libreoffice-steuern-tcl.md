# LibreOffice / soffice aus Tcl(/Tk) steuern und nutzen

*Stand: 2026-05-28*

Wie man LibreOffice aus Tcl heraus zum Konvertieren, Rendern, Drucken,
Text-Extrahieren und Validieren benutzt — geerdet an den Werkzeugen des
`odf`-Projekts (`tools/odftwopdf.tcl`, `odfvalidate.tcl`, `tclodfval.tcl`,
`odf-inspect.tcl`). Schwerpunkt: die **CLI-Schiene** (robust, scriptbar) plus
die Fallen, die in der Praxis Zeit kosten.

> Getestet gegen **LibreOffice 26.2**. Die CLI-Optionen sind seit Jahren stabil.

---

## 0. Drei Wege — und wann welcher

| Weg | Wofür | Aufwand |
|-----|-------|---------|
| **CLI via `exec`** (`--headless --convert-to …`) | Konvertieren (PDF/PNG/DOCX/…), Text-Dump, Drucken. **Der Standardweg.** | gering |
| **UNO-Bridge** (`--accept=socket…;urp`) | echte programmatische Steuerung (Zellen setzen, Seriendruck, Felder aktualisieren) | hoch (kein fertiges Tcl-UNO-Binding) |
| **eigene ODF-Lib** (`odf`) | `.odt`/`.ods`/`.odg`/… **erzeugen und lesen** ganz ohne soffice | — (reines Tcl/tdom) |

**Wichtig:** Zum *Erzeugen* von ODF braucht man soffice **nicht** — das macht die
native `odf`-Library (Tcl + tdom). soffice kommt erst ins Spiel, wenn man
**rendern** (PDF/PNG zur optischen Kontrolle), in ein **Fremdformat**
konvertieren (DOCX/XLSX) oder **drucken** will. Validiert wird mit der
odfvalidator-jar (Java), ebenfalls ohne soffice-Laufzeit.

---

## 1. soffice von Tcl aus finden und starten

Binärname ist `soffice` (Linux/macOS) oder `libreoffice` (manche Distros);
unter Windows `soffice.exe`. Auflösen mit `auto_execok`, skip-on-missing statt
hart scheitern:

```tcl
set soffice [auto_execok soffice]
if {$soffice eq ""} { set soffice [auto_execok libreoffice] }
if {$soffice eq ""} {
    puts stderr "WARN: soffice/libreoffice nicht im PATH -- LO-Schritte übersprungen"
}
```

`auto_execok` liefert eine **Liste** (unter Windows ggf. mit `cmd /c …`), daher
beim Aufruf immer `{*}$soffice` expandieren, nie als String einsetzen.

---

## 2. Headless-Konvertierung (`--convert-to`) — der Kern

```tcl
exec {*}$soffice --headless --norestore --nologo --nofirststartwizard \
     --convert-to pdf --outdir /ziel/ordner /pfad/datei.odt
```

- `--headless` — keine GUI (impliziert von `--convert-to`, schadet aber nicht).
- `--norestore` — keine Wiederherstellung nach „Absturz" (sonst hängt es nach
  einem vorherigen Kill).
- `--nologo --nofirststartwizard` — kein Splash, kein Erststart-Assistent.
- `--convert-to EXT[:FilterName]` — Zielformat.
- `--outdir DIR` — Ausgabeordner (sonst cwd).

Mehrere Dateien/Globs gehen auch, aber für Fehlerklassifizierung pro Datei
(s. u.) ruft man besser **eine Datei pro Aufruf** auf.

### Filter-Namen

`--convert-to pdf` genügt meist — LO wählt den passenden Default-Filter nach
Eingabetyp. Bei Mehrdeutigkeit hängt man `:FilterName` an. Die stabilen
PDF-Export-Filter:

| Eingabe | Filter |
|---------|--------|
| Writer (.odt) | `writer_pdf_Export` |
| Calc (.ods) | `calc_pdf_Export` |
| Draw (.odg) | `draw_pdf_Export` |
| Impress (.odp) | `impress_pdf_Export` |

```tcl
--convert-to pdf:writer_pdf_Export      ;# erzwingt den Writer-PDF-Filter
--convert-to "txt:Text (encoded):UTF8"  ;# Klartext, UTF-8
--convert-to "html:XHTML Writer File:UTF8"
--convert-to "MS Word 2007 XML"         ;# .docx (Filter-Name ohne ext geht auch)
```

Es gibt **kein** zuverlässiges `--list-filters` auf der CLI. Wer die exakten
Namen braucht: in LO ein Basic-Makro über `com.sun.star.document.FilterFactory`
laufen lassen, oder die bekannten `*_pdf_Export`-Namen verwenden.

### PNG-Rendering: oft der Umweg über PDF

Writer→PNG direkt ist unzuverlässig (kein guter Direkt-Filter; nur die erste
Seite). Robuster: erst **PDF** via soffice, dann **PDF→PNG** via `pdftocairo`
(poppler) oder `pdftoppm` — gibt alle Seiten sauber:

```tcl
exec {*}$soffice --headless … --convert-to pdf --outdir $out $f
exec pdftocairo -png $out/datei.pdf $out/datei      ;# datei-1.png, datei-2.png, …
```

Draw/Impress (`.odg`/`.odp`) dagegen exportieren PNG direkt brauchbar.

---

## 3. Die zwei Hardenings, ohne die Batch-Rendern hängt

Das ist die teuerste Lektion und der Grund, warum `odftwopdf.tcl` so aussieht
wie es aussieht.

### (a) `timeout --kill-after` um JEDEN Aufruf

Nicht jedes ODF ist ein Seiten-Dokument. Ein **standalone Chart** (`.odc`) ist
keine Seite — der Headless-Export-Pfad **hängt** und kehrt nie zurück. Ohne
Schutz blockiert *eine* Datei den ganzen Batch.

```tcl
# GNU coreutils timeout: SIGTERM nach 30s, notfalls SIGKILL 10s später
exec {*}[auto_execok timeout] --kill-after=10s 30s \
     {*}$soffice --headless … --convert-to pdf --outdir $out $f
```

`timeout(1)` liefert Exit **124** bei TERM-Timeout, **137** (128+9) wenn es
SIGKILL brauchte. Die klassifiziert man (s. Abschnitt 4) als TIMEOUT statt FAIL.

### (b) Eigenes Wegwerf-Profil pro Aufruf (Single-Instance-Lock!)

LibreOffice ist **single-instance**: ein zweiter Aufruf verbindet sich per Lock
mit der schon laufenden `soffice.bin`. Hängt die erste (gekillte, aber als
Leiche im Lock verbliebene) Instanz, **vergiftet sie alle folgenden Aufrufe** —
sie werden nie fertig. Lösung: jeder Aufruf bekommt ein **eigenes,
wegwerfbares** User-Profil:

```tcl
set prof [file normalize [file join [pwd] .lo_prof_[pid]_[clock clicks -milliseconds]]]
exec {*}$soffice --headless --norestore --nologo --nofirststartwizard \
     -env:UserInstallation=file://$prof \
     --convert-to pdf --outdir $out $f
file delete -force $prof      ;# danach wegräumen
```

`-env:UserInstallation=file://…` setzt eine Bootstrap-Variable auf ein frisches
Profil — kein gemeinsamer Lock, keine Vergiftung. (Pfad als `file://`-URL, kein
nackter Pfad.)

**Zusammen** ergeben (a)+(b) den robusten Aufruf — siehe `sofficeConvert` in
`tools/odftwopdf.tcl`.

---

## 4. Exit-Codes von `exec` klassifizieren

`exec` wirft bei Exit≠0; die Detail-Codes stehen in `-errorcode`:

```tcl
proc run {label cmd} {
    if {[catch {exec {*}$cmd} err opts]} {
        set code [dict get $opts -errorcode]
        if {[lindex $code 0] eq "CHILDSTATUS" && [lindex $code 2] in {124 137}} {
            puts stderr "TIMEOUT ($label)"      ;# vom timeout(1) gekillt
        } else {
            puts stderr "FAIL ($label): $err"
        }
        return 0
    }
    return 1
}
```

`-errorcode` ist bei beendeten Kindern `{CHILDSTATUS <pid> <exitcode>}`. So
trennt man „hängengeblieben" (124/137) sauber von „echt fehlgeschlagen".

---

## 5. Weitere CLI-Modi (aus `soffice --help`)

| Option | Zweck |
|--------|-------|
| `--cat datei` | Textinhalt nach stdout dumpen (impliziert headless). Schnelle Textextraktion ohne Konvertierung. |
| `--script-cat datei` | eingebettete Makros dumpen. |
| `--convert-to … --convert-images-to jpg` | beim Export alle Bilder ins Zielbildformat wandeln. |
| `--print-to-file --outdir DIR datei` | „Druck" in eine Datei (PostScript/PDF je nach Druckertreiber). |
| `-p datei` / `--pt Drucker datei` | auf Standard- bzw. benannten Drucker drucken, danach schließen. |
| `--infilter="…"` | Eingabefilter erzwingen, wenn die Autoerkennung danebenliegt (z. B. CSV-Encoding). |
| `--writer`/`--calc`/`--draw`/`--impress`/`--global`/`--math`/`--web` | leeres Dokument des Typs erzeugen. |
| `-n datei` / `-o datei` | folgende Dateien als Vorlage (neu) bzw. zum Bearbeiten öffnen. |
| `--cat` ⚠ | **nicht** mit `--convert-to` kombinierbar. |

`--cat` ist der billigste Weg, um in einem Tcl-Skript schnell an den reinen
Text eines Fremddokuments zu kommen (DOCX, alte ODT) — wenn die eigene Lib es
(noch) nicht liest.

---

## 6. Validieren mit der odfvalidator-jar (ohne soffice)

Konformität prüft die **ODF-Toolkit-jar** über Java, unabhängig von soffice:

```tcl
exec java -jar $jar -v datei.odt        ;# -v verbose (voller Report)
exec java -jar $jar -w datei.odt        ;# -w mit Warnungen
```

### jar-Auflösung (drei robuste Muster aus dem Projekt)

```tcl
# 1) explizites Argument  2) Umgebungsvariable  3) glob neben dem Skript/Repo
proc findJar {explicit} {
    if {$explicit ne ""} { return $explicit }
    if {[info exists ::env(ODFVALIDATOR_JAR)]} { return $::env(ODFVALIDATOR_JAR) }
    set here [file dirname [file normalize [info script]]]
    foreach dir [list $here [file join $here validator] [file join $here ..]] {
        set hits [glob -nocomplain -directory $dir odfvalidator*jar-with-dependencies.jar]
        if {[llength $hits]} { return [lindex [lsort $hits] end] }
    }
    error "odfvalidator jar nicht gefunden (ODFVALIDATOR_JAR setzen oder mitliefern)"
}
```

Für ein **PATH-taugliches** Tool (jar liegt *neben* dem Skript, das selbst per
Symlink erreichbar ist) den Skriptpfad über aufgelöste Symlinks bestimmen —
nicht über `pwd` (siehe `tclodfval.tcl::scriptDir`):

```tcl
proc scriptDir {} {
    set self [file normalize [info script]]
    for {set i 0} {[file type $self] eq "link" && $i < 32} {incr i} {
        set link [file readlink $self]
        set self [file normalize [expr {[file pathtype $link] eq "relative"
                                        ? [file join [file dirname $self] $link] : $link}]]
    }
    return [file dirname $self]
}
```

### Verdikt aus der Ausgabe ziehen

Der Validator schreibt eine menschenlesbare Zusammenfassung; nicht der
Exit-Code allein zählt:

```tcl
set conformant [expr {![string match {*NOT conformant*} $report]}]
# Fehler/Warnungs-Zähler aus der "Info: N errors, M warnings"-Zeile:
regexp {Info: (no errors|[0-9]+ error[s]?), (no warnings|[0-9]+ warning[s]?)} \
       $line -> errs warns
```

**Falle (kein Lib-Bug):** Eine `.odb` meldet auf Container-Ebene
„mimetype … is invalid for the ODF XML Schema" — das ist für Datenbank-
Dokumente **inhärent** (auch LOs eigene `.odb`). Maßstab ist der
`content.xml`-Befund, nicht der Container-Hinweis.

---

## 7. Inspektion ganz ohne soffice

Für ein **eigenes** ODF braucht man weder soffice noch die jar, um die Struktur
zu sehen — das geht über die `odf`-API selbst (`odf-inspect.tcl`): Package +
Text öffnen, `blocks`/`runs`/`tableRows`/`imageInfo`/`styleRegistry` auslesen
und ausgeben. Reiner Consumer, kein Bibliothekscode. stdout vorher auf UTF-8
stellen, damit Umlaute stimmen:

```tcl
fconfigure stdout -encoding utf-8
set pkg [odf::Package new $path]
set txt [odf::Text new $pkg]
foreach b [$txt blocks] { … walkBlock … }
$txt destroy ; $pkg destroy
```

Das ist schneller und genauer als ein PDF-Render, wenn man die **Struktur**
(welche Stile, welche Anker, welche Tabellen) prüfen will, nicht die Optik.

---

## 8. UNO-Bridge (fortgeschritten, selten nötig)

Echte programmatische Steuerung (Felder aktualisieren, Seriendruck ausführen,
Zellen rechnen lassen) geht über **UNO**. soffice als Server starten:

```tcl
exec {*}$soffice --headless --norestore --invisible \
     --accept={socket,host=localhost,port=2002;urp;} &
```

Danach spricht ein Client das **URP**-Protokoll über den Socket. Für Tcl gibt
es **kein** gepflegtes UNO-Binding — praktikabel sind zwei Wege:

- **Pragmatisch:** ein kleines **Python-UNO**-Skript schreiben (Python-UNO
  liegt LO bei) und es aus Tcl per `exec` aufrufen. Tcl steuert den Ablauf,
  Python macht die UNO-Calls.
- **Nur wenn nötig:** das URP-Protokoll direkt über einen Tcl-Socket sprechen
  (sehr aufwändig; lohnt fast nie).

Für das `odf`-Projekt ist UNO bisher **nicht** nötig: Erzeugen macht die Lib,
Rendern/Konvertieren die `--convert-to`-CLI, Validieren die jar.

---

## 9. Fallen-Kurzübersicht

```
1) soffice als String statt {*}$soffice aufgerufen        -> bricht bei Listen/Windows
2) --convert-to auf .odc / Nicht-Seiten-Doc               -> hängt; timeout PFLICHT
3) kein eigenes UserInstallation-Profil                   -> Single-Instance-Lock vergiftet Folgeaufrufe
4) timeout-Exit 124/137 als FAIL fehlgedeutet             -> ist TIMEOUT (CHILDSTATUS prüfen)
5) Writer -> PNG direkt erwartet                          -> nur Seite 1/unzuverlässig; Umweg über PDF+pdftocairo
6) UserInstallation als nackter Pfad statt file://-URL    -> ignoriert
7) jar über pwd statt Skriptpfad gesucht (PATH-Tool)      -> nicht gefunden; scriptDir + Symlink-Auflösung
8) .odb-Container-„invalid mimetype" als Fehler gewertet  -> inhärent; content.xml zählt
9) --cat mit --convert-to kombiniert                      -> nicht erlaubt
10) Profil nach Lauf nicht gelöscht                       -> .lo_prof_*-Müll sammelt sich
```

---

## 10. Werkzeuge im `odf`-Projekt (`tools/`)

| Skript | Zweck | Kernidee |
|--------|-------|----------|
| `odftwopdf.tcl` | Batch: `out/*.{odt,ods,odg,odc,odm}` → PDF+PNG + Validierung | timeout + Wegwerf-Profil pro Aufruf; PDF→PNG via pdftocairo; Exit-Klassifizierung |
| `odfvalidate.tcl` | Batch-Validierung eines Ordners; PASS/FAIL + Summary, Exit≠0 bei Nonkonformität (CI-tauglich) | jar-Auflösung Arg→ENV→glob; Verdikt aus Ausgabe |
| `tclodfval.tcl` | eine Datei validieren, vollen Report in Datei schreiben; PATH-tauglich | jar **neben** dem Skript (Symlinks aufgelöst); Exit 0/1/2 |
| `odf-inspect.tcl` | Struktur-Dump eines `.odt` über die `odf`-API | reiner Consumer, kein soffice/jar |

Aufruf-Reihenfolge im Projekt: erzeugen (Lib) → **validieren** (`tclodfval`/
`odfvalidate`) → **rendern** (`odftwopdf`, Gregor extern in echtem LO) →
optisch prüfen. Jede Stufe ist unabhängig; eine grüne Stufe sagt nichts über
die nächste (siehe `odf-erzeugen-fallen.md`).

---

## Siehe auch

- `odf-erzeugen-fallen.md` — die Drei-Stufen-Wahrheit (wohlgeformt ≠
  schema-gültig ≠ rendert) und die `.odc`-Hang-Falle im Detail.
- `tdom.md` — Container-Teile lesen/schreiben, DOM bauen.
- `auto-execok-plattform.md` — `auto_execok` und Plattform-Binärnamen.
- `exec-externe-programme.md` / `exec-pipelines.md` — `exec`, `-errorcode`,
  Pipelines.

## Referenzen

- `soffice --help` (LibreOffice 26.2) — die hier benutzten CLI-Optionen.
- [LibreOffice: Documentation/DevGuide](https://wiki.documentfoundation.org/Documentation/DevGuide) — UNO/Filter.
- [ODF Toolkit / odfvalidator](https://odftoolkit.org/) — die Validator-jar.
- poppler-utils (`pdftocairo`, `pdftoppm`) — PDF→PNG.

---

*Letzte Aktualisierung: 2026-05-28*
