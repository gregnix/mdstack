# ODF/ODT erzeugen - Fallen & Konformität

*Stand: 2026-05-28*

Wer ODF-Textdokumente (`.odt`) selbst erzeugt -- mit tdom, von Hand oder über
eine eigene Bibliothek -- stößt auf eine Kette von Fallen, die alle dieselbe
Wurzel haben:

> **Wohlgeformt ≠ schema-gültig ≠ rendert wie gewünscht.**

Ein Dokument kann sauberes XML sein, am Schema durchfallen; oder am Schema
durchkommen und in LibreOffice trotzdem leer/falsch aussehen. Dieses Dokument
sammelt die Fallen aus dem Bau einer nativen ODF-Bibliothek und ist nach dieser
Drei-Stufen-Wahrheit geordnet.

## Aufbau eines ODT

Ein `.odt` ist ein **ZIP-Container** mit XML-Teilen:

```
mimetype                 application/vnd.oasis.opendocument.text  (unkomprimiert, ZUERST)
content.xml              Inhalt + automatische Stile
styles.xml               benannte Stile, Seitenlayout, Master-Pages, Fonts
meta.xml                 Metadaten (Titel, Autor, Generator …)
META-INF/manifest.xml    Inhaltsverzeichnis des Containers (+ Medientypen)
Pictures/…               eingebettete Bilder
```

Geprüft wird gegen das **OASIS-ODF-Schema** (Validator, z. B. odfvalidator.org),
**gerendert** wird in LibreOffice. Beide muss man ernst nehmen -- sie sind nicht
deckungsgleich.

## Stufe 1: Der Container (ZIP) -- bevor überhaupt XML zählt

### mimetype zuerst, unkomprimiert

Der erste ZIP-Eintrag **muss** `mimetype` sein, **STORED** (nicht deflate),
ohne Extra-Feld. Daran erkennen Werkzeuge den Dokumenttyp am Byte-Offset.

```tcl
# RICHTIG: mimetype als allerersten Eintrag, Methode STORED
zipAdd $zip mimetype "application/vnd.oasis.opendocument.text" -method stored
# danach erst content.xml, styles.xml … (komprimiert ok)
```

### Die unsichtbare Falle: ungültiger DOS-Zeitstempel

ZIP-Einträge tragen ein DOS-Datum/-Zeit-Feld. Schreibt man dort **Null**
(0000-00-00), ist das **kein gültiges DOS-Datum** -- manche Validatoren melden
das als kryptischen Fehler (z. B. „extra field"/Header-Problem), obwohl die
Struktur sonst identisch zu einem konformen Dokument ist.

```tcl
# FALSCH: all-zero Datum/Zeit -> ungültiges DOS-Datum
set dosdate 0 ; set dostime 0

# RICHTIG: gültiger fester Zeitstempel (1980-01-01 00:00:00)
set dostime 0           ;# 00:00:00
set dosdate 33          ;# 0b0000000_0001_00001 = Jahr 1980, Monat 1, Tag 1
# (Jahr-1980)<<9 | Monat<<5 | Tag ; 1980 -> 0, Monat 1, Tag 1 -> 33)
```

Ein fester, gültiger Zeitstempel macht die Ausgabe außerdem **deterministisch**
(reproduzierbare Builds). Lehre: Bei „komischen" Container-Fehlern zuerst den
DOS-Zeitstempel prüfen, nicht stundenlang nach einem Extra-Feld suchen.

## Stufe 2: Schema-Gültigkeit (der Validator)

### Namespaces: jeder Präfix muss am Wurzelknoten gebunden sein -- pro Datei

`content.xml` und `styles.xml` sind **getrennte** XML-Dokumente mit **eigenen**
Wurzel-Namespace-Deklarationen. Ein Präfix, das man in einer Datei benutzt, muss
**in genau dieser Datei** an der Wurzel deklariert sein.

```xml
<!-- FALSCH: styles.xml benutzt svg:font-family, deklariert svg: aber nicht -->
<office:document-styles xmlns:office="…" xmlns:style="…" xmlns:fo="…">
  <office:font-face-decls>
    <style:font-face style:name="Mono" svg:font-family="DejaVu"/>  <!-- Fatal: svg ungebunden -->
```

```xml
<!-- RICHTIG: xmlns:svg im Wurzel-Gerüst von styles.xml ergänzen -->
<office:document-styles … xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0">
```

**Masche:** `content.xml` deklariert `svg:` oft schon (für Bilder/`svg:height`),
`styles.xml` aber nicht -- und genau dort braucht man `svg:font-family`
(Font-Faces) und `svg:height` (Kopf-/Fußzeilenhöhe). Beide Gerüste müssen die
nötigen Präfixe je für sich mitbringen.

> tdom erzeugt `createElement style:foo` klaglos -- das ungebundene Präfix fällt
> erst beim Serialisieren/Validieren auf. Siehe `tdom.md`.

### Body-Tabellenstile gehören in content.xml (automatic styles)

Das ist gleich eine doppelte Falle -- Schema **und** Rendering:

```xml
<!-- FALSCH: Tabellenstil als benannter Stil in styles.xml -->
<!-- styles.xml: office:styles deklariert table: nicht -> "table: prefix not bound" (Fatal) -->
<!-- und: LibreOffice ignoriert gemeinsame (common) Tabellenstile für Body-Tabellen -->
```

```xml
<!-- RICHTIG: Tabellen-/Spalten-/Zellstile als AUTOMATISCHE Stile in content.xml -->
<office:automatic-styles>
  <style:style style:name="Tab1"  style:family="table">…</style:style>
  <style:style style:name="Col1"  style:family="table-column">…</style:style>
  <style:style style:name="CellA" style:family="table-cell">…</style:style>
</office:automatic-styles>
```

Merksatz: Was zum **Inhalt** gehört (Body-Tabellen und ihre Spalten/Zellen),
wird in `content.xml` als *automatic style* definiert -- nicht als benannter
Stil in `styles.xml`.

### style:style: die Kind-Reihenfolge ist vorgeschrieben

Innerhalb eines `<style:style>` müssen die Eigenschaftsgruppen in **fester
Schema-Reihenfolge** stehen. Falsche Reihenfolge → Validator meldet etwas wie
*„style:paragraph-properties not allowed here; Possible: <…>"*.

```xml
<!-- RICHTIG: table-cell- vor paragraph- vor text-properties -->
<style:style style:name="CellA" style:family="table-cell">
  <style:table-cell-properties …/>
  <style:paragraph-properties …/>
  <style:text-properties …/>
</style:style>
```

```tcl
# Praxis: beim Bauen die Property-Gruppen nach kanonischer Ordnung sortieren,
# nicht in der Reihenfolge anhängen, in der man sie gerade setzt.
set order {
    style:table-cell-properties 0
    style:paragraph-properties   1
    style:text-properties        2
}
# -> Gruppen in dieser Reihenfolge an <style:style> appendChild
```

Die korrekte Reihenfolge liest man notfalls direkt aus den „Possible tag names"
der Validator-Meldung ab.

### Attribute am falschen Element

Nicht jedes plausible Attribut ist überall erlaubt. Beispiel aus der Praxis:

```xml
<!-- FALSCH: style:num-letter-sync ist auf page-layout-properties NICHT erlaubt -->
<style:page-layout-properties … style:num-format="1" style:num-letter-sync="true"/>

<!-- RICHTIG: weglassen (num-format bleibt) -->
<style:page-layout-properties … style:num-format="1"/>
```

Lehre: Der Validator ist hier die Wahrheit, nicht das Bauchgefühl -- Attribute
nur dort setzen, wo das Schema sie zulässt.

## Stufe 3: Rendert es auch? (LibreOffice)

Schema-gültig heißt **nicht**, dass LibreOffice es so anzeigt, wie gedacht.
Diese Fälle sind besonders tückisch, weil der Validator zufrieden ist.

### Kopfzeilen-Regionen werden in Text-Dokumenten ignoriert

`style:region-left/center/right` ist schema-gültig, aber **LibreOffice Writer
ignoriert es in Text-Kopf-/Fußzeilen** (es ist v. a. für Tabellendokumente
gedacht). Ergebnis: die Kopfzeile bleibt **leer**.

```xml
<!-- FALSCH (rendert leer in Writer): -->
<style:header>
  <style:region-left><text:p><text:title/></text:p></style:region-left>
  <style:region-center><text:p><text:date/></text:p></style:region-center>
  <style:region-right><text:p>Seite <text:page-number/></text:p></style:region-right>
</style:header>
```

```xml
<!-- RICHTIG: EIN Absatz mit Mitte-/Rechts-Tabstopp (so macht es Writer selbst) -->
<style:header>
  <text:p text:style-name="HF1">links<text:tab/>mitte<text:tab/>rechts</text:p>
</style:header>
<!-- HF1: Absatzstil mit Tabstopps bei halber bzw. voller Textbreite -->
<style:style style:name="HF1" style:family="paragraph">
  <style:paragraph-properties>
    <style:tab-stops>
      <style:tab-stop style:position="8.5cm" style:type="center"/>
      <style:tab-stop style:position="17cm"  style:type="right"/>
    </style:tab-stops>
  </style:paragraph-properties>
</style:style>
```

Die Tabstopp-Positionen rechnet man aus dem Seitenlayout aus:
`Textbreite = Seitenbreite - linker - rechter Rand`; Mitte-Tab bei der Hälfte,
Rechts-Tab bei der vollen Textbreite.

### Master-Page: Kinder in Schema-Reihenfolge

Innerhalb von `<style:master-page>` müssen Kopf-/Fuß-Elemente in dieser
Reihenfolge stehen:

```
header, header-left, header-first, footer, footer-left, footer-first
```

Eine Fußzeile **vor** der Kopfzeile einzuhängen ist ein latenter Fehler --
beim Einfügen sortieren, nicht einfach anhängen.

### Zentriertes Bild: nur als as-char

Ein paragraph-verankerter Frame **schwebt** und wird von `text-align` des
Absatzes **nicht** bewegt. Ein „zentriertes" Bild landet so irgendwo seitlich.

```xml
<!-- FALSCH: schwebender Frame, Absatz-Zentrierung wirkt nicht -->
<text:p text:style-name="Centered">
  <draw:frame text:anchor-type="paragraph" …><draw:image …/></draw:frame>
</text:p>

<!-- RICHTIG: as-char (Bild liegt wie ein Zeichen in der Zeile) im zentrierten Absatz -->
<text:p text:style-name="Centered">
  <draw:frame text:anchor-type="as-char" …><draw:image …/></draw:frame>
</text:p>
<!-- Centered: <style:paragraph-properties fo:text-align="center"/> -->
```

Für **schwebende/positionierte** Bilder dagegen einen Grafikstil mit
`style:horizontal-pos`/`style:wrap` verwenden und `text:anchor-type="paragraph"`
(oder `page`) -- das sind zwei verschiedene Mechanismen, die man nicht mischt.

### draw:frame: Kind-Reihenfolge (Inhalt zuerst, dann Alt-Text)

**Korrektur (verifiziert gegen das RNG-Schema):** Anders als oft vermutet
gehören `svg:title`/`svg:desc` **nach** den Frame-Inhalt, nicht davor. Das
`draw:frame`-Content-Model ist:

```
[draw:image | draw:text-box | draw:object | …]*   (der Inhalt)
  → office:event-listeners?  → draw:glue-point*
  → draw:image-map?  → svg:title?  → svg:desc?  → draw:contour-*?
```

Also: **`draw:image` zuerst**, *danach* `svg:title` → `svg:desc`. Die
umgekehrte Reihenfolge ist **schema-ungültig** — der Validator meldet an
`draw:image` sinngemäß „nur contour-* erlaubt". LibreOffice toleriert die
falsche Reihenfolge, der Validator nicht.

```xml
<!-- RICHTIG: Inhalt zuerst, dann Alt-Text -->
<draw:frame …>
  <draw:image xlink:href="Pictures/logo.png" xlink:type="simple"
              xlink:show="embed" xlink:actuate="onLoad"/>
  <svg:title>Logo</svg:title>
  <svg:desc>Firmenlogo</svg:desc>
</draw:frame>
```

```xml
<!-- FALSCH: svg:title/desc VOR draw:image -> Validator-Fehler an draw:image -->
<draw:frame …>
  <svg:title>Logo</svg:title>
  <draw:image …/>
</draw:frame>
```

### Bilder einbetten: Pictures/ + Manifest

Ein Bild muss als Container-Teil liegen **und** im Manifest mit Medientyp stehen,
sonst zeigt LibreOffice nichts (oder der Validator meckert):

```xml
<!-- META-INF/manifest.xml -->
<manifest:file-entry manifest:full-path="Pictures/logo.png"
                     manifest:media-type="image/png"/>
```

Den Medientyp ermittelt man aus den **Magic Bytes** (PNG `‰PNG`, JPEG `FF D8`,
GIF `GIF8`), nicht blind aus der Endung. Siehe `binary scan` für das Auslesen
der Bildmaße aus dem Header.

## Weitere Dokumenttypen: ODS, ODG, Chart, Master (.odm)

Die ODT-Fallen oben gelten sinngemäß für alle ODF-Typen; diese hier sind
typ-spezifisch und ebenfalls teuer gelernt.

### ODS: eine `table:table` braucht Spalten **vor** den Zeilen (Stufe 2)

Eine `table:table` muss **mindestens eine** `table:table-column` deklarieren,
und zwar **vor** den `table:table-row`. Fehlt sie, meldet der Validator
„table-row not allowed here". Auch eine sonst leere Tabelle braucht also
mindestens eine Spalte (und Zeile). Praxis: beim Serialisieren die breiteste
Zeile zählen und so viele `table:table-column` voranstellen.

### ODS: Named Ranges sind Dokument-Epilog (Stufe 2)

`table:named-expressions` (mit `table:named-range`/`table:named-expression`)
ist **Epilog**-Inhalt von `office:spreadsheet` — der Container muss **nach
allen** `table:table` stehen. Fügt man später noch eine Tabelle hinzu, muss
der Named-Ranges-Container wieder ans Ende. (Alternativ als letztes Kind einer
einzelnen `table:table` für sheet-lokale Namen.)

### ODS-View-Settings: `settings.xml` braucht `xmlns:ooo` (Stufe 3)

Freeze-Panes & Co. landen in `settings.xml` unter dem config-item-set
`ooo:view-settings`. Dieser Name verlangt einen **auflösbaren `ooo`-Präfix**
(`http://openoffice.org/2004/office`). Fehlt die Deklaration an der Wurzel,
verwirft LibreOffice die **kompletten** View-Settings (also auch Freeze)
**stillschweigend** — obwohl die Datei schema-gültig ist. Klassisches
„schema-gültig ≠ von LO honoriert", empirisch via Headless-LO gefunden.

### ODG-Connector: IDREF auf `xml:id`, nicht `draw:id` (Stufe 2)

`draw:connector` referenziert seine Endpunkte über `draw:start-shape`/
`draw:end-shape` — das sind **IDREFs auf die kanonische `xml:id`** der
Zielform. Ein bloßes `draw:id` zählt nicht (Validator: „referenced by IDREF
but not defined"). Lösung wie LibreOffice: an Connector-Zielen **beide**
setzen (`xml:id` + `draw:id`, gleicher Wert). Außerdem braucht jede
`draw:page` eine `draw:master-page-name`.

### ODG-Connector: `svg:viewBox` ist Pflicht (Stufe 2)

`draw:connector` referenziert `common-draw-viewbox-attlist` **ohne**
`<optional>` → `svg:viewBox` (4 Integer) ist **vorgeschrieben**, auch wenn LO
den Connector ohne sie rendert. ViewBox + `svg:d` aus den Endpunkten berechnen
(1/100-mm-Raster); der Editor routet beim Öffnen neu.

### ODG: `draw:g` trägt weder Layer noch Transform (Stufe 2)

Das Gruppen-Element referenziert weder `common-draw-layer-name-attlist` noch
`common-draw-transform-attlist`. Eine Gruppe kann also **kein** `draw:layer`/
`draw:transform`-Attribut tragen — solche Eigenschaften gehören an die
Einzelformen, nicht an die Gruppe.

### Cross-Document-Style-Referenzen scheitern in LO (Stufe 3)

Ein Style, der von einer Form auf einer **Master-Page** (in `styles.xml`)
referenziert wird, muss **selbst in `styles.xml`** liegen. Liegt er als
automatic style in `content.xml`, ist die Datei zwar schema-gültig, aber LO
rendert die Form mit Default-Stil (typisch: blaue Default-Füllung statt der
gemeinten). Faustregel: Wer in styles.xml referenziert, definiert in styles.xml.

### Eingebettetes Chart: `office:chart` darf nicht leer sein (Stufe 2)

Ein `<office:chart/>` ohne Inhalt wirft „uncompleted content model". Es braucht
ein `chart:chart` mit `chart:class` **und** einer `chart:plot-area`. Die
Chart-Daten liegen in einer selbsttragenden `local-table` (flaches
column+rows-Modell genügt); Serien/Kategorien referenzieren sie per Zellbereich
(`local-table.B2:.B4`). Das Objekt liegt als `Object N/content.xml` mit
Manifest-Eintrag `Object N/` (Chart-Mimetype) und wird über
`draw:frame > draw:object xlink:href="./Object N"` eingebunden. (Inline-MathML
über `math:math` braucht dagegen **kein** Sub-Dokument/Manifest.)

### Master-Dokument (.odm): es gibt kein `office:text-master` (Stufe 2)

Ein Globaldokument hat **kein** spezielles Body-Element — der Body ist normales
`office:text`. Das „Master"-Wesen ergibt sich allein aus dem Paket-Mimetype
(`…opendocument.text-master`) plus verlinkten `text:section`. Dabei muss
`text:section-source` das **erste Kind** der `text:section` sein; die
verlinkten Dateien sind externe Geschwister (nicht eingebettet), der `href`
wird nicht validiert.

### Notizen-Nummerierung ist implementation-defined (Stufe 3)

Ohne explizite `text:notes-configuration` nummeriert LibreOffice Fußnoten
arabisch (`1, 2, …`), **Endnoten aber römisch** (`i, ii, …`). Wenn die
Nummerierung bestimmt sein soll, explizit setzen (z. B.
`-class endnote -num-format 1` für arabische Endnoten). Per Headless-LO
bestätigt — der Default ist nicht garantiert.

### Synthetische Bilder: PNG-CRC muss stimmen (Stufe 3)

Wer ein PNG **programmatisch** zusammensetzt (z. B. ein 1×1-Pixel-Füllbild für
Bitmap-Fills), muss die **Chunk-CRCs korrekt berechnen**. Ein falscher
IDAT-CRC fällt beim Validator nicht auf (er prüft XML, nicht die Bild-Bytes),
aber LibreOffice bricht den Render mit „libpng error: IDAT: CRC error" ab. CRCs
chunk-weise mit `zlib crc32` über `Typ+Daten` erzeugen und gegenprüfen.

## Fremddokumente laden und wieder speichern

Lädt man ein fremd erzeugtes ODT (z. B. von odfpy oder älteren Tools) und
speichert es originalgetreu zurück, **erbt** man dessen Macken (fehlendes
`manifest:version`, `draw:image` ohne `type`, Tabellenzeile ohne Spalten …).

```
# Diese Validator-Fehler stammen aus der QUELLE, nicht aus dem eigenen Code.
# Bewusste Entscheidung: originalgetreu durchreichen ("no magic"),
# NICHT stillschweigend "reparieren".
```

Wer normalisieren will, tut das **explizit** und dokumentiert -- nicht als
versteckte Magie beim Speichern.

## Datenbank-Dokument (.odb) als Serienbrief-Datenquelle

Eine *datei-basierte* `.odb` ist **kein** gewöhnliches ODF-Dokument im selben
Sinn wie ein `.odt`: sie ist nur eine **Verbindungsbeschreibung** auf einen
externen Ordner mit Textdateien (CSV). Der Inhalt (`office:database` / `db:*`)
**ist** im ODF-1.3-Schema -- aber drei Fallen, die genau die Drei-Stufen-
Wahrheit spiegeln.

### Stufe 2: Der Mimetype ist für den Validator „nicht-Standard"

`application/vnd.oasis.opendocument.base` steht **nicht** auf der Liste der vom
odfvalidator anerkannten Standard-ODF-Mimetypes. Folge: `content.xml` validiert
sauber, aber auf Container-Ebene kommt

```
Error: The ODF mimetype 'application/vnd.oasis.opendocument.base'
       is invalid for the ODF XML Schema document!
```

Das ist **inhärent** für Datenbank-Dokumente, **kein** Generierungsfehler --
auch LibreOffices eigene `.odb` wird so gemeldet. Maßstab ist der
`content.xml`-Befund („no errors"), nicht der Container-Hinweis.

### Stufe 2: LibreOffice schreibt selbst nicht schema-konform

LO lässt am `db:file-based-database` das schema-**pflichtige**
`xlink:type="simple"` weg (es ist bei eigenen Dateien lax). Der Validator
meldet dann *„element db:file-based-database is missing type attribute"*. Ein
eigener Generator **soll** `xlink:type="simple"` setzen -- dann ist `content.xml`
konform **und** LO akzeptiert es trotzdem.

```xml
<!-- RICHTIG (konform + von LO akzeptiert): -->
<db:file-based-database xlink:type="simple" xlink:href="../"
                        db:media-type="text/csv" db:extension="csv"/>
```

### Stufe 3: Wie LO den href auflöst -- relativ zur Package-Wurzel

Der `xlink:href` wird **nicht** wie ein normaler Dateipfad relativ zur
`.odb`-*Datei* aufgelöst, sondern relativ zur **Package-Wurzel**: die `.odb`
verhält sich wie ein **Verzeichnis**. `xlink:href="../"` zeigt damit auf den
Ordner, der die `.odb` **enthält** -- nicht eine Ebene darüber.

```
.odb = examples/db/Addresses.odb     (wirkt wie ein Ordner "Addresses.odb/")
href "../"  ->  pop "Addresses.odb/"  ->  examples/db/   (= Ordner MIT der .odb)
```

Praktisch: die CSV(s) gehören **neben** die `.odb`, in denselben Ordner.
Empirisch in LibreOffice geprüft (gleiche `.odb`, href `../`):

- CSV **neben** der `.odb` (`db/`) → **Daten erscheinen**.
- CSV eine Ebene höher (`examples/`) → **keine Daten**.

Das ist auch genau das, was LO selbst schreibt, wenn `.odb` und CSV-Ordner
zusammenliegen.

### href + Profil-Ablage beißen sich

Da `../` immer der Ordner *der* `.odb` ist: Serienbrief-`.odb` „können nur
angemeldet genutzt werden" und werden gern ins LO-Profil (`.../database/`)
gelegt, damit sie nicht verloren gehen. Liegt die `.odb` dort, zeigt `../` auf
das Profil-`database/`-Verzeichnis -- wo die CSV nicht liegt → keine Tabelle →
Felder bleiben leer. Zwei saubere Varianten:

- `.odb` + CSV **zusammen** in einem Ordner lassen, href `../`, **dort**
  anmelden -- relativer Pfad passt (self-contained); oder
- `.odb` ins Profil → **absoluter** href (`file:///.../ordner/`).

### Weitere Fakten zur Text/CSV-Quelle

- **Tabellenname = Dateiname ohne Endung** (`Recipients.csv` → Tabelle
  `Recipients`).
- Die Text-Datenbank ist **nur lesend** (für Serienbrief egal).
- **Leere** `db:driver-settings` = LO-Defaults (Feldtrenner Komma, Texttrenner
  `"`). Nur bei abweichenden Trennern explizit `db:delimiter`
  (`db:field`/`db:string`/`db:decimal`/`db:thousand`) + `db:character-set`.
- Container-Teile: `mimetype`, `settings.xml`, `content.xml`, `manifest` --
  **kein** `styles.xml`/`meta.xml`.

### Serienbrief-Felder im .odt

`text:database-display` verweist über `text:database-name="<Anmeldename>"` +
`text:table-name` + `text:column-name` auf die **registrierte** Quelle; die
Daten liegen außerhalb. Eine `.odb` muss man dafür nicht selbst erzeugen --
es genügt, die Quelle einmal in LO anzumelden. Wer es self-contained will,
generiert die Verbindungs-`.odb` (s. o.) gleich mit.

## Headless-Konvertierung: nicht jedes ODF ist ein Seiten-Dokument

`soffice --headless --convert-to pdf datei.odc` **hängt** bei einem standalone
Chart-Dokument (`.odc`): ein nacktes Chart ist kein Seiten-Dokument, der
Headless-Export-Pfad dafür blockiert (sinngemäß für andere Nicht-Seiten-
Bodies). Zwei Konsequenzen für ein Batch-Render-Skript:

- **Jeden** soffice-Aufruf in `timeout --kill-after` kapseln -- sonst hängt
  *ein* Dokument den ganzen Batch.
- **Jedem** Aufruf ein eigenes Wegwerf-Profil geben
  (`-env:UserInstallation=file:///tmp/...`), sonst verbindet sich der nächste
  Aufruf über den Single-Instance-Lock mit einer hängenden `soffice.bin`-
  Leiche und wird nie fertig.

Will man das Chart *wirklich* als PDF/PNG sehen: nicht das nackte `.odc`
konvertieren, sondern das Chart in eine Wegwerf-`.odt` **einbetten**
(`appendObject`) und **diese** rendern -- eingebettete Charts exportiert Writer
problemlos.

## Werkzeuge & Workflow

```tcl
# 1) Wohlgeformt + Namespaces: streng parsen (wirft bei ungebundenem Präfix)
package require tdom
dom parse [readPart styles.xml] d ; # Fehler -> Namespace/Struktur kaputt

# 2) Schema: gegen den OASIS-ODF-Validator (odfvalidator.org / ODF-Toolkit-JAR)

# 3) Rendering: in LibreOffice öffnen UND zur Kontrolle nach PDF exportieren
#    (headless:  soffice --headless --convert-to pdf datei.odt)
```

Die drei Stufen sind **nacheinander** zu nehmen: erst wohlgeformt, dann
schema-gültig, dann optisch geprüft. Eine grüne Stufe sagt nichts über die
nächste aus.

## Häufige Fehler (Kurzübersicht)

```
1)  mimetype nicht erster Eintrag / nicht STORED            -> Container ungültig
2)  all-zero DOS-Zeitstempel                                -> kryptischer Validator-Fehler
3)  Präfix in styles.xml benutzt, aber nicht an der Wurzel  -> "prefix not bound" (Fatal)
4)  Body-Tabellenstil in styles.xml statt content.xml       -> table: unbound / wird ignoriert
5)  style:style Property-Gruppen in falscher Reihenfolge     -> "not allowed here"
6)  Attribut am falschen Element (z.B. num-letter-sync)      -> not allowed
7)  Kopfzeile via style:region-* in Writer                  -> rendert LEER
8)  Bild "zentriert" mit anchor=paragraph                   -> schwebt seitlich (as-char nötig)
9)  svg:title/desc VOR draw:image                          -> falsch; Inhalt zuerst, dann title/desc
10) Bild ohne Manifest-Eintrag / falscher Medientyp          -> wird nicht angezeigt
11) .odb-Mimetype vom Validator als „invalid“ gemeldet      -> inhärent (DB-Doc), content.xml zählt
12) db:file-based-database ohne xlink:type="simple"          -> Schema-Fehler (LO lässt es weg)
13) .odb-href ist package-relativ ("../" = Ordner MIT der .odb) -> CSV neben die .odb; Profil-Ablage -> absoluter file://-href
14) soffice --convert-to auf .odc (Nicht-Seiten-Doc)         -> hängt; timeout + eigenes Profil, oder einbetten
15) ODS-Tabelle ohne table:table-column vor den Zeilen       -> "table-row not allowed"
16) ODS-View-Settings ohne xmlns:ooo                         -> LO verwirft Freeze STILLSCHWEIGEND
17) ODG-Connector referenziert draw:id statt xml:id          -> "IDREF not defined" (beide setzen)
18) ODG-Connector ohne svg:viewBox                           -> Schema-Fehler (Pflicht, 4 Integer)
19) Master-Page-Shape-Style nur in content.xml               -> LO rendert Default-Stil (Style in styles.xml)
20) leeres <office:chart/>                                   -> "uncompleted content model" (chart:chart + plot-area)
21) Endnoten-Nummerierung nicht gesetzt                      -> LO nummeriert römisch (i, ii, …)
22) synthetisches PNG mit falschem IDAT-CRC                  -> "libpng error: IDAT: CRC error" im Render
```

## Praxis-Muster

### Beim Bauen die Kind-Reihenfolge erzwingen

```tcl
# Property-Gruppen nicht in Setz-Reihenfolge anhängen, sondern nach
# kanonischer Schema-Ordnung sortieren, dann appendChild.
proc orderedAppend {styleEl groups order} {
    foreach g [lsort -command [list byOrder $order] $groups] {
        $styleEl appendChild $g
    }
}
```

### mimetype-first beim Schreiben

```tcl
# Reihenfolge der ZIP-Einträge bewusst steuern: mimetype zuerst (STORED),
# Rest danach (deflate). Niemals dem Default des ZIP-Writers überlassen.
```

### Selbsttest aller erzeugten Teile

```tcl
# Vor dem Ausliefern jeden XML-Teil streng parsen -- fängt ungebundene
# Präfixe und Struktur-Schnitzer ab, bevor der Validator es tut.
foreach part {content.xml styles.xml meta.xml META-INF/manifest.xml} {
    dom parse [readPart $part] tmp ; # wirft bei Problem
}
```

## Siehe auch

- `tdom.md` -- DOM bauen/serialisieren, ungebundene Präfixe, Kind-Reihenfolge
- `binary scan` -- Bild-Header (PNG/JPEG/GIF) und ZIP-Records lesen
- `zipkit-deployment.md` / `starpack-grundlagen.md` -- ZIP/VFS im Deployment
- `encoding-unicode.md` -- UTF-8 beim Lesen/Schreiben der Container-Teile

## Referenzen

- [OASIS ODF 1.3 Spezifikation](https://docs.oasis-open.org/office/OpenDocument/v1.3/)
- [ODF-Validator (odfvalidator.org)](https://odfvalidator.org/)
- [ODF Toolkit](https://odftoolkit.org/)
- [LibreOffice: Documentation/DevGuide](https://wiki.documentfoundation.org/Documentation/DevGuide)
- LibreOffice Base Guide (Text/CSV-Datenquelle, Anmeldung für Serienbrief)

---

*Letzte Aktualisierung: 2026-05-28 (draw:frame-Reihenfolge korrigiert; ODS/ODG/Chart/Master/settings-Fallen ergänzt)*
