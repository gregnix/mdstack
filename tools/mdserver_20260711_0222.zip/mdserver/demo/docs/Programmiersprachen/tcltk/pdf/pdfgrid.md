# pdfgrid - PDF-Tabellen

*Stand: 2026-04-29*

pdfgrid ist eine Tabellenbibliothek für pdf4tcl. Sie ermöglicht die
Erstellung professioneller Tabellen in PDFs mit Features wie automatischen
Summen, Gruppierung, Conditional Formatting und Templates.

## Überblick

pdf4tcl bietet keine eingebaute Tabellen-API. pdfgrid fuellt diese Luecke
mit einer deklarativen, erweiterbaren Architektur. Der Core (pdfgrid)
handhabt Zeilen und Spalten, die Extras-Schicht ergänzt Summen,
Formatierung und Templates ohne den Core zu verändern.

## Grundlegende Verwendung

```tcl
# Grid erstellen
set g [pdfgrid::proc::new -pdf $pdf -columns {40 80 30}]

# Header-Zeile
pdfgrid::proc::row $g {
    {{text "Nr." -style header}}
    {{text "Artikel" -style header}}
    {{text "Preis" -style header align right}}
}

# Datenzeilen
pdfgrid::proc::row $g {
    {{text "1"}}
    {{text "Laptop"}}
    {{text "899.00" align right}}
}

pdfgrid::proc::row $g {
    {{text "2"}}
    {{text "Monitor"}}
    {{text "249.00" align right}}
}

# Rendern
pdfgrid::proc::render $g
```

## Styles

### Style definieren

```tcl
pdfgrid::style define header {
    -font Helvetica-Bold
    -fill "#eeeeee"
}

pdfgrid::style define total {
    -font Helvetica-Bold
}

pdfgrid::style define negative {
    -textcolor red
}
```

### Style verwenden

```tcl
pdfgrid::proc::row $g {
    {{text "Artikel" -style header}}
    {{text "Preis" -style header align right}}
}
```

## Automatische Summen

Summen werden explizit registriert und ausgelöst. Es gibt keine
implizite Typ-Erkennung.

### Summe definieren und sammeln

```tcl
# Spalte 1 für Summe registrieren
pdfgrid::sum column $g 1 total

# Datenzeilen mit -value für Berechnung
pdfgrid::proc::row $g {
    {{text "Laptop"}}
    {{text "899.00" -value 899.00 align right}}
}

pdfgrid::proc::row $g {
    {{text "Monitor"}}
    {{text "249.00" -value 249.00 align right}}
}
```

Wichtig: Nur der `-value`-Parameter wird beruecksichtigt. Der angezeigte
Text (`text`) und der Rechenwert (`-value`) sind getrennt.

### Summenzeile ausgeben

```tcl
pdfgrid::sum row $g total {
    {{text "Summe:" -style total}}
    {{sum total align right -style total}}
}
```

### Mehrere Summen pro Tabelle

```tcl
pdfgrid::sum column $g 1 netto
pdfgrid::sum column $g 2 mwst
pdfgrid::sum column $g 3 brutto

# Datenzeilen ...

pdfgrid::sum row $g netto {
    {{text "Summe:"}}
    {{sum netto align right}}
    {{sum mwst align right}}
    {{sum brutto align right}}
}
```

### Summen-API

| Befehl                       | Beschreibung                      |
|------------------------------|-----------------------------------|
| `pdfgrid::sum column $g col key` | Spalte für Summe registrieren |
| `pdfgrid::sum::get $g key`  | Aktuellen Summenwert abfragen     |
| `pdfgrid::sum::list $g`     | Alle Summen-Keys auflisten        |
| `pdfgrid::sum::reset $g key`| Summe zurücksetzen               |
| `pdfgrid::sum::resetAll $g` | Alle Summen zurücksetzen         |
| `pdfgrid::sum row $g key {cells}` | Summenzeile rendern         |

## Conditional Formatting

Styles werden automatisch auf Zellen angewendet, wenn eine Bedingung
erfüllt ist. Die Auswertung erfolgt vor dem Rendern.

### Bedingung und Style definieren

```tcl
# Styles
pdfgrid::style define negative {-textcolor red}
pdfgrid::style define positive {-textcolor darkgreen -font Helvetica-Bold}

# Bedingungen
pdfgrid::cond define neg {
    if {$value < 0}
    then negative
}

pdfgrid::cond define pos {
    if {$value >= 0}
    then positive
}
```

### Bedingung anwenden

```tcl
pdfgrid::proc::row $g {
    {{text "Saldo"}}
    {{text "-150.00" -value -150.00 -cond neg align right}}
}
```

### Summen mit Conditional Formatting

```tcl
pdfgrid::style define sumNeg {-textcolor red -font Helvetica-Bold}
pdfgrid::style define sumPos {-textcolor darkgreen -font Helvetica-Bold}

pdfgrid::cond define sumNegative {
    if {$value < 0}
    then sumNeg
}

pdfgrid::sum row $g total {
    {{text "Summe:"}}
    {{sum total -cond sumNegative align right}}
}
```

## Gruppensummen

Zeilen können nach einem Gruppenschluessel gesammelt und
Zwischensummen pro Gruppe berechnet werden.

### Gruppierung definieren

```tcl
pdfgrid::group by $g 0 category
pdfgrid::sum column $g 2 total
```

Parameter: Grid-Handle, Spaltenindex für den Gruppenschluessel,
und der Gruppen-Key.

### Gruppenwechsel

Der Gruppenwechsel wird automatisch erkannt, wenn sich der Wert in
der Gruppenspalte aendert. Die Daten müssen vorher sortiert sein,
da pdfgrid keine automatische Sortierung durchführt.

## Multi-Header

Mehrere Header-Zeilen können definiert und bei Seitenumbruechen
automatisch wiederholt werden.

### Header definieren

```tcl
pdfgrid::header add $g {
    {{text "Artikel" rowspan 2 -style header}}
    {{text "Preise" colspan 2 align center -style header}}
}

pdfgrid::header add $g {
    {{text "Netto" -style header}}
    {{text "Brutto" -style header}}
}
```

Die Reihenfolge der `header add`-Aufrufe bestimmt die Reihenfolge
der Header-Zeilen.

### Automatische Wiederholung

Headers werden beim ersten `render()` und bei jedem Seitenumbruch
automatisch gerendert.

### Header-API

| Befehl                         | Beschreibung                |
|--------------------------------|-----------------------------|
| `pdfgrid::header add $g {cells}` | Header-Zeile hinzufügen |
| `pdfgrid::header render $g`   | Headers manuell rendern     |
| `pdfgrid::header hasHeaders $g`| Prüfen ob Headers definiert |

## Templates

Templates sind vordefinierte Grid-Konfigurationen für einen schnellen
Start. Sie setzen Defaults für Margins, Spaltenbreiten und Styles.

### Template definieren

```tcl
pdfgrid::template define invoice {
    margins {15 20 15 20}
    columns {10 80 25 25}
    styles {
        header {-font Helvetica-Bold -fill "#eeeeee"}
        total  {-font Helvetica-Bold}
    }
}
```

### Template anwenden

```tcl
set g [pdfgrid::proc::new -pdf $pdf]
pdfgrid::template apply $g invoice
```

Explizite Grid-Optionen gewinnen immer. Wenn beim Erstellen des Grids
bereits `-columns` gesetzt wurde, überschreibt das Template diese nicht.

### Template-API

| Befehl                              | Beschreibung             |
|-------------------------------------|--------------------------|
| `pdfgrid::template define name {body}` | Template definieren   |
| `pdfgrid::template apply $g name`   | Template anwenden        |
| `pdfgrid::template list`            | Alle Templates auflisten |
| `pdfgrid::template get name`        | Definition abrufen       |

## Vollständiges Beispiel: Rechnung

```tcl
# Template
pdfgrid::template define invoice {
    margins {15 20 15 20}
    columns {10 80 25 25}
    styles {
        header {-font Helvetica-Bold -fill "#eeeeee"}
        total  {-font Helvetica-Bold}
    }
}

# Grid erstellen
set g [pdfgrid::proc::new -pdf $pdf]
pdfgrid::template apply $g invoice

# Summen registrieren
pdfgrid::sum column $g 3 brutto

# Header
pdfgrid::proc::row $g {
    {{text "Pos" -style header}}
    {{text "Artikel" -style header}}
    {{text "Einzelpreis" -style header align right}}
    {{text "Gesamt" -style header align right}}
}

# Datenzeilen
pdfgrid::proc::row $g {
    {{text "1"}}
    {{text "Webentwicklung (40h)"}}
    {{text "85.00" align right}}
    {{text "3400.00" -value 3400.00 align right}}
}

pdfgrid::proc::row $g {
    {{text "2"}}
    {{text "Hosting (1 Jahr)"}}
    {{text "240.00" align right}}
    {{text "240.00" -value 240.00 align right}}
}

# Summenzeile
pdfgrid::sum row $g brutto {
    {{text "" colspan 3}}
    {{text "Gesamt:" -style total}}
    {{sum brutto align right -style total}}
}

pdfgrid::proc::render $g
```

## Design-Prinzipien

pdfgrid folgt konsequent dem Prinzip der Explizitheit:

- Keine implizite Typ-Erkennung
- Keine automatische Sortierung
- Keine versteckte Magie
- Explizite Optionen gewinnen immer über Defaults und Templates
- Alle Erweiterungen (Summen, Conditional Formatting, Templates) liegen
  in der Extras-Schicht und greifen nicht in den Core ein

## Abgrenzung

Was pdfgrid bewusst nicht macht: keine automatische Spaltenbreitenberechnung,
keine eingebaute Paginierung, keine Abhängigkeit von pdfdoclib.
pdfgrid ist ein eigenstaendiges Modul, das direkt mit pdf4tcl arbeitet.
