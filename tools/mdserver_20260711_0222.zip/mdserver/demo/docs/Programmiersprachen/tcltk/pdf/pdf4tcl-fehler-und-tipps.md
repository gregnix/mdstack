# pdf4tcl Fehler und Tipps

*Stand: 2026-04-29*

Dieses Dokument sammelt die häufigsten Fehler bei der Arbeit mit pdf4tcl,
deren Lösungen und Tipps für bessere Performance. Die Erkenntnisse
stammen aus der Praxis mit zahlreichen Demos und Projekten.

## Die 10 häufigsten Fehler

### Fehler 1: orient nicht explizit gesetzt

Das Weglassen von `-orient` führt zu Code, dessen Verhalten vom
Default abhaengt und sich bei Versionswechseln ändern kann.

```tcl
# FALSCH - abhängig vom Default
set pdf [::pdf4tcl::new %AUTO% -paper a4]

# RICHTIG - immer explizit
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
```

### Fehler 2: Baseline vergessen

Die Y-Position bei `$pdf text` ist die Baseline, nicht die Oberkante.
Text bei Y=0 wird abgeschnitten.

```tcl
# FALSCH - Text unsichtbar
$pdf setFont 18 Helvetica
$pdf text "Test" -x 50 -y 0

# RICHTIG - Y >= Schriftgröße
$pdf setFont 18 Helvetica
$pdf text "Test" -x 50 -y 20
```

### Fehler 3: Falsche Font-Namen

Helvetica verwendet `-Oblique`, Times verwendet `-Italic`.

```tcl
# FALSCH
$pdf setFont 12 Helvetica-Italic
$pdf setFont 12 Times-Oblique

# RICHTIG
$pdf setFont 12 Helvetica-Oblique
$pdf setFont 12 Times-Italic
```

### Fehler 4: Farben nicht zurückgesetzt

Farben bleiben aktiv bis sie explizit geändert werden. Nach farbigem
Text oder Formen wird oft vergessen, auf Schwarz zurückzusetzen.

```tcl
# FALSCH - alles danach ist rot
$pdf setFillColor 1.0 0.0 0.0
$pdf text "Warnung" -x 50 -y 100
$pdf text "Normaler Text" -x 50 -y 120    ;# Immer noch rot!

# RICHTIG - Farbe zurücksetzen
$pdf setFillColor 1.0 0.0 0.0
$pdf text "Warnung" -x 50 -y 100
$pdf setFillColor 0.0 0.0 0.0
$pdf text "Normaler Text" -x 50 -y 120
```

### Fehler 5: destroy vor write

Das PDF-Objekt wird zerstört bevor das Dokument gespeichert wird.

```tcl
# FALSCH - Reihenfolge
$pdf endPage
$pdf destroy
$pdf write -file output.pdf    ;# Fehler: Objekt existiert nicht mehr

# RICHTIG - Reihenfolge
$pdf endPage
$pdf write -file output.pdf
$pdf destroy
```

### Fehler 6: endPage vergessen

Ohne `endPage` wird die letzte Seite nicht korrekt abgeschlossen.

```tcl
# FALSCH - letzte Seite fehlt oder ist defekt
$pdf startPage
$pdf text "Inhalt" -x 50 -y 50
$pdf write -file output.pdf
$pdf destroy

# RICHTIG
$pdf startPage
$pdf text "Inhalt" -x 50 -y 50
$pdf endPage
$pdf write -file output.pdf
$pdf destroy
```

### Fehler 7: gsave/grestore vergessen

Transformationen ohne gsave/grestore beeinflussen alle nachfolgenden
Zeichenoperationen.

```tcl
# FALSCH - alles danach ist rotiert
$pdf translate 200 300
$pdf rotate 45
$pdf text "Rotiert" -x 0 -y 0
$pdf text "Normal?" -x 50 -y 400    ;# Auch rotiert!

# RICHTIG
$pdf gsave
$pdf translate 200 300
$pdf rotate 45
$pdf text "Rotiert" -x 0 -y 0
$pdf grestore
$pdf text "Normal" -x 50 -y 400     ;# Tatsächlich normal
```

### Fehler 8: Tk nicht geladen für Bilder

Ohne `package require Tk` sind Bild-Operationen nicht möglich.

```tcl
# FALSCH
package require pdf4tcl 0.9
set img [image create photo -file "logo.png"]    ;# Fehler!

# RICHTIG
package require pdf4tcl 0.9
package require Tk
set img [image create photo -file "logo.png"]
```

### Fehler 9: RGB-Werte 0-255 statt 0.0-1.0

pdf4tcl erwartet Farbwerte zwischen 0.0 und 1.0, nicht 0 bis 255.

```tcl
# FALSCH - Werte > 1.0
$pdf setFillColor 255 0 0

# RICHTIG
$pdf setFillColor 1.0 0.0 0.0

# Oder umrechnen
$pdf setFillColor [expr {255/255.0}] [expr {0/255.0}] [expr {0/255.0}]
```

### Fehler 10: Ausgabe-Verzeichnis fehlt

```tcl
# FALSCH - Verzeichnis existiert nicht
$pdf write -file output/report.pdf    ;# Fehler wenn output/ nicht existiert

# RICHTIG - Verzeichnis sicherstellen
file mkdir output
$pdf write -file output/report.pdf
```

## Troubleshooting

### "can't find package pdf4tcl"

Ursache: pdf4tcl nicht im auto_path.

Lösung 1: Pfad prüfen.
```tcl
puts $auto_path
```

Lösung 2: Pfad explizit setzen.
```tcl
lappend auto_path /pfad/zu/pdf4tcl
package require pdf4tcl
```

Lösung 3: Direkt laden.
```tcl
source /pfad/zu/pdf4tcl.tcl
```

### "invalid command name ::pdf4tcl::new"

Ursache: Alte API (0.8.x) vs. neue API (0.9.x).

```tcl
# Korrekt für 0.9.x
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
```

### PDF wird nicht erstellt

Debug-Vorgehensweise:

```tcl
if {[catch {
    $pdf write -file output.pdf
} err]} {
    puts "ERROR: $err"
    puts $::errorInfo
}
```

Häufige Ursachen: Verzeichnis existiert nicht, keine Schreibrechte,
PDF-Objekt bereits zerstört.

### Umlaute werden nicht dargestellt

Die Standard-Fonts unterstützen WinAnsi/CP1252. Deutsche Umlaute
funktionieren, aber Zeichen ausserhalb dieses Bereichs nicht.

```tcl
# Funktioniert
$pdf text "Gruesse und Schoenes" -x 50 -y 100

# Problematisch (Unicode)
$pdf text "Chinesische Zeichen" -x 50 -y 120
```

Lösung: Sanitization-Funktion verwenden, die problematische Zeichen
durch ASCII-Aequivalente ersetzt.

### Text erscheint am falschen Ort

Pruefpunkte: Ist `-orient true` gesetzt? Wird die richtige Einheit
verwendet (pt, nicht mm)? Liegt die Y-Position innerhalb der Seite?

```tcl
# Debug: Raster zeichnen
proc debug_grid {pdf} {
    $pdf setStrokeColor 0.95 0.95 0.95
    $pdf setLineWidth 0.25
    for {set x 0} {$x <= 595} {set x [expr {$x + 50}]} {
        $pdf line $x 0 $x 842
    }
    for {set y 0} {$y <= 842} {set y [expr {$y + 50}]} {
        $pdf line 0 $y 595 $y
    }
    $pdf setStrokeColor 0 0 0
}
```

## Performance-Tipps

### Kompression immer aktivieren

```tcl
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 1]
```

Reduziert Dateigröße um Faktor 3-5 bei nur 15% mehr Generierungszeit.

### Bilder optimieren

Bilder sind oft der größte Anteil an der Dateigröße. Tipps:

- Bilder vor dem Einbetten auf die benoetigte Größe skalieren
- PNG für Diagramme und Screenshots
- JPEG für Fotos (ab Tk 8.6)
- Gleiche Bilder nur einmal laden und wiederverwenden

```tcl
# FALSCH - Bild auf jeder Seite neu laden
for {set i 0} {$i < 100} {incr i} {
    set img [image create photo -file "logo.png"]
    $pdf startPage
    $pdf image $img -x 50 -y 30 -width 80
    image delete $img
    $pdf endPage
}

# BESSER - Bild einmal laden
set img [image create photo -file "logo.png"]
for {set i 0} {$i < 100} {incr i} {
    $pdf startPage
    $pdf image $img -x 50 -y 30 -width 80
    $pdf endPage
}
image delete $img
```

### Font-Wechsel minimieren

Jeder `setFont`-Aufruf erzeugt einen Eintrag im PDF-Stream.
Bei tausenden Zeilen ist es effizienter, gleich formatierte Texte
zu buendeln.

```tcl
# LANGSAMER - staendiger Font-Wechsel
foreach item $daten {
    $pdf setFont 10 Helvetica-Bold
    $pdf text [dict get $item label] -x 50 -y $y
    $pdf setFont 10 Helvetica
    $pdf text [dict get $item value] -x 200 -y $y
    incr y 15
}

# SCHNELLER - Labels und Werte getrennt
$pdf setFont 10 Helvetica-Bold
foreach item $daten {
    $pdf text [dict get $item label] -x 50 -y [dict get $item y]
}
$pdf setFont 10 Helvetica
foreach item $daten {
    $pdf text [dict get $item value] -x 200 -y [dict get $item y]
}
```

### Größe messen

```tcl
# PDF-Größe nach Erzeugung prüfen
set size [file size output.pdf]
puts "PDF-Größe: [expr {$size / 1024}] KB"

# Bei Problemen mit pdfinfo analysieren
# pdfinfo output.pdf
```

## Validierung mit externen Tools

### poppler-utils

```bash
# PDF-Informationen anzeigen
pdfinfo dokument.pdf

# Text extrahieren (zum Prüfen)
pdftotext dokument.pdf -
```

### MuPDF

```bash
# PDF-Struktur analysieren
mutool info dokument.pdf
```

### Checkliste vor Auslieferung

- Alle Seiten vorhanden und korrekt
- Fonts korrekt dargestellt
- Bilder an richtiger Position und Größe
- Kompression aktiviert
- Dateigröße akzeptabel
- Text extrahierbar (pdftotext)
