# pdf4tcl Grundlagen

*Stand: 2026-04-29*

Dieses Dokument behandelt Installation, Koordinatensystem, Einheiten und
die ersten Schritte mit pdf4tcl. Es richtet sich an Einsteiger, die mit
Tcl/Tk bereits vertraut sind und nun PDF-Dokumente erzeugen moechten.

## Installation

### Voraussetzungen

pdf4tcl benötigt Tcl/Tk ab Version 8.6. Die empfohlene Version von
pdf4tcl ist 0.9.4. Optional können folgende Tools installiert werden:

- poppler-utils: `pdfinfo` und `pdftotext` für PDF-Validierung
- mupdf: Leichtgewichtiger PDF-Viewer
- ghostscript: Für PDF/A-Konvertierung

### Installation über Paketmanager

```bash
# Debian/Ubuntu
sudo apt-get install tcllib

# Fedora
sudo dnf install tcllib

# macOS
brew install tcllib
```

### Lokale Installation (projektspezifisch)

```tcl
#!/usr/bin/env tclsh

# Lokale Version laden
lappend auto_path [file join [file dirname [info script]] pdf4tcl094]
package require pdf4tcl 0.9
```

### Systemweite Installation

```bash
mkdir -p ~/.local/lib/tcl8.6/pdf4tcl0.9

cp pdf4tcl.tcl ~/.local/lib/tcl8.6/pdf4tcl0.9/
echo "package ifneeded pdf4tcl 0.9 [list source [file join \$dir pdf4tcl.tcl]]" \
    > ~/.local/lib/tcl8.6/pdf4tcl0.9/pkgIndex.tcl
```

### Installation prüfen

```tcl
#!/usr/bin/env tclsh

if {[catch {package require pdf4tcl 0.9} err]} {
    puts "ERROR: pdf4tcl nicht gefunden - $err"
    exit 1
}

puts "pdf4tcl Version: [package require pdf4tcl]"

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage
$pdf setFont 18 Helvetica-Bold
$pdf text "Installation successful!" -x 50 -y 50
$pdf endPage

set outfile "test-installation.pdf"
$pdf write -file $outfile
$pdf destroy

puts "Test-PDF erstellt: $outfile"
```

## Koordinatensystem

Das Koordinatensystem ist die häufigste Fehlerquelle bei Anfaengern.
pdf4tcl unterstützt zwei Modi, die über `-orient` gesteuert werden.

### Mode 1: orient true (empfohlen)

Der Ursprung (0,0) liegt oben links. Y wächst nach unten, X nach rechts.
Dies entspricht dem Verhalten von Tk Canvas und HTML.

```
(0,0) ---------------------> X
  |
  |    Dokument
  |
  v
  Y
```

```tcl
set pdf [pdf4tcl::pdf4tcl create %AUTO% -paper a4 -orient true]
$pdf startPage

# Text oben
$pdf text "Oben" -x 50 -y 50      ;# Y=50 --> nahe dem oberen Rand

# Text unten
$pdf text "Unten" -x 50 -y 800    ;# Y=800 --> nahe dem unteren Rand

$pdf endPage
```

### Mode 2: orient false (mathematisch)

Der Ursprung (0,0) liegt unten links. Y wächst nach oben.
Dies entspricht dem kartesischen Koordinatensystem.

```
  Y
  ^
  |
  |    Dokument
  |
(0,0) ---------------------> X
```

```tcl
set pdf [pdf4tcl::pdf4tcl create %AUTO% -paper a4 -orient false]
$pdf startPage

# Text unten
$pdf text "Unten" -x 50 -y 50     ;# Y=50 --> nahe dem unteren Rand

# Text oben
$pdf text "Oben" -x 50 -y 800     ;# Y=800 --> nahe dem oberen Rand

$pdf endPage
```

### Empfehlung

`-orient true` immer explizit setzen. Der Code wird dadurch
selbstdokumentierend und unabhängig von möglichen Default-Änderungen.

```tcl
# RICHTIG - immer explizit
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]

# FALSCH - abhängig vom Default
set pdf [::pdf4tcl::new %AUTO% -paper a4]
```

## Einheiten

### Points als Grundeinheit

pdf4tcl rechnet intern in Points (pt). Ein Point entspricht 1/72 Inch.
Die Umrechnung:

| Von       | Nach    | Faktor            |
|-----------|---------|-------------------|
| 1 inch    | pt      | 72                |
| 1 mm      | pt      | 2.8346            |
| 1 pt      | mm      | 0.3528            |
| 1 cm      | pt      | 28.346            |

### Konvertierungsfunktionen

```tcl
proc mm_to_pt {mm} {
    return [expr {$mm / 25.4 * 72.0}]
}

proc cm_to_pt {cm} {
    return [expr {$cm / 2.54 * 72.0}]
}

proc pt_to_mm {pt} {
    return [expr {$pt * 25.4 / 72.0}]
}
```

### Typische Werte für A4

```tcl
mm_to_pt 210    ;# --> 595.276 pt (A4 Breite)
mm_to_pt 297    ;# --> 841.890 pt (A4 Höhe)
mm_to_pt 20     ;# --> 56.693 pt (2cm Rand)
mm_to_pt 10     ;# --> 28.346 pt (1cm Rand)
```

### A4-Abmessungen

| Format | mm          | pt              | inch           |
|--------|-------------|-----------------|----------------|
| A4     | 210 x 297   | 595.276 x 841.890 | 8.27 x 11.69 |
| A3     | 297 x 420   | 842 x 1191     | 11.69 x 16.54  |
| A5     | 148 x 210   | 420 x 595      | 5.83 x 8.27    |
| Letter | 216 x 279   | 612 x 792      | 8.5 x 11       |

## Erste Schritte

### Das minimale PDF

```tcl
#!/usr/bin/env tclsh
package require pdf4tcl 0.9

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage
$pdf setFont 18 Helvetica-Bold
$pdf text "Hello World!" -x 50 -y 100
$pdf endPage
$pdf write -file hello.pdf
$pdf destroy
```

### Zeile für Zeile erklärt

`::pdf4tcl::new` erstellt ein neues PDF-Objekt. `%AUTO%` generiert
automatisch einen Befehlsnamen (z.B. `pdf1`). Mit `-paper a4` wird
das Papierformat A4 (595 x 842 pt) gesetzt. `-orient true` legt den
Koordinatenursprung auf oben links fest.

`startPage` beginnt eine neue Seite. `setFont` setzt Schriftgröße und
Schriftart. `text` schreibt Text an die angegebene Position. `endPage`
schliesst die Seite ab. `write -file` speichert das PDF. `destroy`
gibt das Objekt frei.

### Text mit verschiedenen Fonts

```tcl
#!/usr/bin/env tclsh
package require pdf4tcl 0.9

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

# Überschrift
$pdf setFont 24 Helvetica-Bold
$pdf text "Mein Dokument" -x 50 -y 60

# Fliesstext
$pdf setFont 12 Times-Roman
$pdf text "Dies ist ein Absatz in Times Roman." -x 50 -y 100

# Hervorgehobener Text
$pdf setFont 12 Helvetica-Bold
$pdf text "Wichtig:" -x 50 -y 130
$pdf setFont 12 Helvetica
$pdf text "Normaler Text nach der Hervorhebung." -x 110 -y 130

# Monospace für Code
$pdf setFont 10 Courier
$pdf text "puts \"Hello World\"" -x 50 -y 170

$pdf endPage
$pdf write -file fonts-demo.pdf
$pdf destroy
```

### Farben und Formen

```tcl
#!/usr/bin/env tclsh
package require pdf4tcl 0.9

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

# Farbiger Text
$pdf setFont 16 Helvetica-Bold
$pdf setFillColor 0.8 0.0 0.0
$pdf text "Roter Text" -x 50 -y 50

# Linie
$pdf setStrokeColor 0.0 0.0 0.0
$pdf setLineWidth 1
$pdf line 50 70 300 70

# Gefuelltes Rechteck
$pdf setFillColor 0.9 0.9 0.9
$pdf rectangle 50 90 250 80 -filled 1

# Text auf Rechteck
$pdf setFillColor 0.0 0.0 0.0
$pdf setFont 12 Helvetica
$pdf text "Text auf grauem Hintergrund" -x 60 -y 120

$pdf endPage
$pdf write -file farben-demo.pdf
$pdf destroy
```

### Speichern und Ausgabe

```tcl
# In Datei speichern
$pdf write -file output.pdf

# Als String zurückgeben
set pdfdata [$pdf get]

# Verzeichnis sicherstellen
file mkdir output
$pdf write -file [file join output dokument.pdf]
```

## Projektstruktur

Eine empfohlene Projektstruktur für pdf4tcl-Projekte:

```
meinprojekt/
|-- src/
|   |-- generate.tcl        # Haupt-Script
|   |-- helpers.tcl          # Hilfsfunktionen
|-- output/                  # Generierte PDFs
|-- data/                    # Eingabedaten
|-- images/                  # Logos und Bilder
```

## Nächste Schritte

- Text-API und Fonts: siehe pdf4tcl-text-und-fonts.md
- Grafik und Farben: siehe pdf4tcl-grafik-und-farben.md
- Layout-Patterns: siehe pdf4tcl-layout-patterns.md
