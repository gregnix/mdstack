# pdfdoclib - Dokument-Abstraktion

*Stand: 2026-04-29*

pdfdoclib ist eine Abstraktionsbibliothek über pdf4tcl. Sie bietet
High-Level-Befehle für Dokumente, Briefe, Etiketten und Styling,
ohne dass man sich um Koordinaten und Points kuemmern muss.

## Überblick

Während pdf4tcl auf der Ebene von Linien, Text und Koordinaten arbeitet,
bietet pdfdoclib Befehle wie `chapter`, `paragraph`, `infoBox` und
`dinLetter`. Die Bibliothek kuemmert sich um Positionierung,
Seitenumbrueche und konsistentes Styling.

## Installation

```tcl
source pdfdoclib-0.4.tm
```

## Grundlegende Verwendung

```tcl
source pdfdoclib-0.4.tm

# Dokument erstellen
document create doc

# Kapitel und Text
doc chapter "Einleitung"
doc paragraph "Dies ist der erste Absatz des Dokuments."
doc paragraph "Hier folgt ein weiterer Absatz."

# Speichern
doc write "dokument.pdf"
```

## Styling-System

### Vordefinierte Styles

pdfdoclib bietet vier vordefinierte Info-Boxen mit Farbhintergrund:

```tcl
doc infoBox "Hinweis: Wichtige Information"
doc warningBox "Achtung: Vorsicht bei dieser Einstellung"
doc errorBox "Fehler: Aktion nicht möglich"
doc successBox "Erfolg: Vorgang abgeschlossen"
```

| Box-Typ    | Hintergrundfarbe | Verwendung          |
|------------|------------------|---------------------|
| infoBox    | Blau             | Hinweise, Tipps     |
| warningBox | Gelb             | Warnungen           |
| errorBox   | Rot              | Fehler, Probleme    |
| successBox | Gruen            | Erfolg, Bestaetigungen |

### Custom Styles

Styles werden als Optionsliste übergeben:

```tcl
doc paragraph "Hervorgehobener Text" 0 \
    {-background {1.0 1.0 0.0} -border 1 \
     -textcolor {0.0 0.0 0.0} -padding 5}
```

### Style setzen und zurücksetzen

```tcl
# Style für folgende Elemente setzen
doc setStyle {-background {0.9 0.9 0.9} -border 1}
doc paragraph "Text mit grauem Hintergrund"
doc paragraph "Auch dieser Text hat grauen Hintergrund"

# Style zurücksetzen
doc resetStyle
doc paragraph "Normaler Text ohne Hintergrund"
```

### Template-System

Templates sind benannte Style-Definitionen für Wiederverwendung:

```tcl
# Template definieren
doc defineTemplate "highlight" \
    {-background {1.0 1.0 0.0} -border 1 \
     -textcolor {0.0 0.0 0.0} -padding 5}

# Template verwenden
doc useTemplate "highlight"
doc paragraph "Hervorgehobener Absatz"
```

### Style-Optionen

| Option         | Typ       | Standard   | Beschreibung         |
|----------------|-----------|------------|----------------------|
| -background    | {r g b}   | ""         | Hintergrundfarbe     |
| -border        | bool      | 0          | Rahmen an/aus        |
| -bordercolor   | {r g b}   | {0 0 0}    | Rahmenfarbe          |
| -borderwidth   | size      | 0.5        | Rahmenbreite         |
| -textcolor     | {r g b}   | {0 0 0}    | Textfarbe            |
| -padding       | size      | 0          | Innenabstand         |

## Spalten-Layouts

### Zwei Spalten

```tcl
doc twoColumns "Linker Text" "Rechter Text"
```

### Drei Spalten

```tcl
doc threeColumns "Links" "Mitte" "Rechts"
```

## DIN-Brief-Support

pdfdoclib unterstützt die Erstellung von DIN-5008-konformen Briefen.

### Grundsyntax

```tcl
doc dinLetter \
    "Musterfirma GmbH\nMax Mustermann\nMusterstr. 123\n12345 Musterstadt" \
    "Anna Schmidt\nBeispiel AG\nHauptstr. 45\n54321 Beispieldorf" \
    "Angebot für Software-Entwicklung" \
    "Sehr geehrte Frau Schmidt,\n\nvielen Dank für Ihr Interesse..." \
    "Mit freundlichen Gruessen" \
    "Max Mustermann" \
    "standard"
```

Die Parameter sind: Absender, Empfaenger, Betreff, Brieftext,
Grussformel, Unterschrift und Layout-Name.

### Verfügbare Layouts

| Layout    | Beschreibung                     |
|-----------|----------------------------------|
| standard  | DIN 5008 konform, 83% Seitenbreite |
| compact   | Kompakt für kurze Briefe        |
| spacious  | Grosszuegig für wichtige Briefe |
| a5        | Für DIN A5 Format               |

### Eigenes Layout definieren

```tcl
doc addLayout "mein_layout" [dict create \
    letterhead [dict create x 30 y 30 w 85 h 65] \
    recipient  [dict create x 120 y 30 w 85 h 65] \
    date       [dict create x 120 y 100 w 85 h 25] \
    subject    [dict create x 30 y 130 w 175 h 30] \
    salutation [dict create x 30 y 165 w 175 h 30] \
    body       [dict create x 30 y 200 w 175] \
    closing    [dict create x 30 y 250 w 85 h 45]]

doc dinLetter $absender $empfaenger $betreff $text \
    "Mit freundlichen Gruessen" "Max Mustermann" "mein_layout"
```

### Layout-Management

```tcl
# Layout wechseln
doc setLayout "compact"

# Verfügbare Layouts anzeigen
set layouts [doc listLayouts]

# Layout-Definition abrufen
set layout [doc getLayout "standard"]
```

## Etiketten

### Adressetiketten

```tcl
doc addressLabel "Max Mustermann" "Musterstr. 123" \
    "Musterstadt" "12345" "Deutschland"
```

### Produktetiketten

```tcl
doc productLabel "Laptop" "999.99" "ABC123" \
    "Hochwertiger Business-Laptop"
```

## Kompatibilität

pdfdoclib 0.4 ist vollständig rueckwaertskompatibel mit Version 0.3.
Alle bestehenden Methoden funktionieren unverändert. Die neuen Features
(Styling, DIN-Brief, Etiketten) sind optional und erweiternd.

## Abgrenzung zu pdf4tcl

| Aspekt            | pdf4tcl         | pdfdoclib           |
|-------------------|-----------------|---------------------|
| Abstraktionsebene | Low-Level       | High-Level          |
| Positionierung    | Manuell (pt)    | Automatisch         |
| Seitenumbruch     | Manuell         | Automatisch         |
| Styling           | setFont/setColor | Templates, Styles  |
| Briefe            | Nicht enthalten | DIN 5008 konform    |
| Etiketten         | Nicht enthalten | Adress-/Produktetiketten |
