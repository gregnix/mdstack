# pdf4tcl Bilder und Seiten

*Stand: 2026-04-29*

Dieses Dokument behandelt das Einbetten von Bildern, Seitenmanagement,
Kompression und die Steuerung von mehrseitigen Dokumenten.

## Bilder einbetten

### Voraussetzungen

pdf4tcl arbeitet mit Tk Photo Images. Dafuer muss `package require Tk`
geladen sein, auch wenn keine GUI angezeigt wird.

```tcl
#!/usr/bin/env tclsh
package require pdf4tcl 0.9
package require Tk            ;# Wichtig für Bilder!
```

Kein Fenster erscheint -- Tk läuft im Hintergrund.

### Bild laden und einbetten

```tcl
# Bild aus Datei laden
set img [image create photo -file "logo.png"]

# In PDF einbetten
$pdf image $img -x 50 -y 100 -width 200

# Aufräumen (wichtig!)
image delete $img
```

Unterstuetzte Formate: PNG, GIF, und ab Tk 8.6 auch JPEG.

### Bildgroesse steuern

```tcl
# Nur Breite angeben (Höhe proportional)
$pdf image $img -x 50 -y 100 -width 200

# Nur Höhe angeben (Breite proportional)
$pdf image $img -x 50 -y 100 -height 100

# Breite und Höhe (kann verzerren)
$pdf image $img -x 50 -y 100 -width 200 -height 100
```

### Bildgroesse abfragen

```tcl
set img [image create photo -file "foto.png"]
set breite [image width $img]
set höhe [image height $img]
puts "Bild: ${breite}x${höhe} Pixel"
```

### Proportionale Skalierung

```tcl
proc fitImage {pdf img x y maxW maxH} {
    set imgW [image width $img]
    set imgH [image height $img]
    
    set scaleW [expr {double($maxW) / $imgW}]
    set scaleH [expr {double($maxH) / $imgH}]
    set scale [expr {min($scaleW, $scaleH)}]
    
    set newW [expr {int($imgW * $scale)}]
    set newH [expr {int($imgH * $scale)}]
    
    $pdf image $img -x $x -y $y -width $newW -height $newH
}
```

### Ressourcen-Management

Bilder müssen nach Verwendung gelöscht werden, um Speicher freizugeben.

```tcl
# RICHTIG - Bild nach Verwendung löschen
set img [image create photo -file "logo.png"]
$pdf image $img -x 50 -y 100 -width 200
image delete $img

# FALSCH - Speicherleck bei vielen Bildern
foreach file $bildliste {
    set img [image create photo -file $file]
    $pdf image $img -x 50 -y $y -width 200
    # image delete vergessen!
}
```

Bei Dokumenten mit vielen Bildern kann ein fehlender `image delete`
zu erheblichem Speicherverbrauch fuehren.

## Seitenmanagement

### Seiten beginnen und beenden

```tcl
$pdf startPage    ;# Neue Seite beginnen
# ... Zeichenoperationen ...
$pdf endPage      ;# Seite abschliessen
```

Jede Seite muss explizit begonnen und beendet werden. Zeichenoperationen
ohne vorangehendes `startPage` fuehren zu Fehlern.

### Mehrseitige Dokumente

```tcl
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]

for {set seite 1} {$seite <= 5} {incr seite} {
    $pdf startPage
    $pdf setFont 12 Helvetica
    $pdf text "Seite $seite von 5" -x 50 -y 50
    $pdf endPage
}

$pdf write -file mehrseitig.pdf
$pdf destroy
```

### Seitenformat wechseln

Innerhalb eines Dokuments können verschiedene Papierformate und
Orientierungen verwendet werden.

```tcl
# Erste Seite: A4 Hochformat
$pdf startPage -paper a4
$pdf text "Hochformat" -x 50 -y 50
$pdf endPage

# Zweite Seite: A4 Querformat
$pdf startPage -paper {842 595}
$pdf text "Querformat" -x 50 -y 50
$pdf endPage
```

### Zeichenbereich abfragen

```tcl
set area [$pdf getDrawableArea]
lassign $area x y breite höhe
puts "Zeichenbereich: ${breite}x${höhe} pt ab ($x, $y)"
```

## Kompression

### Kompression aktivieren

Die Kompression reduziert die Dateigröße erheblich und sollte immer
aktiviert werden.

```tcl
# RICHTIG - mit Kompression
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 1]

# Ohne Kompression (nur für Debugging)
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 0]
```

Typische Ergebnisse:

| Szenario        | Ohne Kompression | Mit Kompression | Faktor |
|-----------------|------------------|-----------------|--------|
| 1 Seite Text    | 20 KB            | 5 KB            | 4x     |
| 50 Seiten Text  | 485 KB           | 95 KB           | 5x     |
| Mit Bildern     | 500 KB           | 200 KB          | 2.5x   |

Die Kompression kostet nur ca. 15% mehr Generierungszeit.

### Benchmark-Funktion

```tcl
proc benchmark_compression {pages} {
    foreach compress {0 1} {
        set start [clock milliseconds]
        
        set pdf [::pdf4tcl::new %AUTO% \
            -paper a4 -orient true -compress $compress]
        
        for {set i 0} {$i < $pages} {incr i} {
            $pdf startPage
            $pdf setFont 12 Helvetica
            for {set j 0} {$j < 40} {incr j} {
                $pdf text "Zeile $j auf Seite $i" \
                    -x 50 -y [expr {50 + $j * 15}]
            }
            $pdf endPage
        }
        
        set filename "bench_compress_${compress}.pdf"
        $pdf write -file $filename
        $pdf destroy
        
        set elapsed [expr {[clock milliseconds] - $start}]
        set size [file size $filename]
        
        puts "Compress $compress: ${elapsed}ms, [expr {$size / 1024}] KB"
    }
}
```

## Speichern

### In Datei speichern

```tcl
# Verzeichnis sicherstellen
file mkdir output

# Speichern
$pdf write -file [file join output dokument.pdf]
```

### Als String zurückgeben

```tcl
set pdfdata [$pdf get]
# Kann z.B. direkt in eine Datenbank geschrieben werden
```

### Fehlerbehandlung beim Speichern

```tcl
if {[catch {
    $pdf write -file output.pdf
} err]} {
    puts "ERROR: $err"
    puts $::errorInfo
}
```

Häufige Ursachen für Fehler beim Speichern: das Ausgabe-Verzeichnis
existiert nicht, fehlende Schreibrechte, oder das PDF-Objekt wurde
bereits mit `$pdf destroy` freigegeben.

## Aufraeum-Reihenfolge

Die korrekte Reihenfolge beim Abschliessen eines Dokuments:

```tcl
# 1. Letzte Seite beenden
$pdf endPage

# 2. PDF speichern
$pdf write -file output.pdf

# 3. PDF-Objekt zerstören
$pdf destroy

# FALSCH - destroy vor write
$pdf destroy
$pdf write -file output.pdf    ;# Fehler!
```

## Vollständiges Beispiel: Dokument mit Bild

```tcl
#!/usr/bin/env tclsh
package require pdf4tcl 0.9
package require Tk

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 1]

$pdf startPage

# Titel
$pdf setFont 20 Helvetica-Bold
$pdf text "Bericht mit Logo" -x 50 -y 50

# Logo einbetten
if {[file exists "logo.png"]} {
    set img [image create photo -file "logo.png"]
    $pdf image $img -x 400 -y 30 -width 100
    image delete $img
}

# Trennlinie
$pdf setStrokeColor 0.6 0.6 0.6
$pdf setLineWidth 0.5
$pdf line 50 80 545 80
$pdf setStrokeColor 0 0 0

# Fliesstext
$pdf setFont 12 Times-Roman
set y 110
foreach zeile {
    "Dies ist der erste Absatz des Berichts."
    "Hier folgt der zweite Absatz mit weiteren Details."
    "Der dritte Absatz schliesst die Zusammenfassung ab."
} {
    $pdf text $zeile -x 50 -y $y
    incr y 20
}

$pdf endPage
$pdf write -file bericht.pdf
$pdf destroy

puts "PDF erstellt: bericht.pdf"
```

## Nächste Schritte

- Layout-Patterns und Helper-Library: siehe pdf4tcl-layout-patterns.md
- Fehler vermeiden: siehe pdf4tcl-fehler-und-tipps.md
