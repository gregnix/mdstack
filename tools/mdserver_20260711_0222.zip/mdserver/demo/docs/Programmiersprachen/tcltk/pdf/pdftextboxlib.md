# pdftextboxlib - Erweiterte TextBox

*Stand: 2026-04-29*

pdftextboxlib ist eine Erweiterung von pdf4tcl, die `drawTextBoxEx`
bereitstellt. Die Funktion kombiniert Textausgabe, Font-Einstellung,
Farben und Rahmen in einem einzigen Aufruf.

## Das Problem

In pdf4tcl erfordert eine formatierte TextBox mehrere separate Aufrufe:

```tcl
# pdf4tcl (Original) - 5 Zeilen für eine Box
$pdf setFont 12 "Helvetica-Bold"
$pdf setFillColor 1.0 0.0 0.0
$pdf setStrokeColor 0.0 0.0 0.0
$pdf setLineWidth 2
$pdf rectangle 50 50 100 50
$pdf drawTextBox 50 50 100 50 "Text" -align center
```

## Die Lösung

pdftextboxlib buendelt alle Optionen in einem Aufruf:

```tcl
# pdftextboxlib - 1 Aufruf
::pdftextbox::drawTextBoxEx $pdf 50 50 100 50 "Text" \
    -align center -fontsize 12 -fontname "Helvetica-Bold" \
    -background {1.0 0.0 0.0} -border 1 -borderwidth 2
```

## Installation

```tcl
source pdftextboxlib.tcl
```

## Grundsyntax

```tcl
::pdftextbox::drawTextBoxEx $pdf x y width height str ?option value...?
```

Die Parameter x, y, width, height und str sind identisch mit
`$pdf drawTextBox` aus pdf4tcl.

## Standard-Optionen (wie pdf4tcl)

| Option     | Werte                         | Standard |
|------------|-------------------------------|----------|
| -align     | left, right, center, justify  | left     |
| -linesvar  | Variablenname                 | -        |
| -dryrun    | bool                          | 0        |

## Zusätzliche Optionen

| Option       | Typ     | Standard     | Beschreibung       |
|--------------|---------|--------------|--------------------|
| -fontsize    | size    | 10           | Schriftgröße     |
| -fontname    | name    | "Helvetica"  | Schriftart         |
| -padding     | size    | 2            | Innenabstand       |
| -border      | bool    | 0            | Rahmen an/aus      |
| -bordercolor | {r g b} | {0 0 0}      | Rahmenfarbe        |
| -borderwidth | size    | 0.5          | Rahmenbreite       |
| -background  | {r g b} | ""           | Hintergrundfarbe   |
| -textcolor   | {r g b} | {0 0 0}      | Textfarbe          |

## Beispiele

### Einfache TextBox mit Rahmen

```tcl
::pdftextbox::drawTextBoxEx $pdf 50 50 100 30 "Hallo Welt!" \
    -border 1
```

### Verschiedene Ausrichtungen

```tcl
# Links
::pdftextbox::drawTextBoxEx $pdf 50 50 60 30 "Links" \
    -align left -border 1

# Zentriert
::pdftextbox::drawTextBoxEx $pdf 120 50 60 30 "Mitte" \
    -align center -border 1

# Rechts
::pdftextbox::drawTextBoxEx $pdf 190 50 60 30 "Rechts" \
    -align right -border 1

# Blocksatz
::pdftextbox::drawTextBoxEx $pdf 50 100 150 40 \
    "Blocksatz: Dieser Text wird gleichmäßig verteilt." \
    -align justify -border 1
```

### Farben

```tcl
# Roter Hintergrund mit weissem Text
::pdftextbox::drawTextBoxEx $pdf 50 50 100 30 "Warnung" \
    -background {1.0 0.0 0.0} -textcolor {1.0 1.0 1.0} -border 1

# Gruener Hintergrund
::pdftextbox::drawTextBoxEx $pdf 160 50 100 30 "Erfolg" \
    -background {0.0 0.8 0.0} -textcolor {1.0 1.0 1.0} -border 1
```

### Schriftarten und -groessen

```tcl
# Kleine Schrift
::pdftextbox::drawTextBoxEx $pdf 50 50 80 30 "Klein" \
    -fontsize 8 -border 1

# Grosse fette Schrift
::pdftextbox::drawTextBoxEx $pdf 140 50 80 30 "Gross" \
    -fontsize 16 -fontname "Helvetica-Bold" -border 1
```

### Verschiedene Rahmen

```tcl
# Duenner grauer Rahmen
::pdftextbox::drawTextBoxEx $pdf 50 50 80 30 "Duenn" \
    -border 1 -borderwidth 0.5 -bordercolor {0.5 0.5 0.5}

# Dicker schwarzer Rahmen
::pdftextbox::drawTextBoxEx $pdf 140 50 80 30 "Dick" \
    -border 1 -borderwidth 2 -bordercolor {0.0 0.0 0.0}

# Roter Rahmen
::pdftextbox::drawTextBoxEx $pdf 230 50 80 30 "Rot" \
    -border 1 -borderwidth 1 -bordercolor {1.0 0.0 0.0}
```

## DIN-Brief mit pdftextboxlib

```tcl
# Briefkopf
::pdftextbox::drawTextBoxEx $pdf 25 25 80 60 \
    "Musterfirma GmbH\nMax Mustermann\nMusterstr. 123\n12345 Musterstadt" \
    -fontsize 10 -fontname "Helvetica"

# Empfaenger
::pdftextbox::drawTextBoxEx $pdf 105 25 80 60 \
    "Anna Schmidt\nBeispiel AG\nHauptstr. 45\n54321 Beispieldorf" \
    -fontsize 10 -fontname "Helvetica"

# Betreff
::pdftextbox::drawTextBoxEx $pdf 25 90 160 20 \
    "Betreff: Angebot für Software-Entwicklung" \
    -fontsize 10 -fontname "Helvetica-Bold"

# Brieftext
::pdftextbox::drawTextBoxEx $pdf 25 140 160 120 \
    "Sehr geehrte Frau Schmidt,\n\nvielen Dank für Ihr Interesse..." \
    -fontsize 10 -fontname "Times-Roman" -align justify
```

## Vorteile gegenüber pdf4tcl

| Aspekt         | pdf4tcl drawTextBox     | pdftextboxlib drawTextBoxEx |
|----------------|-------------------------|-----------------------------|
| Font setzen    | Separater Aufruf        | Option -fontname/-fontsize  |
| Farbe setzen   | Separater Aufruf        | Option -textcolor           |
| Hintergrund    | Separater rectangle     | Option -background          |
| Rahmen         | Separater rectangle     | Option -border              |
| Codezeilen     | 5-6 Zeilen              | 1 Zeile                     |
| State-Tracking | Manuell (Farben reset)  | Automatisch                 |

## Zusammenspiel mit anderen Bibliotheken

pdftextboxlib arbeitet direkt mit pdf4tcl und kann unabhängig von
pdfdoclib und pdfgrid verwendet werden. Es eignet sich besonders für
Fälle, in denen einzelne formatierte Textblöcke benötigt werden,
ohne die volle Abstraktion von pdfdoclib.

| Bibliothek    | Staerke                           |
|---------------|-----------------------------------|
| pdftextboxlib | Einzelne formatierte Textblöcke  |
| pdfdoclib     | Vollständige Dokument-Abstraktion |
| pdfgrid       | Tabellarische Daten               |
