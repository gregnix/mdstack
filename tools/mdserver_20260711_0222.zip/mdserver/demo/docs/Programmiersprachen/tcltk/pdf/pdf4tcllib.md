# pdf4tcllib - PDF-Erweiterungen für pdf4tcl

*Stand: 2026-04-29*

pdf4tcllib erweitert pdf4tcl um Unicode-Handling, Emoji-Fallbacks,
Seitenkontext-Verwaltung, Textumbruch und vereinfachte Tabellen.
Verpackt als einzelne .tm-Datei (~2700 Zeilen, stand 0.1.1).

## Überblick

Während pdf4tcl auf der Ebene von Linien, Text und Koordinaten arbeitet,
bietet pdf4tcllib eine Schicht darüber: Seitenkontext mit Raendern,
Unicode-sichere Textausgabe, automatischen Textumbruch und
High-Level-Tabellen. Die Bibliothek löst Probleme die bei jedem
PDF-Projekt wiederkehren.

## Installation

```tcl
# Als .tm Modul
tcl::tm::path add /pfad/zu/lib
package require pdf4tcllib 0.1

# Oder in vendors/tm/ (mdstack, mdhelp4)
tcl::tm::path add vendors/tm
package require pdf4tcllib 0.1
```

Abhängigkeit: pdf4tcl (in vendors/pkg/ oder systemweit).

## Module

pdf4tcllib ist intern in Namespaces gegliedert:

| Namespace | Zeilen | Aufgabe |
|---|---|---|
| page | 240 | Seitenkontext, Grid, Orientation |
| text | 230 | Unicode-sicherer Text, Textumbruch |
| table | 355 | Tabellen (simpleTable + render) |
| unicode | 310 | Sanitization, Emoji-Fallbacks, BOM |
| color | 90 | Farbpaletten, RGB-Helfer |
| core | 120 | readFile, version, validate_pdf |

## Seitenkontext (page)

### Das Problem

In pdf4tcl muss man Seitengroesse, Raender und Textbereich
bei jeder Koordinatenberechnung selbst verwalten:

```tcl
# Ohne pdf4tcllib - überall Wiederholung:
set pageW [expr {595.28}]  ;# A4
set margin [expr {20 * 2.835}]
set textW [expr {$pageW - 2 * $margin}]
set startX $margin
set startY [expr {841.89 - $margin}]
```

### Die Lösung: page::context

```tcl
# Standardaufruf mit orient (empfohlen):
set ctx [pdf4tcllib::page::context a4 -margin 20 -orient true]

# Optionen:
#   -margin N       Rand in mm (Standard: 20)
#   -orient true    Ursprung oben links, y wächst nach unten (Standard, empfohlen)
#   -orient false   Ursprung unten links, y wächst nach oben (Standard-PDF)
#   -landscape 1    Querformat

# Zugriff auf berechnete Werte (orient true):
dict get $ctx page_w    ;# 595.28  (Seitenbreite in pt)
dict get $ctx page_h    ;# 841.89  (Seitenhoehe in pt)
dict get $ctx left      ;#  56.7   (linker Rand in pt)
dict get $ctx top       ;#  56.7   (oberer Rand -- kleiner Wert = oben bei orient true)
dict get $ctx bottom    ;# 785.19  (unterer Rand -- grosser Wert = unten bei orient true)
dict get $ctx text_w    ;# 481.88  (Textbreite in pt)
dict get $ctx text_h    ;# 728.49  (Texthoehe in pt)
dict get $ctx margin    ;#  56.7   (Rand in pt)
```

**Wichtig:** `top` und `bottom` sind orient-abhängig:

| | orient true (empfohlen) | orient false |
|---|---|---|
| `top` | kleiner Wert (~56pt) -- nahe Seitenoberrand | grosser Wert (~785pt) |
| `bottom` | grosser Wert (~785pt) -- nahe Seitenunterrand | kleiner Wert (~56pt) |
| y-Richtung | y wächst nach unten (`y + step`) | y wächst nach oben (`y - step`) |

### Context-Aliase

Beide Konventionen sind gueltig und gleichzeitig im Dict enthalten:

| Ausführlich | Kurz | Bedeutung |
|---|---|---|
| page_w | PW | Seitenbreite |
| page_h | PH | Seitenhoehe |
| left | SX | Startposition X (linker Rand) |
| top | SY | Startposition Y (oberer Rand) |
| text_w | SW | Verfügbare Textbreite |
| text_h | SH | Verfügbare Texthoehe |
| margin | margin_pt | Rand in Points |

```tcl
# Beide funktionieren:
set w [dict get $ctx page_w]
set w [dict get $ctx PW]
```

### Grid-System

Teilt die Seite in Spalten auf:

```tcl
# 3 Spalten, aktuelle Spalte 0 (erste)
lassign [pdf4tcllib::page::grid $pdf $ctx 3 0] gx gy gw gh

# Ohne ctx (wird intern geholt):
lassign [pdf4tcllib::page::grid $pdf 3 0] gx gy gw gh
```

### y-Position weiterschreiben: _advance

`page::_advance` bewegt y in der korrekten Richtung für das aktuelle orient:

```tcl
# orient true:  y += step  (nach unten)
# orient false: y -= step  (nach unten)
pdf4tcllib::page::_advance $ctx y $step

# Typische Verwendung:
set y [dict get $ctx top]       ;# Textbeginn oben
$pdf setFont 12 Helvetica
$pdf text "Zeile 1" -x $lx -y $y
pdf4tcllib::page::_advance $ctx y 16   ;# nächste Zeile
$pdf text "Zeile 2" -x $lx -y $y
pdf4tcllib::page::_advance $ctx y 16
$pdf text "Zeile 3" -x $lx -y $y
```

Alternativ direkt mit `set y [expr {$y + $step}]` bei orient true.
`_advance` ist nützlich wenn Code für beide orient-Modi funktionieren soll.

### Orientierungslegende

Debug-Hilfe: zeichnet Seitenformat, Raender und Textbereich:

```tcl
pdf4tcllib::page::orientationLegend $pdf $ctx
```

## Text (text)

### Unicode-sicherer Text

Standard-PDF-Fonts (Helvetica, Courier) können kein Unicode.
pdf4tcllib sanitiert automatisch:

```tcl
# Problematische Zeichen werden ersetzt:
set clean [pdf4tcllib::unicode::sanitize $text]
# Box-Drawing: │ → |   ─ → -   ┼ → +
# Checkboxen:  ☑ → [x]  ☐ → [ ]
# Bullets:     • → *    … → ...
```

### Emoji-Fallbacks

Emojis werden auf ASCII-Darstellung gemappt:

| Emoji | Fallback | Beschreibung |
|---|---|---|
| Grinning Face | :-) | Laecheln |
| Party Popper | (!) | Feier |
| Thumbs Up | (+1) | Daumen hoch |
| Heart | <3 | Herz |
| Unbekannt | (U+FFFD) | Ersatzzeichen |

```tcl
# In readFile integriert:
set text [pdf4tcllib::readFile "dokument.md"]
# Liest binär, entfernt BOM, ersetzt Emoji
```

### Textumbruch (writeParagraph)

Automatischer Zeilenumbruch für laengere Texte:

```tcl
set newY [pdf4tcllib::text::writeParagraph $pdf $x $y $width $text \
    -fontsize 11 -leading 14]
# Gibt die Y-Position nach dem letzten Text zurück
```

### Baseline-Positionierung

Wichtig: `$pdf text` positioniert an der **Baseline**, nicht an der
Oberkante der Buchstaben.

```
    Oberkante (Ascent)    ← ca. 0.75 × fontSize über Baseline
    ──────────────────
    Hello World           ← Baseline (hier setzt pdf4tcl den Text)
    ──────────────────
    Unterkante (Descent)  ← ca. 0.25 × fontSize unter Baseline
```

Für Text in Boxen:

```tcl
# Baseline = boxY + fontSize
# Ascender reichen ~0.75*fontSize nach oben
set baseline [expr {$boxY + $fontSize}]
$pdf text "Hello" -x $boxX -y $baseline
```

## Tabellen (table)

### simpleTable (High-Level)

Ein Aufruf, automatische Spaltenberechnung:

```tcl
set headers {Name Alter Stadt}
set rows {
    {Alice 30 Berlin}
    {Bob 25 Hamburg}
    {Carol 35 Muenchen}
}
pdf4tcllib::table::simpleTable $pdf $ctx $headers $rows
```

Features:
- Automatische Spaltenbreiten (gleichmäßig)
- Header mit grauem Hintergrund
- Zebra-Streifen
- Rahmenlinien

### table::render (Low-Level)

Volle Kontrolle über Spaltenbreiten, Alignment, Farben:

```tcl
set cols {
    {width 40  align left   header "Nr."}
    {width 120 align left   header "Artikel"}
    {width 60  align right  header "Preis"}
}
set data {
    {1 "Laptop" "1.299,00"}
    {2 "Maus" "29,90"}
}
pdf4tcllib::table::render $pdf $x $y $cols $data
```

### Wann welche API?

| Situation | API |
|---|---|
| Schnelle Datentabelle | simpleTable |
| Eigene Spaltenbreiten | render |
| Alignment pro Spalte | render |
| Bestellformular, Rechnung | render |
| Debug-Ausgabe, Übersicht | simpleTable |

## Hilfsfunktionen

### validate_pdf

Prüft ob eine Datei ein gueltiges PDF ist:

```tcl
if {[pdf4tcllib::validate_pdf "output.pdf"]} {
    puts "PDF ok"
} else {
    puts "Ungueltig oder nicht vorhanden"
}
```

### version

```tcl
puts [pdf4tcllib::version]
# → 0.1
```

### readFile

Binaeres Lesen mit automatischer Vorverarbeitung:

```tcl
set text [pdf4tcllib::readFile "dokument.md"]
# 1. Binär lesen (kein Encoding-Problem)
# 2. BOM entfernen
# 3. Emoji ersetzen (preprocessBytes)
# 4. Unbekannte Zeichen → U+FFFD (sanitize)
```

## Zusammenspiel mit anderen Modulen

```
pdf4tcl (Basis)
  └── pdf4tcllib (Erweiterungen)
        ├── mdpdf         (Markdown-Datei → PDF)
        └── mdhelp_pdf    (Text-Widget → PDF)
```

- **mdpdf** nutzt pdf4tcllib für Markdown→PDF Konvertierung
- **mdhelp_pdf** nutzt pdf4tcllib für den PDF-Export aus dem Viewer
- Beide nutzen page::context, text::writeParagraph, table::simpleTable

## Verteilung

pdf4tcllib ist eine einzelne .tm-Datei:

| Kontext | Pfad |
|---|---|
| Eigenständig (pdf4tcllib) | lib/pdf4tcllib-0.1.tm |
| In mdstack-2.0 | vendors/tm/pdf4tcllib-0.1.tm |
| In mdhelp4 | vendors/tm/pdf4tcllib-0.1.tm |

Kein `auto_path` nötig. Nur `tcl::tm::path add` auf das
Verzeichnis, dann `package require pdf4tcllib`.

## Häufige Fehler

### Text ragt über Zellenrahmen

```tcl
# FALSCH - Baseline zu hoch:
set textY [expr {$y0 + int(($cellH - $fontSize) / 2.0)}]

# RICHTIG - Baseline tief genug:
set textY [expr {$y0 + int(($cellH - $fontSize) / 0.45)}]
```

### Emoji im PDF

```tcl
# FALSCH - Standard-Fonts können kein Emoji:
$pdf text "Hello 😀" -x 50 -y 700

# RICHTIG - Vorher sanitieren:
set clean [pdf4tcllib::unicode::sanitize "Hello 😀"]
$pdf text $clean -x 50 -y 700
# → "Hello :-)"
```

### Linien als Text-Striche

```tcl
# FALSCH - Breite passt nie exakt:
$pdf text [string repeat "-" 40] -x $x -y $y

# RICHTIG - Echte PDF-Linie:
$pdf line $x $lineY [expr {$x + $width}] $lineY
```

### Context-Keys verwechselt

```tcl
# Beide gueltig - Aliase im selben Dict:
dict get $ctx page_w    ;# ausführlich
dict get $ctx PW         ;# kurz
# FEHLER: dict get $ctx pageW  (camelCase gibt es nicht)
```

### top-Wert hängt von orient ab

```tcl
# orient true (Standard): top = margin_pt = ~56pt (kleiner Wert = oben)
set ctx [pdf4tcllib::page::context a4 -orient true]
dict get $ctx top   ;# 56.69 -- Textbeginn oben

# orient false: top = page_h - margin_pt = ~785pt (grosser Wert = oben)
set ctx [pdf4tcllib::page::context a4 -orient false]
dict get $ctx top   ;# 785.20 -- Textbeginn oben (im Orient-false-System)

# y weiterrücken:
# orient true:  set y [expr {$y + 16}]           ;# oder _advance $ctx y 16
# orient false: set y [expr {$y - 16}]            ;# oder _advance $ctx y 16
```
