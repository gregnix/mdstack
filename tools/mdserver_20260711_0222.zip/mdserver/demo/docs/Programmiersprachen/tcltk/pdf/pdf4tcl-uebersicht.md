# pdf4tcl Dokumentation - Übersicht

*Stand: 2026-04-29*

Diese Dokumentation behandelt die PDF-Erzeugung mit Tcl. Sie deckt
pdf4tcl als Kernbibliothek sowie die darauf aufbauenden Bibliotheken
pdfdoclib, pdfgrid und pdftextboxlib ab.

## Aufbau

Die Dokumentation ist in folgende Dateien gegliedert:

### Kernbibliothek pdf4tcl

| Datei                           | Inhalt                               |
|---------------------------------|--------------------------------------|
| pdf4tcl-grundlagen.md           | Installation, Koordinaten, Einheiten |
| pdf4tcl-text-und-fonts.md       | Text-API, 14 Standard-Fonts, Encoding|
| pdf4tcl-grafik-und-farben.md    | Linien, Rechtecke, Farben, Transformationen |
| pdf4tcl-bilder-und-seiten.md    | Bilder, Seitenmanagement, Kompression|
| pdf4tcl-layout-patterns.md      | Helper-Library, Page Context, Spalten|
| pdf4tcl-fehler-und-tipps.md     | Häufige Fehler, Troubleshooting     |
| pdf4tcl-api-referenz.md         | Kompakte Befehlsuebersicht           |
| pdf4tcl-forms-manual.md         | addForm API-Referenz (8 Feldtypen)   |
| pdf4tcl-forms-technical.md      | addForm Interna, Ff-Flags, AcroForm  |

### Erweiterungsbibliotheken

| Datei                | Inhalt                                    |
|----------------------|-------------------------------------------|
| pdf4tcllib.md        | Unicode, Emoji, Seitenkontext, Tabellen   |
| pdf4tclforms.md      | PDF-Formulare, Felder, Bestellformulare   |
| pdfdoclib.md         | Dokument-Abstraktion, DIN-Briefe, Styles  |
| pdfgrid.md           | Tabellen, Summen, Conditional Formatting  |
| pdftextboxlib.md     | Erweiterte TextBox mit Inline-Optionen    |

### Demos

| Datei                | Inhalt                                    |
|----------------------|-------------------------------------------|
| demo-forms-tk.tcl    | Tk-GUI zum Testen aller 8 addForm-Felder  |

## Lesereihenfolge für Einsteiger

1. pdf4tcl-grundlagen.md - Installation und erste Schritte
2. pdf4tcl-text-und-fonts.md - Texte sicher positionieren
3. pdf4tcl-grafik-und-farben.md - Formen und Farben
4. pdf4tcl-bilder-und-seiten.md - Bilder und mehrseitige Dokumente
5. pdf4tcl-layout-patterns.md - Professionelle Layouts
6. pdf4tcl-fehler-und-tipps.md - Fehler vermeiden

## Lesereihenfolge für Fortgeschrittene

1. pdf4tcl-api-referenz.md - Schnelle Befehlsuebersicht
2. pdf4tcllib.md - Unicode, Seitenkontext, Tabellen (mdstack/mdhelp)
3. pdf4tclforms.md - Formulare erstellen und befüllen
4. pdf4tcl-forms-manual.md - addForm API-Referenz (alle Feldtypen)
5. pdfdoclib.md - Wenn High-Level-Abstraktion benötigt wird
6. pdfgrid.md - Wenn Tabellen benötigt werden
7. pdftextboxlib.md - Wenn formatierte Textblöcke benötigt werden

## Architektur

Die Bibliotheken bilden eine Schichtarchitektur:

```
 pdfdoclib        pdfgrid        pdftextboxlib
 (Dokumente)      (Tabellen)     (TextBox)
     |                |               |
     +--------+-------+-------+-------+
              |               |
        Helper-Library    pdf4tcl (Core)
                              |
                        pdf4tcllib (Unicode, Kontext, Tabellen)
                              |
                         PDF-Datei
```

pdf4tcl ist der Low-Level-Core, der direkt PDF-Strukturen erzeugt.
pdf4tcllib erweitert pdf4tcl um Unicode-Handling, Seitenkontext und
vereinfachte Tabellen. Es wird von mdpdf und mdhelp_pdf genutzt.
Die anderen Erweiterungsbibliotheken sind unabhängig voneinander
und können einzeln oder kombiniert verwendet werden.

## Versionen

| Bibliothek    | Version | Tcl-Minimum |
|---------------|---------|-------------|
| pdf4tcl       | 0.9.4   | 8.6         |
| pdf4tcllib    | 0.1     | 8.6         |
| pdfdoclib     | 0.4     | 8.6         |
| pdfgrid       | 0.3.6   | 8.6         |
| pdftextboxlib | 1.0     | 8.6         |
