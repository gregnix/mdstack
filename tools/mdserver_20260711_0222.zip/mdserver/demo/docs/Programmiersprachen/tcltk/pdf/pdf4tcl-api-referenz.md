# pdf4tcl Forms - PDF-Formulare mit pdf4tcl

*Stand: 2026-04-29*

Anleitung zum Erstellen von PDF-Formularen mit pdf4tcl.
Behandelt Druck-Formulare (visuell) und interaktive AcroForm-Felder.

## Zwei Arten von PDF-Formularen

### Druck-Formulare (visuell)

Statische PDFs die wie ein Formular aussehen: Labels, Linien,
Kästchen, Tabellen. Werden ausgedruckt und per Hand ausgefuellt.
pdf4tcl kann das direkt.

### Interaktive Formulare (AcroForm)

PDFs mit ausfuellbaren Feldern im PDF-Viewer: Textfelder, Checkboxen,
Dropdowns, Radio-Buttons. pdf4tcl unterstützt diese über die
Methode `addForm` mit acht Feldtypen: `text`, `password`,
`checkbutton` (Alias `checkbox`), `combobox`, `listbox`,
`radiobutton`, `pushbutton` und `signature`.

### Wann welches?

| Anforderung | Druck-Formular | AcroForm |
|---|---|---|
| Ausfüllen am Bildschirm | Nein | Ja |
| Ausdrucken und per Hand | Ja | Ja |
| Daten zurücklesen | Nein | Ja (FDF/XFDF) |
| Komplexitaet | Niedrig | Mittel |
| pdf4tcl Support | Direkt | Direkt (addForm) |

## Druck-Formulare

### Grundstruktur

Ein Druck-Formular besteht aus drei Elementen:

1. Labels (Beschriftungen)
2. Felder (leere Bereiche oder Linien)
3. Rahmen und Struktur (Kästchen, Trennlinien)

### Einfaches Formular

```tcl
package require pdf4tcl

proc createForm {filename} {
    set pdf [pdf4tcl::new %AUTO% -paper a4]
    $pdf startPage

    set margin 56.7   ;# 20mm
    set x $margin
    set y 780          ;# Oben beginnen
    set fieldW 200     ;# Feldbreite
    set labelW 100     ;# Label-Breite
    set lineH 20       ;# Zeilenhöhe

    $pdf setFont 14 Helvetica-Bold
    $pdf text "Bestellformular" -x $x -y $y
    set y [expr {$y - 30}]

    $pdf setFont 10 Helvetica
    foreach label {Name: Vorname: Strasse: PLZ/Ort: Telefon: E-Mail:} {
        # Label
        $pdf text $label -x $x -y $y

        # Feld-Linie
        set fx [expr {$x + $labelW}]
        $pdf setStrokeColor 0.5 0.5 0.5
        $pdf setLineWidth 0.5
        $pdf line $fx [expr {$y - 3}] [expr {$fx + $fieldW}] [expr {$y - 3}]
        $pdf setStrokeColor 0 0 0

        set y [expr {$y - $lineH}]
    }

    $pdf write -file $filename
    $pdf destroy
}

createForm "bestellung.pdf"
```

### Formularfelder als Kästchen

Felder mit Rahmen statt Linien wirken professioneller:

```tcl
proc formField {pdf x y w h {text ""}} {
    # Hintergrund (leicht grau)
    $pdf setFillColor 0.97 0.97 0.97
    $pdf rectangle $x $y $w $h -filled 1
    $pdf setFillColor 0 0 0

    # Rahmen
    $pdf setStrokeColor 0.6 0.6 0.6
    $pdf setLineWidth 0.5
    $pdf rectangle $x $y $w $h
    $pdf setStrokeColor 0 0 0

    # Vorausgefuellter Text (optional)
    if {$text ne ""} {
        $pdf setFont 9 Helvetica
        set textY [expr {$y + 4}]
        $pdf text $text -x [expr {$x + 3}] -y $textY
    }
}

# Verwendung:
set fieldH 16
formField $pdf 160 $y 250 $fieldH
```

### Checkbox-Felder

```tcl
proc checkbox {pdf x y {checked 0} {size 10}} {
    # Kästchen zeichnen
    $pdf setStrokeColor 0.3 0.3 0.3
    $pdf setLineWidth 0.75
    $pdf rectangle $x $y $size $size

    # Haken (wenn angekreuzt)
    if {$checked} {
        $pdf setLineWidth 1.5
        set x1 [expr {$x + 2}]
        set y1 [expr {$y + 4}]
        set x2 [expr {$x + 4}]
        set y2 [expr {$y + 2}]
        set x3 [expr {$x + 8}]
        set y3 [expr {$y + 8}]
        $pdf line $x1 $y1 $x2 $y2
        $pdf line $x2 $y2 $x3 $y3
    }

    $pdf setStrokeColor 0 0 0
    $pdf setLineWidth 0.5
}

# Verwendung:
checkbox $pdf $x $y 0        ;# Leer
checkbox $pdf $x $y 1        ;# Angekreuzt

$pdf setFont 9 Helvetica
$pdf text "Ich akzeptiere die AGB" -x [expr {$x + 14}] -y $y
```

### Radio-Buttons

```tcl
proc radioCircle {pdf x y {filled 0} {radius 5}} {
    set cx [expr {$x + $radius}]
    set cy [expr {$y + $radius}]

    $pdf setStrokeColor 0.3 0.3 0.3
    $pdf setLineWidth 0.75
    $pdf circle $cx $cy $radius

    if {$filled} {
        $pdf setFillColor 0.2 0.2 0.2
        $pdf circle $cx $cy [expr {$radius - 2.5}] -filled 1
        $pdf setFillColor 0 0 0
    }

    $pdf setStrokeColor 0 0 0
}
```

Hinweis: Diese visuellen Radio-Buttons sind nur für Druck-Formulare.
Für interaktive Radio-Buttons `addForm radiobutton` verwenden (s.u.).

### Zeilen-Layout mit Label+Feld

```tcl
proc formRow {pdf x y labelText fieldW {fieldH 16} {labelW 120}} {
    # Label
    $pdf setFont 9 Helvetica
    set baseline [expr {$y + 4}]
    $pdf text $labelText -x $x -y $baseline

    # Feld
    set fx [expr {$x + $labelW}]
    formField $pdf $fx $y $fieldW $fieldH

    # Nächste Y-Position (mit Abstand)
    return [expr {$y - $fieldH - 6}]
}

# Formular aufbauen:
set y 750
set y [formRow $pdf $margin $y "Name:"     250]
set y [formRow $pdf $margin $y "Vorname:"  250]
set y [formRow $pdf $margin $y "Strasse:"  250]
set y [formRow $pdf $margin $y "PLZ:"       60]
set y [formRow $pdf $margin $y "Ort:"      250]
```

### Zwei-Spalten-Layout

```tcl
proc formRow2Col {pdf x y label1 w1 label2 w2 {fieldH 16} {labelW 80}} {
    # Linke Spalte
    $pdf setFont 9 Helvetica
    $pdf text $label1 -x $x -y [expr {$y + 4}]
    formField $pdf [expr {$x + $labelW}] $y $w1 $fieldH

    # Rechte Spalte
    set x2 [expr {$x + $labelW + $w1 + 20}]
    $pdf text $label2 -x $x2 -y [expr {$y + 4}]
    formField $pdf [expr {$x2 + $labelW}] $y $w2 $fieldH

    return [expr {$y - $fieldH - 6}]
}

# PLZ und Ort nebeneinander:
set y [formRow2Col $pdf $margin $y "PLZ:" 60 "Ort:" 180]
```

## Vorausgefuellte Formulare

Formulare mit Daten aus einer Datenbank oder Dict befüllen:

```tcl
proc filledForm {pdf ctx data} {
    set x [dict get $ctx left]
    set y [dict get $ctx top]
    set fw 250
    set fh 16
    set lw 120

    $pdf setFont 14 Helvetica-Bold
    $pdf text "Kundendaten" -x $x -y $y
    set y [expr {$y - 30}]

    foreach {label key} {
        Name:     name
        Strasse:  street
        PLZ:      zip
        Ort:      city
        Telefon:  phone
        E-Mail:   email
    } {
        set val ""
        if {[dict exists $data $key]} {
            set val [dict get $data $key]
        }

        $pdf setFont 9 Helvetica
        $pdf text $label -x $x -y [expr {$y + 4}]

        set fx [expr {$x + $lw}]
        formField $pdf $fx $y $fw $fh $val

        set y [expr {$y - $fh - 6}]
    }

    return $y
}

# Verwendung:
set kunde [dict create \
    name   "Ebbing-Lohaus" \
    street "Musterstr. 1" \
    zip    "48691" \
    city   "Vreden" \
    phone  "02564/1234" \
    email  "info@example.de"]

filledForm $pdf $ctx $kunde
```

## Tabellen-Formulare

### Bestellliste

```tcl
proc orderTable {pdf x y data {colWidths {30 200 50 60 60}}} {
    set headers {Nr. Artikel Menge Preis Summe}
    set cellH 16
    set totalW 0
    foreach w $colWidths { set totalW [expr {$totalW + $w}] }

    # Header
    $pdf setFillColor 0.85 0.85 0.85
    $pdf rectangle $x $y $totalW $cellH -filled 1
    $pdf setFillColor 0 0 0
    $pdf setFont 9 Helvetica-Bold

    set cx $x
    foreach hdr $headers w $colWidths {
        set baseline [expr {$y + 4}]
        $pdf text $hdr -x [expr {$cx + 3}] -y $baseline
        set cx [expr {$cx + $w}]
    }

    # Rahmenlinien Header
    $pdf setStrokeColor 0.4 0.4 0.4
    $pdf setLineWidth 0.5
    $pdf rectangle $x $y $totalW $cellH

    set y [expr {$y - $cellH}]

    # Datenzeilen
    $pdf setFont 9 Helvetica
    set nr 1
    set gesamtsumme 0.0

    foreach row $data {
        lassign $row artikel menge preis
        set summe [expr {$menge * $preis}]
        set gesamtsumme [expr {$gesamtsumme + $summe}]

        set values [list $nr $artikel $menge \
            [format "%.2f" $preis] [format "%.2f" $summe]]

        set cx $x
        foreach val $values w $colWidths {
            $pdf text $val -x [expr {$cx + 3}] -y [expr {$y + 4}]
            set cx [expr {$cx + $w}]
        }

        $pdf rectangle $x $y $totalW $cellH
        set y [expr {$y - $cellH}]
        incr nr
    }

    # Leere Zeilen zum Ausfüllen
    for {set i 0} {$i < 5} {incr i} {
        $pdf rectangle $x $y $totalW $cellH
        # Nr. vorausfuellen
        $pdf text $nr -x [expr {$x + 3}] -y [expr {$y + 4}]
        set y [expr {$y - $cellH}]
        incr nr
    }

    # Summenzeile
    $pdf setFont 9 Helvetica-Bold
    set sumX [expr {$x + [lindex $colWidths 0] + [lindex $colWidths 1] \
                       + [lindex $colWidths 2]}]
    $pdf text "Gesamt:" -x [expr {$sumX + 3}] -y [expr {$y + 4}]
    set sumVX [expr {$sumX + [lindex $colWidths 3]}]
    $pdf text [format "%.2f" $gesamtsumme] \
        -x [expr {$sumVX + 3}] -y [expr {$y + 4}]

    $pdf setLineWidth 1.0
    $pdf rectangle $sumX $y \
        [expr {[lindex $colWidths 3] + [lindex $colWidths 4]}] $cellH

    $pdf setStrokeColor 0 0 0
    $pdf setLineWidth 0.5

    return [expr {$y - $cellH}]
}
```

## Seitenrahmen und Kopfzeile

```tcl
proc formPage {pdf ctx title {subtitle ""}} {
    $pdf startPage

    set x [dict get $ctx left]
    set y [dict get $ctx top]
    set w [dict get $ctx text_w]

    # Kopfleiste
    $pdf setFillColor 0.15 0.25 0.45
    $pdf rectangle $x $y $w 30 -filled 1
    $pdf setFillColor 1 1 1
    $pdf setFont 14 Helvetica-Bold
    $pdf text $title -x [expr {$x + 8}] -y [expr {$y + 9}]

    if {$subtitle ne ""} {
        $pdf setFont 9 Helvetica
        $pdf text $subtitle -x [expr {$x + 8}] -y [expr {$y + 22}]
    }

    $pdf setFillColor 0 0 0

    # Seitenrahmen (duenne Linie)
    $pdf setStrokeColor 0.7 0.7 0.7
    $pdf setLineWidth 0.25
    $pdf rectangle $x [dict get $ctx bottom] $w [dict get $ctx text_h]
    $pdf setStrokeColor 0 0 0

    # Fusszeile
    $pdf setFont 7 Helvetica
    set footY [expr {[dict get $ctx bottom] + 2}]
    $pdf text "Seite 1" -x $x -y $footY
    set dateStr [clock format [clock seconds] -format "%d.%m.%Y"]
    $pdf text $dateStr -x [expr {$x + $w - 40}] -y $footY

    # Startposition für Inhalt zurückgeben
    return [expr {$y - 40}]
}
```

## Interaktive AcroForm-Felder

pdf4tcl unterstützt interaktive Formularfelder über die Methode
`addForm`. Sieben Feldtypen stehen zur Verfügung.

### Syntax

```tcl
$pdf addForm type x y width height ?option value ...?
```

Gemeinsame Optionen:
- `-id string` - Eindeutige ID im Dokument (sonst automatisch)
- `-init value` - Anfangswert

### Textfeld

```tcl
$pdf addForm text 100 500 200 20
$pdf addForm text 100 470 200 20 -id vorname -init "Max"
$pdf addForm text 100 430 200 60 -id bemerkung -multiline 1
```

### Passwort-Feld

Wie Textfeld, aber Eingabe wird maskiert:

```tcl
$pdf addForm password 100 400 200 20 -id kennwort
```

### Checkbox

```tcl
$pdf addForm checkbutton 100 370 12 12 -id agb
$pdf addForm checkbutton 100 350 12 12 -id newsletter -init true
```

Eigene Darstellung über XObjects:

```tcl
set on [$pdf startXObject -paper {12p 12p} -margin 0]
$pdf setFillColor 0 0.5 0
$pdf rectangle 0 0 12 12 -filled 1
$pdf endXObject

$pdf addForm checkbutton 100 330 12 12 -id custom -on $on
```

### Combobox (Dropdown)

```tcl
$pdf addForm combobox 100 300 150 20 \
    -id farbe -options {Rot Gruen Blau} -init Rot

# Editierbar (freie Eingabe möglich)
$pdf addForm combobox 100 270 150 20 \
    -id land -options {Deutschland Oesterreich Schweiz} -editable 1

# Sortierte Anzeige
$pdf addForm combobox 100 240 150 20 \
    -id stadt -options {Vreden Ahaus Stadtlohn Gronau} -sort 1
```

### Listbox

```tcl
$pdf addForm listbox 100 150 150 80 \
    -id produkt -options {Petunien Calibrachoa Pelargonien Verbenen}

# Mehrfachauswahl
$pdf addForm listbox 300 150 150 80 \
    -id extras -options {Duenger Toepfe Erde Etiketten} -multiselect 1
```

### Radiobutton

Radio-Buttons werden über `-group` zu Gruppen zusammengefasst.
Pro Gruppe kann nur ein Button aktiv sein:

```tcl
$pdf addForm radiobutton 100 120 12 12 -group versand -value Normal
$pdf text "Normal" -x 116 -y 122

$pdf addForm radiobutton 100 100 12 12 -group versand -value Express
$pdf text "Express" -x 116 -y 102

# Vorauswahl mit -init 1
$pdf addForm radiobutton 100 80 12 12 -group zahlung -value Rechnung -init 1
$pdf addForm radiobutton 100 60 12 12 -group zahlung -value Vorkasse
```

### Pushbutton

Buttons mit Aktionen:

```tcl
# Reset-Button (alle Felder löschen)
$pdf addForm pushbutton 100 30 80 20 \
    -id btnReset -caption "Löschen" -action reset

# URL oeffnen
$pdf addForm pushbutton 200 30 80 20 \
    -id btnWeb -caption "Website" -action url \
    -url "https://example.com"

# Formular absenden
$pdf addForm pushbutton 300 30 80 20 \
    -id btnSend -caption "Senden" -action submit \
    -url "https://example.com/submit"
```

### Signature

Signaturfeld mit visuellem Platzhalter (gestrichelte Linie + Label):

```tcl
# Signaturfeld mit eigenem Label
$pdf addForm signature 100 100 200 50 \
    -id sig1 -label "Hier unterschreiben"

# Ohne Label (Default-Text "Signature")
$pdf addForm signature 100 40 200 50 -id sig2
```

`-label` ist nur für `signature` erlaubt.

### Gemeinsame Optionen

**`-required`** markiert ein Feld als Pflichtfeld (Ff bit 2).
Gilt für text, password, checkbox, combobox, listbox, radiobutton.
Nicht erlaubt für pushbutton und signature.

```tcl
$pdf addForm text 100 300 200 20 -id pflicht -required 1
$pdf addForm checkbox 100 270 14 14 -id agb -required 1
```

**`-readonly`** sperrt ein Feld gegen Bearbeitung (Ff bit 1):

```tcl
$pdf addForm text 100 240 200 20 -id gesperrt \
    -init "Nicht änderbar" -readonly 1
```

**Validierung:** `-group` und `-value` bei Radiobuttons müssen
alphanumerisch sein (Buchstaben, Ziffern, Unterstrich).
URLs in Pushbutton-Aktionen werden automatisch escaped.

### Formulardaten zurücklesen

```tcl
set forms [pdf4tcl::getForms "formular.pdf"]
dict for {id info} $forms {
    set typ   [dict get $info type]
    set wert  [dict get $info value]
    set flags [dict get $info flags]
    puts "$id: typ=$typ wert=$wert flags=$flags"
}
```

### Komplettes interaktives Formular

```tcl
package require pdf4tcl

pdf4tcl::new pdf -paper a4 -compress 0
pdf startPage

pdf setFont 14 Helvetica-Bold
pdf text "Anmeldung" -x 56 -y 780

pdf setFont 10 Helvetica

# Textfelder
pdf text "Name:" -x 56 -y 740
pdf addForm text 160 735 250 20 -id name

pdf text "E-Mail:" -x 56 -y 710
pdf addForm text 160 705 250 20 -id email

pdf text "Passwort:" -x 56 -y 680
pdf addForm password 160 675 250 20 -id passwort

# Dropdown
pdf text "Abteilung:" -x 56 -y 650
pdf addForm combobox 160 645 200 20 \
    -id abteilung -options {Vertrieb Produktion Verwaltung Logistik}

# Checkboxen
pdf addForm checkbutton 56 615 12 12 -id agb
pdf text "AGB akzeptiert" -x 74 -y 617

pdf addForm checkbutton 56 595 12 12 -id newsletter -init true
pdf text "Newsletter abonnieren" -x 74 -y 597

# Radio-Buttons
pdf text "Versand:" -x 56 -y 570
pdf addForm radiobutton 160 568 12 12 -group versand -value Standard -init 1
pdf text "Standard" -x 176 -y 570
pdf addForm radiobutton 260 568 12 12 -group versand -value Express
pdf text "Express" -x 276 -y 570

# Signatur
pdf text "Unterschrift:" -x 56 -y 540
pdf addForm signature 160 530 200 45 -id unterschrift -label "Bitte unterschreiben"

# Buttons
pdf addForm pushbutton 160 480 80 22 -id btnReset -caption "Löschen" -action reset
pdf addForm pushbutton 260 480 80 22 -id btnSend  -caption "Absenden" -action submit \
    -url "https://example.com/form"

pdf write -file "anmeldung.pdf"
pdf destroy
```

### Kombination: Visuelles Layout + interaktive Felder

Das beste Ergebnis entsteht durch Kombination von visuellen Elementen
(Rahmen, Farben, Labels) mit interaktiven Feldern:

```tcl
proc interactiveFormRow {pdf x y label fieldW {fieldH 18} {labelW 120}} {
    # Visuelles Label
    $pdf setFont 9 Helvetica
    $pdf text $label -x $x -y [expr {$y + 4}]

    # Visueller Rahmen
    set fx [expr {$x + $labelW}]
    $pdf setFillColor 0.97 0.97 0.97
    $pdf rectangle $fx $y $fieldW $fieldH -filled 1
    $pdf setFillColor 0 0 0
    $pdf setStrokeColor 0.6 0.6 0.6
    $pdf rectangle $fx $y $fieldW $fieldH
    $pdf setStrokeColor 0 0 0

    # Interaktives Feld darüber
    $pdf addForm text $fx $y $fieldW $fieldH

    return [expr {$y - $fieldH - 6}]
}
```

### Externe Werkzeuge (Alternative)

Falls die nativen AcroForm-Felder nicht ausreichen, können externe
Tools die PDF-Formulare nachbearbeiten:

```tcl
# pdftk: Felder aus PDF lesen
exec pdftk formular.pdf dump_data_fields

# pdftk: Formular mit FDF befüllen
proc fillPdfForm {template output data} {
    set fdf "%FDF-1.2\n1 0 obj\n<< /FDF << /Fields \[\n"
    dict for {name value} $data {
        append fdf "<< /T ($name) /V ($value) >>\n"
    }
    append fdf "\] >> >>\nendobj\ntrailer\n"
    append fdf "<< /Root 1 0 R >>\n%%EOF"

    set fdfFile [file rootname $output].fdf
    set fh [open $fdfFile w]
    puts -nonewline $fh $fdf
    close $fh

    exec pdftk $template fill_form $fdfFile output $output flatten
}
```

## Komplettes Beispiel: Bestellformular

```tcl
package require pdf4tcl

proc createOrderForm {filename company data} {
    set pdf [pdf4tcl::new %AUTO% -paper a4]

    # Seitenkontext
    set margin 56.7
    set pw 595.28
    set ph 841.89
    set tw [expr {$pw - 2 * $margin}]

    $pdf startPage

    set x $margin
    set y [expr {$ph - $margin}]

    # ── Firmenkopf ──
    $pdf setFont 16 Helvetica-Bold
    $pdf text [dict get $company name] -x $x -y $y
    set y [expr {$y - 18}]

    $pdf setFont 9 Helvetica
    $pdf text [dict get $company address] -x $x -y $y
    set y [expr {$y - 12}]
    $pdf text [dict get $company contact] -x $x -y $y
    set y [expr {$y - 25}]

    # Trennlinie
    $pdf setStrokeColor 0.3 0.3 0.3
    $pdf setLineWidth 1.0
    $pdf line $x $y [expr {$x + $tw}] $y
    $pdf setStrokeColor 0 0 0
    $pdf setLineWidth 0.5
    set y [expr {$y - 20}]

    # ── Titel ──
    $pdf setFont 14 Helvetica-Bold
    $pdf text "Bestellformular" -x $x -y $y
    set y [expr {$y - 8}]

    $pdf setFont 8 Helvetica
    set dateStr [clock format [clock seconds] -format "%d.%m.%Y"]
    $pdf text "Datum: $dateStr" -x [expr {$x + $tw - 80}] -y $y
    set y [expr {$y - 20}]

    # ── Kundendaten ──
    $pdf setFont 10 Helvetica-Bold
    $pdf text "Kundendaten" -x $x -y $y
    set y [expr {$y - 18}]

    set lw 80
    set fw 200
    set fh 16
    $pdf setFont 9 Helvetica

    foreach {label key} {
        Name:     name
        Strasse:  street
        PLZ/Ort:  city
        Telefon:  phone
        E-Mail:   email
    } {
        set val ""
        if {[dict exists $data $key]} {
            set val [dict get $data $key]
        }

        $pdf text $label -x $x -y [expr {$y + 4}]
        set fx [expr {$x + $lw}]

        # Feld mit grauem Hintergrund
        $pdf setFillColor 0.96 0.96 0.96
        $pdf rectangle $fx $y $fw $fh -filled 1
        $pdf setFillColor 0 0 0
        $pdf setStrokeColor 0.6 0.6 0.6
        $pdf rectangle $fx $y $fw $fh
        $pdf setStrokeColor 0 0 0

        if {$val ne ""} {
            $pdf text $val -x [expr {$fx + 3}] -y [expr {$y + 4}]
        }

        set y [expr {$y - $fh - 4}]
    }

    set y [expr {$y - 10}]

    # ── Bestelltabelle ──
    $pdf setFont 10 Helvetica-Bold
    $pdf text "Bestellung" -x $x -y $y
    set y [expr {$y - 18}]

    set cols {30 220 50 60 60}
    set hdrs {"Nr." "Artikel" "Menge" "Einzelpreis" "Summe"}
    set totalW 0
    foreach w $cols { set totalW [expr {$totalW + $w}] }

    # Header
    $pdf setFillColor 0.2 0.3 0.5
    $pdf rectangle $x $y $totalW $fh -filled 1
    $pdf setFillColor 1 1 1
    $pdf setFont 8 Helvetica-Bold

    set cx $x
    foreach hdr $hdrs w $cols {
        $pdf text $hdr -x [expr {$cx + 2}] -y [expr {$y + 4}]
        set cx [expr {$cx + $w}]
    }
    $pdf setFillColor 0 0 0
    set y [expr {$y - $fh}]

    # Datenzeilen
    $pdf setFont 8 Helvetica
    set nr 1
    set gesamt 0.0

    if {[dict exists $data items]} {
        foreach item [dict get $data items] {
            lassign $item artikel menge preis
            set summe [expr {$menge * $preis}]
            set gesamt [expr {$gesamt + $summe}]

            # Zebrastreifen
            if {$nr % 2 == 0} {
                $pdf setFillColor 0.95 0.95 0.95
                $pdf rectangle $x $y $totalW $fh -filled 1
                $pdf setFillColor 0 0 0
            }

            set vals [list $nr $artikel $menge \
                [format "%.2f" $preis] [format "%.2f" $summe]]

            set cx $x
            foreach val $vals w $cols {
                $pdf text $val -x [expr {$cx + 2}] -y [expr {$y + 4}]
                set cx [expr {$cx + $w}]
            }

            $pdf setStrokeColor 0.7 0.7 0.7
            $pdf line $x $y [expr {$x + $totalW}] $y
            $pdf setStrokeColor 0 0 0

            set y [expr {$y - $fh}]
            incr nr
        }
    }

    # Leere Zeilen
    for {set i 0} {$i < 5} {incr i} {
        $pdf setStrokeColor 0.8 0.8 0.8
        $pdf rectangle $x $y $totalW $fh
        $pdf setStrokeColor 0 0 0
        $pdf text "$nr." -x [expr {$x + 2}] -y [expr {$y + 4}]
        set y [expr {$y - $fh}]
        incr nr
    }

    # Summenzeile
    $pdf setFont 9 Helvetica-Bold
    $pdf setLineWidth 1.0
    set sumLabelX [expr {$x + [lindex $cols 0] + [lindex $cols 1]}]
    $pdf text "Gesamt:" -x [expr {$sumLabelX + 2}] -y [expr {$y + 4}]

    set sumValX [expr {$sumLabelX + [lindex $cols 2] + [lindex $cols 3]}]
    if {$gesamt > 0} {
        $pdf text [format "%.2f EUR" $gesamt] \
            -x [expr {$sumValX + 2}] -y [expr {$y + 4}]
    }
    $pdf line $sumLabelX $y [expr {$x + $totalW}] $y
    $pdf line $sumLabelX [expr {$y + $fh}] [expr {$x + $totalW}] [expr {$y + $fh}]
    $pdf setLineWidth 0.5

    set y [expr {$y - 30}]

    # ── Unterschrift ──
    $pdf setFont 9 Helvetica
    $pdf text "Datum, Unterschrift:" -x $x -y $y
    $pdf setLineWidth 0.5
    $pdf line [expr {$x + 110}] [expr {$y - 3}] \
              [expr {$x + 350}] [expr {$y - 3}]

    $pdf write -file $filename
    $pdf destroy
}

# ── Aufruf ──

set firma [dict create \
    name    "Ebbing-Lohaus GmbH" \
    address "Musterstr. 1, 48691 Vreden" \
    contact "Tel: 02564/1234 | info@example.de"]

set bestellung [dict create \
    name   "Max Mustermann" \
    street "Hauptstr. 10" \
    city   "48691 Vreden" \
    items  {
        {"Petunia F1 Dream" 500 0.12}
        {"Calibrachoa MiniFamous" 200 0.18}
        {"Pelargonium Calliope" 300 0.15}
    }]

createOrderForm "bestellung-2026.pdf" $firma $bestellung
```

## Tipps

### Baseline beachten

pdf4tcl positioniert Text an der Baseline, nicht an der Oberkante.
In Formularfeldern mit Höhe $fh:

```tcl
# Text 4pt über Unterkante des Feldes
set textY [expr {$fieldY + 4}]
```

### Farben zurücksetzen

Nach jedem farbigen Element Farben explizit zurücksetzen:

```tcl
$pdf setFillColor 0.85 0.85 0.85   ;# Grau
$pdf rectangle ...
$pdf setFillColor 0 0 0             ;# Schwarz zurück!
```

Vergisst man das, wird aller folgende Text grau.

### Seitenumbruch in langen Formularen

```tcl
proc checkPageBreak {pdf ctx yVar neededH pdfPageNum} {
    upvar $yVar y
    upvar $pdfPageNum pageNum
    set bottom [dict get $ctx bottom]

    if {($y - $neededH) < $bottom} {
        $pdf startPage
        incr pageNum
        set y [dict get $ctx top]
        return 1
    }
    return 0
}
```

### Fonts für Formulare

| Font | Verwendung |
|---|---|
| Helvetica-Bold | Titel, Abschnitts-Überschriften |
| Helvetica | Labels, Beschriftungen |
| Helvetica 9pt | Feldinhalt, Hinweistexte |
| Courier | Festbreitenwerte (IBAN, Codes) |

### Masseinheiten

pdf4tcl arbeitet in Points. Umrechnung:

```tcl
# mm nach Points
proc mm2pt {mm} { expr {$mm * 2.835} }

# Feldbreite 60mm
set fw [mm2pt 60]   ;# 170.1 pt
```
