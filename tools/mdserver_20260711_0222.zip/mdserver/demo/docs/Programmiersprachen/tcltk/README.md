# mdDoku-tcltk — Tcl/Tk Detail-Referenz

*Stand: 2026-04-29*

Eine deutschsprachige **Detail-Referenz** zu Tcl/Tk-Befehlen, -APIs und
wichtigen Erweiterungen. Pro Befehl oder Thema ein Artikel — gedacht zum
Nachschlagen, nicht zum Durchlesen.

[![License: CC BY-SA 4.0](https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-sa/4.0/)
[![Code License: MIT](https://img.shields.io/badge/Code-MIT-blue.svg)](LICENSE)

## Charakter

| Kennzahl | Wert |
|---|---|
| Artikel | 70+ |
| Umfang | ~40.000 Zeilen Markdown |
| Sprache | Deutsch |
| Stil | API-/Befehls-Referenz mit Beispielen |
| Zugriff | thematisch über `index.md` und `indexsub.md` |

## Aufbau

```
.
├── index.md, indexsub.md       ← thematischer Einstieg
│
├── tcltk/                      ← Tcl- und Tk-Kern-Themen
│   ├── Tcl/                    ← Tcl-Sprache (39 Artikel)
│   └── tk/                     ← Tk-Widgets und -Mechanik (15 Artikel)
│
├── nemethi/                    ← Csaba Nemethi's tablelist + scrollutil
├── json/                       ← rl-json-Bibliothek (5 Artikel)
├── pdf/                        ← pdf4tcl-Familie (15 Artikel)
├── windows/                    ← Windows-Spezifika (TWAPI, etc.)
└── man/                        ← Manpage-Erstellung (nroff)
```

## Was hier zu finden ist

Pro Tcl/Tk-Befehl oder pro Thema ein fokussierter Artikel:

- **Was macht der Befehl?** (Zweck, Syntax)
- **Wie wird er typisch verwendet?** (Beispiele)
- **Welche Optionen gibt es?** (Referenz-Tabellen)
- **Was sind die Fallstricke?** (typische Fehler)

Das Werk deckt drei Bereiche ab:

### Tcl-Sprache (`tcltk/Tcl/`)

Detail-Referenz zu allen wichtigen Tcl-Konzepten — von Variablen-Scope
bis Metaprogrammierung, von TclOO bis Coroutinen, von regexp bis tdbc.

### Tk-Widgets (`tcltk/tk/`)

Spezifika der Tk-Widgets: text-Widget mit allen Tag- und Mark-Details,
canvas, treeview, ttk-Theming, geometry-Manager. Plus tkpath (für SVG).

### Erweiterungen (`nemethi/`, `json/`, `pdf/`, `windows/`, `man/`)

Dokumentation zu wichtigen Tcl-Erweiterungen aus der Praxis:
tablelist, rl-json, pdf4tcl, TWAPI, nroff-Manpages.

## Verwandte Werke

mdDoku-tcltk ist eine **Detail-Referenz** — nicht Lehrbuch, nicht
Praxis-Wissensbasis. Es gibt drei verwandte Werke mit anderen Profilen:

| Werk | Charakter | Wann hier hinkommen |
|---|---|---|
| **Tcl/Tk Build-Handbuch** | Lehrbuch | "Wie baue ich eine C-Erweiterung?" — TEA, Stubs, Plattformen |
| **Advanced Tcl/Tk Programming** | Lehrbuch | "Wie strukturiere ich meine Anwendung?" — Internals, Patterns |
| **mdDoku-tcltk** (dieses Werk) | API-Referenz | "Wie funktioniert genau Befehl X?" — Syntax, Optionen, Beispiele |
| **Knownhow** | Praxis-Wissensbasis | "Warum tut X nicht was ich erwartet habe?" — Frage/Antwort aus realen Projekten |

Die vier Werke ergänzen sich:
- Im **Lehrbuch** wird ein Konzept didaktisch erklärt
- In **mdDoku-tcltk** werden API-Details nachgeschlagen
- Im **Build-Handbuch** wird die Erweiterung gebaut
- Im **Knownhow** wird ein konkretes Praxis-Problem gelöst

## Lizenz

Doku-Text: [CC BY-SA 4.0](LICENSE)
Code-Beispiele: [MIT](LICENSE)

## Mitwirkung

Korrekturen und Ergänzungen sind willkommen — siehe [CONTRIBUTING.md](CONTRIBUTING.md).

## Stil

- **Imperativ und unpersönliche Form** — keine "du"-Anrede
- **Kurze, fokussierte Artikel** statt langer Lehrkapitel
- **Direkt nutzbare Code-Beispiele** in jedem Artikel
- **Querverweise** zwischen verwandten Artikeln
- **Echte deutsche Umlaute** (ä, ö, ü) — auch in Code-Kommentaren
