# tailcall — Tail-Rekursion und Stack-freie Weitergabe

*Stand: 2026-04-29*

Tcl 8.6+. Kategorie: Kontrollfluss, Rekursion.

---

## Das Problem: Rekursion und Stack-Tiefe

Beispiel: die Fakultät von 10000 berechnen. Eine normale rekursive Proc
baut dabei 10000 Stack-Frames auf — irgendwann bricht Tcl mit einem
Stack-Overflow ab.

Das klassische Muster ist die *Tail-Rekursion*: der rekursive Aufruf ist der
*letzte* Schritt der Proc, es folgt nichts mehr. In diesem Fall ist der eigene
Stack-Frame überflüssig — er könnte sofort freigegeben werden, bevor der
rekursive Aufruf passiert.

Genau das tut `tailcall`.

---

## Das Modell: Stack-Frame ersetzen statt stapeln

Normale Rekursion:
```
factorial 5
  factorial 4
    factorial 3
      factorial 2
        factorial 1   <- erst hier gibt es Ergebnisse
      <- 2
    <- 6
  <- 24
<- 120
```

Jeder Aufruf wartet auf den nächsten. Der Stack wächst linear.

Mit `tailcall`:
```
factorial 5
  tailcall factorial 4   <- eigener Frame wird sofort freigegeben
    tailcall factorial 3
      tailcall factorial 2
        return 120       <- direkt ans Original zurück
```

Kein Wachstum. Der Stack bleibt konstant tief.

---

## Grundsyntax

```tcl
tailcall command ?arg ...?
```

Entspricht funktional:
```tcl
return [uplevel 1 [list command ?arg ...?]]
```

Der Unterschied zu einem direkten Aufruf: der *aktuelle* Stack-Frame wird
weggeräumt bevor `command` aufgerufen wird. `command` läuft damit auf der
Ebene des *Aufrufers* — nicht als Kind der aktuellen Proc.

---

## Schritt 1: Tail-rekursive Fakultät

Klassisches Beispiel ohne `tailcall` — bricht bei großen n:

```tcl
proc factorial_naiv {n} {
    if {$n < 2} { return 1 }
    return [expr {$n * [factorial_naiv [expr {$n - 1}]]}]
    # Multipliziert NACH dem rekursiven Aufruf -> Stack wächst!
}
```

Mit Akkumulator und `tailcall` — konstanter Stack:

```tcl
proc factorial {n {accum 1}} {
    if {$n < 2} { return $accum }
    tailcall factorial [expr {$n - 1}] [expr {$accum * $n}]
    # tailcall ist der LETZTE Schritt — kein Stack-Wachstum
}

factorial 10000   ;# kein Stack-Overflow
```

Der Akkumulator (`accum`) trägt das Zwischenergebnis mit — so muss nach dem
rekursiven Aufruf nichts mehr berechnet werden, und `tailcall` kann den Frame
sicher freigeben.

---

## Schritt 2: Gegenseitige Rekursion

Zwei Procs die sich gegenseitig aufrufen — mit normalen Aufrufen würde der
Stack wachsen:

```tcl
proc printList {liste} {
    if {[llength $liste]} {
        puts "> [lindex $liste 0]"
        tailcall printList2 [lrange $liste 1 end]
    }
}

proc printList2 {liste} {
    if {[llength $liste]} {
        puts "< [lindex $liste 0]"
        tailcall printList [lrange $liste 1 end]
    }
}

printList {a b c d e}
# -> > a
#    < b
#    > c
#    < d
#    > e
```

Jede Proc übergibt die Kontrolle an die andere und räumt sich selbst weg.
Beide zusammen verbrauchen nie mehr als einen Stack-Frame.

---

## Schritt 3: Namespace-Auflösung

Ein wichtiges Detail: `tailcall` löst den Befehlsnamen im *aktuellen*
Namespace auf — nicht im Namespace des Aufrufers.

```tcl
namespace eval myns {
    proc helper {} {
        tailcall list a b c   ;# list wird in myns gesucht, dann global
    }
}
```

Das ist in der Praxis selten relevant, aber wichtig wenn man eigene
`list`- oder `string`-Wrapper in einem Namespace hat.

---

## Einschränkungen

`tailcall` darf **nicht** verwendet werden:

- Innerhalb von `uplevel` in eine Proc
- Innerhalb von `catch` in einer Proc oder Lambda

```tcl
proc falsch {} {
    catch {
        tailcall andereProc   ;# Fehler!
    }
}
```

---

## Verhältnis zu Coroutinen

Der einzige Berührungspunkt mit Coroutinen ist das `yieldMultiple`-Idiom:

```tcl
proc yieldMultiple {value} {
    tailcall yieldto string cat $value
}
```

Hier ist `tailcall` nötig, weil `yieldto` den eigenen Stack-Frame von
`yieldMultiple` nicht sehen soll — die Coroutine soll so pausieren als wäre
`yieldto` direkt aufgerufen worden. Ohne `tailcall` würde `yieldMultiple`
als Extra-Frame im Coroutine-Stack hängenbleiben.

Siehe [coroutine.md](coroutine.md) → Abschnitt *yieldMultiple*.

---

## Wann tailcall — wann nicht

| Situation | Lösung |
|---|---|
| Rekursion deren Tiefe unbegrenzt sein kann | `tailcall` |
| Gegenseitige Rekursion zwischen zwei Procs | `tailcall` |
| Letzter Aufruf in Proc, Frame unnötig | `tailcall` |
| Rekursion mit bekannter kleiner Tiefe | normaler Aufruf reicht |
| Ergebnis nach dem Aufruf noch gebraucht | `tailcall` unmöglich |

Die letzte Zeile ist entscheidend: `tailcall` ist nur möglich wenn nach dem
Aufruf *wirklich* nichts mehr passiert. Sobald das Ergebnis noch weiterverarbeitet
wird — `expr {$n * [proc ...]}` — ist es kein Tail-Call mehr.

---

## Siehe auch

- [proc.md](proc.md) — Grundlagen Prozeduren
- [coroutine.md](coroutine.md) — yieldMultiple-Idiom
- [source-eval-apply.md](source-eval-apply.md) — apply und Lambda

## Quellen

- Tcl 9.0 Manpage: `tailcall`
- Nadkarni, Ashok P.: *The Tcl Programming Language*, 2nd ed., 2025
