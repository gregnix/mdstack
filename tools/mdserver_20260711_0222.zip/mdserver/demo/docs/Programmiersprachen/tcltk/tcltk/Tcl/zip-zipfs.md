# ZIP von Hand + zipfs (Tcl 9) - Fallen

*Stand: 2026-05-25*

Manchmal braucht man ZIP-Dateien mit **byte-genauer Kontrolle** über Reihenfolge
und Kompression der Einträge -- etwa für ODF/OOXML-Container, bei denen
`mimetype` zuerst und unkomprimiert stehen muss. Dann reicht ein
High-Level-Werkzeug nicht; man baut das ZIP selbst mit `zlib` und
`binary format`. Dieses Dokument behandelt den ZIP-Aufbau, die Fallen dabei und
die Abgrenzung zu `zipfs` (Tcl 9).

## Wann von Hand, wann zipfs?

- **`zipfs`** (Tcl 9, eingebaut): ZIP als Dateisystem **mounten**, daraus lesen,
  Apps/Starkits deployen. Komfortabel zum Lesen und für Deployment.
- **Von Hand** (`zlib` + `binary format`): wenn man die **exakte Byte-Struktur**
  steuern muss -- Eintragsreihenfolge, STORED vs. deflate pro Eintrag, kein
  Extra-Feld, fester Zeitstempel. Typisch: ODF/OOXML schreiben.

## ZIP-Struktur in Kürze

Eine ZIP-Datei besteht aus drei Teilen:

```
[Local File Header + Daten]   für jeden Eintrag, hintereinander
[Central Directory]           ein Verzeichniseintrag pro Datei
[End Of Central Directory]    (EOCD) am Dateiende, zeigt aufs Verzeichnis
```

Gelesen wird **von hinten**: zuerst das EOCD finden, daraus den Offset des
Central Directory, dort die Einträge -- jeder verweist auf seinen Local Header.

## Local File Header (little-endian!)

```
Offset Feld                     Format
0      Signatur "PK\x03\x04"    a4
4      Version needed           s
6      Flags                    s
8      Kompressionsmethode      s     (0 = STORED, 8 = DEFLATE)
10     DOS-Zeit                 s
12     DOS-Datum                s
14     CRC-32                   i
18     komprimierte Größe       i
22     unkomprimierte Größe     i
26     Dateinamenlänge n        s
28     Extra-Feld-Länge         s
30     Dateiname                a(n)
…      Daten
```

```tcl
# Local Header + Daten schreiben (binary format, alle Felder little-endian)
proc zipLocal {name data method} {
    set crc   [zlib crc32 $data]
    set usize [string length $data]
    if {$method == 8} {
        set stored [zlib deflate $data]       ;# RAW deflate -- nicht compress!
    } else {
        set stored $data
    }
    set csize [string length $stored]
    set hdr [binary format "a4 s s s s s i i i s s a*" \
        "PK\x03\x04" 20 0 $method $::dostime $::dosdate \
        $crc $csize $usize [string length $name] 0 $name]
    return $hdr$stored
}
```

## Falle 1: zlib deflate vs. zlib compress (RAW deflate!)

ZIP-Methode 8 erwartet **rohen** Deflate-Strom -- **ohne** zlib-Header/Adler32.
`zlib compress` erzeugt aber das zlib-Format (mit Header). Man braucht
`zlib deflate`.

```tcl
# FALSCH: zlib-Format (2-Byte-Header + 4-Byte-Adler) -> ZIP defekt
set stored [zlib compress $data]

# RICHTIG: roher Deflate-Strom
set stored [zlib deflate $data]

# Entpacken entsprechend:
set data [zlib inflate $stored]      ;# zu deflate
# (nicht 'zlib decompress', das wäre zum zlib-Format)
```

Analog: `zlib gzip`/`gunzip` ist das gzip-Format -- auch nicht ZIP.

## Falle 2: CRC-32 von den UNkomprimierten Daten

Die CRC-32 im Header ist die der **Originaldaten**, nicht der komprimierten.

```tcl
# RICHTIG:
set crc [zlib crc32 $data]           ;# Originaldaten

# FALSCH:
set crc [zlib crc32 [zlib deflate $data]]    ;# CRC der komprimierten Daten
```

## Falle 3: DOS-Datum/-Zeit -- gültig und >= 1980

Das DOS-Zeitformat ist gepackt; ein **all-zero** Datum (0000-00-00) ist
**ungültig** und kann Validatoren/Tools irritieren. Minimum ist 1980-01-01.

```tcl
# Packen:
proc dosTime {h m s}  { expr {($h<<11) | ($m<<5) | ($s>>1)} }   ;# Sek. /2!
proc dosDate {y mo d} { expr {(($y-1980)<<9) | ($mo<<5) | $d} }

# Fester gültiger Zeitstempel (deterministisch + gültig):
set dostime 0          ;# 00:00:00
set dosdate 33         ;# 1980-01-01  (Jahr 0, Monat 1, Tag 1)
```

Die Sekunden werden **halbiert** gespeichert (2-Sekunden-Auflösung) -- ein
historischer DOS-Eigenheit. Ein fester Zeitstempel macht Builds reproduzierbar.

## Central Directory + EOCD

```
Central-Directory-Eintrag "PK\x01\x02" : wie Local Header, plus
   Offset des Local Headers, Kommentar-/Extra-/Dateiattribute.
EOCD "PK\x05\x06" : Anzahl Einträge, Größe und Offset des Central Directory.
```

```tcl
# Pro Eintrag merken: name, crc, csize, usize, method, localOffset.
# Central-Directory-Eintrag:
proc zipCentral {e} {
    dict with e {}
    binary format "a4 s s s s s s i i i s s s s s i i a*" \
        "PK\x01\x02" 20 20 0 $method $::dostime $::dosdate \
        $crc $csize $usize [string length $name] 0 0 0 0 0 $localOffset $name
}
# EOCD:
proc zipEOCD {count cdSize cdOffset} {
    binary format "a4 s s s s i i s" \
        "PK\x05\x06" 0 0 $count $count $cdSize $cdOffset 0
}
```

Beim Zusammensetzen: erst alle Local-Records (Offsets mitzählen!), dann das
Central Directory, dann das EOCD.

## Falle 4: mimetype-first für ODF/OOXML

ODF (und OOXML) verlangen den **ersten** Eintrag als unkomprimiertes Manifest
des Typs:

```tcl
# RICHTIG: mimetype zuerst, STORED (Methode 0), kein Extra-Feld
append zip [zipLocal mimetype \
    "application/vnd.oasis.opendocument.text" 0]
# danach content.xml, styles.xml … (Methode 8 ok)
```

```
# FALSCH: ZIP-Writer entscheidet selbst über Reihenfolge/Kompression
# -> mimetype landet komprimiert oder nicht zuerst -> Container ungültig
```

Niemals dem Default eines High-Level-ZIP-Writers überlassen, wenn die
Reihenfolge zählt -- darum hier von Hand. Siehe `odf-erzeugen-fallen.md`.

## Lesen: EOCD finden, Verzeichnis ablaufen

```tcl
proc zipRead {bytes} {
    # EOCD von hinten suchen (Signatur PK\x05\x06)
    set i [string last "PK\x05\x06" $bytes]
    if {$i < 0} { error "kein EOCD -- kein ZIP" }
    binary scan [string range $bytes [expr {$i+10}] [expr {$i+19}]] "s i i" \
        count cdSize cdOff
    set count [expr {$count & 0xffff}]
    # Central Directory ab cdOff ablaufen … (Einträge mit "PK\x01\x02")
    # je Eintrag: method, csize, usize, namelen, localOffset lesen,
    # dann am Local Header die Daten holen und ggf. inflaten.
}
```

**Masche:** EOCD per `string last` suchen, nicht von vorn -- ZIP wird vom Ende
her gelesen. Bei ZIP-Kommentaren steht das EOCD nicht exakt am Dateiende.

## zipfs (Tcl 9)

`zipfs` ist in Tcl 9 eingebaut und ersetzt die alte Metakit-VFS:

```tcl
# ZIP als Dateisystem mounten und daraus lesen/sourcen
zipfs mount myapp.zip /myapp
source /myapp/main.tcl
lappend auto_path /myapp/lib
package require mylib

# Ein ZIP-Image programmatisch erzeugen (Verzeichnisbaum -> ZIP):
zipfs mkzip out.zip ./srcdir

# Selbst-startendes Kit: Interpreter + angehängtes ZIP
zipfs mkimg myapp.bin ./app.vfs
```

Für **reines Lesen/Mounten und Deployment** ist `zipfs` erste Wahl. Für das
byte-genaue **Schreiben** eines spezifischen Containers (mimetype-first,
STORED/deflate gemischt) baut man weiterhin von Hand -- `zipfs mkzip`
kontrolliert Reihenfolge/Kompression nicht so fein.

## Häufige Fehler (Kurzübersicht)

```
1) zlib compress statt zlib deflate     -> zlib-Header im ZIP, Datei defekt
2) CRC-32 der komprimierten statt der Originaldaten
3) all-zero / <1980 DOS-Datum           -> ungültig, irritiert Validatoren
4) Sekunden nicht halbiert in dosTime
5) Felder big-endian gepackt            -> ZIP ist LITTLE-endian
6) mimetype nicht zuerst / nicht STORED  -> ODF/OOXML-Container ungültig
7) lokale Offsets im Central Directory falsch mitgezählt
8) EOCD von vorn gesucht                -> bei Kommentar/Anhang verfehlt
9) ZIP-Bytes ohne Binärmodus geschrieben -> open … wb
```

## Siehe auch

- `odf-erzeugen-fallen.md` -- mimetype-first, Container-Konformität
- `binary scan`/`format` -- Header-Felder packen/lesen, Endianness
- `zipkit-deployment.md` / `starpack-grundlagen.md` -- Deployment mit VFS
- `encoding-unicode.md` -- Binärmodus beim Lesen/Schreiben

## Referenzen

- [ZIP File Format (PKWARE APPNOTE)](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT)
- [Tcl: zlib Manual](https://www.tcl.tk/man/tcl9.0/TclCmd/zlib.html)
- [Tcl: zipfs Manual](https://www.tcl.tk/man/tcl9.0/TclCmd/zipfs.html)

---

*Letzte Aktualisierung: Mai 2026*
