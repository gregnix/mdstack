# Namespace

*Stand: 2026-04-29*

Namespaces kapseln Prozeduren und Variablen in einem eigenen Gueltigkeitsbereich.
Sie verhindern Namenskollisionen und strukturieren groessere Programme.

## Grundkonzept

Ein Namespace ist ein benannter Bereich, in dem Variablen und Prozeduren
unabhängig vom globalen Scope existieren. Innerhalb eines Namespaces können
Prozeduren und Variablen ohne Qualifizierung angesprochen werden. Von aussen
ist der vollständige Pfad nötig.

```tcl
namespace eval app {
    variable version "1.0"

    proc hello {} {
        variable version
        return "App v$version"
    }
}

puts [app::hello]   ;# -> "App v1.0"
```

Der `namespace eval`-Befehl erzeugt den Namespace (falls nicht vorhanden) und
führt das Script in dessen Kontext aus. Mehrfache Aufrufe von `namespace eval`
auf denselben Namespace überschreiben ihn nicht, sondern erweitern ihn.

## Hierarchie und Benennung

Namespaces sind hierarchisch wie ein Dateisystem organisiert.
Das Trennzeichen ist `::` statt `/`.

### Absolute und relative Namen

| Schreibweise | Bedeutung |
|:-------------|:----------|
| `::foo::bar` | Absolut: bar im Namespace foo, ausgehend von global |
| `foo::bar` | Relativ: bar im Namespace foo, ausgehend vom aktuellen Namespace |
| `::` | Der globale Namespace (Wurzel) |

```tcl
namespace eval outer {
    namespace eval inner {
        proc where {} {
            return [namespace current]
        }
    }
}

puts [outer::inner::where]   ;# -> ::outer::inner
```

### Verschachtelte Namespaces

Verschachtelung kann direkt oder schrittweise definiert werden:

```tcl
# Schrittweise
namespace eval a {
    namespace eval b {
        proc hello {} { return "a::b" }
    }
}

# Direkt (aequivalent)
namespace eval a::b {
    proc hello {} { return "a::b" }
}
```

Die direkte Variante erzeugt automatisch alle Zwischenebenen.

## Scoping-Regeln

Namespace-Scopes haben Eigenschaften von globalem und lokalem Scope:

**Ähnlich wie globaler Scope:**

- Prozeduren, die innerhalb eines Namespaces definiert werden, sind im
  gesamten Namespace sichtbar.
- Variablen, die mit `variable` deklariert werden, sind persistent und
  überleben Prozedur-Aufrufe.
- Prozeduren im Namespace können auf die Namespace-Variablen zugreifen.

**Ähnlich wie lokaler Scope:**

- Code im Namespace hat keinen direkten Zugriff auf den globalen Scope.
- Namespaces sind immer innerhalb des globalen Scopes enthalten.

**Wichtiger Unterschied zu C++/Java:** Namespace-Kapselung ist beratend
(advisory), nicht erzwungen. Jede Entitaet kann über ihren vollen Pfad
von aussen erreicht werden.

## Der variable-Befehl

`variable` deklariert eine persistente Variable innerhalb eines Namespaces.
Sie ist das Namespace-Aequivalent zu `global`.

### Syntax

```tcl
variable varName ?value? ?varName2 value2? ...
```

### Verwendung in Prozeduren

Innerhalb einer Prozedur muss `variable` verwendet werden, um auf die
Namespace-Variable zuzugreifen:

```tcl
namespace eval counter {
    variable count 0

    proc increment {} {
        variable count
        incr count
    }

    proc get {} {
        variable count
        return $count
    }
}

counter::increment
counter::increment
puts [counter::get]   ;# -> 2
```

Ohne `variable count` in der Prozedur würde eine lokale Variable
erzeugt statt auf die Namespace-Variable zuzugreifen.

### Mehrere Variablen deklarieren

```tcl
namespace eval config {
    variable host "localhost"
    variable port 8080
    variable debug 0
}
```

Oder in einer Zeile:

```tcl
namespace eval config {
    variable host "localhost" port 8080 debug 0
}
```

## Export und Import

### namespace export

Markiert Prozeduren als oeffentlich. Nur exportierte Prozeduren können
importiert werden.

```tcl
namespace eval math {
    namespace export add subtract

    proc add {a b} { expr {$a + $b} }
    proc subtract {a b} { expr {$a - $b} }
    proc _helper {x} { return $x }   ;# nicht exportiert
}
```

Export-Patterns unterstützen Glob-Syntax:

```tcl
namespace export *         ;# alles exportieren
namespace export get*      ;# alles was mit "get" beginnt
```

### namespace import

Macht exportierte Prozeduren im aktuellen Namespace verfügbar:

```tcl
namespace import math::add math::subtract

puts [add 3 4]        ;# -> 7 (ohne Qualifizierung)
puts [subtract 10 3]  ;# -> 7
```

Mit `-force` werden existierende Prozeduren überschrieben:

```tcl
namespace import -force math::*
```

### Empfehlung

In der Praxis ist der vollständige Pfad (`math::add`) meist besser als
Import, weil die Herkunft einer Prozedur sofort klar ist. Das Regelbuch
verbietet `namespace import *` ausdruecklich.

## Namespace-Variablen von aussen lesen

Der Zugriff auf Namespace-Variablen von aussen erfordert besondere Syntax,
weil `$ns::var` vom Parser als eine einzige Variable interpretiert wird.

### Variante 1: Doppeltes set

```tcl
set ns "config"
puts [set ${ns}::host]           ;# -> localhost
```

### Variante 2: Verschachteltes set

```tcl
puts [set [set ns]::host]        ;# -> localhost
```

### Variante 3: namespace upvar

```tcl
namespace upvar $ns host myHost
puts $myHost                      ;# -> localhost
```

`namespace upvar` verknüpft eine lokale Variable mit einer Namespace-Variable
und ist die sauberste Lösung.

## Inspektion

### namespace current

Gibt den aktuellen Namespace zurück:

```tcl
namespace eval app {
    proc where {} { return [namespace current] }
}
puts [app::where]   ;# -> ::app
```

### namespace parent

Gibt den übergeordneten Namespace zurück:

```tcl
namespace eval a::b {
    puts [namespace parent]   ;# -> ::a
}
```

### namespace children

Listet Kind-Namespaces:

```tcl
namespace eval a {
    namespace eval b {}
    namespace eval c {}
}
puts [namespace children a]   ;# -> ::a::b ::a::c
```

### namespace exists

Prüft ob ein Namespace existiert:

```tcl
if {[namespace exists ::app]} {
    puts "app existiert"
}
```

### namespace qualifiers und namespace tail

Zerlegen einen qualifizierten Namen:

```tcl
namespace qualifiers ::a::b::proc1   ;# -> ::a::b
namespace tail ::a::b::proc1         ;# -> proc1
```

## Namensaufloesung (Name Resolution)

Wenn ein unqualifizierter Name referenziert wird, sucht Tcl in dieser
Reihenfolge:

1. Im aktuellen Namespace
2. Im globalen Namespace (`::`)

Es wird **nicht** in übergeordneten Namespaces gesucht. Ein Namespace `a::b`
hat keinen automatischen Zugriff auf Prozeduren in `a`.

```tcl
namespace eval outer {
    proc greet {} { return "outer" }

    namespace eval inner {
        # greet ist hier NICHT sichtbar (kein Upward-Lookup)
        # Aufruf von greet würde im globalen Scope suchen
    }
}
```

Um eine Prozedur aus dem Eltern-Namespace aufzurufen, muss sie qualifiziert
werden:

```tcl
namespace eval outer::inner {
    proc test {} {
        outer::greet        ;# relativ, oder:
        ::outer::greet      ;# absolut
    }
}
```

## namespace which

Findet den vollqualifizierten Namen eines Befehls oder einer Variable
im aktuellen Scope. Nützlich um zu prüfen, ob ein Name existiert und
woher er kommt.

### Befehle suchen

```tcl
namespace eval app {
    proc start {} {}
}

namespace which app::start    ;# -> ::app::start
namespace which puts          ;# -> ::puts
namespace which gibtsNicht    ;# -> "" (leerer String)
```

### Variablen suchen

Mit der Option `-variable`:

```tcl
namespace eval app {
    variable config "test"
}

namespace eval app {
    namespace which -variable config   ;# -> ::app::config
}
```

### Typischer Einsatz

Prüfen ob ein Befehl existiert bevor er verwendet wird:

```tcl
if {[namespace which myCmd] ne ""} {
    myCmd arg1 arg2
}
```

Oder in der Record-Prozedur aus der Ensemble-Doku, um Namenskollisionen
zu verhindern:

```tcl
if {[uplevel 1 [list namespace which $name]] ne ""} {
    error "Befehl '$name' existiert bereits."
}
```

## namespace origin

Gibt den ursprünglichen Befehl zurück, auf den ein importierter
Befehl verweist. Damit lässt sich die Herkunft eines per
`namespace import` eingefuehrten Befehls zurückverfolgen.

```tcl
namespace eval math {
    namespace export add
    proc add {a b} { expr {$a + $b} }
}

namespace import math::add

namespace origin add          ;# -> ::math::add
```

Wenn der Befehl nicht importiert wurde, gibt `namespace origin` einen
Fehler:

```tcl
namespace origin puts
# Fehler: "puts" is not a namespace-imported command
```

### Kette von Imports

Bei mehrfachem Import über Zwischenstationen gibt `namespace origin`
den allerersten Ursprung zurück:

```tcl
namespace eval a {
    namespace export hello
    proc hello {} { return "original" }
}

namespace eval b {
    namespace import ::a::hello
    namespace export hello
}

namespace import ::b::hello
namespace origin hello    ;# -> ::a::hello (nicht ::b::hello)
```

## namespace code und namespace inscope

### namespace code

Erzeugt ein Script, das im aktuellen Namespace ausgeführt wird.
Nützlich für Callbacks:

```tcl
namespace eval app {
    proc onClick {} {
        puts "clicked in [namespace current]"
    }

    # Callback für ein Widget
    set cmd [namespace code {onClick}]
    # -> ::namespace inscope ::app {onClick}
}
```

### namespace inscope

Führt ein Script in einem bestimmten Namespace aus, ähnlich wie
`namespace eval`, aber mit einem wichtigen Unterschied: Zusätzliche
Argumente werden als Listenelemente an das Script angehängt.

```tcl
namespace inscope ::app myProc arg1 arg2
# führt ::app::myProc arg1 arg2 aus
```

## namespace path

Seit Tcl 8.5. Definiert eine Liste von Namespaces, in denen nach
unqualifizierten Befehlen gesucht wird, bevor der globale Namespace
geprüft wird.

```tcl
namespace eval tools {
    proc log {msg} { puts "LOG: $msg" }
}

namespace eval app {
    namespace path ::tools

    proc run {} {
        log "gestartet"   ;# findet ::tools::log
    }
}
```

Ohne `namespace path` würde `log` im globalen Scope gesucht und
nicht gefunden.

## namespace unknown

Definiert einen Handler für unbekannte Befehle innerhalb eines Namespaces.
Aequivalent zu `unknown` für den globalen Scope.

```tcl
namespace eval app {
    namespace unknown [list apply {{ns args} {
        puts "Unbekannter Befehl in $ns: $args"
    }} ::app]
}
```

## Löschen von Namespaces

### namespace delete

Loescht einen Namespace mitsamt aller Variablen, Prozeduren und
Kind-Namespaces:

```tcl
namespace delete ::app
```

Vorsicht: Alle Referenzen auf Prozeduren und Variablen in diesem
Namespace werden ungültig.

## Häufige Fehler

### Variable ohne variable-Deklaration

```tcl
# FALSCH: Erzeugt lokale Variable statt Namespace-Variable
namespace eval app {
    proc increment {} {
        incr count   ;# Fehler: count nicht definiert
    }
}

# RICHTIG:
namespace eval app {
    variable count 0
    proc increment {} {
        variable count
        incr count
    }
}
```

### Globale Variable statt Namespace-Variable

```tcl
# FALSCH: global statt variable
namespace eval app {
    proc get {} {
        global data   ;# greift auf ::data zu, nicht ::app::data
    }
}

# RICHTIG:
namespace eval app {
    proc get {} {
        variable data   ;# greift auf ::app::data zu
    }
}
```

### Proc-Namen die Tcl-Builtins überdecken

```tcl
# FALSCH: set, get, info etc. als Proc-Namen
namespace eval app {
    proc set {key value} { ... }   ;# überdeckt ::set
}

# RICHTIG: Spezifische Namen
namespace eval app {
    proc setValue {key value} { ... }
}
```

## Das scriptDir-Problem

Ein häufiger Bug bei Modulen: `info script` liefert den Pfad des
aktuell ausgeführten Scripts, ist aber nur während der Ausführung
gueltig. Bei `package require` kann der Wert leer sein.

### Das Problem

```tcl
namespace eval ::mymodule {
    # Kann leer oder "." sein!
    variable scriptDir [file dirname [info script]]
}
```

### Robuste Lösung

```tcl
namespace eval ::mymodule {
    variable scriptDir [file normalize [file dirname [info script]]]

    # Fallback wenn info script leer ist
    if {$scriptDir eq "" || $scriptDir eq "."} {
        set scriptDir [file normalize [pwd]]
    }
}
```

### Verwendung in Prozeduren

```tcl
namespace eval ::mymodule {
    variable scriptDir  ;# oben initialisiert

    proc loadResource {name} {
        variable scriptDir
        set path [file join $scriptDir resources $name]
        if {![file exists $path]} {
            error "Resource nicht gefunden: $path"
        }
        set fd [open $path r]
        try {
            return [read $fd]
        } finally {
            close $fd
        }
    }
}
```

**Tipp:** In `.tm`-Modulen ist `info script` zuverlässiger als in
Packages mit `pkgIndex.tcl`, weil das Modul direkt geladen wird.
Trotzdem ist der Fallback sinnvoll für interaktive Nutzung.

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `namespace eval ns script` | Namespace erzeugen/erweitern, Script ausführen |
| `namespace current` | Aktuellen Namespace abfragen |
| `namespace parent ?ns?` | Eltern-Namespace abfragen |
| `namespace children ?ns?` | Kind-Namespaces auflisten |
| `namespace exists ns` | Prüfen ob Namespace existiert |
| `namespace export pattern` | Prozeduren als oeffentlich markieren |
| `namespace import ?-force? pattern` | Exportierte Prozeduren importieren |
| `namespace delete ns` | Namespace löschen |
| `namespace qualifiers name` | Namespace-Anteil eines Namens |
| `namespace tail name` | Letzten Teil eines Namens |
| `namespace code script` | Callback im aktuellen Namespace erzeugen |
| `namespace inscope ns script` | Script in Namespace ausführen |
| `namespace path nsList` | Suchpfad für Befehle setzen |
| `namespace unknown handler` | Handler für unbekannte Befehle |
| `namespace which ?-variable? name` | Vollqualifizierten Namen finden |
| `namespace origin name` | Ursprung eines importierten Befehls |
| `namespace upvar ns var local` | Namespace-Variable verknüpfen |
| `variable name ?value?` | Persistente Namespace-Variable deklarieren |

## Siehe auch

- [Namespace Ensemble](namespace-ensemble.md) -- Ensembles als Befehlsinterface
- [Variable Scope](variable-scope.md) -- `variable`, `upvar`, `namespace upvar`
- [Package](package.md) -- Pakete in Namespaces organisieren
- [Prozeduren](proc.md) -- Procs innerhalb von Namespaces
- [TclOO](tcloo.md) -- Objekte nutzen Namespaces intern
- [Metaprogramming](metaprogramming.md) -- `namespace code`, `namespace inscope`
- [Text-Widget Tags](text-widget-tags.md) -- Tag-Verwaltung in Namespaces
- [Geometry Manager](geometry-manager.md) -- GUI-Code in Namespaces
- [Substitution](substitution-escaping.md) -- Quoting-Regeln bei `namespace eval`
