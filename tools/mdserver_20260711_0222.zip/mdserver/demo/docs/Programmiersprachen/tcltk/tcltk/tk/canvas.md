# Tk Canvas-Widget Referenzhandbuch

*Stand: 2026-04-29*

Umfassende deutsche Referenz für das Tk Canvas-Widget (Tcl/Tk 8.6 und 9.x).

## Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Widget erstellen](#widget-erstellen)
3. [Konfigurationsoptionen](#konfigurationsoptionen)
4. [Item-Typen](#item-typen)
5. [Item-Optionen](#item-optionen)
6. [Tags und IDs](#tags-und-ids)
7. [Item-Manipulation](#item-manipulation)
8. [Koordinaten und Transformationen](#koordinaten-und-transformationen)
9. [Scrolling](#scrolling)
10. [Bindings auf Items](#bindings-auf-items)
11. [Stacking Order](#stacking-order)
12. [PostScript-Export](#postscript-export)
13. [PDF-Export via pdf4tcl](#pdf-export-via-pdf4tcl)
14. [PostScript zu PDF konvertieren](#postscript-zu-pdf-konvertieren)
15. [Bekannte Probleme und Lösungen](#bekannte-probleme-und-loesungen)
16. [Praxisbeispiele](#praxisbeispiele)

> **Version:** 2026-04-05 — ergänzt: `-bbox`, `-fontmap`, Canvas-Pfad vs. Befehlsname,
> `update idletasks`, mehrseitiger Export (canvasToPdf-Muster), ps2pdf vs gs, A4-Punkte

---

## Überblick

Das Canvas-Widget ist ein mächtiges 2D-Zeichen-Widget für:

- Vektorgrafiken (Linien, Rechtecke, Polygone, Bögen)
- Textdarstellung mit beliebiger Positionierung
- Eingebettete Bilder
- Eingebettete Widgets (Buttons, Entry-Felder etc.)
- Interaktive Diagramme und Visualisierungen
- Drag & Drop Interfaces
- Zeichenanwendungen

### Kernkonzepte

| Konzept | Beschreibung |
|---------|--------------|
| Item | Ein Grafikobjekt auf dem Canvas (Linie, Rechteck, Text etc.) |
| Item-ID | Eindeutige numerische ID, die beim Erstellen zurückgegeben wird |
| Tag | Benannter Bezeichner, der mehreren Items zugewiesen werden kann |
| Koordinaten | Canvas verwendet ein Koordinatensystem mit Ursprung oben links |
| Scrollregion | Der virtuelle Bereich, der gescrollt werden kann |

---

## Widget erstellen

### Syntax

```tcl
canvas pathName ?options?
```

### Minimales Beispiel

```tcl
canvas .c -width 400 -height 300
pack .c
```

### Mit Scrollbars

```tcl
canvas .c -width 400 -height 300 \
    -scrollregion {0 0 1000 1000} \
    -xscrollcommand {.xsb set} \
    -yscrollcommand {.ysb set}

ttk::scrollbar .xsb -orient horizontal -command {.c xview}
ttk::scrollbar .ysb -orient vertical -command {.c yview}

grid .c -row 0 -column 0 -sticky nsew
grid .ysb -row 0 -column 1 -sticky ns
grid .xsb -row 1 -column 0 -sticky ew

grid rowconfigure . 0 -weight 1
grid columnconfigure . 0 -weight 1
```

---

## Konfigurationsoptionen

### Geometrie

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -width | Pixel | Breite des sichtbaren Bereichs |
| -height | Pixel | Höhe des sichtbaren Bereichs |
| -scrollregion | Liste | Virtuelle Größe {x1 y1 x2 y2} |
| -confine | Boolean | Scrolling auf scrollregion beschränken (default: true) |

### Aussehen

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -background / -bg | Farbe | Hintergrundfarbe |
| -borderwidth / -bd | Pixel | Rahmenbreite |
| -relief | Relief | Rahmentyp (flat, raised, sunken, groove, ridge) |
| -highlightthickness | Pixel | Fokus-Rahmenbreite |
| -highlightcolor | Farbe | Fokus-Rahmenfarbe |
| -highlightbackground | Farbe | Fokus-Rahmenfarbe ohne Fokus |

### Scrolling

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -xscrollcommand | Callback | Callback für horizontale Scrollbar |
| -yscrollcommand | Callback | Callback für vertikale Scrollbar |
| -xscrollincrement | Pixel | Scroll-Schrittweite horizontal |
| -yscrollincrement | Pixel | Scroll-Schrittweite vertikal |

### Sonstiges

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -closeenough | Float | Abstand für "closest" Erkennung (default: 1.0) |
| -cursor | Cursor | Mauszeiger über dem Canvas |
| -insertbackground | Farbe | Cursor-Farbe in Text-Items |
| -insertwidth | Pixel | Cursor-Breite in Text-Items |
| -selectbackground | Farbe | Selektions-Hintergrund |
| -selectforeground | Farbe | Selektions-Vordergrund |
| -selectborderwidth | Pixel | Selektions-Rahmen |
| -state | State | normal oder disabled |

---

## Item-Typen

### Linie (line)

```tcl
# Einfache Linie
.c create line 10 10 100 100

# Polylinie (mehrere Punkte)
.c create line 10 10 50 50 100 30 150 80

# Mit Optionen
.c create line 10 10 100 100 \
    -fill red \
    -width 3 \
    -arrow last \
    -arrowshape {10 15 5} \
    -smooth true \
    -dash {4 2}
```

**Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -fill | Linienfarbe |
| -width | Linienbreite |
| -arrow | Pfeilspitzen: none, first, last, both |
| -arrowshape | Pfeilform {d1 d2 d3} |
| -capstyle | Linienenden: butt, projecting, round |
| -joinstyle | Ecken: bevel, miter, round |
| -smooth | Glättung: true/false oder bezier/raw |
| -splinesteps | Anzahl Segmente bei smooth |
| -dash | Strichmuster |
| -dashoffset | Offset für Strichmuster |

### Rechteck (rectangle)

```tcl
# Einfaches Rechteck (x1 y1 x2 y2)
.c create rectangle 10 10 100 50

# Mit Optionen
.c create rectangle 10 10 100 50 \
    -fill blue \
    -outline black \
    -width 2 \
    -stipple gray50
```

**Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -fill | Füllfarbe (leer = transparent) |
| -outline | Rahmenfarbe |
| -width | Rahmenbreite |
| -stipple | Füllmuster (Bitmap) |
| -outlinestipple | Rahmenmuster |

### Oval / Ellipse (oval)

```tcl
# Oval innerhalb der Bounding-Box
.c create oval 10 10 100 60

# Kreis (gleiche Breite und Höhe)
.c create oval 50 50 100 100 -fill yellow
```

Optionen wie bei rectangle.

### Bogen (arc)

```tcl
# Tortenstück
.c create arc 10 10 100 100 \
    -start 0 \
    -extent 90 \
    -style pieslice \
    -fill red

# Bogensegment
.c create arc 10 10 100 100 \
    -start 45 \
    -extent 180 \
    -style chord \
    -fill blue

# Nur Bogen (keine Füllung)
.c create arc 10 10 100 100 \
    -start 0 \
    -extent 270 \
    -style arc \
    -outline green \
    -width 3
```

**Spezielle Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -start | Startwinkel in Grad (0 = 3 Uhr) |
| -extent | Winkelausdehnung in Grad |
| -style | pieslice (Tortenstück), chord (Segment), arc (nur Bogen) |

### Polygon (polygon)

```tcl
# Dreieck
.c create polygon 50 10 10 90 90 90 -fill green

# Stern
.c create polygon 50 0 61 35 98 35 68 57 79 91 50 70 21 91 32 57 2 35 39 35 \
    -fill yellow -outline black
```

Optionen wie bei rectangle, plus:

| Option | Beschreibung |
|--------|--------------|
| -smooth | Kurven statt Ecken |
| -splinesteps | Glättungsgrad |

### Text (text)

```tcl
# Einfacher Text
.c create text 100 50 -text "Hello World"

# Mit Optionen
.c create text 100 50 \
    -text "Mehrzeiliger\nText" \
    -font {Helvetica 14 bold} \
    -fill blue \
    -anchor center \
    -justify center \
    -width 200
```

**Spezielle Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -text | Der anzuzeigende Text |
| -font | Schriftart |
| -fill | Textfarbe |
| -anchor | Anker: n, ne, e, se, s, sw, w, nw, center |
| -justify | Ausrichtung: left, center, right |
| -width | Max. Breite (0 = keine Begrenzung) |
| -angle | Rotation in Grad (Tk 8.6+) |

### Bild (image)

```tcl
# Bild laden
image create photo myPhoto -file "bild.png"

# Im Canvas anzeigen
.c create image 100 100 -image myPhoto -anchor center
```

**Wichtig:** Referenz auf das Bild-Objekt behalten!

```tcl
# FALSCH - Bild kann garbage-collected werden
.c create image 100 100 -image [image create photo -file "bild.png"]

# RICHTIG - Referenz behalten
set img [image create photo -file "bild.png"]
.c create image 100 100 -image $img
lappend ::images $img  ;# Referenz speichern
```

**Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -image | Das Bild-Objekt |
| -anchor | Anker relativ zur Position |

### Bitmap (bitmap)

```tcl
# Eingebautes Bitmap
.c create bitmap 50 50 -bitmap warning -foreground red

# Eigenes Bitmap
.c create bitmap 50 50 -bitmap @mybitmap.xbm
```

### Eingebettetes Fenster (window)

```tcl
# Button im Canvas
ttk::button .c.btn -text "Klick mich" -command {puts "Geklickt!"}
.c create window 100 100 -window .c.btn -anchor center

# Entry-Feld
ttk::entry .c.entry -textvariable ::eingabe
.c create window 200 100 -window .c.entry -width 150
```

**Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -window | Das einzubettende Widget |
| -anchor | Anker relativ zur Position |
| -width | Breite überschreiben |
| -height | Höhe überschreiben |

---

## Item-Optionen

### Gemeinsame Optionen

| Option | Anwendbar auf | Beschreibung |
|--------|---------------|--------------|
| -tags | alle | Tag(s) zuweisen |
| -state | alle | normal, disabled, hidden |
| -fill | rectangle, oval, polygon, arc, text | Füllfarbe |
| -outline | rectangle, oval, polygon, arc | Rahmenfarbe |
| -width | line, rectangle, oval, polygon, arc | Linienbreite |
| -stipple | rectangle, oval, polygon, arc, text | Füllmuster |
| -dash | line, rectangle, oval, polygon, arc | Strichmuster |

### Stipple-Muster

Eingebaute Bitmap-Muster:

```tcl
# Verfügbare Muster
gray75 gray50 gray25 gray12 hourglass info questhead warning error
```

### Dash-Muster

```tcl
# Gestrichelt
-dash {4 4}

# Strich-Punkt
-dash {6 2 2 2}

# Gepunktet
-dash .
```

---

## Tags und IDs

### Item-ID

Beim Erstellen eines Items wird eine eindeutige numerische ID zurückgegeben:

```tcl
set rectId [.c create rectangle 10 10 50 50]
puts "Erstellt mit ID: $rectId"

# Mit ID ansprechen
.c itemconfigure $rectId -fill red
```

### Tags

Tags sind benannte Bezeichner, die mehreren Items zugewiesen werden können:

```tcl
# Bei Erstellung
.c create rectangle 10 10 50 50 -tags {box clickable red}
.c create oval 60 10 100 50 -tags {circle clickable blue}

# Nachträglich hinzufügen
.c addtag selected withtag clickable

# Tag entfernen
.c dtag $itemId selected

# Alle Tags eines Items
.c gettags $itemId
```

### Spezielle Tags

| Tag | Beschreibung |
|-----|--------------|
| all | Alle Items |
| current | Item unter dem Mauszeiger |

### Tag-Suchbefehle

```tcl
# Tag hinzufügen nach verschiedenen Kriterien
.c addtag newtag above $itemId       ;# Items über diesem
.c addtag newtag below $itemId       ;# Items unter diesem
.c addtag newtag closest x y         ;# Nächstes Item zu Punkt
.c addtag newtag enclosed x1 y1 x2 y2    ;# Vollständig im Rechteck
.c addtag newtag overlapping x1 y1 x2 y2 ;# Überlappend mit Rechteck
.c addtag newtag withtag existingTag ;# Items mit bestehendem Tag
```

### Items finden

```tcl
# Alle Items
.c find all

# Nach Tag
.c find withtag clickable

# An Position
.c find overlapping 50 50 60 60

# Vollständig im Bereich
.c find enclosed 0 0 100 100

# Nächstes Item zu Punkt
.c find closest 75 75

# Über/unter einem Item
.c find above $itemId
.c find below $itemId
```

---

## Item-Manipulation

### Konfigurieren

```tcl
# Option setzen
.c itemconfigure $itemId -fill red

# Option abfragen
.c itemcget $itemId -fill

# Mehrere Optionen
.c itemconfigure $itemId -fill red -outline black -width 2

# Per Tag (alle betroffenen Items)
.c itemconfigure clickable -fill yellow
```

### Verschieben

```tcl
# Relativ verschieben
.c move $itemId 10 20           ;# 10 Pixel rechts, 20 Pixel runter
.c move clickable -5 0          ;# Alle mit Tag 5 Pixel links
```

### Koordinaten setzen/abfragen

```tcl
# Koordinaten abfragen
set coords [.c coords $itemId]

# Koordinaten setzen (absolut)
.c coords $itemId 100 100 200 150

# Bei Polygonen
.c coords $polyId 10 10 50 10 30 50
```

### Löschen

```tcl
# Einzelnes Item
.c delete $itemId

# Nach Tag
.c delete clickable

# Alle Items
.c delete all
```

### Typ abfragen

```tcl
set type [.c type $itemId]
# Gibt zurück: arc, bitmap, image, line, oval, polygon, rectangle, text, window
```

---

## Koordinaten und Transformationen

### Koordinatensystem

- Ursprung (0,0) ist oben links
- X wächst nach rechts
- Y wächst nach unten
- Einheit: Pixel (oder andere Einheiten mit Suffix)

### Koordinaten-Einheiten

```tcl
# Pixel (Standard)
.c create line 10 10 100 100

# Zentimeter
.c create line 1c 1c 5c 5c

# Millimeter
.c create line 10m 10m 50m 50m

# Zoll (Inch)
.c create line 0.5i 0.5i 2i 2i

# Punkt (1/72 Zoll)
.c create line 36p 36p 144p 144p
```

### Canvas-Koordinaten vs. Fenster-Koordinaten

```tcl
# Fenster -> Canvas (berücksichtigt Scrolling)
set canvasX [.c canvasx $windowX]
set canvasY [.c canvasy $windowY]

# Mit Rasterung
set canvasX [.c canvasx $windowX 10]  ;# Auf 10er-Raster
```

### Skalieren

```tcl
# Um Faktor skalieren (relativ zu Ursprungspunkt)
.c scale $itemId $originX $originY $xScale $yScale

# Beispiel: Verdoppeln um Punkt (50,50)
.c scale myitem 50 50 2.0 2.0

# Alle Items skalieren
.c scale all 0 0 1.5 1.5
```

### Bounding Box

```tcl
# Bounding Box eines Items
set bbox [.c bbox $itemId]
lassign $bbox x1 y1 x2 y2

# Bounding Box mehrerer Items
set bbox [.c bbox tag1 tag2]

# Bounding Box aller Items
set bbox [.c bbox all]
```

---

## Scrolling

### Scrollregion konfigurieren

```tcl
# Feste Größe
.c configure -scrollregion {0 0 2000 1500}

# Dynamisch an Inhalt anpassen
proc updateScrollregion {canvas} {
    set bbox [$canvas bbox all]
    if {$bbox ne ""} {
        $canvas configure -scrollregion $bbox
    }
}
```

### Scrollbefehle

```tcl
# Scroll-Position abfragen (0.0 - 1.0)
set pos [.c xview]
set pos [.c yview]

# Zu Bruch scrollen
.c xview moveto 0.5    ;# Mitte horizontal
.c yview moveto 0.0    ;# Ganz oben

# Um Einheiten scrollen
.c xview scroll 1 units
.c yview scroll -1 pages

# Zu Punkt scrollen (macht Punkt sichtbar)
# Kein direkter Befehl - muss berechnet werden
```

### Scroll-Position aus Koordinate berechnen

```tcl
proc scrollToItem {canvas itemId} {
    set bbox [$canvas bbox $itemId]
    if {$bbox eq ""} return
    
    lassign $bbox x1 y1 x2 y2
    lassign [$canvas cget -scrollregion] sx1 sy1 sx2 sy2
    
    set width [expr {$sx2 - $sx1}]
    set height [expr {$sy2 - $sy1}]
    
    # Zentrieren
    set cx [expr {($x1 + $x2) / 2.0}]
    set cy [expr {($y1 + $y2) / 2.0}]
    
    set fracX [expr {($cx - $sx1) / $width - 0.5}]
    set fracY [expr {($cy - $sy1) / $height - 0.5}]
    
    $canvas xview moveto $fracX
    $canvas yview moveto $fracY
}
```

---

## Bindings auf Items

### Grundlagen

```tcl
# Binding auf Item-ID
.c bind $itemId <Button-1> {puts "Geklickt!"}

# Binding auf Tag
.c bind clickable <Button-1> {puts "Clickable geklickt!"}

# Binding auf alle Items
.c bind all <Enter> {puts "Maus über Item"}
```

### Das "current" Tag

```tcl
# current = Item unter dem Mauszeiger
.c bind all <Enter> {
    %W itemconfigure current -fill red
}

.c bind all <Leave> {
    %W itemconfigure current -fill blue
}
```

### Event-Substitutionen

| Substitution | Beschreibung |
|--------------|--------------|
| %W | Widget-Pfad |
| %x, %y | Fenster-Koordinaten |
| %X, %Y | Bildschirm-Koordinaten |
| %b | Button-Nummer |
| %s | State (Modifier) |

### Wichtig: Canvas-Koordinaten in Bindings

```tcl
# Fenster-Koordinaten -> Canvas-Koordinaten
.c bind all <Button-1> {
    set cx [%W canvasx %x]
    set cy [%W canvasy %y]
    puts "Canvas-Position: $cx, $cy"
}
```

### Binding-Reihenfolge

Bindings werden in dieser Reihenfolge ausgeführt:
1. Item-spezifische Bindings (nach Tag-Priorität)
2. Canvas-Widget Bindings
3. Toplevel Bindings

```tcl
# Binding-Kette unterbrechen
.c bind myitem <Button-1> {
    puts "Item-Binding"
    break  ;# Stoppt weitere Verarbeitung
}
```

---

## Stacking Order

Items haben eine Z-Ordnung (Stacking Order). Später erstellte Items liegen über früheren.

### Reihenfolge ändern

```tcl
# Nach ganz oben
.c raise $itemId

# Nach ganz unten
.c lower $itemId

# Über bestimmtes Item
.c raise $itemId $otherItemId

# Unter bestimmtes Item
.c lower $itemId $otherItemId
```

### Items finden nach Stacking Order

```tcl
# Item über diesem
.c find above $itemId

# Item unter diesem
.c find below $itemId
```

---

## PostScript-Export

Das Canvas kann als PostScript/EPS exportiert werden:

```tcl
# Einfacher Export
.c postscript -file "output.ps"

# Mit Optionen
.c postscript -file "output.eps" \
    -colormode color \
    -pagewidth 8i \
    -pageheight 10i \
    -x 0 -y 0 \
    -width 400 -height 300

# In Variable statt Datei
set psData [.c postscript]
```

**Optionen:**

| Option | Beschreibung |
|--------|--------------|
| -file | Ausgabedatei (fehlt → gibt PS-String zurück) |
| -colormode | color, gray, mono |
| -pagewidth, -pageheight | Seitengröße mit Einheit: `595p` (A4 pt), `17c` (cm), `8i` (inch) |
| -x, -y | Startkoordinaten im Canvas |
| -width, -height | Zu exportierender Bereich im Canvas |
| -rotate | true für Querformat |
| -pagex, -pagey | Position auf der Seite |
| -fontmap | Dict: Tk-Font → PS-Font |

**A4-Export:**

```tcl
# Kompletter Canvas-Inhalt, A4-Seitengröße
.c postscript \
    -pagewidth  595p \
    -pageheight 842p \
    -file output.ps

# Nur sichtbarer Bereich (bbox)
set bbox [.c bbox all]
lassign $bbox x1 y1 x2 y2
.c postscript \
    -x $x1 -y $y1 -width [expr {$x2-$x1}] -height [expr {$y2-$y1}] \
    -pagewidth 595p \
    -file output.ps
```

**Einschränkungen:**
- Eingebettete Fenster werden nicht exportiert
- Bilder nur eingeschränkt (Bitmap, kein Alpha)
- Transparenz / Stipple nicht unterstützt
- Immer nur eine Seite
- Unicode außerhalb Latin-1 wird nicht korrekt exportiert

---

## PDF-Export via pdf4tcl

Mit `pdf4tcl` kann ein Canvas direkt als Vektorgrafik in eine PDF-Seite exportiert werden.
Alle Items bleiben scharf bei beliebigem Zoom — keine Bitmap-Konvertierung.

### Grundprinzip

```tcl
package require pdf4tcl

canvas .c -width 500 -height 400 -background white
.c create rectangle 20 20 200 100 -fill "#b3d1f0" -outline "#0055aa" -width 2
.c create text 100 60 -text "Hallo Welt" -font {Helvetica 16 bold}
pack .c
update idletasks   ;# WICHTIG: Canvas muss gerendert sein!

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 1]
$pdf startPage
$pdf canvas .c -x 50 -y 50 -width 500 -height 400
$pdf endPage
$pdf write -file output.pdf
$pdf destroy
```

### Optionen von `$pdf canvas`

| Option | Beschreibung |
|--------|--------------|
| `-x X` | X-Position auf der PDF-Seite (Points) |
| `-y Y` | Y-Position auf der PDF-Seite (Points) |
| `-width W` | Breite auf der PDF-Seite (Points) |
| `-height H` | Höhe auf der PDF-Seite (Points) |
| `-bbox {x1 y1 x2 y2}` | Nur diesen Canvas-Bereich exportieren |
| `-fontmap dict` | Tk-Font → TTF-Datei für Unicode-Unterstützung |
| `-sticky` | nw (default), ns, ew, nsew — Ausrichtung |
| `-bg 1` | Hintergrundfarbe des Canvas mitmalen |

### `update idletasks` ist Pflicht

```tcl
pack .c
update idletasks   ;# Canvas MUSS gerendert sein, sonst leeres PDF
```

### Nur einen Teilbereich exportieren (`-bbox`)

```tcl
# Bounding Box des Canvas-Inhalts
set bbox [.c bbox all]
lassign $bbox x1 y1 x2 y2
set cw [expr {$x2 - $x1}]
set ch [expr {$y2 - $y1}]

$pdf canvas .c \
    -bbox $bbox \
    -x 20 -y 20 \
    -width  555 \
    -height [expr {$ch * 555.0 / $cw}]
```

### Unicode mit `-fontmap`

Standard-PDF-Fonts (Helvetica etc.) unterstützen nur Latin-1.
Für Unicode-Zeichen (✔ ✗ → Umlaute außerhalb Latin-1) TTF-Font mappen:

```tcl
# fontmap: Tk-Fontname → TTF-Datei
set fontmap {}
foreach {tk ttf} {
    Helvetica /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf
    Courier   /usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf
    Times     /usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf
} {
    if {[file exists $ttf]} { lappend fontmap $tk $ttf }
}

$pdf canvas .c -fontmap $fontmap -bbox $bbox -x 20 -y 20 -width 555 -height 802
```

### Canvas-Pfad vs. Befehlsname

Wenn ein Canvas-Widget intern umbenannt wird (z.B. durch `rename`),
existieren zwei verschiedene Namen:

```tcl
rename .mycanvas ::internal::cv    ;# Tcl-Befehl umbenannt
# .mycanvas → Tk-Window-Path (existiert noch als Fenster)
# ::internal::cv → Tcl-Befehlsname (für canvas-Befehle wie create, bbox etc.)

# pdf4tcl braucht den Tk-Window-Path:
$pdf canvas .mycanvas     ;# ✔ funktioniert (winfo exists .mycanvas = true)
$pdf canvas $cv           ;# ✗ schlägt fehl ("bad window path name")

# Canvas-Befehle (create, bbox etc.) brauchen den Tcl-Befehlsnamen:
$cv bbox all              ;# ✔
.mycanvas bbox all        ;# ✗ (kein Befehl mehr)
```

### Mehrseitig: frisches Canvas pro Seite

Das Standardmuster aus pdf4tcllib (Demo 51) für mehrseitige Dokumente:

```tcl
proc canvasToPdf {pdf x y w h drawScript} {
    canvas .tmp -width $w -height $h -background white
    pack .tmp
    uplevel 1 $drawScript   ;# Inhalt zeichnen
    update idletasks
    $pdf canvas .tmp -x $x -y $y -width $w -height $h
    destroy .tmp
}

set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true -compress 1]

# Seite 1
$pdf startPage
canvasToPdf $pdf 55 65 480 520 {
    .tmp create text 240 30 -text "Seite 1" -font {Helvetica 14 bold}
}
$pdf endPage

# Seite 2
$pdf startPage
canvasToPdf $pdf 55 65 480 520 {
    .tmp create text 240 30 -text "Seite 2" -font {Helvetica 14 bold}
}
$pdf endPage

$pdf write -file output.pdf
$pdf destroy
```

### Mehrere Canvas auf einer Seite

```tcl
$pdf startPage
$pdf canvas .c1 -x  50 -y 50 -width 200 -height 200
$pdf canvas .c2 -x 280 -y 50 -width 200 -height 200
$pdf endPage
```

### Text + Canvas gemischt

```tcl
$pdf startPage
$pdf setFont 14 Helvetica-Bold
$pdf text "Abbildung 1" -x 50 -y 30
$pdf canvas .c -x 50 -y 50 -width 500 -height 400
$pdf endPage
```

### Unterstützte Canvas-Items

| Item | Exportiert? | Anmerkung |
|------|-------------|-----------|
| rectangle | ✔ | |
| oval | ✔ | |
| line | ✔ | inkl. -arrow, -dash |
| polygon | ✔ | |
| arc | ✔ | |
| text | ✔ | Font-Mapping beachten |
| image (photo) | ✔ | als Bitmap eingebettet |
| bitmap | ✔ | |
| window | ✗ | eingebettete Widgets nicht exportiert |

**Einschränkungen:**
- `window`-Items werden nicht exportiert
- `-stipple` (Füllmuster) wird nicht unterstützt
- Transparenz (`-alpha`) nur mit TTF-Font und pdf4tcl 0.9.4.25+
- Canvas muss sichtbar gerendert sein (`update idletasks`)

---

## PostScript zu PDF konvertieren

Der PostScript-Export von Tk (`.c postscript`) erzeugt eine `.ps`-Datei.
Diese kann auf zwei Wegen in PDF umgewandelt werden:

### Via ps2pdf (Ghostscript-Wrapper)

```tcl
.c postscript -file output.ps -pagewidth 595p -pageheight 842p

proc ps2pdf {psFile pdfFile} {
    if {[auto_execok ps2pdf] eq ""} {
        error "ps2pdf nicht gefunden (Ghostscript installieren)"
    }
    exec ps2pdf $psFile $pdfFile
}

ps2pdf output.ps output.pdf
```

### Via Ghostscript direkt

```tcl
proc gs2pdf {psFile pdfFile} {
    set gs [auto_execok gs]
    if {$gs eq ""} { error "Ghostscript (gs) nicht gefunden" }
    exec $gs -dBATCH -dNOPAUSE -dQUIET \
        -sDEVICE=pdfwrite \
        -sOutputFile=$pdfFile \
        $psFile
}
```

### Vergleich der drei Exportwege

| Methode | Befehl | Vorteile | Nachteile |
|---------|--------|----------|-----------|
| PostScript | `.c postscript` | Pure Tk, keine Abhängigkeit | Nur 1 Seite, kein PDF, kein Unicode |
| PS → PDF | `ps2pdf` / `gs` | Einfach | Ghostscript erforderlich, 1 Seite |
| pdf4tcl | `$pdf canvas .c` | Mehrseitig, Unicode, volle PDF-API | pdf4tcl erforderlich |

**Wann welche Methode:**
- Schneller Einmal-Export ohne Abhängigkeiten → PostScript
- PostScript vorhanden, PDF benötigt → `ps2pdf`
- Mehrseitiges Dokument, Unicode, Header/Footer → pdf4tcl direkt

---

## Bekannte Probleme und Lösungen

### 1. Bild verschwindet (Garbage Collection)

**Problem:** Bilder verschwinden, weil das Image-Objekt garbage-collected wird.

```tcl
# FALSCH
.c create image 100 100 -image [image create photo -file "bild.png"]

# RICHTIG
namespace eval ::myapp {
    variable images {}
}

proc addImage {canvas x y file} {
    set img [image create photo -file $file]
    lappend ::myapp::images $img
    $canvas create image $x $y -image $img
}
```

### 2. Koordinaten bei Scrolling falsch

**Problem:** Event-Koordinaten sind Fenster-Koordinaten, nicht Canvas-Koordinaten.

```tcl
# FALSCH
.c bind all <Button-1> {
    .c create oval [expr {%x-5}] [expr {%y-5}] [expr {%x+5}] [expr {%y+5}]
}

# RICHTIG
.c bind all <Button-1> {
    set cx [%W canvasx %x]
    set cy [%W canvasy %y]
    %W create oval [expr {$cx-5}] [expr {$cy-5}] [expr {$cx+5}] [expr {$cy+5}]
}
```

### 3. find closest findet immer etwas

**Problem:** `find closest` gibt immer ein Item zurück, auch wenn weit entfernt.

```tcl
# Mit Distanzprüfung
proc findNearby {canvas x y maxDist} {
    set item [$canvas find closest $x $y]
    if {$item eq ""} {return ""}
    
    set bbox [$canvas bbox $item]
    lassign $bbox x1 y1 x2 y2
    
    # Prüfe ob Punkt nah genug
    set cx [expr {($x1 + $x2) / 2.0}]
    set cy [expr {($y1 + $y2) / 2.0}]
    set dist [expr {hypot($x - $cx, $y - $cy)}]
    
    if {$dist <= $maxDist} {
        return $item
    }
    return ""
}
```

### 4. Text-Item Breite

**Problem:** Text ohne -width wächst unbegrenzt.

```tcl
# Feste Breite mit Umbruch
.c create text 100 100 -text $langerText -width 200 -anchor nw
```

### 5. Smooth-Linien mit wenigen Punkten

**Problem:** Smooth-Linien brauchen mindestens 4 Punkte.

```tcl
# Für 3 Punkte Zwischenpunkte einfügen
proc smoothLine {canvas args} {
    if {[llength $args] < 8} {
        # Weniger als 4 Punkte - kein Smooth
        return [$canvas create line {*}$args]
    }
    return [$canvas create line {*}$args -smooth true]
}
```

### 6. Performance bei vielen Items

**Problem:** Canvas wird langsam bei tausenden Items.

```tcl
# Lösungen:
# 1. Items außerhalb des sichtbaren Bereichs auf hidden setzen
proc updateVisibility {canvas} {
    lassign [$canvas xview] x1frac x2frac
    lassign [$canvas yview] y1frac y2frac
    lassign [$canvas cget -scrollregion] sx1 sy1 sx2 sy2
    
    set x1 [expr {$sx1 + ($sx2-$sx1) * $x1frac}]
    set x2 [expr {$sx1 + ($sx2-$sx1) * $x2frac}]
    set y1 [expr {$sy1 + ($sy2-$sy1) * $y1frac}]
    set y2 [expr {$sy1 + ($sy2-$sy1) * $y2frac}]
    
    # Sichtbare zeigen
    foreach item [$canvas find overlapping $x1 $y1 $x2 $y2] {
        $canvas itemconfigure $item -state normal
    }
}

# 2. Gruppen zusammenfassen wo möglich
# 3. Nur sichtbaren Bereich zeichnen (virtuelles Scrolling)
```

---

## Praxisbeispiele

### Einfaches Zeichenprogramm

```tcl
package require Tk

# Variablen
set ::drawing 0
set ::lastX 0
set ::lastY 0
set ::currentColor black
set ::lineWidth 2

# Canvas erstellen
canvas .c -width 600 -height 400 -bg white
pack .c -fill both -expand 1

# Toolbar
frame .toolbar
pack .toolbar -fill x

foreach {color name} {black Schwarz red Rot blue Blau green Grün} {
    button .toolbar.c$color -text $name -bg $color -fg white \
        -command [list set ::currentColor $color]
    pack .toolbar.c$color -side left -padx 2
}

ttk::spinbox .toolbar.width -from 1 -to 20 -width 5 \
    -textvariable ::lineWidth
pack .toolbar.width -side left -padx 5

button .toolbar.clear -text "Löschen" -command {.c delete all}
pack .toolbar.clear -side right -padx 5

# Zeichnen-Bindings
.c bind all <Button-1> {startDraw %W %x %y}
bind .c <Button-1> {startDraw %W %x %y}
bind .c <B1-Motion> {continueDraw %W %x %y}
bind .c <ButtonRelease-1> {set ::drawing 0}

proc startDraw {w x y} {
    set ::drawing 1
    set ::lastX [$w canvasx $x]
    set ::lastY [$w canvasy $y]
}

proc continueDraw {w x y} {
    if {!$::drawing} return
    
    set cx [$w canvasx $x]
    set cy [$w canvasy $y]
    
    $w create line $::lastX $::lastY $cx $cy \
        -fill $::currentColor \
        -width $::lineWidth \
        -capstyle round
    
    set ::lastX $cx
    set ::lastY $cy
}
```

### Interaktives Balkendiagramm

```tcl
package require Tk

proc createBarChart {canvas data} {
    $canvas delete all
    
    set width [winfo width $canvas]
    set height [winfo height $canvas]
    set margin 50
    set barWidth 40
    set spacing 20
    
    # Maximum finden
    set maxVal 0
    foreach {label value} $data {
        if {$value > $maxVal} {set maxVal $value}
    }
    
    # Skalierung
    set chartHeight [expr {$height - 2 * $margin}]
    set scale [expr {double($chartHeight) / $maxVal}]
    
    # Balken zeichnen
    set x $margin
    set colors {#4285f4 #ea4335 #fbbc04 #34a853 #ff6d01 #46bdc6}
    set colorIdx 0
    
    foreach {label value} $data {
        set barHeight [expr {$value * $scale}]
        set y1 [expr {$height - $margin}]
        set y2 [expr {$y1 - $barHeight}]
        
        set color [lindex $colors $colorIdx]
        set colorIdx [expr {($colorIdx + 1) % [llength $colors]}]
        
        # Balken
        set bar [$canvas create rectangle $x $y1 [expr {$x + $barWidth}] $y2 \
            -fill $color -outline "" -tags bar]
        
        # Wert über Balken
        $canvas create text [expr {$x + $barWidth/2}] [expr {$y2 - 10}] \
            -text $value -anchor s -font {Arial 10}
        
        # Label unter Balken
        $canvas create text [expr {$x + $barWidth/2}] [expr {$y1 + 10}] \
            -text $label -anchor n -font {Arial 9}
        
        # Hover-Effekt
        $canvas bind $bar <Enter> [list $canvas itemconfigure $bar -fill #ff9800]
        $canvas bind $bar <Leave> [list $canvas itemconfigure $bar -fill $color]
        
        set x [expr {$x + $barWidth + $spacing}]
    }
}

# Demo
canvas .c -width 500 -height 300 -bg white
pack .c -fill both -expand 1

set data {
    "Jan" 45
    "Feb" 72
    "Mär" 63
    "Apr" 89
    "Mai" 54
    "Jun" 96
}

bind .c <Configure> {createBarChart .c $data}
after 100 {createBarChart .c $data}
```

### Drag & Drop mit Snap-to-Grid

```tcl
package require Tk

set ::gridSize 20

canvas .c -width 400 -height 300 -bg white
pack .c -fill both -expand 1

# Gitter zeichnen
proc drawGrid {canvas} {
    $canvas delete grid
    set w [winfo width $canvas]
    set h [winfo height $canvas]
    
    for {set x 0} {$x < $w} {incr x $::gridSize} {
        $canvas create line $x 0 $x $h -fill #e0e0e0 -tags grid
    }
    for {set y 0} {$y < $h} {incr y $::gridSize} {
        $canvas create line 0 $y $w $y -fill #e0e0e0 -tags grid
    }
    $canvas lower grid
}

# Draggable Items erstellen
proc createDraggable {canvas x y w h color} {
    set id [$canvas create rectangle $x $y [expr {$x+$w}] [expr {$y+$h}] \
        -fill $color -outline black -tags draggable]
    return $id
}

# Snap to Grid
proc snapToGrid {value} {
    return [expr {round($value / double($::gridSize)) * $::gridSize}]
}

# Drag-Handling
set ::dragData [dict create]

.c bind draggable <Button-1> {
    set item [%W find withtag current]
    set bbox [%W bbox $item]
    dict set ::dragData item $item
    dict set ::dragData offsetX [expr {[%W canvasx %x] - [lindex $bbox 0]}]
    dict set ::dragData offsetY [expr {[%W canvasy %y] - [lindex $bbox 1]}]
}

.c bind draggable <B1-Motion> {
    if {![dict exists $::dragData item]} return
    set item [dict get $::dragData item]
    set bbox [%W bbox $item]
    set w [expr {[lindex $bbox 2] - [lindex $bbox 0]}]
    set h [expr {[lindex $bbox 3] - [lindex $bbox 1]}]
    
    set newX [expr {[%W canvasx %x] - [dict get $::dragData offsetX]}]
    set newY [expr {[%W canvasy %y] - [dict get $::dragData offsetY]}]
    
    %W coords $item $newX $newY [expr {$newX + $w}] [expr {$newY + $h}]
}

.c bind draggable <ButtonRelease-1> {
    if {![dict exists $::dragData item]} return
    set item [dict get $::dragData item]
    set bbox [%W bbox $item]
    
    set x1 [snapToGrid [lindex $bbox 0]]
    set y1 [snapToGrid [lindex $bbox 1]]
    set w [expr {[lindex $bbox 2] - [lindex $bbox 0]}]
    set h [expr {[lindex $bbox 3] - [lindex $bbox 1]}]
    
    %W coords $item $x1 $y1 [expr {$x1 + $w}] [expr {$y1 + $h}]
    set ::dragData [dict create]
}

# Initialisieren
bind .c <Configure> {drawGrid .c}
after 100 {
    drawGrid .c
    createDraggable .c 40 40 60 40 #4285f4
    createDraggable .c 140 80 80 60 #ea4335
    createDraggable .c 60 160 50 50 #34a853
}
```

---

## Siehe auch

- [text.md](text.md) - Text-Widget Referenz
- [listbox.md](listbox.md) - Listbox-Widget Referenz
- [treeview.md](treeview.md) - Treeview-Widget Referenz
- [tkopath.md](tkopath.md) - tko::path SVG-Canvas mit Antialiasing
- **Tcl/Tk Manual:** https://www.tcl-lang.org/man/tcl8.6/TkCmd/canvas.html
- **pdf4tcl:** https://sourceforge.net/projects/pdf4tcl/
