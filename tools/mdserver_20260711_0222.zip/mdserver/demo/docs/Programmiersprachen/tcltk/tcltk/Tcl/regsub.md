# regsub - Regex-Ersetzung

*Stand: 2026-04-29*

`regsub` ersetzt Teilstrings die einem RE-Pattern entsprechen. Das Ergebnis wird
zurückgegeben oder in einer Variablen gespeichert.

**Syntax:** `regsub ?optionen? RE STRING SUBSPEC ?VARNAME?`

Wenn `VARNAME` nicht angegeben wird, gibt der Befehl das Ergebnis zurück. Mit
`VARNAME` wird das Ergebnis gespeichert und die Anzahl der Ersetzungen zurückgegeben.

**Quelle:** https://www.tcl-lang.org/man/tcl8.6/TclCmd/regsub.html

## Grundlagen

```tcl
# Ohne VARNAME: Ergebnis zurückgeben
regsub {test} "This is a test" "example"
;# This is a example

# Mit VARNAME: Ergebnis speichern, Anzahl zurückgeben
regsub {test} "This is a test" "example" result
;# 1
set result  ;# This is a example
```

## Backreferences in SUBSPEC

In der Ersetzungszeichenkette stehen `\0` bzw. `&` für den gesamten Treffer,
`\1` bis `\9` für den Inhalt der entsprechenden Capturing-Gruppe.

```tcl
regsub {(\d+) (\d+)} "Example: 100 200" {\0 reversed is \2 \1}
;# Example: 100 200 reversed is 200 100

regsub {(\d+) (\d+)} "Example: 100 200" {& reversed is \2 \1} var
;# var = "Example: 100 200 reversed is 200 100"
```

Der nicht-matchende Teil des Strings bleibt unverändert (`Example:` im Beispiel).

## Optionen

### -all

Ersetzt alle Vorkommen, nicht nur das erste.

```tcl
regsub -all {a} "banana" "o" result
;# result = "bonono"

regsub -all {(c)olor} "Colors colors" {\1olour}
;# Colors colours
```

### -nocase

```tcl
regsub -nocase -all {(c)olor} "Colors colors" {\1olour}
;# Colours colours
```

### -start OFFSET

Startet die Suche ab Position OFFSET.

### -line, -lineanchor, -linestop, -expanded

Selbe Bedeutung wie bei `regexp` (siehe regexp.md).

## Doppelte Wörter entfernen

```tcl
regsub -all {\m(\w+)(\s+)\1\M} {
    Words are often repeated when
    when a word appears at the end of a line
    line and is repeated on the next.
} {\1}
;# Words are often repeated when a word appears at the end of a line and is ...
```

## URL-Dekodierung (string map + regsub + subst)

Klassische Kombination der drei Befehle:

```tcl
proc urlDecode {str} {
    set specialMap {"[" "%5B" "]" "%5D"}
    set seqRE {%([0-9a-fA-F]{2})}
    set replacement {[format "%c" [scan "\1" "%2x"]]}
    set modStr [regsub -all $seqRE [string map $specialMap $str] $replacement]
    return [encoding convertfrom utf-8 [subst -nobackslash -novariable $modStr]]
}

urlDecode "http%3A%2F%2Ffoo%20bar%2F"  ;# http://foo bar/
```

## -command: Berechnete Ersetzung (Tcl 9 / ab 8.7)

Mit `-command` wird SUBSPEC als Befehl behandelt. Der Befehl erhält den Treffer
als Argument (und bei Capturing-Gruppen zusätzliche Argumente) und sein Rückgabewert
wird als Ersetzung verwendet.

```tcl
# URL-Encoding: Nicht-alphanumerische Zeichen -> %XX
proc enc {ch} { format %%%02X [scan $ch %c] }
regsub -command -all {[^0-9A-Za-z]} "some-random+string" enc
;# some%2Drandom%2Bstring
```

### Weitere -command-Beispiele

Ersten Buchstaben nach Satzzeichen grossschreiben:

```tcl
set text "First sentence. second sentence? third sentence."
regsub -command -all {([.!?])\s+(.)} $text {
    apply {{- punc ch} {return "$punc [string toupper $ch]"}}
}
;# First sentence. Second sentence? Third sentence.
```

Markdown-Überschriften nach HTML konvertieren:

```tcl
proc md2html {- level text} {
    set h h[string length $level]
    return "<$h>$text</$h>"
}

set mdLine "# First level heading\n## A second level heading"
regsub -all -line -command {^(#+)\s+(.*)$} $mdLine md2html
;# <h1>First level heading</h1>
;# <h2>A second level heading</h2>
```

## Metazeichen in Literalen escapen

Wenn ein Literal als Teil eines grösseren RE-Ausdrucks verwendet wird, müssen
Metazeichen escaped werden:

```tcl
regsub -all {[][*+?{}()<>|.^$\\]} $literal_string {\\&} escaped
```

## Beispiele

### Whitespace normalisieren

```tcl
regsub -all {\s+} $text " " normalized
```

### Kommentare entfernen

```tcl
regsub -all {#[^\n]*} $code "" stripped
```

### Namensformat umkehren

```tcl
regsub {(\w+) (\w+)} "John Doe" {\2, \1} result
;# Doe, John
```

### HTML-Tags entfernen

```tcl
regsub -all {<[^>]+>} $html "" text
```

## Siehe auch

- **regexp** -- Pattern-Matching und Treffer-Extraktion
- **string map** -- Einfache Zeichenersetzung ohne RE
- **Tcl/Tk Manual:** https://www.tcl-lang.org/man/tcl8.6/TclCmd/regsub.html
