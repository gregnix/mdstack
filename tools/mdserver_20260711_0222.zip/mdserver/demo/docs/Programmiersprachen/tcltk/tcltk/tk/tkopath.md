# tko::path -- SVG-Canvas für Tcl/Tk

*Stand: 2026-04-29*

Umfassende deutsche Referenz für `tko::path` (tko-Paket, tkpath-Erweiterung).

## Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Installation](#installation)
3. [Widget erstellen](#widget-erstellen)
4. [Unterschiede zu tk::canvas](#unterschiede-zu-tkcanvas)
5. [Item-Typen](#item-typen)
6. [Gemeinsame Item-Optionen](#gemeinsame-item-optionen)
7. [Styles](#styles)
8. [Gradienten](#gradienten)
9. [Transformationen (Matrix)](#transformationen-matrix)
10. [Antialiasing](#antialiasing)
11. [PDF-Export mit pdf4tcl](#pdf-export-mit-pdf4tcl)
12. [Fontsize: Pixel vs. Points](#fontsize-pixel-vs-points)
13. [Bekannte Probleme](#bekannte-probleme)
14. [Vollständige Beispiele](#vollständige-beispiele)
15. [Siehe auch](#siehe-auch)

---

## Überblick

`tko::path` ist ein erweitertes Canvas-Widget das SVG-Grafik-Primitiven
direkt in Tk implementiert. Es erweitert `tk::canvas` um:

- **Antialiasing** -- glatte Kanten (cairo auf Linux, GDI+ auf Windows)
- **Opacity** -- Transparenz für Füllung und Rahmen
- **SVG-Pfade** -- vollständige `M L C Q A Z`-Syntax
- **Gradienten** -- linear und radial, benannte Objekte
- **Styles** -- wiederverwendbare Darstellungsstile
- **Affine Transformationen** -- Matrix pro Item
- **Baumstruktur** -- Items können in Gruppen verschachtelt werden

`tko::path` ist Teil des `tko`-Pakets (OO-Erweiterung für Tk), das
auf dem originalen `tkpath`-Paket von Mats Bengtsson basiert.

**Wichtig:** `tko::path` ist ein Drop-in für `tk::canvas` -- die meisten
`canvas`-Befehle funktionieren identisch. Nur die Item-Namen weichen ab.

---

## Installation

```tcl
# Verfügbarkeit prüfen
if {[catch {package require tko} err]} {
    puts "tko nicht verfügbar: $err"
    # Fallback auf tk::canvas
}

# Antialiasing einschalten (empfohlen)
catch { set ::path::antialias 1 }
```

**Bezugsquellen:**
- fossil-Repository: `chiselapp.com/user/rene/repository/tkpath`
- AndroWish enthält eine aktuelle Version
- Debian/Ubuntu: `apt install tko` (falls verfügbar)

---

## Widget erstellen

```tcl
package require tko
catch { set ::path::antialias 1 }   ;# Antialiasing einschalten

# Erstellen -- identisch zu canvas
tko::path .p -width 500 -height 400 -background white
pack .p

# Alle Standard-Canvas-Optionen funktionieren:
# -width -height -background -relief -borderwidth
# -xscrollcommand -yscrollcommand -scrollregion
```

---

## Unterschiede zu tk::canvas

### Item-Namen (umbenannt gegenüber tkpath 0.2)

| tk::canvas | tko::path | Koordinaten | Hinweis |
|------------|-----------|-------------|---------|
| `rectangle x1 y1 x2 y2` | `rect x1 y1 x2 y2` | Bounding Box | tko: `-rx`/`-ry` für abgerundete Ecken |
| `oval x1 y1 x2 y2` | `circle cx cy -r R` | Mittelpunkt + Radius | tko: kein Bounding-Box-Argument |
| `oval x1 y1 x2 y2` | `ellipse cx cy -rx Rx -ry Ry` | Mittelpunkt + Radien | tko only |
| `line x1 y1 x2 y2` | `line x1 y1 x2 y2` | gleich | tko: `-stroke` statt `-fill` |
| `polygon x y ...` | `polygon x y ...` | gleich | oder `path` für SVG-Syntax |
| `arc` (begrenzt) | `path M ... A ... Z` | SVG | tko: volle SVG-Bogensyntax |
| `text x y` | `text x y` | gleich | tko: `-fontsize` statt `-font` |
| `image x y` | `image x y` | gleich | gleiche Anchor-Logik |
| (kein Äquivalent) | `path pathSpec` | SVG M L C Q A Z | tko only |
| (kein Äquivalent) | `group` | keine Coords | Gruppencontainer |

### Farb-Optionen (anders als canvas)

| tk::canvas | tko::path |
|------------|-----------|
| `-fill color` | `-fill color` (Füllung) |
| `-outline color` | `-stroke color` |
| `-width N` | `-strokewidth N` |
| `-dash pattern` | `-strokedasharray pattern` |
| (nicht vorhanden) | `-fillopacity 0.0..1.0` |
| (nicht vorhanden) | `-strokeopacity 0.0..1.0` |

---

## Item-Typen

### rect -- Rechteck

```tcl
# Einfaches Rechteck (wie canvas rectangle)
.p create rect x1 y1 x2 y2 ?-rx value? ?-ry value? ?optionen?

# Ohne abgerundete Ecken
.p create rect 10 10 200 100 \
    -fill "#b3d1f0" -stroke "#0055aa" -strokewidth 2

# Mit abgerundeten Ecken
.p create rect 10 10 200 100 -rx 12 \
    -fill "#ffe066" -stroke "#cc8800" -strokewidth 2

# Nur Rahmen, gestrichelt
.p create rect 10 10 200 100 \
    -fill "" -stroke "#cc3300" -strokewidth 2 \
    -strokedasharray {8 4}
```

**Spezifische Optionen:**

| Option | Beschreibung |
|--------|--------------|
| `-rx value` | Eckradius X (oder einheitlicher Radius wenn -ry fehlt) |
| `-ry value` | Eckradius Y |

### circle -- Kreis

```tcl
# Wichtig: Koordinaten sind Mittelpunkt + Radius als Option
.p create circle cx cy -r radius ?optionen?

# Gefüllter Kreis
.p create circle 100 100 -r 50 \
    -fill "#ffcccc" -stroke "#cc0000" -strokewidth 2

# Nur Rahmen
.p create circle 200 100 -r 50 \
    -fill "" -stroke "#0000cc" -strokewidth 2

# Mit Transparenz
.p create circle 150 100 -r 50 \
    -fill "#006600" -fillopacity 0.5 -stroke "" -strokewidth 0
```

**Achtung:** Im Gegensatz zu `tk::canvas oval` nimmt `circle` den
Mittelpunkt `cx cy` und den Radius als `-r`-Option, keine Bounding-Box.

### ellipse -- Ellipse

```tcl
.p create ellipse cx cy ?-rx value? ?-ry value? ?optionen?

.p create ellipse 200 100 -rx 80 -ry 40 \
    -fill "#ccffcc" -stroke "#006600" -strokewidth 1.5
```

### line -- Linie

```tcl
.p create line x1 y1 x2 y2 ?optionen?

# Einfache Linie
.p create line 10 50 300 50 -stroke black -strokewidth 2

# Gestrichelt
.p create line 10 70 300 70 -stroke "#0055aa" -strokewidth 2 \
    -strokedasharray {8 3}

# Mit Pfeilspitzen
.p create line 10 90 300 90 -stroke "#cc3300" -strokewidth 2 \
    -endarrow 1 -startarrow 1
```

**Hinweis:** Bei `line` ist `-stroke` die Farbe (nicht `-fill` wie bei canvas).

### polyline -- Mehrsegment-Linie (offen)

```tcl
.p create polyline x1 y1 x2 y2 x3 y3 ... ?optionen?

.p create polyline 10 100 100 20 200 100 300 20 \
    -stroke "#006600" -strokewidth 2
```

### polygon -- Geschlossenes Polygon

```tcl
.p create polygon x1 y1 x2 y2 x3 y3 ... ?optionen?

# Dreieck
.p create polygon 50 100 100 20 150 100 \
    -fill "#ddeeff" -stroke "#003399" -strokewidth 2

# Stern (viele Punkte)
set pts {}
set cx 200; set cy 150
for {set i 0} {$i < 10} {incr i} {
    set r [expr {($i%2) ? 25 : 55}]
    set a [expr {-3.14159/2.0 + $i*3.14159/5.0}]
    lappend pts [expr {$cx + $r*cos($a)}] [expr {$cy + $r*sin($a)}]
}
.p create polygon {*}$pts -fill "#ffe066" -stroke "#cc8800" -strokewidth 2
```

### path -- SVG-Pfad

Das mächtigste Item -- implementiert die vollständige SVG-Pfad-Syntax:

```tcl
.p create path pathSpec ?optionen?

# Wichtig: pathSpec muss als einzelne Liste übergeben werden
.p create path {M 10 10 L 100 10 L 100 100 Z} -fill "#b3d1f0"

# Bezier-Kurve
.p create path {M 50 200 C 100 100 200 100 250 200} \
    -fill "" -stroke "#cc6600" -strokewidth 2.5

# Elliptischer Bogen
.p create path {M 50 100 A 80 50 0 0 1 250 100} \
    -fill "#cceeff" -stroke "#006699" -strokewidth 2
```

**SVG-Pfad-Befehle:**

| Befehl | Bedeutung |
|--------|-----------|
| `M x y` | Move to (Stift abheben) |
| `L x y` | Line to (gerade Linie) |
| `H x` | Horizontale Linie |
| `V y` | Vertikale Linie |
| `C x1 y1 x2 y2 x y` | Kubische Bezier-Kurve |
| `S x2 y2 x y` | Glatte kubische Bezier-Kurve |
| `Q x1 y1 x y` | Quadratische Bezier-Kurve |
| `T x y` | Glatte quadratische Bezier-Kurve |
| `A rx ry phi large sweep x y` | Elliptischer Bogen |
| `Z` | Pfad schließen |

Kleinbuchstaben = relative Koordinaten (z.B. `l dx dy` statt `L x y`).

**Hilfsfunktionen für Pfaddaten:**

```tcl
# Kreis als Pfad
set spec [path::path circle $cx $cy $r]

# Ellipse als Pfad
set spec [path::path ellipse $cx $cy $rx $ry]
```

### text -- Text

```tcl
.p create text x y ?optionen?

# Standard
.p create text 100 50 -text "Hallo Welt" \
    -fontsize 14 -fill "#1a3f7a" -textanchor start

# Zentriert
.p create text 250 50 -text "Zentriert" \
    -fontsize 14 -fill black -textanchor middle

# Fett + kursiv
.p create text 100 80 -text "Fett kursiv" \
    -fontsize 12 \
    -fontweight bold \
    -fontslant italic \
    -fill "#cc3300" -textanchor start

# Courier
.p create text 100 110 -text "Monospace" \
    -fontsize 12 -fontfamily Courier -textanchor start
```

**Text-Optionen:**

| Option | Werte | Beschreibung |
|--------|-------|--------------|
| `-text string` | | Anzuzeigender Text |
| `-fontsize float` | | Schriftgröße in **Pixel** (nicht Points!) |
| `-fontfamily name` | | Schriftfamilie (z.B. Helvetica, Courier) |
| `-fontweight` | normal, bold | Schriftstärke |
| `-fontslant` | normal, italic, oblique | Kursiv |
| `-textanchor` | start, middle, end, n, s, e, w, nw, ... | Ausrichtung |
| `-filloverstroke` | boolean | Füllung über Rahmen zeichnen |

**Wichtig:** `-fontsize` ist in **Pixel**, pdf4tcl `setFont` ist in **Points**.
Konversion bei 96 dpi: `points = pixels * 0.75`

### image -- Bild

```tcl
.p create image x y -image photoImage ?optionen?

set img [image create photo -file bild.png]
.p create image 50 50 -image $img -anchor nw

# Skaliert
.p create image 50 50 -image $img -width 200 -height 150
```

### group -- Gruppe

Gruppen sind unsichtbare Container für andere Items. Optionen die
auf eine Gruppe gesetzt werden, werden an Kinder vererbt (sofern
die Kinder die Option nicht selbst setzen).

```tcl
# Gruppe erstellen
set grp [.p create group]

# Items in der Gruppe
.p create rect 10 10 100 60 -parent $grp -fill "#b3d1f0"
.p create text 55 35 -text "In Gruppe" -parent $grp -textanchor middle

# Gruppe verschieben (alle Kinder folgen)
.p move $grp 50 50

# Gruppe mit gemeinsamer Farbe
set grp2 [.p create group -fill "#cc3300" -stroke "#660000"]
.p create rect 10 10 80 80 -parent $grp2   ;# erbt -fill und -stroke
.p create circle 120 45 -r 30 -parent $grp2
```

---

## Gemeinsame Item-Optionen

Alle Items (außer `group`) unterstützen diese Optionen:

**Füllung:**

| Option | Beschreibung |
|--------|--------------|
| `-fill color\|gradientToken` | Füllfarbe oder Gradient |
| `-fillopacity 0.0..1.0` | Transparenz der Füllung |
| `-fillrule nonzero\|evenodd` | Füllregel für komplexe Pfade |

**Rahmen:**

| Option | Beschreibung |
|--------|--------------|
| `-stroke color` | Rahmenfarbe |
| `-strokewidth float` | Rahmenbreite |
| `-strokeopacity 0.0..1.0` | Transparenz des Rahmens |
| `-strokedasharray liste` | Strichmuster (Liste von Pixel-Längen) |
| `-strokelinecap butt\|round\|square` | Linienenden |
| `-strokelinejoin miter\|round\|bevel` | Eckenverbindung |

**Allgemein:**

| Option | Beschreibung |
|--------|--------------|
| `-matrix {a b c d tx ty}` | Affine Transformation |
| `-parent tagOrId` | Eltern-Gruppe |
| `-state normal\|disabled\|hidden` | Sichtbarkeit |
| `-style styleToken` | Benannter Stil |
| `-tags tagListe` | Tags zuweisen |

**Pfeile** (nur für `line`, `polyline`, `path`):

| Option | Beschreibung |
|--------|--------------|
| `-startarrow boolean` | Pfeil am Anfang |
| `-endarrow boolean` | Pfeil am Ende |
| `-startarrowlength float` | Länge des Pfeils |
| `-endarrowwidth float` | Breite des Pfeils |

---

## Styles

Styles sind benannte, wiederverwendbare Darstellungsstile.
Sie werden global (für den ganzen Canvas) oder pro Canvas-Instanz definiert.

```tcl
# Globalen Stil erstellen
set s1 [tko::path::style create \
    -fill "#b3d1f0" \
    -stroke "#0055aa" \
    -strokewidth 2]

# Instanz-Stil (nur für diesen Canvas)
set s2 [.p style create \
    -fill "#ffe066" \
    -stroke "#cc8800" \
    -strokewidth 1.5]

# Stil anwenden
.p create rect 10 10 150 80 -style $s1
.p create circle 200 45 -r 35 -style $s2

# Stil nachträglich ändern -- alle Items mit diesem Stil aktualisieren sich
tko::path::style configure $s1 -fill "#d0e8ff"

# Aufräumen
tko::path::style delete $s1
```

---

## Gradienten

Gradienten sind benannte Objekte die als Füllfarbe verwendet werden.

### Linearer Gradient

```tcl
# Global
set lg [tko::path::gradient create linear \
    -stops {{0 "#ff6666"} {0.5 "#ffff66"} {1 "#66ff66"}}]

# Vertikal (von oben nach unten)
set lg_v [tko::path::gradient create linear \
    -lineartransition {0 0 0 1} \
    -stops {{0 "#ffffff"} {1 "#003399"}}]

# Diagonal
set lg_d [.p gradient create linear \
    -lineartransition {0 0 1 1} \
    -stops {{0 "#0055aa"} {1 "#aaddff"}}]

# Gradient verwenden
.p create rect 10 10 300 100 -fill $lg
.p create rect 10 120 300 210 -fill $lg_v
```

**Gradient-Optionen (linear):**

| Option | Beschreibung |
|--------|--------------|
| `-stops {offset color ?opacity?} ...` | Farbstopps (offset 0.0..1.0) |
| `-lineartransition {x1 y1 x2 y2}` | Richtungsvektor (bbox-relativ 0..1) |
| `-units bbox\|userspace` | Koordinatensystem der Transition |
| `-method pad\|repeat\|reflect` | Verhalten außerhalb des Bereichs |

### Radialer Gradient

```tcl
set rg [tko::path::gradient create radial \
    -stops {{0 "#ffffff"} {0.5 "#4488ff"} {1 "#001166"}}]

# Mittelpunkt und Radius anpassen
set rg2 [tko::path::gradient create radial \
    -radialtransition {0.3 0.3 0.7 0.5 0.5} \
    -stops {{0 "#ffffff"} {1 "#cc3300"}}]

.p create circle 150 150 -r 100 -fill $rg
```

**Gradient-Optionen (radial):**

| Option | Beschreibung |
|--------|--------------|
| `-radialtransition {cx cy r fx fy}` | Kreismittelpunkt, Radius, Fokuspunkt |

---

## Transformationen (Matrix)

Jedes Item kann eine affine Transformation tragen.
`tko::matrix`-Hilfsfunktionen erzeugen fertige Matrix-Listen:

```tcl
# Rotation um Mittelpunkt (cx, cy)
.p create rect 100 100 200 150 \
    -matrix [tko::matrix rotate 30 150 125]

# Skalierung
.p create circle 200 200 -r 50 \
    -matrix [tko::matrix scale 1.5 0.8]

# Verschiebung
.p create text 0 0 -text "Verschoben" \
    -matrix [tko::matrix move 100 50]

# Scherung in X-Richtung
.p create rect 10 10 100 60 \
    -matrix [tko::matrix skewx 20]

# Kombination: zuerst rotieren, dann verschieben
set m [tko::matrix mult \
    [tko::matrix rotate 45] \
    [tko::matrix move 200 200]]
.p create rect -40 -20 40 20 -matrix $m
```

**tko::matrix-Funktionen:**

| Funktion | Beschreibung |
|----------|--------------|
| `tko::matrix rotate angle ?cx cy?` | Rotation um cx/cy (Standard: 0 0) |
| `tko::matrix scale sx ?sy?` | Skalierung (sy = sx wenn weggelassen) |
| `tko::matrix move dx dy` | Translation |
| `tko::matrix skewx angle` | Scherung in X |
| `tko::matrix skewy angle` | Scherung in Y |
| `tko::matrix flip ?cx cy fx fy?` | Spiegelung |
| `tko::matrix mult ma mb` | Matrizenmultiplikation |

**Direkte Matrix-Syntax** `{a b c d tx ty}`:

```tcl
# Identität
set m {1 0 0 1 0 0}

# Skalierung 2x
set m {2 0 0 2 0 0}

# Rotation um 45 Grad
set a [expr {3.14159/4.0}]
set m [list [expr {cos($a)}] [expr {sin($a)}] \
           [expr {-sin($a)}] [expr {cos($a)}] 0 0]
```

---

## Antialiasing

```tcl
# Einschalten (cairo-Backend auf Linux, GDI+ auf Windows)
set ::path::antialias 1

# Ausschalten
set ::path::antialias 0

# Pixel-Alignment (verhindert verschwommene 1px-Linien)
# Gibt an ob cairo/GDI+ Integer-Koordinaten auf Pixel-Grenzen setzt
set info [path::pixelalign]

# Depixelize: automatische Korrektur für Integer-Linienbreiten
set ::path::depixelize 1
```

**Hinweis:** Antialiasing ist ein **Screen-Feature** -- es beeinflusst
den PDF-Export nicht. PDFs sind immer Vektoren und werden vom
PDF-Viewer mit dessen eigenem Antialiasing gerendert.

---

## PDF-Export mit pdf4tcl

**Wichtig:** Für `tko::path` MUSS die `-bbox`-Option angegeben werden:

```tcl
# Standard canvas -- ohne -bbox
$pdf canvas .canvas_widget -x X -y Y -width W -height H

# tko::path -- -bbox all PFLICHT
$pdf canvas .path_widget -bbox [.path_widget bbox all] -x X -y Y -width W -height H
```

Ohne `-bbox` weiß pdf4tcl nicht welche Items existieren und der
Export ist leer oder unvollständig.

### Vollständiges Export-Beispiel

```tcl
package require tko
package require pdf4tcl
catch { set ::path::antialias 1 }

# Widget aufbauen
tko::path .p -width 400 -height 300 -background white
pack .p

.p create rect 20 20 180 100 -rx 8 \
    -fill "#b3d1f0" -stroke "#0055aa" -strokewidth 2
.p create circle 250 60 -r 40 \
    -fill "#ffcccc" -stroke "#cc0000" -strokewidth 2
.p create path {M 20 150 C 100 100 300 200 380 150} \
    -fill "" -stroke "#006600" -strokewidth 2.5
.p create text 200 250 -text "tko::path -> PDF" \
    -fontsize 16 -fill "#1a3f7a" -textanchor middle

update

# PDF erzeugen
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

$pdf canvas .p \
    -bbox [.p bbox all] \
    -x 50 -y 50 \
    -width 400 -height 300

$pdf endPage
$pdf write -file output.pdf
$pdf destroy
```

### Was exportiert wird

| Item | Exportiert via -bbox? |
|------|-----------------------|
| `rect` | Ja |
| `circle` | Ja (via itempdf) |
| `ellipse` | Ja (via itempdf) |
| `line` | Ja |
| `polyline` | Ja |
| `polygon` | Ja |
| `path` (SVG) | Ja (via itempdf) |
| `text` | Ja |
| `image` | Ja (Bitmap) |
| `-fill gradient` | Nein (Screen only) |
| `-fillopacity` | Nein (Screen only) -- wird solid gerendert |

### tkoToPdf-Hilfsproc

Für temporäre Canvas (nicht dauerhaft sichtbar):

```tcl
proc tkoToPdf {pdf x y w h drawScript} {
    # Fenster weit außerhalb des Bildschirms positionieren
    toplevel .tmp
    wm geometry .tmp "${w}x${h}+2000+2000"
    tko::path .tmp.p -width $w -height $h -background white
    pack .tmp.p -fill both -expand 1
    uplevel 1 $drawScript
    update
    # -bbox all ist Pflicht
    $pdf canvas .tmp.p -bbox [.tmp.p bbox all] -x $x -y $y -width $w -height $h
    destroy .tmp
}

# Verwendung
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

tkoToPdf $pdf 50 50 400 300 {
    .tmp.p create rect 10 10 200 100 -rx 8 \
        -fill "#b3d1f0" -stroke "#0055aa" -strokewidth 2
    .tmp.p create circle 250 60 -r 40 \
        -fill "#ffcccc" -stroke "#cc0000" -strokewidth 2
}

$pdf endPage
$pdf write -file output.pdf
$pdf destroy
```

---

## Fontsize: Pixel vs. Points

`tko::path` verwendet `-fontsize` in **Pixel**.
`pdf4tcl` verwendet `setFont` in **Points**.

Bei 96 dpi Bildschirmauflösung:

```
points = pixels × 0.75
pixels = points / 0.75
```

```tcl
proc px2pt {px} { expr {$px * 0.75} }
proc pt2px {pt} { expr {$pt / 0.75} }

# Für 12pt-Text in tko::path:
set fontSizePx [expr {int([pt2px 12])}]   ;# = 16
.p create text 10 30 -text "Hallo" -fontsize $fontSizePx

# Konversionstabelle:
# 8px  ->  6pt    10px ->  7.5pt   12px ->  9pt    14px -> 10.5pt
# 16px -> 12pt    20px -> 15pt     24px -> 18pt    32px -> 24pt
```

---

## Bekannte Probleme

### circle: falsche Syntax

```tcl
# FALSCH -- dritter Positionsargument nicht erlaubt
.p create circle 100 100 50

# RICHTIG -- Radius als Option
.p create circle 100 100 -r 50
```

### path: Kommas nicht erlaubt

```tcl
# FALSCH -- SVG-Standard erlaubt Kommas, tko::path nicht
.p create path {M 10,10 L 100,50}

# RICHTIG -- nur Leerzeichen als Trenner
.p create path {M 10 10 L 100 50}
```

### pack -relief funktioniert nicht

```tcl
# FALSCH
pack .p -relief sunken -borderwidth 1

# RICHTIG
.p configure -relief sunken -borderwidth 1
pack .p
```

### PDF-Export leer ohne -bbox

```tcl
# FALSCH -- Items fehlen im PDF
$pdf canvas .p -x 50 -y 50 -width 400 -height 300

# RICHTIG
$pdf canvas .p -bbox [.p bbox all] -x 50 -y 50 -width 400 -height 300
```

### Gradient im PDF

Gradienten werden im PDF-Export nicht übertragen -- das Item wird
mit der Fallback-Farbe (Schwarz oder Weiß) gerendert. Für PDF-Gradienten
`pdf4tcllib::drawing::gradient_v` oder `gradient_h` verwenden.

---

## Vollständige Beispiele

### Beispiel 1: Alle Item-Typen

```tcl
package require tko
catch { set ::path::antialias 1 }

tko::path .p -width 600 -height 500 -background white
pack .p

# rect
.p create rect 10 10 150 80 -rx 8 \
    -fill "#b3d1f0" -stroke "#0055aa" -strokewidth 2

# circle
.p create circle 220 45 -r 35 \
    -fill "#ffcccc" -stroke "#cc0000" -strokewidth 2

# ellipse
.p create ellipse 370 45 -rx 70 -ry 30 \
    -fill "#ccffcc" -stroke "#006600" -strokewidth 2

# line mit Pfeil
.p create line 10 120 300 120 \
    -stroke "#333333" -strokewidth 2 -endarrow 1

# SVG path (Stern)
set cx 100; set cy 220
set pts "M"
for {set i 0} {$i < 10} {incr i} {
    set r [expr {($i%2) ? 20 : 50}]
    set a [expr {-3.14159/2.0 + $i*3.14159/5.0}]
    if {$i==0} {append pts " [expr {$cx+$r*cos($a)}] [expr {$cy+$r*sin($a)}]"} \
    else        {append pts " L [expr {$cx+$r*cos($a)}] [expr {$cy+$r*sin($a)}]"}
}
append pts " Z"
.p create path $pts -fill "#ffe066" -stroke "#cc8800" -strokewidth 2

# Opacity
foreach {cx col} {300 "#cc3300" 360 "#0055aa" 330 "#006600"} {
    .p create circle $cx 220 -r 35 \
        -fill $col -fillopacity 0.5 -stroke "" -strokewidth 0
}

# text
.p create text 10 320 -text "Normal" \
    -fontsize 14 -fill black -textanchor start
.p create text 130 320 -text "Fett" \
    -fontsize 14 -fontweight bold -fill "#003399" -textanchor start
.p create text 240 320 -text "Kursiv" \
    -fontsize 14 -fontslant italic -fill "#cc3300" -textanchor start

# Matrix-Transform
.p create rect 10 360 120 420 \
    -fill "#e8f0ff" -stroke "#336699" -strokewidth 1.5 \
    -matrix [tko::matrix rotate 15 65 390]
```

### Beispiel 2: Interaktiver Canvas mit Drag

```tcl
package require tko
catch { set ::path::antialias 1 }

tko::path .p -width 500 -height 400 -background "#f8f8f8"
pack .p

# Draggable Items erstellen
foreach {x y col} {50 80 "#4285f4"  180 80 "#ea4335"  310 80 "#34a853"} {
    .p create circle $x $y -r 35 -fill $col -fillopacity 0.8 \
        -stroke white -strokewidth 2 -tags draggable
}

# Drag-Handling
set drag(active) 0

.p bind draggable <ButtonPress-1> {
    set drag(active) 1
    set drag(item) [%W find withtag current]
    set drag(x) [%W canvasx %x]
    set drag(y) [%W canvasy %y]
}

.p bind draggable <B1-Motion> {
    if {!$drag(active)} return
    set dx [expr {[%W canvasx %x] - $drag(x)}]
    set dy [expr {[%W canvasy %y] - $drag(y)}]
    %W move $drag(item) $dx $dy
    set drag(x) [%W canvasx %x]
    set drag(y) [%W canvasy %y]
}

.p bind draggable <ButtonRelease-1> {
    set drag(active) 0
}
```

### Beispiel 3: Gradient-Füllung

```tcl
package require tko
catch { set ::path::antialias 1 }

tko::path .p -width 500 -height 300 -background white
pack .p

# Horizontaler Farbverlauf
set lg [.p gradient create linear \
    -stops {{0 "#ff6666"} {0.5 "#ffff66"} {1 "#66ff66"}}]
.p create rect 10 10 490 80 -fill $lg -stroke "#888888" -strokewidth 1

# Radialer Gradient
set rg [.p gradient create radial \
    -stops {{0 "#ffffff"} {0.4 "#4488ff"} {1 "#001166"}}]
.p create circle 150 200 -r 80 -fill $rg -stroke "#003399" -strokewidth 1

# Diagonal
set lg2 [.p gradient create linear \
    -lineartransition {0 0 1 1} \
    -stops {{0 "#ffe066"} {1 "#cc6600"}}]
.p create rect 280 120 490 280 -rx 15 \
    -fill $lg2 -stroke "#996600" -strokewidth 2
```

---

## Siehe auch

- [canvas.md](canvas.md) - tk::canvas Referenzhandbuch
- **tko-Repository:** `chiselapp.com/user/rene/repository/tkpath`
- **SVG-Pfad-Syntax:** https://www.w3.org/TR/SVG11/paths.html
- **pdf4tcl:** https://sourceforge.net/projects/pdf4tcl/
