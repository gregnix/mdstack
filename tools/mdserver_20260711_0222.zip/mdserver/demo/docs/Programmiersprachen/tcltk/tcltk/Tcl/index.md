# Tcl/Tk Wissensbasis

*Stand: 2026-04-29*

Willkommen zur integrierten Dokumentation.

## Kategorien

### Knownhow (Tcl/Tk Referenz)

Die komplette Tcl/Tk Wissensbasis mit 192 Artikeln zu:

- Grundlagen (Variablen, Listen, Dicts)
- Tk Widgets (Canvas, Text, Tablelist)
- TclOO (Objektorientierung)
- Patterns (Action, Observer, Factory)
- Datenbanken (TDBC, SQLite)
- Und vieles mehr...

Siehe: [Knownhow Index](knownhow/INDEX.md)

### Tcl Code-Organisation

14 ausführliche technische Referenzen (~8900 Zeilen) zu
Strukturierung, Modularisierung und Ausführung von Tcl-Code.

**Namespaces und Module**

- [namespace.md](code-organisation/namespace.md) -- Kapselung, Hierarchie, variable, export/import, code/inscope, path, which, origin
- [namespace-ensemble.md](code-organisation/namespace-ensemble.md) -- Unterbefehle, Map, Prefix-Matching, -unknown, -parameters, verschachtelt, exists
- [package.md](code-organisation/package.md) -- provide/require/ifneeded, Versionierung, pkgIndex.tcl, auto_path, prefer/forget/unknown
- [tm-module.md](code-organisation/tm-module.md) -- Dateinamen-Konvention, :: zu Verzeichnisse, tcl::tm::path, Dispatcher-Pattern

**Prozeduren und Scope**

- [proc.md](code-organisation/proc.md) -- Parameter, Defaults, args, return -code, tailcall, rename, verbotene Namen
- [variable-scope.md](code-organisation/variable-scope.md) -- global, variable, upvar, uplevel, apply, namespace upvar, Scope-Fallen

**Objektorientierung**

- [tcloo.md](code-organisation/tcloo.md) -- Klassen, constructor/destructor, self/my, Vererbung, Mixins, Filter, Forward, Patterns

**Introspektion und Laufzeit**

- [info.md](code-organisation/info.md) -- commands/procs, body/args/default, exists/vars/globals/locals, level/frame, script, patchlevel, object/class
- [interp.md](code-organisation/interp.md) -- Kind-Interpreter, Aliase, Safe-Interpreter, Limits, versteckte Befehle

**Ausführung und Fehlerbehandlung**

- [source-eval-apply.md](code-organisation/source-eval-apply.md) -- source, eval vs. {*}, apply, uplevel, Command-Prefix, Sicherheit
- [error-handling.md](code-organisation/error-handling.md) -- Return-Codes, catch, try/on/trap/finally, error/throw, return -code, Weiterleitung
- [trace.md](code-organisation/trace.md) -- Variable-Traces, Command-Traces, Execution-Traces, Anwendungen
- [metaprogramming.md](code-organisation/metaprogramming.md) -- Command-Prefix vs. Script, Code-Konstruktion, Templates, Metaprogramming-Muster

**Globalisierung**

- [globalization.md](code-organisation/globalization.md) -- encoding convertto/convertfrom, Profile, msgcat-Lokalisierung, Locales, Katalogdateien, IDNA

### KI-Assistenten

Anleitungen für die Arbeit mit KI-Tools:

- [Claude Tcl/Tk Wissen](ki-ai/CLAUDE-TCL-TK-WISSEN.md)
- [Claude FAQ](ki-ai/CLAUDE-TCL-TK-FAQ.md)
- [ChatGPT Tcl/Tk](ki-ai/Chatgpt-TclTk.md)
- [Cursor Tcl/Tk](ki-ai/Cursor-TclTk.md)

## Schnelleinstieg

### Häufige Themen

- [Event Loop](knownhow/event-loop.md)
- [TDBC Grundlagen](knownhow/tdbc-grundlagen.md)
- [Tablelist Grundlagen](knownhow/tablelist-grundlagen.md)
- [TclOO Vollständig](knownhow/tcloo-vollständig.md)
- [Action Pattern](knownhow/action-pattern-tcl.md)
- [Namespace Vollständig](knownhow/namespace-vollständig.md)


<!-- mdindexgen:begin -->
## Inhalt

 - [Fehlerbehandlung und Exceptions](error-handling.md)
 - [exec und open -- Prozesse und Pipelines in Tcl](exec-und-open.md)
 - [Globalisierung: Encoding, Lokalisierung, IDNA](globalization.md)
 - [Der info-Befehl](info.md)
 - [Interpreter (interp)](interp.md)
 - [Metaprogramming und Code-Konstruktion](metaprogramming.md)
 - [Namespace Ensemble](namespace-ensemble.md)
 - [Namespace](namespace.md)
 - [Package](package.md)
 - [Prozeduren (proc)](proc.md)
 - [Reguläre Ausdrücke in Tcl -- regexp, regsub, re_syntax](regexp-und-regsub.md)
 - [Code laden und ausführen: source, eval, apply](source-eval-apply.md)
 - [Tcl Standalone-Binaries: Starkits und Starpacks](starpack-grundlagen.md)
 - [Das String-Modell -- Tcl verstehen](string-modell.md)
 - [Substitution und Escaping](substitution-escaping.md)
 - [TclOO](tcloo.md)
 - [TDBC -- Tcl Database Connectivity](tdbc.md)
 - [Tcl Module (.tm)](tm-module.md)
 - [Traces](trace.md)
 - [Variable Scope](variable-scope.md)
 - [Tcl 9 Deployment: Zipkits, ZipFS und BAWT](zipkit-deployment.md)
<!-- mdindexgen:end -->
