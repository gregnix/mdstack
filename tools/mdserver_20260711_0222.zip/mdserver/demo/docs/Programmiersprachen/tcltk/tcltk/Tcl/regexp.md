# regexp - Regular Expressions

*Stand: 2026-04-29*

`regexp` prüft ob ein String auf ein Regular-Expression-Pattern passt und extrahiert
optional Treffer. Tcl unterstützt drei RE-Formen (Basic, Extended, Advanced); hier
wird ausschliesslich die Advanced-Form beschrieben, die ein Superset der anderen ist.

**Syntax:** `regexp ?optionen? RE STRING ?MATCHVAR MATCHVAR ...?`

**Quelle:** https://www.tcl-lang.org/man/tcl8.6/TclCmd/regexp.html

## Grundprinzip

Ohne Optionen und Variablen gibt `regexp` 1 zurück wenn STRING das Muster RE enthält,
sonst 0. Es reicht, wenn ein Teilstring matched -- es sei denn, man verankert mit `^`/`$`.

```tcl
regexp XY aaXYbb   ;# 1
regexp XY aaYXbb   ;# 0
```

## Zeichen und Klassen

### Metazeichen

Zeichen ohne Sonderbedeutung matchen sich selbst. Backslash-Escapes wie `\n`, `\t`,
`\uhhhh` und `\Uhhhhhhhh` stehen für Sonderzeichen.

```tcl
# Backslash-Verarbeitung: beide Formen aequivalent
regexp "\\t" "abc\tdef"   ;# 1
regexp {\t}  "abc\tdef"   ;# 1
```

### Punkt -- beliebiges Zeichen

`.` matcht genau ein beliebiges Zeichen.

```tcl
regexp X.Y aXcYb   ;# 1
regexp X.Y aXYb    ;# 0  (kein Zeichen zwischen X und Y)
regexp X.Y aXccYb  ;# 0  (zwei Zeichen)
```

### Bracket-Ausdrücke

`[...]` matcht genau eines der enthaltenen Zeichen. Innerhalb von Brackets verlieren
die meisten Metazeichen ihre Sonderbedeutung.

```tcl
regexp {ab[XYZ]cd} abYcd   ;# 1
regexp {ab[XYZ]cd} abQcd   ;# 0
regexp {a[.]c}     a.c     ;# 1  (Punkt ist literal)
regexp {a[.]c}     abc     ;# 0
regexp {[0-9]}     a5c     ;# 1  (Bereich)
regexp {[-0-9]}    a-c     ;# 1  (Minus als erstes Zeichen = literal)
```

### POSIX-Zeichenklassen

Innerhalb von Brackets können benannte Klassen verwendet werden.

```tcl
regexp {[[:digit:]]} a5c       ;# 1
regexp {[[:digit:]]} "a\u0968c" ;# 1  (Devanagari 2 -- nicht nur ASCII)
regexp {[[:alpha:]]} abc       ;# 1
```

Verfügbare Klassen: `[:alnum:]` `[:alpha:]` `[:blank:]` `[:cntrl:]` `[:digit:]`
`[:graph:]` `[:lower:]` `[:print:]` `[:punct:]` `[:space:]` `[:upper:]` `[:xdigit:]`

Mehrere Klassen und Bereiche lassen sich kombinieren:

```tcl
regexp {a[xy[:upper:][:digit:]]b} axb  ;# 1
regexp {a[xy[:upper:][:digit:]]b} a5b  ;# 1
regexp {a[xy[:upper:][:digit:]]b} aqb  ;# 0
```

Mit `^` am Anfang: Negation.

```tcl
regexp {a[^xy[:digit:]]b} aQb  ;# 1
regexp {a[^xy[:digit:]]b} a5b  ;# 0
```

### Kurzformen

```tcl
\d   # [[:digit:]]
\D   # [^[:digit:]]
\s   # [[:space:]]
\S   # [^[:space:]]
\w   # Wortzeichen (alphanumerisch + _)
\W   # Nicht-Wortzeichen
```

`\d`, `\s`, `\w` dürfen innerhalb von Brackets stehen; `\D`, `\S`, `\W` nicht
(stattdessen `^`-Negation verwenden).

```tcl
regexp {a\db}   a5b    ;# 1
regexp {a[\d\s]b} "a\tb" ;# 1
```

## Quantifier

Ein Quantifier folgt einem Atom und gibt die Anzahl der Wiederholungen an.

```tcl
regexp {aX*b}    ab      ;# 1  (0 oder mehr)
regexp {aX+b}    ab      ;# 0  (1 oder mehr)
regexp {aX?b}    ab      ;# 1  (0 oder 1)
regexp {aX?b}    aXXb    ;# 0
regexp aX{2}b    aXXb    ;# 1  (genau 2)
regexp aX{2,}b   aXXXb   ;# 1  (2 oder mehr)
regexp aX{2,4}b  aXXXb   ;# 1  (2 bis 4)
```

### Gier (Greediness)

Standardmässig matchen Quantifier so viel wie möglich. Ein angehängtes `?` macht
sie nicht-gierig (so wenig wie nötig).

```tcl
regexp -inline {^(x+)(.*y)$}  xxyy  ;# xxyy xx yy  (gierig: xx + yy)
regexp -inline {^(x+?)(.*y)$} xxyy  ;# xxyy x xyy  (nicht-gierig: x + xyy)
```

Typischer Anwendungsfall: XML-Tags extrahieren.

```tcl
# Gierig -- matcht bis zum LETZTEN </Item>
regexp {<Item>(.*)</Item>} "<Item>1</Item><Item>2</Item>" - content
set content  ;# 1</Item><Item>2  (falsch)

# Nicht-gierig -- matcht bis zum ERSTEN </Item>
regexp {<Item>(.*?)</Item>} "<Item>1</Item><Item>2</Item>" - content
set content  ;# 1  (korrekt)
```

## Gruppen

### Capturing-Gruppen

`(...)` fasst einen Teilausdruck zusammen und speichert den Treffer für
Back-References und Variablen.

```tcl
regexp {a(XY)+b} aXYXYb  ;# 1
```

### Non-Capturing-Gruppen

`(?:...)` gruppiert ohne zu speichern.

```tcl
regexp {a(?:XY)+b} aXYXYb  ;# 1
```

## Alternation

`|` verbindet Alternativen mit niedriger Priorität -- `apple|banana` ist
gleichwertig zu `(apple)|(banana)`.

```tcl
regexp {Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday} Monday  ;# 1
regexp {(Sun|Mon|Tues|Wednes|Thurs|Fri|Sat)day} Friday                    ;# 1
```

## Anker und Constraints

### ^ und $

`^` verankert am Stringanfang, `$` am Stringende.

```tcl
regexp {^XY} aXY   ;# 0
regexp {^XY} XYb   ;# 1
regexp {XY$} aXY   ;# 1
regexp {^XY$} XY   ;# 1
regexp {^XY$} aXYb ;# 0
```

### Position-Constraints

| Escape | Bedeutung |
|--------|-----------|
| `\A` | Stringanfang (unabhängig von `-line`) |
| `\Z` | Stringende (unabhängig von `-line`) |
| `\m` | Wortanfang |
| `\M` | Wortende |
| `\y` | Wortgrenze (Anfang oder Ende) |
| `\Y` | Nicht an Wortgrenze |

```tcl
regexp {\mX}  "a Xb"  ;# 1  (X steht am Wortanfang)
regexp {\mX}  "aXb"   ;# 0
regexp {X\M}  "aX b"  ;# 1  (X steht am Wortende)
```

### Lookahead

Positive Lookaheads `(?=...)` und negative `(?!...)` matchen ohne Zeichen zu
konsumieren.

```tcl
# Teilnummer: 2-10 Zeichen, Format [A-Z]+[0-9]+
set re {^(?=.{2,10}$)[A-Z]+[0-9]+$}
regexp $re A0          ;# 1
regexp $re ABC2345678  ;# 1
regexp $re 1234567890  ;# 0  (nur Ziffern)
regexp $re ABC12345678 ;# 0  (mehr als 10 Zeichen)
```

### Back-References

`\N` referenziert den Treffer der N-ten Capturing-Gruppe. Damit lassen sich
doppelte Wörter erkennen:

```tcl
regexp {\m(\w+)\s+\1\M} "This sentence has has repeated words."  ;# 1
regexp {\m(\w+)\s+\1\M} "This sentence has no repeated words."   ;# 0
```

## Optionen

### -nocase

Gross-/Kleinschreibung ignorieren.

```tcl
regexp -nocase {xy} aXYb  ;# 1
```

### -all

Zählt alle Treffer im String.

```tcl
regexp -all X+ aXXbXCXXX  ;# 3
```

### -inline

Gibt Treffer als Liste zurück statt in Variablen zu speichern.

```tcl
regexp -inline {(X+)(?:Y+)(Z+)} aXXYYZZZb     ;# XXYYZZZ XX ZZZ
regexp -inline -indices {(X+)(?:Y+)(Z+)} aXXYYZZZb  ;# {1 7} {1 2} {5 7}
```

Mit `-all` werden alle Treffer als flache Liste geliefert:

```tcl
regexp -inline -all {(X+)(?:Y+)(Z+)} aXXYYZZZbXYZ
;# XXYYZZZ XX ZZZ XYZ X Z
```

### -indices

Speichert Start- und Endindex statt Inhalt.

```tcl
regexp -indices {(X+)(?:Y+)(Z+)} aXXYYZZZb match xes zes
;# match={1 7}  xes={1 2}  zes={5 7}
```

### -start OFFSET

Startet die Suche ab Position OFFSET.

```tcl
regexp -inline -all a+ "aaabacaa"          ;# aaa a aa
regexp -start 4 -inline -all a+ "aaabacaa" ;# a aa
```

### -expanded

Whitespace und Kommentare (`#`) im Pattern werden ignoriert -- ermöglicht
lesbare mehrzeilige Patterns.

```tcl
regexp -inline -all -expanded {
    \m          # Wortanfang
    (\w+)\s+    # Wort + Whitespace
    \1          # dasselbe Wort nochmals
    \M          # Wortende
} "This sentence has has repeated words."
;# {has has} has
```

### Zeilensensibler Match: -line, -lineanchor, -linestop

`-lineanchor`: `^` und `$` matchen Zeilenanfang/-ende.
`-linestop`: `.` und `[^...]` matchen keine Newlines.
`-line`: kombiniert beide.

```tcl
set fc "First line\nSecond line with trailing space \nThird line with tab\t"
regexp -all {\s+$} $fc        ;# 1  (nur Dateiende)
regexp -all -line {\s+$} $fc  ;# 2  (alle Zeilen mit trailing whitespace)
```

## Option-Metasyntax

Optionen können in das Pattern eingebettet werden mit `(?OPTS)` am Anfang.

| Eingebettet | Option |
|-------------|--------|
| `(?i)` | `-nocase` |
| `(?c)` | case-sensitiv (Standard) |
| `(?n)` | `-line` |
| `(?p)` | `-linestop` |
| `(?w)` | `-lineanchor` |
| `(?x)` | `-expanded` |

```tcl
regexp {(?i)xy} aXYb         ;# 1
regexp {(?n)\s+$} $fc        ;# Zeilen mit trailing whitespace
```

## Literal-Matching mit `***=`

Wenn der Suchstring Metazeichen enthält, kann er mit `***=` als Literal
gekennzeichnet werden.

```tcl
set s "X."
regexp -all $s aX.bXcX.d       ;# 3  (Punkt als Metazeichen -- falsch)
regexp -all "***=$s" aX.bXcX.d ;# 2  (Punkt als Literal -- korrekt)
```

Innerhalb eines grösseren RE-Ausdrucks müssen Metazeichen einzeln escaped werden:

```tcl
regsub -all {[][*+?{}()<>|.^$\\]} $literal {\\&} escaped_literal
```

## Treffer extrahieren

```tcl
# In Variablen speichern
regexp {(\w+) is (\d+)} "John is 30" -> name age
;# name=John  age=30

# Nur Indices
regexp -indices {X+} aXXXc pos
;# pos={1 3}
```

`->` ist eine Konvention: eine Variable für den Gesamttreffer, an dem man nicht
interessiert ist (beliebiger Name, oft auch `-`).

## Beispiele

### Doppelte Wörter erkennen

```tcl
regexp {\m(\w+)\s+\1\M} "This sentence has has repeated words."  ;# 1
```

### Teilnummer validieren

```tcl
set re {^(?=.{2,10}$)[A-Z]+[0-9]+$}
regexp $re ABC99   ;# 1
regexp $re abc99   ;# 0
```

### Zeilenenden mit trailing whitespace zählen

```tcl
regexp -all -line {\s+$} $file_content
```

### E-Mail validieren

```tcl
proc isEmail {addr} {
    return [regexp {^[\w._%+-]+@[\w.-]+\.[a-zA-Z]{2,}$} $addr]
}
```

## Siehe auch

- **regsub** -- Regex-Ersetzung
- **re_syntax** -- vollständige RE-Syntaxreferenz (Tcl man page)
- **string match** -- Glob-Pattern
- **Tcl/Tk Manual:** https://www.tcl-lang.org/man/tcl8.6/TclCmd/regexp.html
