# exec und open -- Prozesse und Pipelines in Tcl

*Stand: 2026-04-29*

Tcl bietet zwei Hauptbefehle, um externe Programme zu starten und mit ihnen
zu kommunizieren: `exec` für einfache Aufrufe und `open` mit Pipe-Syntax
für komplexere Szenarien mit Kanalzugriff. Ergaenzt werden diese durch
`chan pipe` für eigenständige Pipes und `tcl::process` (ab Tcl 9.0) für
die Überwachung von Kindprozessen.

---

## Überblick: Wann welchen Befehl?

| Anforderung | Befehl | Begruendung |
|-------------|--------|-------------|
| Programm ausführen, Ausgabe sammeln | `exec` | Einfach, synchron, Ergebnis als String |
| Daten stueckweise lesen/schreiben | `open \|...` | Kanal mit gets/puts/fileevent |
| Hintergrundprozess mit PID-Kontrolle | `open \|...` | `pid $chan` liefert echte PID |
| Hintergrundprozess, kein Datenaustausch | `exec ... &` | Feuer-und-vergiss |
| Getrennte stdin/stdout/stderr-Kanäle | `chan pipe` | Volle Kontrolle über alle Stroeme |
| Interaktiver Dialog mit Kindprozess | `open \|...` mit `r+` | Bidirektional lesen/schreiben |
| Langlebigen Prozess sauber beenden | `open \|...` | `close $chan` oder `kill [pid $chan]` |

---

## exec -- Synchrone Prozessausfuehrung

### Syntax

```tcl
exec ?-keepnewline? ?-ignorestderr? ?--? arg ?arg ...? ?&?
```

Der Befehl startet eine Pipeline aus einem oder mehreren Programmen. Ohne `&`
wartet `exec` bis alle Prozesse beendet sind und gibt die Standardausgabe des
letzten Prozesses als Ergebnis zurück.

### Einfacher Aufruf

```tcl
# Einzelnes Programm, Ausgabe als String
set result [exec ls -la /tmp]

# Pipeline: Ausgabe von Programm A als Eingabe für Programm B
set found [exec grep -r "TODO" src/ | sort -u]
```

### Argumente übergeben

Argumente durchlaufen zuerst Tcls Substitutionsregeln, dann die des
aufgerufenen Programms. Wichtig: Tcl führt kein Glob-Expanding durch.

```tcl
# Falsch: Tcl expandiert *.tcl NICHT
exec ls *.tcl

# Richtig: Glob explizit durchführen
exec ls {*}[glob *.tcl]
```

Auf Windows müssen Dateipfade für viele Programme in native Form
umgewandelt werden:

```tcl
exec cmd /c dir [file nativename [file dirname [info nameofexecutable]]]
```

### Programme finden

```tcl
# Absoluter Pfad
exec /usr/bin/pw-play test.wav

# Relativer Pfad oder nur Programmname (durchsucht PATH)
exec pw-play test.wav

# Shell-interne Befehle prüfen
if {[auto_execok ifconfig] ne ""} {
    set info [exec ifconfig]
}
```

### Eingabe umleiten

Drei Möglichkeiten, dem Kindprozess Daten als Standardeingabe zu geben:

```tcl
# Aus Datei
exec programm < eingabe.txt

# Aus einem offenen Kanal
set fd [open eingabe.txt r]
exec programm <@ $fd
close $fd

# Aus einem Tcl-Wert (Inline-Daten)
exec tclsh << {puts "Hallo von stdin"}
```

### Ausgabe umleiten

```tcl
# Standardausgabe in Datei (überschreiben)
exec programm > ausgabe.txt

# Standardausgabe anfügen
exec programm >> ausgabe.txt

# Standardfehler in Datei
exec programm 2> fehler.log

# Beide in dieselbe Datei
exec programm >& alles.log

# In einen offenen Kanal
set fd [open ergebnis.txt w]
exec programm >@ $fd
close $fd
```

Bei Umleitung gibt `exec` einen leeren String zurück.

### Fehlerbehandlung

`exec` wirft einen Fehler in zwei Situationen: wenn der Kindprozess mit
einem Exit-Code ungleich 0 beendet wird, oder wenn er auf stderr schreibt
(ausser bei `-ignorestderr`).

Die Error-Codes geben praezise Auskunft über die Fehlerursache:

| errorCode | Bedeutung |
|-----------|-----------|
| `NONE` | Exit-Code 0, aber Ausgabe auf stderr |
| `CHILDSTATUS pid code` | Prozess beendet mit Exit-Code ungleich 0 |
| `CHILDKILLED pid signal msg` | Prozess durch Signal beendet |
| `CHILDSUSP pid signal msg` | Prozess suspendiert |
| `POSIX code msg` | Betriebssystemfehler (Datei nicht gefunden etc.) |

Das vollständige Fehlerbehandlungs-Template mit `try`:

```tcl
try {
    set result [exec programm argumente ...]
} trap NONE output {
    # Exit-Code 0, aber stderr-Ausgabe vorhanden
    # $output enthält stdout + stderr
} trap CHILDSTATUS {- ropts} {
    # Prozess beendet mit Fehler-Exit-Code
    lassign [dict get $ropts -errorcode] -> pid exitCode
    puts "PID $pid beendet mit Code $exitCode"
} trap CHILDKILLED {- ropts} {
    # Prozess durch Signal getoetet
    lassign [dict get $ropts -errorcode] -> pid signal reason
    puts "PID $pid getoetet durch $signal: $reason"
} trap CHILDSUSP {- ropts} {
    # Prozess suspendiert
    lassign [dict get $ropts -errorcode] -> pid signal reason
} trap POSIX {- ropts} {
    # Betriebssystemfehler
    lassign [dict get $ropts -errorcode] -> posixCode reason
    puts "Fehler: $posixCode - $reason"
}
```

Einfachere Variante mit `catch`:

```tcl
if {[catch {exec programm args} result]} {
    puts "Fehler: $result"
    puts "Code: $::errorCode"
} else {
    puts "Ergebnis: $result"
}
```

### Hintergrundprozesse mit &

Mit `&` als letztem Argument kehrt `exec` sofort zurück. Der Rückgabewert
ist eine Liste der PIDs aller Prozesse in der Pipeline:

```tcl
set pids [exec programm1 | programm2 > out.log &]
# pids = {1234 5678}
```

Ohne Ausgabeumleitung gehen stdout und stderr des Kindprozesses an die
Standardausgabe der Tcl-Anwendung.

Wichtige Einschränkung: Bei `exec ... &` hat man keinen Kanal zum
Kindprozess. Man kann weder seine Ausgabe lesen noch Fehler erkennen, es
sei denn, man leitet alles in Dateien um.

### Einschränkungen von exec

`exec` hat mehrere Limitierungen, die in der Praxis relevant sind:

- Kein interaktiver Datenaustausch: Man kann nicht abwechselnd Daten
  senden und Antworten lesen.
- Keine Encoding-Kontrolle: Es wird immer das System-Encoding verwendet.
- Spezialzeichen in Argumenten sind schwer zu übergeben, wenn sie mit
  Umleitungsoperatoren kollidieren.
- `exec ... &` liefert eine PID, aber keinen Fehlerkanal -- wenn der
  Prozess sofort scheitert, erfährt man es nicht.

All diese Probleme löst `open` mit Pipe-Syntax.

---

## open mit Pipe-Syntax -- Kanäle für Prozess-Pipelines

### Syntax

```tcl
open |programm ?zugriffsmodus?
open |[list programm arg1 arg2 ...] ?zugriffsmodus?
```

Das `|`-Zeichen am Anfang des Pfads signalisiert, dass `open` keine Datei
oeffnet, sondern eine Prozess-Pipeline startet. Der Rest wird wie bei `exec`
behandelt (Programme, Umleitungen, Pipes).

`open` gibt einen Kanal zurück, über den man mit `gets`, `puts`, `read`,
`fileevent` und allen anderen Kanal-Operationen arbeiten kann.

### Zugriffsmodi

| Modus | Lesen | Schreiben | Typischer Einsatz |
|-------|-------|-----------|-------------------|
| `r` | Ja | Nein | Ausgabe eines Programms lesen |
| `w` | Nein | Ja | Daten an ein Programm senden |
| `r+` | Ja | Ja | Dialog mit einem Programm |

### Lese-Pipe: Programmausgabe zeilenweise verarbeiten

```tcl
set chan [open "|wpctl status" r]
while {[gets $chan line] >= 0} {
    if {[string match "*RUNNING*" $line]} {
        puts "Aktiv: $line"
    }
}
close $chan
```

Im Gegensatz zu `exec` kann man hier die Ausgabe zeilenweise verarbeiten,
statt alles auf einmal als String zu erhalten. Das ist entscheidend bei
grossen Datenmengen oder kontinuierlichen Datenstromen.

### Schreib-Pipe: Daten an ein Programm senden

```tcl
set chan [open "|gzip > archiv.gz" w]
puts $chan "Zeile 1"
puts $chan "Zeile 2"
puts $chan "Zeile 3"
close $chan
```

Die Daten werden bei `close` (oder bei vollem Puffer) an das Programm
übergeben.

### Bidirektionale Pipe: Dialog mit einem Programm

```tcl
set chan [open |[list tclsh] r+]
chan configure $chan -buffering line

puts $chan {puts [expr {2 + 3}]}
gets $chan result
# result = "5"

puts $chan {exit}
close $chan
```

Achtung: `tclsh` im Pipeline-Modus ist nicht-interaktiv. Es gibt kein
Prompt aus und gibt Ergebnisse nicht automatisch auf stdout aus -- man muss
`puts` explizit verwenden.

### PID abfragen: pid

Der `pid`-Befehl liefert die Prozess-IDs aller Prozesse in der Pipeline:

```tcl
set chan [open "|programm1 | programm2" r]
set pidList [pid $chan]
# pidList = {1234 5678}
```

Das ist entscheidend, wenn man einen Prozess gezielt beenden muss:

```tcl
set chan [open "|pw-record aufnahme.wav" r]
set recPid [lindex [pid $chan] 0]

# Später: Aufnahme beenden
exec kill $recPid
close $chan
```

### Fehlerbehandlung bei Pipelines

Fehler in Pipeline-Prozessen werden erst beim `close` sichtbar. Wenn ein
Prozess mit einem Exit-Code ungleich 0 beendet wurde oder auf stderr
geschrieben hat, wirft `close` eine Exception:

```tcl
set chan [open |[list programm args] r]
# ... Daten lesen ...
try {
    close $chan
} trap CHILDSTATUS {- ropts} {
    lassign [dict get $ropts -errorcode] -> pid exitCode
    puts "Prozess $pid beendet mit Code $exitCode"
}
```

Wichtig: Bei einer Multi-Prozess-Pipeline zeigt der Fehler nicht an,
welcher Prozess gescheitert ist. Dafuer braucht man `tcl::process status`
(ab Tcl 9.0).

---

## list-Form vs. String-Form bei open

Es gibt zwei Schreibweisen, um Programme mit `open` zu starten. Sie
unterscheiden sich in der Behandlung von Leerzeichen und Sonderzeichen:

```tcl
# String-Form: Anfaellig für Probleme mit Leerzeichen
set chan [open "|programm arg1 arg2" r]

# list-Form: Sicher, empfohlen
set chan [open |[list programm arg1 arg2] r]
```

Die list-Form ist immer vorzuziehen, besonders wenn Argumente Leerzeichen
oder Sonderzeichen enthalten koennten:

```tcl
# Falsch: Dateiname mit Leerzeichen wird aufgespalten
set chan [open "|pw-record meine datei.wav" r]

# Richtig: list schützt den Dateinamen
set chan [open |[list pw-record "meine datei.wav"] r]
```

---

## Asynchrone I/O mit fileevent

Die größte Staerke von `open |...` gegenüber `exec` ist die Möglichkeit,
I/O asynchron zu verarbeiten. Statt zu blockieren, registriert man einen
Callback, der aufgerufen wird, wenn Daten verfügbar sind.

### Grundmuster: Non-blocking Lese-Pipe

```tcl
proc onReadable {chan} {
    if {[gets $chan line] >= 0} {
        puts "Empfangen: $line"
        return
    }
    if {[eof $chan]} {
        chan event $chan readable {}
        close $chan
        puts "Prozess beendet"
        return
    }
    # Unvollstaendige Zeile -- wird beim nächsten Event weitergelesen
}

set chan [open |[list tail -f /var/log/syslog] r]
chan configure $chan -blocking 0 -buffering line
chan event $chan readable [list onReadable $chan]
```

Kritisch: Bei `eof` muss man entweder den Handler entfernen oder den Kanal
schließen. Sonst wird der Handler endlos aufgerufen, weil EOF immer wieder
als "lesbar" gemeldet wird.

### Muster: Prozessausgabe in GUI-Widget

```tcl
proc pipeToText {chan textWidget} {
    if {[gets $chan line] >= 0} {
        $textWidget insert end "$line\n"
        $textWidget see end
        return
    }
    if {[eof $chan]} {
        chan event $chan readable {}
        catch {close $chan}
        $textWidget insert end "--- FERTIG ---\n"
    }
}

set chan [open |[list make -C /pfad/zum/projekt] r]
chan configure $chan -blocking 0 -buffering line
chan event $chan readable [list pipeToText $chan .txt]
```

### Schreib-Events

Analog zu `readable` gibt es `writable`, um benachrichtigt zu werden, wenn
der Kanal bereit ist, Daten anzunehmen:

```tcl
chan event $chan writable [list onWritable $chan]
```

Das ist nützlich, wenn man grosse Datenmengen in ein Programm schreibt und
den Ausgabepuffer nicht unkontrolliert wachsen lassen will.

---

## Half-Close: Schreibseite schließen

Manche Filter-Programme lesen ihre gesamte Eingabe, bevor sie Ausgabe
produzieren. Man muss ihnen signalisieren, dass keine weiteren Daten kommen
(EOF), ohne den Lesekanal zu schließen.

```tcl
set chan [open |[list sort] r+]
chan configure $chan -buffering line

puts $chan "Banane"
puts $chan "Apfel"
puts $chan "Kirsche"

# Schreibseite schließen -> sort sieht EOF und gibt aus
chan close $chan write

# Jetzt die sortierte Ausgabe lesen
while {[gets $chan line] >= 0} {
    puts $line
}
# Apfel
# Banane
# Kirsche
close $chan
```

`chan close $chan write` schliesst nur die Schreibrichtung. Der Lesekanal
bleibt offen. Das funktioniert auch bei Netzwerk-Sockets.

---

## chan pipe -- Eigenstaendige Pipes

`chan pipe` erzeugt ein Pipe-Paar ohne Verbindung zu einem Prozess. Das
erlaubt volle Kontrolle über die Verdrahtung von stdin, stdout und stderr:

```tcl
# Pipe für Kindprozess-stdin
lassign [chan pipe] childRead myWrite

# Pipe für Kindprozess-stdout
lassign [chan pipe] myRead childWrite

# Kindprozess starten mit umgeleiteten Kanälen
exec programm <@ $childRead >@ $childWrite &

# Kindseite im Elternprozess schließen (wichtig!)
close $childRead
close $childWrite

# Jetzt kommunizieren
puts $myWrite "Eingabedaten"
close $myWrite                  ;# EOF für Kindprozess
set ergebnis [read $myRead]
close $myRead
```

Der Hauptvorteil gegenüber `open |...` mit `r+`: Man kann stdout und stderr
des Kindprozesses auf getrennte Kanäle legen:

```tcl
lassign [chan pipe] childRead myWrite     ;# stdin
lassign [chan pipe] myReadOut childOut     ;# stdout
lassign [chan pipe] myReadErr childErr     ;# stderr

exec programm <@ $childRead >@ $childOut 2>@ $childErr &

close $childRead
close $childOut
close $childErr

# stdout und stderr getrennt lesen
set stdout_data [read $myReadOut]
set stderr_data [read $myReadErr]
close $myReadOut
close $myReadErr
close $myWrite
```

---

## tcl::process -- Kindprozesse verwalten (Tcl 9.0+)

Ab Tcl 9.0 gibt es das `tcl::process`-Ensemble für die Überwachung
asynchron gestarteter Prozesse. In Tcl 8.6 ist es nicht verfügbar.

### Prozesse auflisten

```tcl
set pid1 [exec programm1 &]
set pid2 [exec programm2 &]
tcl::process list
# {1234 5678}
```

### Status abfragen

```tcl
set child [exec programm &]
after 100                  ;# Warten
set statusDict [tcl::process status $child]
# child_pid {exitcode errormsg errorcodelist}
```

Der Status ist ein Dictionary mit PID als Schlüssel. Ein leerer Wert
bedeutet, der Prozess läuft noch:

```tcl
# Auf Beendigung warten
set statusDict [tcl::process status -wait $child]
lassign [dict get $statusDict $child] exitCode errMsg errCode
```

### Ressourcen bereinigen

Wenn ein Kindprozess beendet wird, bleiben Betriebssystem-Ressourcen
reserviert bis `waitpid` aufgerufen wird. Standardmäßig passiert das
automatisch beim nächsten `exec` oder `open`.

```tcl
# Manuell bereinigen
tcl::process purge $pid

# Alle Kindprozess-Ressourcen freigeben
tcl::process purge

# Automatisches Bereinigen steuern
tcl::process autopurge 0     ;# Ausschalten
tcl::process autopurge 1     ;# Einschalten (Standard)
```

Autopurge ausschalten ist nützlich, wenn man den Status mehrerer
nacheinander gestarteter Prozesse abfragen will, ohne dass er bei jedem
neuen `exec` verloren geht.

---

## Praxismuster

### Muster 1: Tool-Verfügbarkeit prüfen

Bevor man ein externes Programm aufruft, sollte man prüfen ob es existiert:

```tcl
proc hasTool {name} {
    return [expr {[auto_execok $name] ne ""}]
}

if {![hasTool pw-record]} {
    error "pw-record nicht gefunden"
}
```

### Muster 2: Programm mit Timeout

`exec` hat keinen eingebauten Timeout. Mit `open` und `after` lässt sich
einer bauen:

```tcl
proc execWithTimeout {command timeoutMs} {
    set chan [open |[list {*}$command] r]
    chan configure $chan -blocking 0

    set result ""
    set afterId [after $timeoutMs [list set ::timedOut 1]]
    set ::timedOut 0

    chan event $chan readable [list apply {{chan} {
        if {[gets $chan line] >= 0} {
            append ::pipeResult "$line\n"
        } elseif {[eof $chan]} {
            set ::timedOut 0
            set ::done 1
        }
    }} $chan]

    set ::pipeResult ""
    set ::done 0
    vwait ::done
    # oder in Tk: kein vwait nötig, Event-Loop läuft

    after cancel $afterId
    if {$::timedOut} {
        set pid [lindex [pid $chan] 0]
        catch {exec kill $pid}
    }
    catch {close $chan}
    return $::pipeResult
}
```

### Muster 3: Hintergrund-Aufnahme mit Pipe-Kanal

Dieses Muster stammt aus der Praxis mit PipeWire-Audioaufnahme. Es zeigt
die Vorteile von `open |...` gegenüber `exec ... &`:

Problematischer Ansatz mit `exec &`:

```tcl
# NICHT EMPFOHLEN
set pid [exec pw-record --target $sourceId aufnahme.wav &]
# Problem 1: Wenn pw-record sofort scheitert, merkt man es nicht
# Problem 2: exec gibt die PID von pw-record zurück, aber ohne
#            Fehlerkanal -- toter Prozess bleibt unbemerkt
```

Robuster Ansatz mit `open |`:

```tcl
proc startRecording {wavFile} {
    # Pipe-Kanal oeffnen
    set chan [open [list | pw-record $wavFile] r]
    set pid [lindex [pid $chan] 0]

    # Fruehe Fehlererkennung: nach 500ms prüfen
    after 500 [list checkRecStarted $pid $chan]

    # Timer für Aufnahmedauer
    after 5000 [list stopRecording $chan]

    return [list chan $chan pid $pid]
}

proc checkRecStarted {pid chan} {
    # Prozess noch am Leben?
    if {[catch {exec kill -0 $pid}]} {
        # Prozess bereits beendet -- Fehler lesen
        set errMsg ""
        catch {
            chan configure $chan -blocking 0
            set errMsg [read $chan]
        }
        catch {close $chan}
        puts "Aufnahme fehlgeschlagen: $errMsg"
    }
}

proc stopRecording {chan} {
    set pid [lindex [pid $chan] 0]
    catch {exec kill $pid}
    after 300 [list catch [list close $chan]]
}
```

Vorteile: `pid $chan` liefert die echte PID. Der Kanal erlaubt
Fehlermeldungen zu lesen. `kill -0` prüft ob der Prozess noch lebt.

### Muster 4: Programmausgabe mit Encoding

```tcl
set chan [open |[list git log --oneline -20] r]
chan configure $chan -encoding utf-8
while {[gets $chan line] >= 0} {
    puts $line
}
close $chan
```

Im Gegensatz zu `exec`, wo immer das System-Encoding verwendet wird, kann
man bei `open`-Kanälen das Encoding frei wählen.

### Muster 5: Mehrere Prozesse in Pipeline überwachen

```tcl
set chan [open "|find /var -name '*.log' | xargs grep ERROR" r]
set pids [pid $chan]
puts "Pipeline gestartet: PIDs = $pids"

chan configure $chan -blocking 0 -buffering line
chan event $chan readable [list handleLine $chan]
```

---

## exec vs. open -- Zusammenfassung

| Eigenschaft | `exec` | `exec ... &` | `open \|...` |
|-------------|--------|--------------|-------------|
| Blockiert | Ja | Nein | Konfigurierbar |
| Ergebnis | stdout-String | PID-Liste | Kanal |
| PID | Nein (nur mit &) | Ja (nur PIDs) | Ja (`pid $chan`) |
| Fehlerkanal | Nein | Nein | Ja |
| Encoding-Kontrolle | Nein | Nein | Ja |
| fileevent | Nein | Nein | Ja |
| Interaktiv | Nein | Nein | Ja (r+) |
| Prozess beenden | Nicht möglich | kill mit PID | `close $chan` oder kill |
| Fehler-Timing | Sofort | Nie (unsichtbar) | Bei close oder fileevent |

Die Faustregel: `exec` für schnelle, einmalige Aufrufe, bei denen man
das gesamte Ergebnis als String braucht. `open |...` für alles andere,
insbesondere für langlebige Prozesse, asynchrone Verarbeitung und
Situationen, in denen man den Prozess kontrolliert beenden muss.

---

## Häufige Fehler und Lösungen

### exec gibt Fehler trotz Erfolg

Wenn ein Programm auf stderr schreibt (z.B. Warnungen), behandelt `exec`
das als Fehler -- auch wenn der Exit-Code 0 ist:

```tcl
# Problem: Warnung auf stderr löst Fehler aus
catch {exec programm args} result
# $::errorCode = NONE

# Lösung 1: stderr ignorieren
exec -ignorestderr -- programm args

# Lösung 2: stderr umleiten
exec programm args 2>/dev/null

# Lösung 3: stderr getrennt auffangen
exec programm args 2>@1   ;# stderr nach stdout
```

### Haengende Pipe bei close

Wenn `close` auf einer Pipe hängt, liegt es daran, dass der Kindprozess
noch läuft und der Kanal im Blocking-Modus ist:

```tcl
# Problem
set chan [open |[list langlebiges_programm] r]
close $chan  ;# hängt!

# Lösung: Prozess vorher beenden
set pid [lindex [pid $chan] 0]
catch {exec kill $pid}
after 200
close $chan
```

### exec & mit timeout/Wrapper gibt falsche PID

Wenn man `exec timeout 5 programm &` verwendet, bekommt man die PID von
`timeout`, nicht von `programm`. Ein `kill` auf diese PID beendet nur
`timeout`, nicht das eigentliche Programm.

```tcl
# Falsch: PID ist die von timeout, nicht von pw-record
set pid [exec timeout 5 pw-record datei.wav &]
exec kill $pid   ;# Beendet timeout, pw-record läuft weiter!

# Richtig: open verwenden, eigenes Timeout bauen
set chan [open [list | pw-record datei.wav] r]
set pid [lindex [pid $chan] 0]   ;# Echte PID
after 5000 [list exec kill $pid]
```

### Vergessenes flush bei Schreib-Pipes

Wenn Daten nicht beim Kindprozess ankommen, liegt es meistens am Buffering:

```tcl
set chan [open |[list programm] w]
puts $chan "Daten"
# Daten stecken im Puffer!

# Lösung 1: Zeilenpufferung
chan configure $chan -buffering line
puts $chan "Daten"   ;# wird sofort gesendet

# Lösung 2: Explizites flush
puts $chan "Daten"
flush $chan

# Lösung 3: Pufferung ausschalten (weniger effizient)
chan configure $chan -buffering none
```

### EOF-Handler nicht entfernt

Das ist einer der häufigsten Fehler bei asynchroner I/O. Wenn bei EOF der
Handler nicht entfernt wird, wird er endlos aufgerufen:

```tcl
# FALSCH: Endlosschleife bei EOF
chan event $chan readable {
    gets $chan line
    puts $line
}

# RICHTIG: EOF prüfen und Handler entfernen
chan event $chan readable [list onRead $chan]
proc onRead {chan} {
    if {[gets $chan line] >= 0} {
        puts $line
        return
    }
    if {[eof $chan]} {
        chan event $chan readable {}
        catch {close $chan}
    }
}
```

### Zombie-Prozesse vermeiden

Jeder mit `exec &` oder `open |` gestartete Prozess muss bereinigt werden.
Bei `open` geschieht das durch `close`. Bei `exec &` in Tcl 9.0+ durch
`tcl::process purge`. In Tcl 8.6 geschieht es automatisch beim nächsten
`exec`.

---

## Kanal-Konfiguration für Pipes

Alle üblichen Kanal-Optionen funktionieren auch mit Pipe-Kanälen:

| Option | Werte | Beschreibung |
|--------|-------|-------------|
| `-blocking` | 0/1 | Non-blocking für fileevent (Standard: 1) |
| `-buffering` | full/line/none | Pufferungsmodus (Standard: full) |
| `-encoding` | utf-8/... | Zeichensatz (Standard: System-Encoding) |
| `-translation` | auto/lf/crlf | Zeilenende-Behandlung |

Typische Konfiguration für asynchrone Lese-Pipe:

```tcl
set chan [open |[list programm] r]
chan configure $chan \
    -blocking 0 \
    -buffering line \
    -encoding utf-8
chan event $chan readable [list handler $chan]
```

---

## Verwandte Befehle

| Befehl | Beschreibung |
|--------|-------------|
| `exec` | Synchrone Prozessausfuehrung |
| `open \|...` | Kanal zu Prozess-Pipeline |
| `close` | Kanal schließen (bei Pipes: Prozess beenden) |
| `chan close $ch write` | Nur Schreibseite schließen (Half-Close) |
| `chan pipe` | Eigenstaendiges Pipe-Paar erzeugen |
| `pid $chan` | PIDs einer Pipeline-Pipe abfragen |
| `pid` | PID des aktuellen Prozesses (ohne Argument) |
| `chan configure` | Encoding, Buffering, Blocking setzen |
| `chan event` / `fileevent` | Asynchrone Lese/Schreib-Events registrieren |
| `eof $chan` | Prüfen ob Kanal am Ende ist |
| `tcl::process list` | Alle Kindprozesse auflisten (Tcl 9.0+) |
| `tcl::process status` | Status abfragen (Tcl 9.0+) |
| `tcl::process purge` | Ressourcen freigeben (Tcl 9.0+) |
| `auto_execok` | Prüfen ob Programm im PATH existiert |
