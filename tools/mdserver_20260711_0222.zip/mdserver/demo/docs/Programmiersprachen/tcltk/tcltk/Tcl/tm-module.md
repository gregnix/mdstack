# Tcl Module (.tm)

*Stand: 2026-04-29*

Tcl Module sind der moderne Mechanismus zum Verteilen und Laden von
Bibliotheken. Ein Modul ist eine einzelne Datei mit festem Namensschema,
die ohne Index-Datei gefunden und geladen wird.

## Grundkonzept

Ein Tcl Modul ist eine Datei mit der Endung `.tm`, deren Name
Paketname und Version kodiert:

```
paketname-version.tm
```

Tcl erkennt das Modul automatisch anhand des Dateinamens. Es braucht
keine `pkgIndex.tcl` und kein `auto_mkindex`.

```tcl
# mypkg-0.1.tm

package provide mypkg 0.1

namespace eval ::mypkg {}

proc ::mypkg::hello {name} {
    return "Hallo $name"
}
```

Laden:

```tcl
tcl::tm::path add /pfad/zu/modulen
package require mypkg 0.1

puts [mypkg::hello "Welt"]   ;# -> "Hallo Welt"
```

## Dateinamen-Konvention

### Einfache Module

| Paketname | Dateiname |
|:----------|:----------|
| `mypkg` | `mypkg-0.1.tm` |
| `mylib` | `mylib-1.0.tm` |
| `utils` | `utils-2.3.1.tm` |

### Module mit :: im Paketnamen (Submodule)

Der Doppelpunkt `::` wird auf Verzeichnisse abgebildet. Das ist eine
feste Regel des Tcl-Modulsystems:

| Paketname | Dateipfad |
|:----------|:----------|
| `mypkg` | `mypkg-0.1.tm` |
| `mypkg::common` | `mypkg/common-0.1.tm` |
| `mypkg::impl::win` | `mypkg/impl/win-0.1.tm` |
| `mypkg::impl::unix` | `mypkg/impl/unix-0.1.tm` |

Verzeichnisstruktur:

```
src/tm/
|-- mypkg-0.1.tm
+-- mypkg/
    |-- common-0.1.tm
    +-- impl/
        |-- unix-0.1.tm
        +-- win-0.1.tm
```

### Häufiger Fehler: Flache Dateinamen für Submodule

Folgendes funktioniert **nicht**:

```
src/tm/
|-- mypkg-0.1.tm
|-- mypkg-common-0.1.tm        <-- FALSCH!
+-- mypkg-impl-win-0.1.tm      <-- FALSCH!
```

Tcl sucht `mypkg::common` ausschliesslich unter `mypkg/common-0.1.tm`.
Die flache Datei `mypkg-common-0.1.tm` wird vom tm-Loader **gar nicht
als Paket erkannt** -- der Loader-Regex erlaubt im Paketnamen nur
Buchstaben, Ziffern, Underscore und Doppelpunkt, **keine
Bindestriche**:

```
^([_[:alpha:]][:_[:alnum:]]*)-([[:digit:]].*)[.]tm$
```

Bei `mypkg-common-0.1.tm` matcht der Loader greedy auf den ersten
Bindestrich: Name = `mypkg`, Version = `common-0.1`. Da `common-0.1`
keine valide Version ist (`package vcompare` schlaegt fehl), ignoriert
der Loader die Datei komplett. Sie ist weder als `mypkg::common` noch
als `mypkg-common` ladbar.

Dasselbe gilt fuer `package provide`-Statements mit Bindestrich:

```tcl
;# Datei: docir-md-0.1.tm
package provide docir-md 0.1   ;# Loader ignoriert die Datei
```

`package require docir-md` schlaegt fehl, weil der Loader die Datei
nicht erkennt.

Loesungen:

1. Hierarchie aufbauen: `docir/md-0.1.tm` mit `package provide docir::md`
2. Underscore statt Bindestrich: `docir_md-0.1.tm` mit `package provide docir_md`
3. Bei nicht-aenderbaren Vendor-Modulen: direktes `source` statt
   `package require`

Verifikation des Loader-Patterns:

```tcl
puts $::tcl::tm::pkgpattern
;# -> ^([_[:alpha:]][:_[:alnum:]]*)-([[:digit:]].*)[.]tm$
```

## Modulsuchpfad

### tcl::tm::path add

Registriert ein Verzeichnis im Modul-Suchpfad:

```tcl
tcl::tm::path add /pfad/zu/modulen
```

Mehrere Verzeichnisse:

```tcl
tcl::tm::path add /pfad/eins /pfad/zwei
```

### Vorfahr/Nachfahr-Konflikt

`tcl::tm::path add` lehnt ein Verzeichnis ab, das Vorfahr oder
Nachfahr eines bereits registrierten Suchpfads ist. Zwei Modulwurzeln,
bei denen eine unterhalb der anderen liegt, sind damit unvereinbar —
unabhängig von der Reihenfolge:

```tcl
tcl::tm::path add /opt/vendor
;# Nachfahr wird abgelehnt:
tcl::tm::path add /opt/vendor/sub
;# -> /opt/vendor/sub is subdirectory of existing module path /opt/vendor.

;# Umgekehrte Reihenfolge hilft nicht:
tcl::tm::path add /opt/vendor/sub
;# Vorfahr wird abgelehnt:
tcl::tm::path add /opt/vendor
;# -> /opt/vendor is ancestor of existing module path /opt/vendor/sub.
```

Betroffen ist besonders das Layout `name/lib/name-ver.tm` (das native
Backend `.so`/`.dll` liegt mit der `.tm` im selben `lib/`): Die korrekte
Modulwurzel `.../name/lib` ist Nachfahr einer gemeinsam genutzten
Vendor-Wurzel und lässt sich daher nicht zusätzlich registrieren.

Ist der Konflikt unvermeidbar, das Modul **direkt sourcen**, statt es über
die Modul-Discovery suchen zu lassen — `source` umgeht den Suchpfad
vollständig:

```tcl
source -encoding utf-8 /opt/vendor/sub/name-1.0.tm
package present name   ;# danach normal verfügbar
```

### tcl::tm::path list

Zeigt die registrierten Suchpfade:

```tcl
puts [tcl::tm::path list]
```

### tcl::tm::path remove

Entfernt ein Verzeichnis aus dem Suchpfad:

```tcl
tcl::tm::path remove /pfad/zu/modulen
```

### Standard-Suchpfade

Tcl durchsucht automatisch bestimmte Verzeichnisse basierend auf
der Tcl-Version und dem Installationsort. Die Funktion
`tcl::tm::path list` zeigt die aktuellen Pfade.

### Unterschied zu auto_path

| Aspekt | `tcl::tm::path` | `auto_path` |
|:-------|:-----------------|:------------|
| Für | .tm Module | pkgIndex.tcl Pakete |
| Index nötig | Nein | Ja (pkgIndex.tcl) |
| Erkennung | Dateiname | Index-Eintrag |
| Unterverzeichnisse | Nur bei :: im Namen | Automatisch durchsucht |

Die beiden Mechanismen sind unabhängig. Ein Verzeichnis in
`tcl::tm::path` wird nicht nach `pkgIndex.tcl` durchsucht und
umgekehrt.

## Modul-Aufbau

### Minimales Modul

```tcl
# hello-0.1.tm

package provide hello 0.1

namespace eval ::hello {}

proc ::hello::greet {name} {
    return "Hallo $name"
}
```

Die drei Pflichtbestandteile:

1. `package provide` mit Name und Version
2. `namespace eval` um den Namespace zu erzeugen
3. Prozeduren im Namespace

### Modul mit Variablen

```tcl
# config-0.1.tm

package provide config 0.1

namespace eval ::config {
    variable data [dict create]
}

proc ::config::set_value {key value} {
    variable data
    dict set data $key $value
}

proc ::config::get_value {key} {
    variable data
    return [dict get $data $key]
}

proc ::config::has {key} {
    variable data
    return [dict exists $data $key]
}
```

### Modul mit Export

```tcl
# mathutil-0.1.tm

package provide mathutil 0.1

namespace eval ::mathutil {
    namespace export clamp lerp
}

proc ::mathutil::clamp {value low high} {
    expr {max($low, min($high, $value))}
}

proc ::mathutil::lerp {a b t} {
    expr {$a + ($b - $a) * $t}
}
```

## Modulare Architektur

Für groessere Bibliotheken empfiehlt sich eine Aufteilung in
mehrere Module mit einem Dispatcher.

### Dispatcher-Pattern

Das Hauptmodul lädt die Teilmodule:

```tcl
# mypkg-0.1.tm (Dispatcher)

package require Tcl 8.6
package provide mypkg 0.1

namespace eval ::mypkg {}

# Gemeinsamer Code
package require -exact mypkg::common 0.1

# Plattformspezifisch
if {$::tcl_platform(platform) eq "windows"} {
    package require -exact mypkg::platform::win 0.1
} else {
    package require -exact mypkg::platform::unix 0.1
}

# Tcl-9-spezifisch
if {[package vcompare [info patchlevel] 9.0] >= 0} {
    package require -exact mypkg::compat::tcl9 0.1
}
```

### Typische Modul-Aufteilung

| Modul | Zweck | Abhängigkeiten |
|:------|:------|:----------------|
| `mypkg-0.1.tm` | Dispatcher | - |
| `mypkg::common` | Gemeinsame Helfer | Kein Tk |
| `mypkg::core` | Kernlogik, Model | Kein Tk |
| `mypkg::ui` | UI-Komponenten | Tk, ttk |
| `mypkg::platform::win` | Windows-Code | - |
| `mypkg::platform::unix` | Unix-Code | - |

### Verzeichnisstruktur

```
src/tm/
|-- mypkg-0.1.tm
+-- mypkg/
    |-- common-0.1.tm
    |-- core-0.1.tm
    |-- ui-0.1.tm
    +-- platform/
        |-- win-0.1.tm
        +-- unix-0.1.tm
```

### Bedingtes Laden von Tk-Abhängigkeiten

UI-Module sollten nur geladen werden, wenn Tk verfügbar ist:

```tcl
# Im Dispatcher:
if {![catch {package require Tk}]} {
    package require -exact mypkg::ui 0.1
}
```

## Module aus mehreren Dateien erzeugen

Per Definition ist ein Modul eine einzelne Datei. Wenn die Quellen
in mehreren Dateien vorliegen, müssen sie zusammengefügt werden:

### Unix/macOS

```bash
cat common.tcl core.tcl util.tcl > mylib-1.0.tm
```

### Windows

```cmd
copy common.tcl+core.tcl+util.tcl mylib-1.0.tm
```

### Reihenfolge beachten

Dateien die Prozeduren oder Daten definieren, müssen vor Dateien stehen
die diese zur Ladezeit verwenden. In der Praxis bedeutet das:

1. Namespace-Deklaration und Variablen zuerst
2. Basis-Prozeduren
3. Hoehere Prozeduren die auf die Basis zugreifen
4. Initialisierungscode

## Module installieren

### Manuell

Eine .tm Datei in ein Verzeichnis kopieren, das in `tcl::tm::path`
registriert ist:

```bash
cp mylib-1.0.tm ~/.tcl/modules/
```

### Im Projekt

Für Projekte die ihre Module mitbringen, ist keine Installation nötig.
Der Modulpfad wird beim Start registriert:

```tcl
# In main.tcl
set appDir [file dirname [file normalize [info script]]]
tcl::tm::path add [file join $appDir src tm]
```

## Demos und Tests

### Demo mit relativem Pfad

```tcl
#!/usr/bin/env wish
# demo/demo-basic.tcl

set scriptDir [file dirname [info script]]
tcl::tm::path add [file join $scriptDir ../src/tm]

package require mypkg 0.1
puts [mypkg::hello "Welt"]
```

### Demo mit Bootstrap

```tcl
# demo/demo-bootstrap.tcl
set demoDir [file dirname [info script]]
set rootDir [file normalize [file join $demoDir ..]]
tcl::tm::path add [file join $rootDir src tm]
```

```tcl
# demo/demo-basic.tcl
source [file join [file dirname [info script]] demo-bootstrap.tcl]
package require mypkg 0.1
puts [mypkg::hello "Welt"]
```

### Tests

```tcl
# tests/all.tcl
package require tcltest
namespace import tcltest::*

set testDir [file dirname [file normalize [info script]]]
set rootDir [file dirname $testDir]
tcl::tm::path add [file join $rootDir src tm]

# Tests ausführen
configure {*}$argv
runAllTests
```

Wichtig: In Tests `tcl::tm::path add` verwenden, nicht `lappend auto_path`.

## Versionierung

### Im Dateinamen

Die Version steht im Dateinamen. Mehrere Versionen können nebeneinander
existieren:

```
src/tm/
|-- mylib-0.1.tm
|-- mylib-0.2.tm
+-- mylib-1.0.tm
```

### Versionsauswahl

```tcl
package require mylib         ;# -> lädt 1.0 (neueste)
package require mylib 0.1     ;# -> lädt 0.2 (kompatibel neuer)
package require -exact mylib 0.1  ;# -> lädt 0.1
```

### -exact für interne Submodule

Wenn ein Dispatcher seine Submodule lädt, sollte `-exact` verwendet
werden, damit alle Teile synchron sind:

```tcl
package require -exact mypkg::common 0.1
package require -exact mypkg::core 0.1
```

## Packages vs. Module: Entscheidungshilfe

### Module bevorzugen wenn

- neues Projekt (kein Legacy)
- reine Tcl-Scripts (keine Shared Libraries)
- einfache Distribution gewünscht (eine Datei)
- Starkit/Starpack/Zipfs geplant
- Performance beim Laden wichtig

### Packages (pkgIndex) bevorzugen wenn

- Shared Libraries (.so, .dll) enthalten
- Aliase benötigt werden (z.B. `Tablelist` für `tablelist`)
- mehrere Dateien bedingt geladen werden sollen
- Legacy-Kompatibilität gefordert ist
- plattformspezifische Binaries pro Architektur

### Kombiniert verwenden

Es ist möglich, .tm Module über eine pkgIndex.tcl zugaenglich zu
machen (z.B. für Aliase):

```tcl
# pkgIndex.tcl
package ifneeded MyPkg 0.1 [list package require -exact mypkg 0.1]
```

Dabei muss das .tm Modul über `tcl::tm::path` erreichbar sein.
Beide Mechanismen nicht für dasselbe Paket mischen.

## Häufige Fehler

### Falscher Dateiname

```
mylib.tm          <-- FALSCH: Version fehlt
mylib-0.1.tcl     <-- FALSCH: Endung muss .tm sein
MyLib-0.1.tm      <-- FALSCH: Gross/Klein muss zum Paketnamen passen
```

### package provide fehlt oder stimmt nicht überein

```tcl
# Datei: mylib-0.1.tm

# FALSCH: Kein package provide
namespace eval ::mylib {}

# FALSCH: Version stimmt nicht überein
package provide mylib 0.2

# RICHTIG:
package provide mylib 0.1
```

### auto_path statt tcl::tm::path

```tcl
# FALSCH: auto_path findet keine .tm Dateien
lappend auto_path /pfad/zu/tm

# RICHTIG:
tcl::tm::path add /pfad/zu/tm
```

### Flache Dateinamen für Submodule

```
# FALSCH: mypkg::common wird so NICHT gefunden
src/tm/mypkg-common-0.1.tm

# RICHTIG: :: wird auf Verzeichnisse abgebildet
src/tm/mypkg/common-0.1.tm
```

### Pfad relativ zum Arbeitsverzeichnis

```tcl
# FALSCH:
tcl::tm::path add "../src/tm"

# RICHTIG:
tcl::tm::path add [file join [file dirname [info script]] ../src/tm]
```

## Debugging

### Welche Modulpfade sind registriert?

```tcl
puts [tcl::tm::path list]
```

### Ist das Paket bekannt?

```tcl
puts [package versions mypkg]    ;# -> z.B. 0.1
```

### Ist das Paket geladen?

```tcl
if {![catch {package present mypkg} ver]} {
    puts "mypkg $ver geladen"
} else {
    puts "mypkg nicht geladen"
}
```

### Alle bekannten Pakete

```tcl
puts [lsort [package names]]
```

### Wo wird ein Paket geladen?

```tcl
puts [package ifneeded mypkg 0.1]
```

Gibt das Script zurück, das bei `package require` ausgeführt wird.
Bei .tm Modulen ist das typischerweise `source /pfad/zu/mypkg-0.1.tm`.

## Zusammenfassung

| Befehl/Konzept | Funktion |
|:---------------|:---------|
| `tcl::tm::path add dir` | Modul-Suchpfad registrieren |
| `tcl::tm::path list` | Registrierte Suchpfade anzeigen |
| `tcl::tm::path remove dir` | Suchpfad entfernen |
| `package provide name ver` | Modul als geladen markieren |
| `package require name ?ver?` | Modul laden |
| `package require -exact name ver` | Exakte Version laden |
| `name-version.tm` | Dateinamen-Konvention |
| `name/sub-version.tm` | Submodul-Konvention (für `::`) |

## Siehe auch

- [Package](package.md) -- Alternative: Klassische Pakete mit pkgIndex.tcl
- [Namespace](namespace.md) -- Module in Namespaces kapseln
- [Code laden](source-eval-apply.md) -- `source` als einfachste Lademethode
- [Info](info.md) -- `info loaded`, Modulpfade inspizieren
