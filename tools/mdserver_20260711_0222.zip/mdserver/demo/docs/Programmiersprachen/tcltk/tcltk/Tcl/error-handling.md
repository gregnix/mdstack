# Fehlerbehandlung und Exceptions

*Stand: 2026-04-29*

Tcl verwendet ein Exception-System auf Basis von Return-Codes. Jeder
Befehl liefert neben seinem Ergebnis einen Return-Code und ein
Options-Dictionary. Fehler werden nicht über spezielle Rückgabewerte
signalisiert, sondern über Exceptions die sich automatisch durch den
Call-Stack nach oben ausbreiten, bis sie abgefangen werden.

## Return-Codes

Jeder Tcl-Befehl liefert bei seiner Ausführung drei Werte:

- das Ergebnis (Result)
- einen ganzzahligen Return-Code
- ein Return-Options-Dictionary

Der Return-Code bestimmt, wie der Aufrufer mit dem Ergebnis umgeht.

### Definierte Return-Codes

| Code | Mnemonic | Bedeutung |
|:-----|:---------|:----------|
| 0 | `ok` | Normale Ausführung, weiter mit nächstem Befehl |
| 1 | `error` | Fehler, Stack-Trace wird aufgebaut |
| 2 | `return` | Prozedur-Rueckkehr |
| 3 | `break` | Schleife abbrechen |
| 4 | `continue` | Nächste Iteration |
| 5+ | benutzerdefiniert | Frei verwendbar (5 bis 0x3FFFFFFF) |

### Return-Code-Propagation

Ein Return-Code von 0/ok bewirkt, dass der Aufrufer normal weitermacht.
Jeder andere Code ist eine Exception. Exceptions breiten sich
automatisch im Call-Stack nach oben aus, bis ein Befehl sie behandelt:

```
             puts "Hallo"        -> ok (0)      -> weiter
             break               -> break (3)   -> nach oben
    while    <-- bekommt break   -> Schleife beenden
             continue            -> continue (4) -> nach oben
    foreach  <-- bekommt continue -> nächste Iteration
             error "kaputt"      -> error (1)   -> nach oben, oben, oben...
    catch    <-- fängt error    -> behandeln
```

Wichtig: Die Semantik der Codes wird nicht von Tcl selbst festgelegt,
sondern vom jeweiligen aufrufenden Befehl. `while` behandelt `break`
als Schleifenende. Ein anderer Befehl könnte `break` anders
interpretieren.

### break und continue

`break` und `continue` sind keine Schluesselwoerter, sondern
normale Befehle die einen bestimmten Return-Code liefern:

```tcl
# break liefert Return-Code 3
catch { break }   ;# -> 3

# continue liefert Return-Code 4
catch { continue }   ;# -> 4
```

Die Schleifenbefehle (`for`, `while`, `foreach`, `lmap`) erkennen
diese Codes und reagieren darauf. Andere Befehle propagieren sie
nach oben.

### return (Code 2)

Der `return`-Befehl liefert Return-Code 2. Wenn die Prozedur-
Auswertung diesen Code sieht, beendet sie die Prozedur und gibt
dem Aufrufer stattdessen Code 0/ok mit dem Return-Wert zurück:

```tcl
proc test {} {
    return "Ergebnis"    ;# Return-Code 2 -> Prozedur endet
    puts "nie erreicht"
}

set r [test]   ;# Aufrufer sieht Code 0/ok mit Ergebnis "Ergebnis"
```

### error (Code 1)

Error-Exceptions breiten sich im gesamten Call-Stack nach oben aus
und fuehren zum Programmabbruch wenn sie nicht abgefangen werden.
Zusätzlich baut Tcl automatisch einen Stack-Trace auf.

## Das Return-Options-Dictionary

Neben Result und Return-Code liefert jeder Befehl ein Dictionary mit
zusätzlichen Informationen.

### Immer vorhanden

| Schlüssel | Inhalt |
|:-----------|:-------|
| `-code` | Der logische Return-Code (ok, error, break, ...) |
| `-level` | Stack-Ebene für die Verarbeitung |

### Bei Fehlern zusätzlich

| Schlüssel | Inhalt |
|:-----------|:-------|
| `-errorinfo` | Menschenlesbarer Stack-Trace |
| `-errorcode` | Maschinenlesbarer Fehler-Code (Liste) |
| `-errorstack` | Strukturierter Stack für Programme |
| `-errorline` | Zeilennummer im Script |

### Anwendungsdefinierte Einträge

Das Dictionary kann beliebige weitere Schlüssel enthalten:

```tcl
return -code error -timestamp [clock seconds] "Fehler"
```

## Fehler abfangen: catch

`catch` führt ein Script aus und fängt jede Exception ab. Der
Return-Code wird als Ergebnis von `catch` zurückgegeben.

### Syntax

```tcl
catch script ?resultVar? ?optsVar?
```

### Grundverwendung

```tcl
if {[catch { set x $nosuchvar } result]} {
    puts "Fehler: $result"
}
```

`catch` gibt den Return-Code zurück: 0 bei Erfolg, 1 bei Fehler,
3 bei break, usw. Das Script-Ergebnis wird in `resultVar` gespeichert.

### Alle Return-Codes abfangen

```tcl
catch { set x "normal" }              ;# -> 0
catch { error "kaputt" }              ;# -> 1
catch { return "wert" }               ;# -> 2
catch { break }                       ;# -> 3
catch { continue }                    ;# -> 4
catch { return -code 5 -level 0 "" }  ;# -> 5
```

### Mit Options-Dictionary

Das dritte Argument empfaengt das Return-Options-Dictionary:

```tcl
catch { set x $nosuchvar } result ropts

puts $result
# -> can't read "nosuchvar": no such variable

puts [dict get $ropts -errorcode]
# -> TCL READ VARNAME

puts [dict get $ropts -errorinfo]
# -> can't read "nosuchvar": no such variable
#    while executing
#    "set x $nosuchvar"
```

### Typisches Muster: Fehler behandeln oder weiterleiten

```tcl
if {[catch { openDatabase $dsn } result ropts]} {
    set ec [lindex [dict get $ropts -errorcode] 0]
    if {$ec eq "POSIX"} {
        # Betriebssystem-Fehler: Fallback verwenden
        set db [openFallbackDb]
    } else {
        # Unbekannter Fehler: weiterleiten
        return -options $ropts $result
    }
} else {
    set db $result
}
```

### Ressourcen sichern mit catch

```tcl
set fd [open "daten.txt" r]
set code [catch {
    set data [read $fd]
    processData $data
} result ropts]
close $fd

if {$code != 0} {
    return -options $ropts $result
}
```

## Fehler abfangen: try

Seit Tcl 8.6. `try` bietet eine strukturiertere Alternative zu
`catch`, besonders wenn verschiedene Fehlerarten unterschiedlich
behandelt werden sollen.

### Syntax

```tcl
try body ?on code varList handlerBody? \
         ?trap errorPattern varList handlerBody? \
         ?finally finalScript?
```

### Einfache Fehlerbehandlung

```tcl
try {
    set fd [open "config.ini" r]
    set data [read $fd]
    close $fd
} on error {result ropts} {
    puts "Fehler: $result"
}
```

### on-Handler für verschiedene Codes

`on` fängt einen bestimmten Return-Code ab:

```tcl
try {
    someCommand
} on ok {result} {
    puts "Erfolg: $result"
} on error {result} {
    puts "Fehler: $result"
} on break {} {
    puts "Break empfangen"
}
```

Die Codes können als Mnemonic (`ok`, `error`, `break`, `continue`)
oder als Zahl angegeben werden.

### trap-Handler für spezifische Fehler-Codes

`trap` fängt nur Fehler mit bestimmtem `-errorcode` ab. Das
Pattern wird als Präfix gegen den Error-Code geprüft:

```tcl
try {
    set fd [open "config.ini" r]
    set data [read $fd]
    close $fd
} trap {POSIX ENOENT} {result} {
    # Datei nicht gefunden -> Defaults verwenden
    set data [defaultConfig]
} trap {POSIX EACCES} {result} {
    # Keine Berechtigung
    puts "Zugriff verweigert: $result"
} on error {result} {
    # Alle anderen Fehler
    puts "Unbekannter Fehler: $result"
}
```

### Reihenfolge der Handler

Handler werden in der angegebenen Reihenfolge geprüft. Der erste
passende wird ausgeführt:

```tcl
try {
    expr {$a / $b}
} trap {ARITH DIVZERO} {result} {
    # Division durch Null: speziell behandeln
    return Inf
} trap {ARITH} {result} {
    # Andere Arithmetik-Fehler
    puts "Rechenfehler: $result"
} on error {result} {
    # Alle uebrigen Fehler (Auffang-Handler)
    error $result
}
```

Wichtig: `trap`-Handler müssen vor `on error` stehen. Ein `on error`
fängt alle Fehler ab, nachfolgende `trap`-Handler werden nie erreicht.

Ein leeres Pattern `trap {} ...` ist aequivalent zu `on error ...`.

### Handler mit Bindestrich (Weiterleitung)

Wenn der Handler-Body ein einzelner Bindestrich `-` ist, wird der
Body des nächsten Handlers verwendet:

```tcl
try {
    riskyOperation
} trap {NETWORK TIMEOUT} {result} - \
  trap {NETWORK REFUSED} {result} {
    # Gleiche Behandlung für Timeout und Connection Refused
    retryWithFallback
}
```

### finally

Der `finally`-Block wird immer ausgeführt, egal ob das Script
erfolgreich war oder eine Exception aufgetreten ist:

```tcl
set fd [open "daten.txt" r]
try {
    set data [read $fd]
    return [parseData $data]
} finally {
    close $fd
}
```

`finally` ist die sauberste Art, Ressourcen freizugeben. Es
wird auch ausgeführt wenn ein Handler eine Exception erzeugt.

### try vs. catch

| Aspekt | `catch` | `try` |
|:-------|:--------|:------|
| Seit | Tcl 8.0 | Tcl 8.6 |
| Handler | Einer für alles | Mehrere, nach Code/Error-Code |
| Error-Code prüfen | Manuell mit `lindex` | `trap` mit Pattern |
| Ressourcen-Cleanup | Manuell | `finally`-Klausel |
| Einsatz | Einfache Fehlerbehandlung | Differenzierte Behandlung |

## Fehler auslösen: error und throw

### error

Der klassische Befehl um einen Fehler auszuloesen:

```tcl
error message ?errorInfo? ?errorCode?
```

```tcl
error "Datei nicht gefunden"
error "Ungültige Eingabe" "" {INPUT VALIDATION}
```

Das optionale `errorInfo`-Argument setzt den initialen Stack-Trace.
Das optionale `errorCode`-Argument setzt den maschinenlesbaren
Fehler-Code.

### throw

Seit Tcl 8.6. Erfordert immer einen Error-Code:

```tcl
throw errorCode message
```

```tcl
throw {INPUT VALIDATION} "Ungültige Eingabe"
throw {AUTH FORBIDDEN} "Zugriff nicht erlaubt"
throw {DB CONNECTION} "Datenbank nicht erreichbar"
```

### throw vs. error

| Aspekt | `error` | `throw` |
|:-------|:--------|:--------|
| Error-Code | Optional | Pflicht |
| errorInfo-Seed | Möglich | Nicht möglich |
| Empfehlung | Legacy, Weiterleitung | Neue Fehler auslösen |

`throw` ist vorzuziehen weil es einen Error-Code erzwingt,
was die programmatische Fehlerbehandlung erleichtert.

### Error-Code-Konventionen

Der Error-Code ist eine Liste. Konvention:

```tcl
# {MODUL GRUND ?details?}
throw {MYAPP NOTFOUND} "Eintrag nicht gefunden"
throw {MYAPP AUTH EXPIRED} "Token abgelaufen"
throw {MYAPP INPUT RANGE} "Wert ausserhalb des Bereichs"
```

Tcl-eigene Error-Codes beginnen mit `TCL`, `POSIX` oder `ARITH`:

```tcl
# Tcl-intern:
# TCL READ VARNAME      -> Variable nicht lesbar
# TCL LOOKUP VARNAME x  -> Variable x nicht gefunden
# POSIX ENOENT          -> Datei nicht gefunden
# POSIX EACCES          -> Keine Berechtigung
# ARITH DIVZERO         -> Division durch Null
# ARITH DOMAIN          -> Mathematischer Definitionsbereich
```

## Fehler auslösen: return -code error

`return -code error` bietet die meiste Kontrolle über die
Fehlererzeugung. Es erlaubt einen sauberen Stack-Trace und
zusätzliche Einträge im Options-Dictionary.

### Grundform

```tcl
proc validate {value} {
    if {$value < 0} {
        return -code error -errorcode {INPUT RANGE} \
            "Wert muss positiv sein: $value"
    }
}
```

### Sauberer Stack-Trace mit -level

Ein häufiges Problem: Hilfsprozeduren die Fehler auslösen,
verunreinigen den Stack-Trace mit ihren eigenen Frames:

```tcl
# Mit error: Stack-Trace zeigt check_integer internals
proc check_integer {arg} {
    if {![string is integer -strict $arg]} {
        error "$arg ist keine Zahl"
    }
}

proc tohex {arg} {
    check_integer $arg
    format %x $arg
}

tohex abc
# -> abc ist keine Zahl
# errorInfo zeigt: error "..." in check_integer Zeile 3,
#                  aufgerufen von tohex Zeile 2
```

Mit `return -level 2 -code error` wird der Fehler so ausgelöst,
als waere er direkt beim Aufrufer des Aufrufers entstanden:

```tcl
proc check_integer {arg} {
    if {![string is integer -strict $arg]} {
        return -level 2 -code error "$arg ist keine Zahl"
    }
}

tohex abc
# -> abc ist keine Zahl
# errorInfo zeigt nur: "tohex abc"
```

Der Stack-Trace ist sauberer und zeigt direkt den fehlerhaften Aufruf.

### Zusätzliche Informationen im Options-Dictionary

```tcl
proc loadConfig {file} {
    if {[catch {open $file r} fd ropts]} {
        return -options $ropts \
            -attemptedFile $file \
            -timestamp [clock seconds] \
            $fd
    }
    # ...
}
```

## Exceptions weiterleiten

### Mit return -options

Die zuverlaessigste Methode, eine gefangene Exception original
weiterzuleiten:

```tcl
proc wrapper {} {
    if {[catch { riskyOperation } result ropts]} {
        # Eigene Logik (Logging, Cleanup, ...)
        log "Fehler: $result"

        # Original-Exception weiterleiten
        return -options $ropts $result
    }
}
```

`return -options $ropts` übertraegt das gesamte Options-Dictionary
inklusive Stack-Trace, Error-Code und allen benutzerdefinierten
Eintraegen.

### Mit error (Legacy)

Aelterer Code verwendet `error` mit drei Argumenten:

```tcl
proc wrapper {} {
    if {[catch { riskyOperation } result]} {
        log "Fehler: $result"
        error $result $::errorInfo $::errorCode
    }
}
```

Nachteile dieser Methode:

- Kann nur Error-Exceptions weiterleiten (nicht break, continue, etc.)
- Benutzerdefinierte Options-Dictionary-Einträge gehen verloren
- Verwendet globale Variablen statt des lokalen Options-Dictionary

### Weiterleitung mit try

```tcl
proc wrapper {} {
    try {
        riskyOperation
    } on error {result ropts} {
        log "Fehler: $result"
        return -options $ropts $result
    }
}
```

## -level und -code im Detail

### Wie return normalerweise funktioniert

```tcl
return "wert"
# ist aequivalent zu:
return -code ok -level 1 "wert"
```

Der `return`-Befehl selbst liefert immer Return-Code 2/return.
Die Prozedur-Auswertung sieht Code 2, dekrementiert `-level` und:

- Wenn `-level` nach Dekrement 0 ist: Prozedur endet mit dem
  Code aus `-code` (normalerweise ok)
- Wenn `-level` größer als 0: Return-Code 2 wird weitergereicht,
  die nächste Prozedur-Ebene dekrementiert erneut

### -level 0: Sofortige Wirkung

Mit `-level 0` wird der `-code` direkt als Return-Code des
`return`-Befehls selbst verwendet:

```tcl
proc demo_level1 {} {
    puts "enter"
    return -code ok -level 1   ;# return-Befehl liefert Code 2
    puts "nie erreicht"        ;# Prozedur endet wegen Code 2
}

proc demo_level0 {} {
    puts "enter"
    return -code ok -level 0   ;# return-Befehl liefert Code 0 (ok)
    puts "wird erreicht!"      ;# Prozedur läuft weiter!
}
```

### -level 0 als Identitaets-Funktion

```tcl
set reciprocal [if {$n == 0} {
    return -level 0 Inf
} else {
    expr {1.0 / $n}
}]
```

`return -level 0` gibt den Wert direkt zurück, ohne die Prozedur
zu verlassen.

### Mehrere Stack-Ebenen überspringen

```tcl
proc innerHelper {} {
    return -level 3 -code ok "Wert aus der Tiefe"
}

proc middle {} {
    innerHelper
    puts "nie erreicht"
}

proc outer {} {
    middle
    puts "nie erreicht"
}
```

`-level 3` bewirkt, dass drei Prozedur-Ebenen übersprungen werden.
Bei jedem Prozedur-Return wird `-level` dekrementiert. Erst wenn
`-level` 0 erreicht, wird der Code aus `-code` als Return-Code
verwendet.

## Emulation anderer Befehle mit return

Da `break`, `continue` und `error` nur spezielle Return-Codes
erzeugen, kann `return` sie emulieren:

```tcl
# break emulieren:
proc stop {} { return -code break }

foreach x {1 2 3} { puts $x; stop }   ;# -> 1

# continue emulieren:
proc skip {} { return -code continue }

foreach x {1 2 3} { skip; puts $x }   ;# (keine Ausgabe)

# error emulieren:
proc fail {msg} { return -code error $msg }
```

## Benutzerdefinierte Return-Codes

Anwendungen können Codes ab 5 für eigene Zwecke verwenden:

```tcl
proc skip {count} {
    return -code 5 $count
}
```

Der Code wird wie jede Exception nach oben propagiert. Nur Befehle
die diesen Code kennen, können darauf reagieren:

```tcl
proc repeat {loopvar count body} {
    upvar 1 $loopvar iter
    for {set iter 0} {$iter < $count} {incr iter} {
        set rc [catch {uplevel 1 $body} result ropts]
        switch $rc {
            0 {}                          ;# ok: weiter
            3 { return }                  ;# break: Schleife beenden
            4 {}                          ;# continue: nächste Iteration
            5 { incr iter $result }       ;# skip: Iterationen überspringen
            default {
                dict incr ropts -level
                return -options $ropts $result
            }
        }
    }
}

repeat n 10 {
    puts "Iteration $n"
    if {$n == 1} { skip 3 }
}
# -> Iteration 0
#    Iteration 1
#    Iteration 5
#    ...
```

### dict incr ropts -level

Beim Weiterleiten in benutzerdefinierten Kontrollstrukturen muss
`-level` inkrementiert werden, weil die Prozedur selbst beim Return
`-level` dekrementiert. Eingebaute Befehle wie `for` und `while`
sind keine Prozeduren und dekrementieren `-level` nicht.

## Eigene Kontrollstrukturen

Das Zusammenspiel von `catch`, `uplevel` und Return-Codes ermöglicht
eigene Kontrollstrukturen die sich wie eingebaute verhalten:

### Vollständiges repeat

```tcl
proc repeat {loopvar count body} {
    upvar 1 $loopvar iter
    for {set iter 0} {$iter < $count} {incr iter} {
        set rc [catch {uplevel 1 $body} result ropts]
        switch $rc {
            0 {}
            3 { return }
            4 {}
            default {
                dict incr ropts -level
                return -options $ropts $result
            }
        }
    }
}
```

### Vollständiges withFile

```tcl
proc withFile {varName filename mode body} {
    upvar 1 $varName fd
    set fd [open $filename $mode]
    set rc [catch {uplevel 1 $body} result ropts]
    close $fd
    if {$rc != 0} {
        dict incr ropts -level
        return -options $ropts $result
    }
    return $result
}

withFile f "daten.txt" r {
    set content [read $f]
    if {[string length $content] == 0} {
        break   ;# funktioniert korrekt!
    }
}
```

### Muster für Kontrollstrukturen

1. `uplevel 1 $body` ausführen, mit `catch` umschlossen
2. Return-Code 0 (ok) und 4 (continue): normal weiterarbeiten
3. Return-Code 3 (break): Schleife/Block beenden
4. Alle anderen Codes: `-level` inkrementieren und weiterleiten

## Error-Information: errorInfo und errorCode

### Globale Variablen

Nach einem nicht abgefangenen Fehler setzt Tcl zwei globale
Variablen:

```tcl
catch {set x $nosuchvar}

puts $::errorInfo
# -> can't read "nosuchvar": no such variable
#    while executing
#    "set x $nosuchvar"

puts $::errorCode
# -> TCL READ VARNAME
```

### -errorinfo: Stack-Trace

Der Stack-Trace wird von Tcl automatisch aufgebaut während sich die
Exception durch den Call-Stack bewegt:

```tcl
proc c {} { error "kaputt" }
proc b {} { c }
proc a {} { b }

catch { a } result ropts

puts [dict get $ropts -errorinfo]
# -> kaputt
#    while executing
#    "error "kaputt""
#    (procedure "c" line 1)
#    invoked from within
#    "c"
#    (procedure "b" line 1)
#    invoked from within
#    "b"
#    (procedure "a" line 1)
#    ...
```

### -errorcode: Maschinenlesbarer Fehler-Code

Strukturiert als Liste, geeignet für programmatische Auswertung:

```tcl
if {[catch {open "x.txt" r} result ropts]} {
    set ec [dict get $ropts -errorcode]
    # ec ist z.B.: POSIX ENOENT {no such file or directory}
    switch [lindex $ec 0] {
        POSIX {
            switch [lindex $ec 1] {
                ENOENT { puts "Datei nicht gefunden" }
                EACCES { puts "Zugriff verweigert" }
                default { puts "OS-Fehler: [lindex $ec 1]" }
            }
        }
        default {
            return -options $ropts $result
        }
    }
}
```

### -errorstack: Strukturierter Stack

Seit Tcl 8.6. Wie `-errorinfo`, aber als maschinenlesbare Liste
aus abwechselnden Token-Wert-Paaren:

```tcl
proc b {} { error "kaputt" }
proc a {} { b }

catch { a } result ropts

puts [dict get $ropts -errorstack]
# -> INNER loadScalar1 CALL b CALL a
```

Token-Typen:

| Token | Bedeutung |
|:------|:----------|
| `INNER` | Interner Bytecode-Befehl |
| `CALL` | Prozeduraufruf (mit Argumenten) |
| `UP` | uplevel-Kontextwechsel |

Auch verfügbar über `info errorstack` (liefert den letzten Fehler).

### -errorline: Zeilennummer

```tcl
catch { set x $nosuchvar } result ropts
puts [dict get $ropts -errorline]   ;# -> 1
```

## Häufige Fehler

### catch ohne Options-Variable

```tcl
# SCHLECHT: errorCode nur über globale Variable erreichbar
if {[catch { riskyOp } result]} {
    puts $::errorCode   ;# globale Variable, fragil
}

# BESSER: Options-Dictionary verwenden
if {[catch { riskyOp } result ropts]} {
    puts [dict get $ropts -errorcode]
}
```

### error ohne Error-Code

```tcl
# SCHLECHT: Kein maschinenlesbarer Error-Code
error "Datei nicht gefunden"

# BESSER: throw mit Error-Code
throw {MYAPP FILE NOTFOUND} "Datei nicht gefunden"
```

### try-Handler in falscher Reihenfolge

```tcl
# FALSCH: on error fängt alles, trap wird nie erreicht
try {
    riskyOp
} on error {result} {
    puts "Fehler"
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"   ;# wird NIE ausgeführt!
}

# RICHTIG: trap vor on error
try {
    riskyOp
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"
} on error {result} {
    puts "Anderer Fehler"
}
```

### Fehler verschlucken

```tcl
# SCHLECHT: Alle Fehler ignoriert
catch { riskyOp }

# BESSER: Mindestens loggen
if {[catch { riskyOp } result]} {
    log "Fehler in riskyOp: $result"
}

# NOCH BESSER: Nur erwartete Fehler abfangen
try {
    riskyOp
} trap {EXPECTED ERROR} {result} {
    handleExpectedError $result
}
# Unerwartete Fehler werden automatisch weitergeleitet
```

### catch um break/continue

```tcl
# FALSCH: catch fängt auch break und continue!
foreach item $list {
    if {[catch { process $item } result]} {
        puts "Fehler: $result"
    }
    if {$done} break   ;# wird von catch NICHT abgefangen
                         ;# (anderer Schleifendurchlauf)
}

# ACHTUNG: Wenn break INNERHALB von catch steht:
foreach item $list {
    catch {
        process $item
        if {$done} break   ;# break wird von catch verschluckt!
    }
}

# BESSER: try mit on error (fängt nur Fehler)
foreach item $list {
    try {
        process $item
        if {$done} break   ;# break wird NICHT abgefangen, geht an foreach
    } on error {result} {
        puts "Fehler: $result"
    }
}
```

## Praxis-Patterns

### Retry-Pattern

Wiederholbare Operationen (Netzwerk, Datenbank) automatisch
erneut versuchen:

```tcl
proc retry {times delay script} {
    for {set i 0} {$i < $times} {incr i} {
        if {![catch {uplevel 1 $script} result]} {
            return $result
        }
        if {$i < $times - 1} {
            after $delay
        }
    }
    return -code error "Alle $times Versuche fehlgeschlagen: $result"
}

# Verwendung:
retry 3 1000 {
    set data [fetchData $url]
}
```

Variante mit exponentiellem Backoff:

```tcl
proc retryBackoff {times script} {
    for {set i 0} {$i < $times} {incr i} {
        if {![catch {uplevel 1 $script} result]} {
            return $result
        }
        if {$i < $times - 1} {
            set wait [expr {int(pow(2, $i) * 500)}]
            after $wait
        }
    }
    return -code error "Alle $times Versuche fehlgeschlagen: $result"
}
```

### Logging-System

Einfaches, erweiterbares Logging mit Leveln:

```tcl
namespace eval ::log {
    variable level 2
    variable levels {0 DEBUG 1 INFO 2 WARN 3 ERROR 4 FATAL}
    variable channel stderr
    variable file ""
}

proc ::log::setLevel {lvl} {
    variable level
    variable levels
    if {[string is integer -strict $lvl]} {
        set level $lvl
    } else {
        set idx [lsearch -exact $levels [string toupper $lvl]]
        if {$idx >= 0} {
            set level [expr {$idx / 2}]
        }
    }
}

proc ::log::setFile {filename} {
    variable file
    set file $filename
}

proc ::log::write {lvl msg} {
    variable level
    variable levels
    variable channel
    variable file

    if {$lvl < $level} return

    set ts [clock format [clock seconds] -format "%Y-%m-%d %H:%M:%S"]
    set name [lindex $levels [expr {$lvl * 2 + 1}]]
    set line "\[$ts\] \[$name\] $msg"

    puts $channel $line

    if {$file ne ""} {
        set fd [open $file a]
        try {
            puts $fd $line
        } finally {
            close $fd
        }
    }
}

# Convenience-Procs:
proc ::log::debug {msg} { write 0 $msg }
proc ::log::info  {msg} { write 1 $msg }
proc ::log::warn  {msg} { write 2 $msg }
proc ::log::error {msg} { write 3 $msg }
proc ::log::fatal {msg} { write 4 $msg }
```

Verwendung:

```tcl
::log::setLevel INFO
::log::setFile "app.log"

::log::info  "Anwendung gestartet"
::log::warn  "Konfiguration nicht gefunden, verwende Standard"
::log::error "Datenbankverbindung fehlgeschlagen"
```

### bgerror -- Globaler GUI-Error-Handler

Unbehandelte Fehler in Event-Callbacks (`after`, `bind`, `command`)
landen in `bgerror`. Standardmäßig zeigt Tk einen Dialog,
aber eine eigene Version ist fast immer besser:

```tcl
proc bgerror {msg} {
    ::log::error "Unbehandelter Fehler: $msg"
    ::log::error "Stack: $::errorInfo"

    tk_messageBox -icon error -title "Fehler" \
        -message "Ein Fehler ist aufgetreten:" \
        -detail $msg
}
```

Seit Tcl 8.6 kann alternativ `interp bgerror` verwendet werden:

```tcl
proc myBgError {msg opts} {
    set code [dict get $opts -errorcode]
    ::log::error "Background-Fehler \[$code\]: $msg"
}
interp bgerror {} myBgError
```

### Assertions und Preconditions

Defensive Programmierung mit fruehen Pruefungen:

```tcl
proc assert {condition {msg ""}} {
    if {![uplevel 1 [list expr $condition]]} {
        if {$msg eq ""} {
            set msg "Assertion fehlgeschlagen: $condition"
        }
        return -code error -errorcode {ASSERT FAILED} $msg
    }
}

proc processData {data} {
    assert {[llength $data] > 0} "Daten duerfen nicht leer sein"
    assert {[dict exists $data id]} "ID fehlt in Daten"
    # ... Verarbeitung ...
}
```

Design by Contract mit Vor- und Nachbedingungen:

```tcl
proc ::contract::require {condition msg} {
    if {![uplevel 1 [list expr $condition]]} {
        return -code error -errorcode {CONTRACT PRECONDITION} \
            "Vorbedingung verletzt: $msg"
    }
}

proc ::contract::ensure {condition msg} {
    if {![uplevel 1 [list expr $condition]]} {
        return -code error -errorcode {CONTRACT POSTCONDITION} \
            "Nachbedingung verletzt: $msg"
    }
}

proc withdraw {account amount} {
    ::contract::require {$amount > 0} "Betrag muss positiv sein"
    ::contract::require {[getBalance $account] >= $amount} "Nicht genug Guthaben"

    set newBalance [expr {[getBalance $account] - $amount}]
    setBalance $account $newBalance

    ::contract::ensure {[getBalance $account] >= 0} "Balance darf nicht negativ sein"
    return $newBalance
}
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `catch script ?resultVar? ?optsVar?` | Exception abfangen, Return-Code zurückgeben |
| `try body ?on/trap? ?finally?` | Strukturierte Fehlerbehandlung |
| `error message ?info? ?code?` | Fehler auslösen |
| `throw errorCode message` | Fehler mit Error-Code auslösen |
| `return -code error msg` | Fehler mit voller Kontrolle auslösen |
| `return -options $ropts $result` | Exception original weiterleiten |
| `return -level N -code error msg` | Fehler N Ebenen höher auslösen |

### Entscheidungshilfe

| Situation | Befehl |
|:----------|:-------|
| Neuen Fehler auslösen | `throw {CODE} "Nachricht"` |
| Fehler mit sauberem Stack | `return -level 2 -code error "msg"` |
| Einfach abfangen | `catch { ... } result` |
| Differenziert abfangen | `try { ... } trap {CODE} { ... }` |
| Ressource sicher schließen | `try { ... } finally { close $fd }` |
| Gefangene Exception weiterleiten | `return -options $ropts $result` |
| Eigene Kontrollstruktur | `catch` + `uplevel` + `dict incr ropts -level` |

## Siehe auch

- [Prozeduren](proc.md) -- `return -code error`, `return -level`
- [Trace](trace.md) -- Execution-Traces zum Debugging
- [Info](info.md) -- `info errorstack` (Tcl 8.7+)
- [Interpreter](interp.md) -- Error-Propagation zwischen Interpretern
- [TclOO](tcloo.md) -- Fehlerbehandlung in Methoden und Konstruktoren
- [Metaprogramming](metaprogramming.md) -- Eigene Kontrollstrukturen mit `catch`
