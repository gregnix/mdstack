# Globalisierung: Encoding, Lokalisierung, IDNA

*Stand: 2026-04-29*

Tcl unterstützt Globalisierung auf drei Ebenen: Zeichencodierung
für den Datenaustausch, Internationalisierung (Unicode-Strings
und -Befehle), und Lokalisierung mit dem msgcat-Paket für
mehrsprachige Anwendungen.

## Zeichencodierung (encoding)

Tcl-Strings sind intern Unicode-Codepoint-Sequenzen. Beim Speichern
oder Datenaustausch müssen sie in Byte-Sequenzen umgewandelt werden.
Die Methode dieser Umwandlung heisst Encoding.

Beispiel: Das Wort "Ola" (mit Akzent) als Byte-Sequenz:

| Encoding | Bytes (hex) |
|:---------|:------------|
| ISO8859-9 | 4f 6c e1 |
| UTF-8 | 4f 6c c3 a1 |
| UTF-16LE | 4f 00 6c 00 e1 00 |

### Unterstuetzte Encodings: encoding names

```tcl
encoding names
# -> cp860 cp861 ... utf-8 iso8859-1 ...
```

`utf-8` und `iso8859-1` sind immer verfügbar.

### Encoding-Profile (Tcl 9)

Profile steuern wie Fehler bei der Kodierung/Dekodierung
behandelt werden:

| Profil | Verhalten | Unicode-konform |
|:-------|:----------|:----------------|
| `strict` | Fehler auslösen (Standard in Tcl 9) | Ja |
| `replace` | Ungültige Bytes durch Ersatzzeichen ersetzen (U+FFFD bzw. `?`) | Ja |
| `tcl8` | Bytes als ISO8859-1 behandeln (stille Korruption) | Nein |

```tcl
encoding profiles
# -> replace strict tcl8
```

Profile sind in Tcl 8.6 nicht verfügbar -- dort werden Fehler
immer wie im `tcl8`-Profil behandelt.

### String kodieren: encoding convertto

```tcl
encoding convertto ?-profile PROFILE? ?-failindex VARNAME? ?ENC? STRING
```

Wandelt einen Tcl-String in eine Byte-Sequenz im Encoding `ENC` um:

```tcl
encoding convertto iso8859-9 $hello   ;# -> 4f 6c e1
encoding convertto utf-8 $hello       ;# -> 4f 6c c3 a1
encoding convertto utf-16le $hello    ;# -> 4f 00 6c 00 e1 00
```

#### Fehlerbehandlung

Wenn ein Zeichen im Ziel-Encoding nicht darstellbar ist:

```tcl
# Standard (strict): Fehler
encoding convertto ascii "Ola"
# -> Fehler: unexpected character at index 2

# replace: Ersatzzeichen verwenden
encoding convertto -profile replace ascii "Ola"
# -> Ol?

# failindex: Position des Fehlers zurückgeben
encoding convertto -failindex idx ascii "Ola"
# -> Ol   (idx = 2)

# Kein Fehler:
encoding convertto -failindex idx ascii "abc"
# -> abc  (idx = -1)
```

`-failindex` ergibt nur mit dem `strict`-Profil Sinn.

### Bytes dekodieren: encoding convertfrom

```tcl
encoding convertfrom ?-profile PROFILE? ?-failindex VARNAME? ENC BINARY
```

Umkehrung von `convertto` -- wandelt Byte-Sequenz in Tcl-String:

```tcl
encoding convertfrom cp1253 $cp1253bytes   ;# -> Griechischer Text
```

Fehlerbehandlung funktioniert analog zu `convertto`:

```tcl
# Bytes die kein gueltiges UTF-8 sind:
encoding convertfrom utf-8 $invalidBytes
# -> Fehler: unexpected byte sequence

encoding convertfrom -profile replace utf-8 $invalidBytes
# -> a<Ersatzzeichen>c

encoding convertfrom -profile tcl8 utf-8 $invalidBytes
# -> Stille Korruption (VERMEIDEN)
```

### Encoding-Verzeichnisse: encoding dirs

```tcl
encoding dirs ?DIRLIST?
```

Gibt die Verzeichnisse zurück in denen Encoding-Definitionen
(.enc-Dateien) gesucht werden. Mit Argument wird die Liste gesetzt:

```tcl
encoding dirs
# -> c:/tcl/lib/tcl9.0/encoding

# Eigenes Verzeichnis hinzufügen:
encoding dirs [linsert [encoding dirs] end /my/encodings]
```

### System-Encoding: encoding system

```tcl
encoding system ?ENC?
```

Das System-Encoding wird verwendet für:

- Systemaufrufe mit String-Argumenten (nicht Windows -- dort
  immer UTF-16 via Win32-API)
- Standard-Encoding für I/O-Kanäle (bis mit `chan configure`
  geändert)

```tcl
encoding system        ;# -> utf-8
encoding system cp1252 ;# System-Encoding ändern (Vorsicht!)
```

## Internationalisierung

Tcl-Strings unterstützen den gesamten Unicode-Zeichensatz.
Alle String-Befehle sind Unicode-fähig:

- `string is digit` erkennt Ziffern aller Schriftsysteme
- Reguläre Ausdrücke arbeiten mit Unicode-Properties
- Zeichen-Klassifizierung (`\w`, `\d` etc.) ist Unicode-konform

Tcl-Anwendungen sind dadurch inherent internationalisiert --
es sind keine zusätzlichen Massnahmen nötig.

## Lokalisierung mit msgcat

Das `msgcat`-Paket ermöglicht die Externalisierung aller
benutzersichtbaren Texte in Nachrichtenkataloge (Message Catalogs).

### Locales

Eine Locale identifiziert Sprache und Region:

| Format | Beispiel | Bedeutung |
|:-------|:---------|:----------|
| Sprache | `en` | Englisch (generisch) |
| Sprache_Land | `en_us` | Englisch (USA) |
| Sprache_Land_System | `de_de_unix` | Deutsch (Deutschland, Unix) |

Locales bilden eine Hierarchie: `en_us` -> `en` -> ROOT.
Wird ein Schlüssel in `en_us` nicht gefunden, wird in `en`
gesucht, dann in ROOT.

Beim Start wird die Locale aus den Umgebungsvariablen `LC_ALL`,
`LC_MESSAGES`, `LANG` (in dieser Reihenfolge) bestimmt. Unter
Windows aus der Registry. Fallback: `C`.

### Nachrichtenkataloge definieren

Katalogdateien heissen `LOCALE.msg` (Locale in Kleinbuchstaben)
und müssen UTF-8-kodiert sein.

#### mcset: Einzelne Übersetzung

```tcl
# en_us.msg
msgcat::mcset en_us hello "Wassup world!"
```

#### mcmset: Mehrere Übersetzungen

```tcl
# en.msg
msgcat::mcmset en {
    hello   "Hello world!"
    goodbye "Goodbye cruel world!"
    TIME    "The current time is %s"
}
```

#### mcflset/mcflmset: Locale aus Dateinamen

Innerhalb von Katalogdateien (geladen mit `mcload`) kann die
Locale aus dem Dateinamen abgeleitet werden:

```tcl
# fr.msg
msgcat::mcflset hello   "Bonjour le monde!"
msgcat::mcflset goodbye "Adieu monde cruel!"
msgcat::mcflset TIME    "L'heure actuelle est %s"

# de.msg
msgcat::mcflmset {
    hello   "Hallo Welt!"
    goodbye "auf Wiedersehen, grausame Welt!"
}
```

### Kataloge laden: mcload

```tcl
package require msgcat
msgcat::mcload [file join [file dirname [info script]] msgs]
# -> Anzahl geladener Locales
```

Katalogdateien werden typischerweise in einem `msgs/`-Unterverzeichnis
des Pakets gespeichert.

```tcl
# Geladene Locales abfragen:
msgcat::mcloadedlocales loaded
# -> en_us en {}

# Nicht mehr benoetigte Locales entladen:
msgcat::mcloadedlocales clear
```

### Übersetzungen abrufen: mc

```tcl
msgcat::mc KEY ?ARG ...?
```

Sucht den Schlüssel in der aktuellen Locale (und deren
Eltern-Locales):

```tcl
msgcat::mc hello
# -> Wassup world!   (wenn Locale = en_us)
```

Wird kein Eintrag gefunden, wird der Schlüssel selbst
zurückgegeben:

```tcl
msgcat::mc "Hi there!"
# -> Hi there!   (kein Katalogeintrag vorhanden)
```

#### Platzhalter mit format

Zusätzliche Argumente werden mit `format` in den
lokalisierten String eingesetzt:

```tcl
set now [clock format [clock seconds] -format %T]
msgcat::mc TIME $now
# -> The current time is 21:05:28
```

### Locale abrufen und setzen: mclocale

```tcl
msgcat::mclocale           ;# Aktuelle Locale abfragen
msgcat::mclocale fr        ;# Locale auf Franzoesisch setzen
msgcat::mc hello           ;# -> Bonjour le monde!
```

System-Locale ermitteln:

```tcl
msgcat::mcutil getsystemlocale
# -> en_us
```

Bei mehreren Interpretern: `mclocale` wirkt nur im aktuellen
Interpreter.

### Locale-Praeferenzen: mcpreferences

Die Suchreihenfolge für Übersetzungen:

```tcl
msgcat::mcpreferences
# -> en_us en {}

# Reihenfolge ändern (fr vor en):
msgcat::mcpreferences en_us fr {}
msgcat::mc goodbye
# -> Adieu monde cruel!   (en_us hat kein "goodbye", fr schon)
```

Praeferenzen für eine bestimmte Locale abfragen (ohne zu ändern):

```tcl
msgcat::mcutil getpreferences en_us
# -> en_us en {}

# Kombinierte Praeferenzen erstellen:
msgcat::mcpreferences {*}[lreplace \
    [msgcat::mcutil getpreferences en_us] end end \
    {*}[msgcat::mcutil getpreferences fr]]
# -> en_us en fr {}
```

### Laengste Übersetzung: mcmax

Nützlich für UI-Layout (z.B. Spaltenbreiten):

```tcl
msgcat::mcmax hello goodbye
# -> 20   (Länge der laengsten Übersetzung)
```

### Namespace-Partitionierung: mcn

Verschiedene Pakete können denselben Schlüssel mit verschiedenen
Übersetzungen verwenden, getrennt durch Namespaces:

```tcl
namespace eval ::anniversary {
    msgcat::mcset en greeting "Happy anniversary!"
}
namespace eval ::xmas {
    msgcat::mcset en greeting "Merry Christmas!"
}

# Lookup im jeweiligen Namespace:
namespace eval ::anniversary {msgcat::mc greeting}
# -> Happy anniversary!
namespace eval ::xmas {msgcat::mc greeting}
# -> Merry Christmas!

# Oder explizit mit mcn:
msgcat::mcn ::anniversary greeting   ;# -> Happy anniversary!
msgcat::mcn ::xmas greeting          ;# -> Merry Christmas!
```

Wird ein Schlüssel im Namespace nicht gefunden, werden
Eltern-Namespaces durchsucht:

```tcl
namespace eval ::anniversary::gold {msgcat::mc greeting}
# -> Happy anniversary!   (aus ::anniversary)
```

### Unbekannte Schlüssel: mcunknown, mcexists

```tcl
# Prüfen ob ein Schlüssel existiert:
msgcat::mcexists hello          ;# -> 1
msgcat::mcexists doesnotexist   ;# -> 0

# Nur exakte Locale (ohne Eltern):
msgcat::mcexists -exactlocale goodbye   ;# -> 0 (nur in en, nicht en_us)

# Nur exakter Namespace (ohne Eltern):
msgcat::mcexists -exactnamespace -namespace ::anniversary::gold greeting
# -> 0
```

`mcunknown` wird aufgerufen wenn `mc` keinen Eintrag findet.
Standard: gibt den Schlüssel zurück. Kann überschrieben werden:

```tcl
proc msgcat::mcunknown {locale key args} {
    puts stderr "WARNUNG: Fehlende Übersetzung: $key ($locale)"
    return $key
}
```

### Private Paket-Locales

Pakete können eigene Locale-Einstellungen unabhängig von
der globalen Locale verwalten. Vorteil: funktioniert auch in
OO-Klassen und -Methoden.

#### mcpackagelocale

```tcl
msgcat::mcpackagelocale get            ;# Paket-Locale abfragen
msgcat::mcpackagelocale set fr         ;# Paket-Locale setzen
msgcat::mcpackagelocale isset          ;# Private Locale gesetzt? (0/1)
msgcat::mcpackagelocale loaded         ;# Geladene Locales für Paket
msgcat::mcpackagelocale preferences    ;# Paket-Praeferenzen
msgcat::mcpackagelocale present LOCALE ;# Locale geladen? (0/1)
msgcat::mcpackagelocale unset          ;# Zur globalen Locale zurück
msgcat::mcpackagelocale clear          ;# Unbenoetigte Locales entladen
```

#### mcpackageconfig

```tcl
msgcat::mcpackageconfig get OPTION
msgcat::mcpackageconfig set OPTION VALUE
msgcat::mcpackageconfig isset OPTION
msgcat::mcpackageconfig unset OPTION
```

| Option | Beschreibung |
|:-------|:-------------|
| `changecmd` | Callback bei Locale-Änderung |
| `loadcmd` | Callback zum Laden von Katalogdateien |
| `mcfolder` | Verzeichnis mit Katalogdateien |
| `unknowncmd` | Paket-spezifischer mcunknown-Ersatz |

#### mcpackagenamespaceget

Liefert den Namespace des Pakets. Unterscheidet sich von
`namespace current` dadurch, dass in OO-Methoden der
definierende Namespace zurückgegeben wird (nicht der
Objekt-Namespace):

```tcl
namespace eval mypkg {
    oo::class create C {
        method demo {} {
            puts [namespace current]                ;# -> ::oo::Obj42
            puts [msgcat::mcpackagenamespaceget]     ;# -> ::mypkg
        }
    }
}
```

#### mcforgetpackage

Setzt alle privaten Locale-Einstellungen eines Pakets zurück:

```tcl
msgcat::mcforgetpackage
```

## Internationalisierte Domainnamen: tcl::idna

Das `tcl::idna`-Paket kodiert nicht-ASCII-Domainnamen nach
dem IDNA-Standard (Internationalized Domain Names in Applications).

```tcl
package require tcl::idna

tcl::idna encode "café.example"       ;# -> xn--caf-dma.example
tcl::idna decode "xn--caf-dma.example" ;# -> café.example

# Ungültige DNS-Zeichen:
tcl::idna encode "slash/invalid"
# -> Fehler: bad character "/" in DNS name
```

### Punycode direkt

IDNA basiert auf dem Punycode-Verfahren. Direkter Zugriff
ohne DNS-Validierung:

```tcl
tcl::idna puny encode "café"     ;# -> caf-dma
tcl::idna puny decode "caf-dma"   ;# -> café

# Punycode akzeptiert alle Zeichen:
tcl::idna puny encode "mit/slash"
# -> mit/slash-   (kein Fehler)
```

## Praxismuster

### Anwendung lokalisieren

```tcl
package require msgcat

# Kataloge laden (aus msgs/ Unterverzeichnis)
msgcat::mcload [file join [file dirname [info script]] msgs]

# Namespace importieren für Bequemlichkeit
namespace import msgcat::mc

# In der Anwendung:
puts [mc greeting]
wm title . [mc app_title]
tk_messageBox -message [mc confirm_delete]
```

### Locale zur Laufzeit wechseln

```tcl
proc switchLanguage {locale} {
    msgcat::mclocale $locale
    # UI-Texte aktualisieren
    updateAllLabels
}
```

### Encoding beim Dateizugriff

```tcl
# Datei mit bestimmtem Encoding lesen:
set fd [open "daten.txt" r]
chan configure $fd -encoding cp1252
set inhalt [read $fd]
close $fd

# Oder direkt konvertieren:
set bytes [read $fd]
set text [encoding convertfrom cp1252 $bytes]
```

### Encoding sicher konvertieren

```tcl
# Mit Fehlerposition:
set result [encoding convertfrom -failindex pos utf-8 $bytes]
if {$pos >= 0} {
    puts "Fehler an Position $pos"
    # Teilweise dekodierte Daten in $result
}

# Mit Ersatzzeichen:
set text [encoding convertfrom -profile replace utf-8 $bytes]
# Ungültige Bytes werden als U+FFFD angezeigt
```

## Zusammenfassung

### encoding-Befehle

| Befehl | Funktion |
|:-------|:---------|
| `encoding names` | Verfügbare Encodings auflisten |
| `encoding profiles` | Verfügbare Profile (Tcl 9) |
| `encoding convertto ?-profile P? ?ENC? STR` | String kodieren |
| `encoding convertfrom ?-profile P? ENC BIN` | Bytes dekodieren |
| `encoding dirs ?DIRLIST?` | Encoding-Verzeichnisse |
| `encoding system ?ENC?` | System-Encoding |

### msgcat-Befehle

| Befehl | Funktion |
|:-------|:---------|
| `msgcat::mcload DIR` | Katalogdateien laden |
| `msgcat::mc KEY ?ARG ...?` | Übersetzung abrufen |
| `msgcat::mcn NS KEY ?ARG ...?` | Übersetzung aus Namespace |
| `msgcat::mclocale ?LOCALE?` | Locale abrufen/setzen |
| `msgcat::mcpreferences ?LOCALE ...?` | Suchreihenfolge |
| `msgcat::mcset LOCALE KEY ?STR?` | Übersetzung definieren |
| `msgcat::mcmset LOCALE LIST` | Mehrere Übersetzungen |
| `msgcat::mcflset KEY ?STR?` | Locale aus Dateiname |
| `msgcat::mcflmset LIST` | Mehrere, Locale aus Dateiname |
| `msgcat::mcmax ?KEY ...?` | Laengste Übersetzung |
| `msgcat::mcexists ?OPTS? KEY` | Schlüssel vorhanden? |
| `msgcat::mcunknown LOCALE KEY` | Fallback (überschreibbar) |
| `msgcat::mcutil getsystemlocale` | System-Locale |
| `msgcat::mcutil getpreferences LOCALE` | Praeferenzen für Locale |
| `msgcat::mcloadedlocales loaded` | Geladene Locales |
| `msgcat::mcpackagelocale SUBCMD` | Private Paket-Locale |
| `msgcat::mcpackageconfig SUBCMD OPT` | Paket-Optionen |
| `msgcat::mcpackagenamespaceget` | Paket-Namespace |
| `msgcat::mcforgetpackage` | Paket-Locale zurücksetzen |

### Katalogdateien

| Dateiname | Locale |
|:----------|:-------|
| `de.msg` | Deutsch |
| `de_de.msg` | Deutsch (Deutschland) |
| `en.msg` | Englisch |
| `en_us.msg` | Englisch (USA) |
| `ROOT.msg` | Fallback |

## Siehe auch

- [Namespace](namespace.md) -- msgcat partitioniert nach Namespace
- [Package](package.md) -- Pakete mit Lokalisierung ausliefern
- [Info](info.md) -- `encoding system`, Plattform-Information
- [Code laden](source-eval-apply.md) -- `source -encoding` für Dateien
