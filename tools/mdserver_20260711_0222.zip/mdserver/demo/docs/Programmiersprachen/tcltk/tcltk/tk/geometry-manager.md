# Geometry Manager: pack, grid, place

*Stand: 2026-04-29*

Tk bietet drei Geometry Manager zur Platzierung von Widgets:
`pack` (linear stapeln), `grid` (tabellarisch anordnen) und
`place` (absolut positionieren). Jeder hat seinen Einsatzbereich.
Dieses Dokument erklärt alle drei Manager mit ihren Optionen,
typischen Layouts und häufigen Fallstricken.

## Grundprinzip

Geometry Manager bestimmen, **wo** und **wie gross** ein Widget
im übergeordneten Container (Parent) angezeigt wird. Ohne
Geometry Manager ist ein Widget unsichtbar -- es existiert
im Widget-Baum, wird aber nicht gezeichnet.

```tcl
ttk::button .btn -text "Klick"
# .btn existiert, ist aber unsichtbar

pack .btn
# Jetzt ist .btn sichtbar -- pack hat es platziert
```

### Wichtige Regel: Nie Manager mischen

In einem Container darf nur **ein** Manager verwendet werden.
Pack und Grid im selben Parent führt zu Endlosschleifen:

```tcl
# FALSCH -- führt zu Problemen:
pack .widget1
grid .widget2   ;# Im selben Parent!

# RICHTIG -- verschiedene Container:
ttk::frame .f1
ttk::frame .f2
pack .f1 .f2 -fill both -expand 1

pack .f1.widget1
grid .f2.widget2
```

## Pack -- Der Lineare

Pack stapelt Widgets in eine Richtung. Ideal für
einfache, lineare Layouts wie Toolbars, Statusleisten
oder vertikale Anordnungen.

### Richtung mit -side

```tcl
pack .w -side top      ;# Von oben (Standard)
pack .w -side bottom   ;# Von unten
pack .w -side left     ;# Von links
pack .w -side right    ;# Von rechts
```

Die Reihenfolge der `pack`-Aufrufe bestimmt die
Stapelreihenfolge. Jedes Widget "beansprucht" einen
Streifen des verbleibenden Platzes.

### Fill und Expand

`-fill` bestimmt, ob ein Widget den zugewiesenen Streifen
fuellt. `-expand` bestimmt, ob der Streifen den
überschuessigen Platz bekommt:

```tcl
# Nur horizontale Breite füllen
pack .w -fill x

# Nur vertikale Höhe füllen
pack .w -fill y

# Beide Richtungen füllen
pack .w -fill both

# Zusaetzlichen Platz beanspruchen UND füllen
pack .w -fill both -expand 1
```

Der Unterschied zwischen `-fill` und `-expand`:

| Kombination | Verhalten |
|:------------|:----------|
| Kein fill, kein expand | Widget behaelt Standardgroesse |
| `-fill x` | Widget fuellt die Breite des Streifens |
| `-fill both -expand 1` | Widget bekommt allen Extra-Platz |
| `-expand 1` ohne fill | Extra-Platz wird reserviert, Widget bleibt klein |

### Padding

```tcl
# Aussen (Abstand um das Widget herum)
pack .w -padx 10 -pady 5

# Asymmetrisch (Tcl 8.4+)
pack .w -padx {5 10} -pady {2 8}
# Links 5, rechts 10, oben 2, unten 8

# Innen (Widget wird größer)
pack .w -ipadx 5 -ipady 3
```

### Anchor

Bestimmt die Position des Widgets innerhalb seines
zugewiesenen Streifens, wenn das Widget kleiner ist:

```tcl
pack .w -anchor w       ;# Links ausrichten
pack .w -anchor center  ;# Zentriert (Standard)
pack .w -anchor ne      ;# Oben rechts
```

### Typisches Layout: Toolbar + Inhalt + Statusleiste

```tcl
ttk::frame .toolbar
pack .toolbar -side top -fill x

ttk::button .toolbar.new -text "Neu"
ttk::button .toolbar.open -text "Oeffnen"
ttk::button .toolbar.save -text "Speichern"
pack .toolbar.new .toolbar.open .toolbar.save -side left -padx 2

ttk::label .status -text "Bereit" -anchor w
pack .status -side bottom -fill x

text .content -wrap word
pack .content -fill both -expand 1
```

**Wichtig:** Die Reihenfolge ist entscheidend! Toolbar und
Statusleiste zuerst packen, dann den Inhalt mit `-expand 1`.
Sonst beansprucht der Inhalt allen Platz und die Statusleiste
wird abgeschnitten wenn das Fenster verkleinert wird.

### Pack-Optionen komplett

| Option | Beschreibung |
|:-------|:-------------|
| `-side` | Stapelrichtung: top, bottom, left, right |
| `-fill` | Fuellrichtung: none, x, y, both |
| `-expand` | Zusaetzlichen Platz beanspruchen: 0/1 |
| `-padx` | Horizontaler Aussenabstand |
| `-pady` | Vertikaler Aussenabstand |
| `-ipadx` | Horizontaler Innenabstand |
| `-ipady` | Vertikaler Innenabstand |
| `-anchor` | Position im Streifen: n, s, e, w, center, ne, ... |
| `-in` | Alternatives Parent-Widget |
| `-before` | Vor diesem Widget einfügen |
| `-after` | Nach diesem Widget einfügen |

## Grid -- Die Tabelle

Grid platziert Widgets in Zeilen und Spalten. Ideal für
Formulare, Dialoge und tabellarische Anordnungen.

### Grundform

```tcl
ttk::label .lName -text "Name:"
ttk::entry .eName

ttk::label .lEmail -text "Email:"
ttk::entry .eEmail

grid .lName  -row 0 -column 0
grid .eName  -row 0 -column 1

grid .lEmail -row 1 -column 0
grid .eEmail -row 1 -column 1
```

### Kurzform

Grid kann Zeilen und Spalten automatisch zuweisen:

```tcl
grid .lName  .eName
grid .lEmail .eEmail
# Automatisch Zeile 0 und 1, Spalten 0 und 1
```

Platzhalter `-` und `x`:

```tcl
grid .label .entry -      ;# entry über 2 Spalten (columnspan)
grid x      .btn          ;# Erste Spalte leer lassen
```

### Sticky -- Ausrichtung in der Zelle

Sticky bestimmt, an welchen Zellenraendern das Widget "klebt":

```tcl
grid .w -sticky w       ;# Links (west)
grid .w -sticky e       ;# Rechts (east)
grid .w -sticky n       ;# Oben (north)
grid .w -sticky s       ;# Unten (south)

grid .w -sticky we      ;# Horizontal füllen (west + east)
grid .w -sticky ns      ;# Vertikal füllen (north + south)
grid .w -sticky nsew    ;# Komplett füllen (alle Seiten)
```

Typisch: Labels mit `-sticky w` (linksbuendig), Entries
mit `-sticky we` (volle Breite):

```tcl
grid .label -sticky w
grid .entry -sticky we
```

### Spanning -- Zellen verbinden

```tcl
# Über 2 Spalten
grid .widget -row 0 -column 0 -columnspan 2

# Über 3 Zeilen
grid .widget -row 0 -column 2 -rowspan 3
```

### Weight -- Wachstumsverhalten

Ohne Weight wachsen Zeilen und Spalten nicht mit dem Fenster.
`weight` bestimmt, wie überschuessiger Platz verteilt wird:

```tcl
# Spalte 1 (Eingabefelder) bekommt allen Extra-Platz
grid columnconfigure . 1 -weight 1

# Zeile 2 (Textbereich) bekommt allen Extra-Platz
grid rowconfigure . 2 -weight 1

# Platz gleichmäßig auf Spalte 0 und 1 verteilen
grid columnconfigure . 0 -weight 1
grid columnconfigure . 1 -weight 1
```

### Minsize und Pad

```tcl
# Mindestbreite für Spalte 0
grid columnconfigure . 0 -minsize 100

# Zusätzlicher Abstand um Spalte 1
grid columnconfigure . 1 -pad 10
```

### Typisches Layout: Formular mit Buttons

```tcl
# Labels
ttk::label .lName  -text "Name:"  -anchor w
ttk::label .lEmail -text "Email:" -anchor w
ttk::label .lPhone -text "Telefon:" -anchor w

# Eingabefelder
ttk::entry .eName
ttk::entry .eEmail
ttk::entry .ePhone

# Layout
grid .lName  .eName  -sticky we -padx 5 -pady 2
grid .lEmail .eEmail -sticky we -padx 5 -pady 2
grid .lPhone .ePhone -sticky we -padx 5 -pady 2

# Button-Leiste
ttk::frame .buttons
ttk::button .buttons.ok -text "OK"
ttk::button .buttons.cancel -text "Abbrechen"
pack .buttons.ok .buttons.cancel -side left -padx 5

grid .buttons -row 3 -column 0 -columnspan 2 -pady 10

# Spalte 1 soll wachsen
grid columnconfigure . 1 -weight 1
```

### Grid-Optionen komplett

| Option | Beschreibung |
|:-------|:-------------|
| `-row` | Zeilennummer (0-basiert) |
| `-column` | Spaltennummer (0-basiert) |
| `-rowspan` | Über mehrere Zeilen |
| `-columnspan` | Über mehrere Spalten |
| `-sticky` | Ausrichtung: n, s, e, w und Kombinationen |
| `-padx` | Horizontaler Aussenabstand |
| `-pady` | Vertikaler Aussenabstand |
| `-ipadx` | Horizontaler Innenabstand |
| `-ipady` | Vertikaler Innenabstand |
| `-in` | Alternatives Parent-Widget |

### Zeilen/Spalten konfigurieren

| Befehl | Beschreibung |
|:-------|:-------------|
| `grid columnconfigure parent col -weight w` | Wachstum der Spalte |
| `grid rowconfigure parent row -weight w` | Wachstum der Zeile |
| `grid columnconfigure parent col -minsize n` | Mindestbreite |
| `grid columnconfigure parent col -pad n` | Zusätzlicher Abstand |
| `grid columnconfigure parent col -uniform group` | Gleiche Breite in Gruppe |

## Place -- Die Absolute

Place positioniert Widgets mit absoluten oder relativen
Koordinaten. Ideal für Overlays, schwebende Buttons
und spezielle Positionierungen.

### Absolute Positionierung

```tcl
place .widget -x 100 -y 50
# Widget an Pixel-Position (100, 50)

place .widget -x 100 -y 50 -width 200 -height 100
# Mit fester Größe
```

### Relative Positionierung

Werte von 0.0 bis 1.0, relativ zum Parent:

```tcl
# Zentriert
place .widget -relx 0.5 -rely 0.5 -anchor center

# Rechts unten
place .widget -relx 1.0 -rely 1.0 -anchor se

# Obere Haelfte füllen
place .widget -relx 0.0 -rely 0.0 \
    -relwidth 1.0 -relheight 0.5
```

### Anchor

Bestimmt, welcher Punkt des Widgets an den Koordinaten liegt:

```tcl
place .w -x 100 -y 100 -anchor nw      ;# Oben-links (Standard)
place .w -x 100 -y 100 -anchor center  ;# Mitte
place .w -x 100 -y 100 -anchor se      ;# Unten-rechts
```

### Kombination absolut + relativ

Absolute Werte werden zu relativen addiert. Das ermöglicht
Muster wie "rechts unten mit 10px Abstand":

```tcl
# Schwebender Button rechts unten mit Abstand
place .floatBtn -relx 1.0 -rely 1.0 -anchor se -x -10 -y -10
```

### Typisches Layout: Overlay

```tcl
# Hauptinhalt
text .content -wrap word
pack .content -fill both -expand 1

# Schwebender Hilfe-Button
ttk::button .help -text "?" -width 3 \
    -command showHelp
place .help -relx 1.0 -rely 1.0 -anchor se -x -15 -y -15

# Lade-Overlay (zentriert, halbtransparent)
ttk::label .loading -text "Laden..." \
    -font {TkDefaultFont 16} \
    -background white
place .loading -relx 0.5 -rely 0.5 -anchor center
# place forget .loading   ;# Overlay entfernen
```

### Place-Optionen komplett

| Option | Beschreibung |
|:-------|:-------------|
| `-x` | Absolute X-Position (Pixel) |
| `-y` | Absolute Y-Position (Pixel) |
| `-relx` | Relative X-Position (0.0 - 1.0) |
| `-rely` | Relative Y-Position (0.0 - 1.0) |
| `-width` | Absolute Breite |
| `-height` | Absolute Höhe |
| `-relwidth` | Relative Breite (0.0 - 1.0) |
| `-relheight` | Relative Höhe (0.0 - 1.0) |
| `-anchor` | Bezugspunkt: n, s, e, w, center, nw, ne, sw, se |
| `-in` | Alternatives Parent-Widget |
| `-bordermode` | inside (Standard) oder outside |

### place -in: Overlay-Frames auf Widgets

Mit `-in` kann ein Frame über einem anderen Widget schweben.
Typischer Einsatz: Linien oder Markierungen über einem
Text-Widget positionieren:

```tcl
# Frame als Kind des Text-Widgets erstellen
frame .txt._line -height 1 -bg "#c8d8e8"

# Auf dem Text-Widget platzieren (nicht im Parent!)
::place .txt._line -in .txt -x 0 -y 30 \
    -relwidth 1.0 -height 1
raise .txt._line
```

`-in .txt` bewirkt, dass die Koordinaten relativ zu `.txt`
sind, nicht zum übergeordneten Container. `raise` hebt
den Frame über den Text-Inhalt.

## Manager mischen -- Richtig

Verschiedene Manager in verschiedenen Containern kombinieren:

```tcl
# Hauptlayout mit Pack
ttk::frame .top
ttk::frame .bottom
pack .top -fill x
pack .bottom -fill both -expand 1

# Toolbar mit Pack (horizontal)
ttk::button .top.b1 -text "Datei"
ttk::button .top.b2 -text "Bearbeiten"
pack .top.b1 .top.b2 -side left -padx 2

# Formular mit Grid
ttk::label .bottom.lName -text "Name:"
ttk::entry .bottom.eName
grid .bottom.lName .bottom.eName -sticky we -padx 5
grid columnconfigure .bottom 1 -weight 1

# Overlay mit Place
ttk::label .bottom.overlay -text "Hinweis"
place .bottom.overlay -relx 1.0 -rely 0.0 -anchor ne
```

## Responsive Layouts

### Mindestgroesse setzen

```tcl
wm minsize . 400 300
wm maxsize . 1200 800    ;# Optional: Maximalgroesse
```

### Auf Größenänderung reagieren

```tcl
bind . <Configure> {
    if {%W eq "."} {
        puts "Neue Größe: %wx%h"
        # Layout anpassen...
    }
}
```

**Wichtig:** Das `%W eq "."` filtert Events von
Kind-Widgets heraus. Ohne diese Prüfung wird der
Handler bei jeder Widget-Änderung aufgerufen.

### Panedwindow für teilbare Bereiche

```tcl
ttk::panedwindow .paned -orient horizontal
pack .paned -fill both -expand 1

# Linke Seite (Baumansicht)
ttk::frame .paned.left
.paned add .paned.left -weight 1

# Rechte Seite (Inhalt)
ttk::frame .paned.right
.paned add .paned.right -weight 3

# Inhalt in den Bereichen
ttk::treeview .paned.left.tree
pack .paned.left.tree -fill both -expand 1

text .paned.right.text -wrap word
pack .paned.right.text -fill both -expand 1
```

### Notebook für Tabs

```tcl
ttk::notebook .nb
pack .nb -fill both -expand 1

ttk::frame .nb.tab1
ttk::frame .nb.tab2

.nb add .nb.tab1 -text "Datei"
.nb add .nb.tab2 -text "Einstellungen"

# Inhalt in Tabs
ttk::label .nb.tab1.info -text "Tab 1 Inhalt"
pack .nb.tab1.info -padx 20 -pady 20
```

## Layout-Debugging

### Widget-Informationen abfragen

```tcl
# Geometrie: BxH+X+Y
winfo geometry .widget    ;# -> 200x100+50+30

# Welcher Manager?
winfo manager .widget     ;# -> pack, grid oder place

# Ist sichtbar?
winfo viewable .widget    ;# -> 0 oder 1

# Alle Kinder
winfo children .          ;# -> .toolbar .content .status

# Angeforderte vs. tatsächliche Größe
winfo reqwidth .widget    ;# Gewuenschte Breite
winfo width .widget       ;# Tatsächliche Breite
```

### Manager-spezifische Informationen

```tcl
pack info .widget         ;# Alle pack-Optionen
grid info .widget         ;# Alle grid-Optionen
place info .widget        ;# Alle place-Optionen

# Grid-Struktur
grid size .               ;# -> Spalten Zeilen
grid slaves .             ;# Tcl 8.x
grid content .            ;# Tcl 9 (neuer Name)
```

### Widgets entfernen (ohne Zerstoerung)

```tcl
pack forget .widget       ;# Aus pack entfernen
grid forget .widget       ;# Aus grid entfernen (config bleibt)
grid remove .widget       ;# Aus grid entfernen (config verloren)
place forget .widget      ;# Aus place entfernen
```

Das Widget existiert weiter und kann später erneut
platziert werden -- nützlich für Show/Hide-Logik.

## Wann welchen Manager?

| Situation | Empfehlung | Grund |
|:----------|:-----------|:------|
| Toolbar, Statusleiste | pack | Einfache lineare Anordnung |
| Formular, Dialog | grid | Tabellarische Label/Entry-Paare |
| Hauptlayout (Toolbar + Content) | pack | Stapeln mit expand |
| Komplexes Formular mit Spanning | grid | columnspan, rowspan |
| Schwebende Buttons, Overlays | place | Absolute/relative Positionierung |
| Zweigeteilte Ansicht | ttk::panedwindow | Verschiebbare Trennlinie |
| Tab-basiertes Layout | ttk::notebook | Registerkarten |
| Komplexe Anwendung | Kombination | Frames als Container-Grenzen |

## Häufige Fehler

### Widget im falschen Container

```tcl
# FALSCH: .btn ist Kind von ".", wird aber "in" .container erwartet
ttk::frame .container
pack .container -fill both -expand 1
ttk::button .btn -text "Klick"
pack .btn
# .btn liegt NEBEN .container, nicht darin!

# RICHTIG: Widget als Kind des Containers erzeugen
ttk::frame .container
pack .container -fill both -expand 1
ttk::button .container.btn -text "Klick"
pack .container.btn
```

### Widget wächst nicht mit

```tcl
# FALSCH: fill ohne expand
text .t
pack .t -fill both
# .t fuellt den zugewiesenen Platz, bekommt aber keinen Extra-Platz

# RICHTIG: fill UND expand
text .t
pack .t -fill both -expand 1
```

### Grid-Zellen wachsen nicht

```tcl
# FALSCH: sticky gesetzt, aber kein weight
grid .widget -sticky nsew
# Widget fuellt die Zelle, aber die Zelle selbst ist minimal

# RICHTIG: weight für Zeile und Spalte setzen
grid .widget -sticky nsew
grid columnconfigure . 0 -weight 1
grid rowconfigure . 0 -weight 1
```

### Pack-Reihenfolge falsch

```tcl
# FALSCH: Inhalt zuerst, dann Statusleiste
text .content
pack .content -fill both -expand 1
ttk::label .status -text "Status"
pack .status -side bottom -fill x
# Bei Fensterverkleinerung wird .status abgeschnitten!

# RICHTIG: Statusleiste zuerst packen
ttk::label .status -text "Status"
pack .status -side bottom -fill x
text .content
pack .content -fill both -expand 1
```

### Widget-Name mit Grossbuchstabe

```tcl
# FALSCH: Grossbuchstabe am Anfang
ttk::label .fonts.TkDefaultFont -text "..."
# -> Error: window name starts with an upper-case letter

# RICHTIG: Kleinbuchstabe
ttk::label .fonts.tkdefaultfont -text "..."
```

### Manager im selben Container mischen

```tcl
# FALSCH: Endlosschleife möglich
ttk::label .l -text "Name:"
ttk::entry .e
pack .l
grid .e    ;# Beide im selben Parent "."!

# RICHTIG: Getrennte Container
ttk::frame .form
pack .form
ttk::label .form.l -text "Name:"
ttk::entry .form.e
grid .form.l .form.e -sticky we
```

### place/raise/lower in Namespaces

```tcl
# FALSCH: "place" kann mit eigenem Proc kollidieren
namespace eval mywidget {
    proc place {w x y} { ... }   ;# eigene Proc
    proc draw {} {
        place .line -x 10 -y 20  ;# ruft mywidget::place auf!
    }
}

# RICHTIG: Tk-Befehle global qualifizieren
namespace eval mywidget {
    proc draw {} {
        ::place .line -x 10 -y 20
        ::raise .line
        ::lower .bg
    }
}
```

Betrifft `place`, `raise`, `lower` -- überall wo
Namespace-Procs denselben Namen haben koennten.
Für `info`, `set`, `list` gilt dasselbe
(siehe FAQ Abschnitt 13).

## Zusammenfassung

### Pack

| Befehl | Funktion |
|:-------|:---------|
| `pack .w -side top` | Von oben stapeln |
| `pack .w -fill both -expand 1` | Allen Platz füllen |
| `pack .w -padx 10 -pady 5` | Aussenabstand |
| `pack forget .w` | Widget entfernen |
| `pack info .w` | Konfiguration abfragen |

### Grid

| Befehl | Funktion |
|:-------|:---------|
| `grid .w -row r -column c` | In Zelle platzieren |
| `grid .w -sticky nsew` | Zelle füllen |
| `grid .w -columnspan 2` | Über 2 Spalten |
| `grid columnconfigure . c -weight 1` | Spalte wächst |
| `grid rowconfigure . r -weight 1` | Zeile wächst |
| `grid remove .w` | Widget entfernen (Config behalten) |

### Place

| Befehl | Funktion |
|:-------|:---------|
| `place .w -x 100 -y 50` | Absolute Position |
| `place .w -relx 0.5 -rely 0.5 -anchor center` | Zentriert |
| `place .w -relwidth 1.0 -relheight 0.5` | Relative Größe |
| `place forget .w` | Widget entfernen |

### Entscheidungshilfe

| Frage | Antwort |
|:------|:--------|
| Lineares Stapeln? | pack |
| Zeilen/Spalten-Raster? | grid |
| Pixel-genaue Position? | place |
| Gemischtes Layout? | Frames als Container, je einen Manager pro Frame |
| Widget soll mitwachsen? | pack: `-expand 1`, grid: `-weight 1` |

## Siehe auch

- [Text-Widget Tags](text-widget-tags.md) -- Tags im Text-Widget
- [TclOO](tcloo.md) -- Widgets als Objekte kapseln
- [Fehlerbehandlung](error-handling.md) -- bgerror für GUI-Fehler
- [Namespace](namespace.md) -- GUI-Code in Namespaces organisieren
- [Info](info.md) -- `winfo` für Widget-Introspektion
