# Prozeduren (proc)

*Stand: 2026-04-29*

Prozeduren sind der zentrale Mechanismus um Code in Tcl wiederverwendbar
zu machen. Der `proc`-Befehl definiert eine benannte Prozedur mit
Parametern und einem Koerper.

## Grundsyntax

```tcl
proc name arglist body
```

- `name` -- der Name der Prozedur
- `arglist` -- die Parameterliste
- `body` -- der auszufuehrende Code

```tcl
proc greet {name} {
    return "Hallo $name"
}

puts [greet "Welt"]   ;# -> Hallo Welt
```

## Parameterliste

### Einfache Parameter

```tcl
proc add {a b} {
    expr {$a + $b}
}

add 3 4   ;# -> 7
```

### Standardwerte (Defaults)

Parameter mit Standardwert werden als Zweier-Liste angegeben:

```tcl
proc connect {host {port 8080} {timeout 30}} {
    puts "Verbinde mit $host:$port (Timeout: $timeout)"
}

connect "example.com"              ;# port=8080, timeout=30
connect "example.com" 443          ;# port=443, timeout=30
connect "example.com" 443 60       ;# port=443, timeout=60
```

Parameter mit Defaults müssen am Ende der Liste stehen, vor einem
eventuellen `args`.

### Variable Argumente (args)

Der spezielle Parametername `args` nimmt beliebig viele zusätzliche
Argumente als Liste auf:

```tcl
proc log {level msg args} {
    set extras [join $args ", "]
    puts "\[$level\] $msg $extras"
}

log INFO "Start"                    ;# -> [INFO] Start
log WARN "Fehler" "code=42" "retry" ;# -> [WARN] Fehler code=42, retry
```

`args` muss immer der letzte Parameter sein. Wenn keine zusätzlichen
Argumente übergeben werden, ist `args` eine leere Liste.

### Keine Parameter

```tcl
proc timestamp {} {
    clock format [clock seconds] -format "%Y-%m-%d %H:%M:%S"
}
```

### Parameterliste als String oder Liste

Die Parameterliste ist eine normale Tcl-Liste:

```tcl
# Beide Varianten sind aequivalent:
proc add {a b} { expr {$a + $b} }
proc add "a b" { expr {$a + $b} }
```

Für Defaults muss die Listenstruktur korrekt sein:

```tcl
proc test {{a 1} {b 2}} { expr {$a + $b} }
```

## Rückgabewerte

### Impliziter Rückgabewert

Ohne explizites `return` gibt eine Prozedur das Ergebnis des letzten
Befehls zurück:

```tcl
proc add {a b} {
    expr {$a + $b}
}
# expr gibt das Ergebnis zurück, das wird zum Rückgabewert
```

### Explizites return

```tcl
proc abs {x} {
    if {$x < 0} {
        return [expr {-$x}]
    }
    return $x
}
```

### return mit Optionen

`return` kann zusätzliche Optionen für die Fehlerbehandlung setzen:

```tcl
# Fehler erzeugen (aequivalent zu error)
return -code error "Ungültige Eingabe"

# Fehler weiterleiten mit originalem Stack
return -code error -errorcode {APP INPUT} -errorinfo $::errorInfo $msg

# break/continue aus einer Prozedur heraus
return -code break
return -code continue
```

Die `-code` Option bestimmt, wie der Aufrufer das `return` interpretiert:

| -code Wert | Wirkung |
|:-----------|:--------|
| `ok` (0) | Normaler Rückgabewert (Standard) |
| `error` (1) | Fehler, wie `error` |
| `return` (2) | Bewirkt `return` im Aufrufer |
| `break` (3) | Bewirkt `break` im Aufrufer |
| `continue` (4) | Bewirkt `continue` im Aufrufer |

## Prozeduren in Namespaces

### Definition innerhalb von namespace eval

```tcl
namespace eval app {
    proc start {} {
        puts "App gestartet"
    }
}

app::start
```

### Definition mit vollqualifiziertem Namen

```tcl
proc ::app::stop {} {
    puts "App gestoppt"
}

app::stop
```

Beide Varianten sind aequivalent. Die Variante innerhalb von
`namespace eval` ist ueblicher und lesbarer.

### Namespace-Variablen in Prozeduren

```tcl
namespace eval counter {
    variable count 0

    proc increment {} {
        variable count
        incr count
    }

    proc get {} {
        variable count
        return $count
    }
}
```

Ohne `variable count` innerhalb der Prozedur würde eine lokale
Variable erzeugt statt auf die Namespace-Variable zuzugreifen.

## Lokaler Scope

Jeder Prozeduraufruf erzeugt einen eigenen lokalen Scope:

- Variablen die innerhalb der Prozedur gesetzt werden, sind lokal.
- Lokale Variablen werden bei Rueckkehr automatisch zerstört.
- Es gibt keinen Zugriff auf Variablen des Aufrufers (ohne `upvar`).
- Es gibt keinen Zugriff auf globale Variablen (ohne `global`).

```tcl
set x 10

proc test {} {
    # x ist hier NICHT sichtbar
    set x 99           ;# lokales x, nicht das globale
    puts $x             ;# -> 99
}

test
puts $x                 ;# -> 10 (unverändert)
```

## Rekursion

Prozeduren können sich selbst aufrufen:

```tcl
proc factorial {n} {
    if {$n <= 1} {
        return 1
    }
    expr {$n * [factorial [expr {$n - 1}]]}
}

factorial 5   ;# -> 120
```

### Endrekursion mit tailcall

Seit Tcl 8.6. `tailcall` ersetzt den aktuellen Stack-Frame statt
einen neuen zu erzeugen, was Stack-Überlauf bei tiefer Rekursion
verhindert:

```tcl
proc factorial {n {acc 1}} {
    if {$n <= 1} {
        return $acc
    }
    tailcall factorial [expr {$n - 1}] [expr {$n * $acc}]
}

factorial 10000   ;# funktioniert ohne Stack-Überlauf
```

## Prozeduren umbenennen und löschen

### rename

```tcl
proc hello {} { return "hello" }

rename hello greet
greet          ;# -> hello
hello          ;# Fehler: invalid command name "hello"
```

### Löschen durch Umbenennen auf leeren String

```tcl
rename greet ""
greet          ;# Fehler: invalid command name "greet"
```

### Überschreiben

Eine neue `proc`-Definition mit demselben Namen überschreibt die
vorherige ohne Warnung:

```tcl
proc hello {} { return "v1" }
proc hello {} { return "v2" }
hello   ;# -> v2
```

## Proc-Namen: Wichtige Regeln

### Keine Tcl-Builtin-Namen verwenden

Prozedurnamen die Tcl-Kernbefehle überdecken, fuehren zu schwer
auffindbaren Fehlern:

```tcl
# VERBOTEN:
proc set {key value} { ... }    ;# überdeckt ::set
proc list {args} { ... }        ;# überdeckt ::list
proc info {args} { ... }        ;# überdeckt ::info
proc get {args} { ... }         ;# kollidiert leicht
proc init {} { ... }            ;# generisch, kollidiert leicht
```

Besser: Spezifische, beschreibende Namen:

```tcl
proc setValue {key value} { ... }
proc buildList {args} { ... }
proc initApp {} { ... }
```

### Namenskonventionen

- Englische Bezeichner: `loadConfig`, nicht `ladeKonfig`
- camelCase für Prozedurnamen
- Unterstrich-Präfix für private Helfer: `_parseArgs`
- Namespace qualifiziert für externe Aufrufe: `app::start`

## Prozeduren als Werte (Command Prefixes)

In Tcl sind Prozedurnamen Strings und können als Werte weitergegeben
werden:

```tcl
proc square {x} { expr {$x * $x} }

set fn square
$fn 5   ;# -> 25
```

### Command Prefix Pattern

Ein Command Prefix ist eine Liste bestehend aus Befehl und optionalen
festen Argumenten:

```tcl
proc multiply {factor x} {
    expr {$factor * $x}
}

set double [list multiply 2]
set triple [list multiply 3]

{*}$double 5   ;# -> 10
{*}$triple 5   ;# -> 15
```

### Callbacks mit Namespaces

Für Callbacks in Widgets oder nach `after` muss der vollqualifizierte
Name verwendet werden, oder `namespace code`:

```tcl
namespace eval app {
    proc onClick {} { puts "clicked" }

    # Variante 1: Vollqualifiziert
    set cmd [list ::app::onClick]

    # Variante 2: namespace code
    set cmd [namespace code onClick]
}
```

## Argumentvalidierung

Tcl prüft nur die Anzahl der Argumente, nicht deren Typ.
Validierung muss manuell erfolgen:

```tcl
proc divide {a b} {
    if {![string is double -strict $a]} {
        return -code error "a muss eine Zahl sein: $a"
    }
    if {![string is double -strict $b]} {
        return -code error "b muss eine Zahl sein: $b"
    }
    if {$b == 0} {
        return -code error "Division durch Null"
    }
    expr {double($a) / $b}
}
```

### Option-Parsing mit args

```tcl
proc createWidget {parent args} {
    # Defaults
    set opts [dict create -width 100 -height 50 -color "white"]
    # Übergebene Optionen einmischen
    foreach {key value} $args {
        if {![dict exists $opts $key]} {
            return -code error "Unbekannte Option: $key"
        }
        dict set opts $key $value
    }
    set w [dict get $opts -width]
    set h [dict get $opts -height]
    puts "Widget ${w}x${h}"
}

createWidget .f -width 200 -color "blue"
```

## Performance-Hinweise

### Bytecode-Kompilierung

Tcl kompiliert Prozeduren beim ersten Aufruf in Bytecode. Der zweite
und folgende Aufrufe sind deutlich schneller. Code auf Top-Level
(ausserhalb von Procs) wird nicht in Bytecode kompiliert.

Faustregel: Performance-kritischen Code immer in Prozeduren packen.

### expr mit geschweiften Klammern

```tcl
# LANGSAM (3-10x): expr ohne Klammern
proc slow {a b} { expr $a + $b }

# SCHNELL: expr mit Klammern
proc fast {a b} { expr {$a + $b} }
```

`expr` mit `{}` wird in Bytecode kompiliert. Ohne Klammern muss
jeder Aufruf neu geparst werden.

## Häufige Fehler

### Fehlende Klammern bei expr

```tcl
# FALSCH: Langsam und unsicher
proc calc {x} { expr $x * 2 }

# RICHTIG:
proc calc {x} { expr {$x * 2} }
```

### args nicht am Ende

```tcl
# FALSCH: args muss der letzte Parameter sein
proc test {args name} { ... }   ;# args frisst alle Argumente

# RICHTIG:
proc test {name args} { ... }
```

### Default-Parameter vor Pflichtparametern

```tcl
# FALSCH: Default vor Pflicht
proc test {{a 1} b} { ... }   ;# b ist nie erreichbar ohne a

# RICHTIG: Pflicht zuerst, dann Defaults
proc test {b {a 1}} { ... }
```

### Rückgabewert vergessen

```tcl
# FALSCH: puts gibt leeren String zurück
proc getMessage {} {
    set msg "Hallo"
    puts $msg            ;# gibt "" zurück, nicht $msg
}

# RICHTIG:
proc getMessage {} {
    set msg "Hallo"
    return $msg
}
```

## Zusammenfassung

| Aspekt | Syntax/Befehl |
|:-------|:-------------|
| Definition | `proc name arglist body` |
| Standardwert | `proc name {{param default}} body` |
| Variable Argumente | `proc name {a b args} body` |
| Rückgabe | `return ?-code type? ?value?` |
| Endrekursion | `tailcall procName args` |
| Umbenennen | `rename oldName newName` |
| Löschen | `rename procName ""` |
| Introspection | `info body`, `info args`, `info default` |
| Existenz prüfen | `info procs name` oder `info commands name` |

## Siehe auch

- [Variable Scope](variable-scope.md) -- Sichtbarkeit in und zwischen Prozeduren
- [Fehlerbehandlung](error-handling.md) -- `return -code error`, `throw`
- [Namespace](namespace.md) -- Procs in Namespaces organisieren
- [Metaprogramming](metaprogramming.md) -- Procs dynamisch erzeugen
- [Code laden](source-eval-apply.md) -- `apply` als anonyme Prozedur
- [Info](info.md) -- `info body`, `info args`, `info default`
