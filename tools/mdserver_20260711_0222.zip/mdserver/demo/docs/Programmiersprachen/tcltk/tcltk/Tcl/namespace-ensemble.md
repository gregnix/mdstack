# Namespace Ensemble

*Stand: 2026-04-29*

Ein Namespace Ensemble buendelt Prozeduren eines Namespaces zu einem einzigen
Befehl mit Unterbefehlen. Statt `math::add 3 4` schreibt man `math add 3 4`.
Das Ergebnis ist eine API im Stil der Tcl-Kernbefehle wie `string length`
oder `dict get`.

## Grundkonzept

Ein Ensemble-Befehl leitet Unterbefehle an Prozeduren im zugehoerigen
Namespace weiter. Der Mechanismus ist in den Tcl-Interpreter eingebaut und
daher schnell.

```tcl
namespace eval counter {
    namespace export increment get reset
    namespace ensemble create

    variable count 0

    proc increment {} {
        variable count
        incr count
    }

    proc get {} {
        variable count
        return $count
    }

    proc reset {} {
        variable count
        set count 0
    }
}

counter increment
counter increment
puts [counter get]     ;# -> 2
counter reset
puts [counter get]     ;# -> 0
```

## Ensemble erzeugen

### Automatisch aus exportierten Prozeduren

```tcl
namespace eval math {
    namespace export add subtract multiply
    namespace ensemble create

    proc add {a b} { expr {$a + $b} }
    proc subtract {a b} { expr {$a - $b} }
    proc multiply {a b} { expr {$a * $b} }
    proc _helper {x} { return $x }   ;# nicht exportiert, nicht im Ensemble
}

puts [math add 3 4]        ;# -> 7
puts [math subtract 10 3]  ;# -> 7
puts [math multiply 2 5]   ;# -> 10
```

Nur Prozeduren die per `namespace export` markiert sind, werden
zu Unterbefehlen. Private Helfer-Prozeduren bleiben verborgen.

### Mit expliziter Map

Die `-map` Option gibt volle Kontrolle über die Zuordnung von
Unterbefehl-Namen zu Prozeduren:

```tcl
namespace eval app {
    proc doStart {} { puts "starting" }
    proc doStop {} { puts "stopping" }
    proc doStatus {} { puts "running" }

    namespace ensemble create -map {
        start  doStart
        stop   doStop
        status doStatus
    }
}

app start    ;# -> "starting"
app stop     ;# -> "stopping"
```

Mit `-map` ist `namespace export` nicht nötig. Die Map kann auch auf
Prozeduren in anderen Namespaces oder auf beliebige Command-Prefixe
verweisen.

### Mit eigenem Befehlsnamen

Standardmäßig heisst der Ensemble-Befehl wie der Namespace.
Mit `-command` kann ein anderer Name gewählt werden:

```tcl
namespace eval ::impl::logging {
    namespace export info warn error
    namespace ensemble create -command ::log
}

log info "Nachricht"    ;# statt impl::logging::info
```

## Ensemble konfigurieren

### namespace ensemble configure

Liest oder aendert die Konfiguration eines existierenden Ensembles:

```tcl
# Konfiguration lesen
namespace ensemble configure math
# -> -map {add ::math::add subtract ::math::subtract ...} -namespace ::math ...

# Einzelne Option lesen
namespace ensemble configure math -map
# -> {add ::math::add subtract ::math::subtract multiply ::math::multiply}

# Konfiguration ändern
namespace ensemble configure math -map {
    add      ::math::add
    subtract ::math::subtract
    multiply ::math::multiply
    sum      ::math::add
}

# Jetzt funktioniert beides:
math add 3 4   ;# -> 7
math sum 3 4   ;# -> 7 (Alias)
```

### Verfügbare Optionen

| Option | Beschreibung |
|:-------|:-------------|
| `-map` | Dict von Unterbefehl zu Prozedur/Command-Prefix |
| `-namespace` | Zugehoeriger Namespace (nur lesbar) |
| `-command` | Name des Ensemble-Befehls |
| `-prefixes` | Abkürzungen erlauben (Standard: 1) |
| `-subcommands` | Liste der erlaubten Unterbefehle |
| `-unknown` | Handler für unbekannte Unterbefehle |
| `-parameters` | Zusätzliche Parameter vor dem Unterbefehl |

## Prefix-Matching

Standardmäßig erlaubt ein Ensemble eindeutige Abkürzungen:

```tcl
namespace eval fs {
    namespace export list create delete
    namespace ensemble create

    proc list {} { puts "listing" }
    proc create {name} { puts "creating $name" }
    proc delete {name} { puts "deleting $name" }
}

fs lis           ;# -> "listing" (eindeutig)
fs cr "test"     ;# -> "creating test" (eindeutig)
```

Abschalten mit:

```tcl
namespace ensemble configure fs -prefixes 0
fs lis           ;# Fehler: unknown subcommand "lis"
```

Für APIs die stabil bleiben sollen, ist `-prefixes 0` empfehlenswert.

## Die -subcommands Option

Beschraenkt die sichtbaren Unterbefehle, unabhängig von der Map:

```tcl
namespace eval app {
    namespace export start stop status debug
    namespace ensemble create -subcommands {start stop status}
}

app start     ;# OK
app debug     ;# Fehler: nicht in -subcommands
```

Wenn `-subcommands` gesetzt ist, wird `-map` nur für die Zuordnung
genutzt, aber die Sichtbarkeit wird durch `-subcommands` bestimmt.

## Die -unknown Option

Definiert einen Handler der aufgerufen wird, wenn ein Unterbefehl nicht
gefunden wird. Der Handler erhält den Ensemble-Befehl und die Argumente:

```tcl
namespace eval plugin {
    namespace ensemble create -unknown ::plugin::handleUnknown

    proc handleUnknown {ensemble subcmd args} {
        # Dynamisch nach einem Plugin suchen
        if {[file exists "plugins/$subcmd.tcl"]} {
            source "plugins/$subcmd.tcl"
            return [list ::plugin::$subcmd]
        }
        return -code error "Unbekanntes Plugin: $subcmd"
    }
}
```

Der Handler muss eine Liste zurückgeben, die als Command-Prefix
für den Aufruf verwendet wird.

## Die -parameters Option

Definiert zusätzliche Parameter, die zwischen dem Ensemble-Befehl
und dem Unterbefehl stehen. Damit kann man Objekt-ähnliche APIs bauen:

```tcl
namespace eval student {
    namespace ensemble create -parameters rec -map {
        name {::apply {{rec} {lindex $rec 0}}}
        age  {::apply {{rec} {lindex $rec 1}}}
    }
}

set s {Alice 22}
student $s name   ;# -> Alice
student $s age    ;# -> 22
```

## Existierende Ensembles erweitern

Da die Map ein Dict ist, kann sie nachträglich erweitert werden:

```tcl
# Vorhandene Map lesen
set map [namespace ensemble configure math -map]

# Neuen Unterbefehl hinzufügen
dict set map divide [list ::apply {{a b} {expr {double($a) / $b}}}]

# Zurueckschreiben
namespace ensemble configure math -map $map

math divide 10 3   ;# -> 3.3333333333333335
```

### Tcl-Kernbefehle erweitern

Das funktioniert auch mit Tcl-Kernbefehlen wie `string`, `encoding` etc.,
weil diese selbst als Ensembles implementiert sind:

```tcl
# encoding um convertfromhex erweitern
proc convertfromhex {args} {
    set hex [lpop args]
    return [encoding convertfrom {*}$args [binary decode hex $hex]]
}

set map [namespace ensemble configure ::encoding -map]
dict set map convertfromhex convertfromhex
namespace ensemble configure ::encoding -map $map

encoding convertfromhex iso8859-1 4142e9   ;# -> ABe (mit Akzent)
```

Vorsicht: Namenskollisionen mit zukuenftigen Tcl-Versionen sind möglich.
Ein Präfix hilft, z.B. `x-convertfromhex`.

## Pattern: Record-Typen mit Ensembles

Ensembles mit `-parameters` erlauben benannte Feld-Zugriffe auf Listen,
ohne Dicts verwenden zu müssen:

```tcl
proc record {recname fields} {
    if {[uplevel 1 [list namespace which $recname]] ne ""} {
        error "Befehl '$recname' existiert bereits."
    }
    set index -1
    set accessor [list ::apply {
        {index rec args}
        {
            if {[llength $args] == 0} {
                return [lindex $rec $index]
            }
            if {[llength $args] == 1} {
                return [lreplace $rec $index $index [lindex $args 0]]
            }
            error "Ungültige Argumentanzahl."
        }
    }]
    set map {}
    foreach field $fields {
        dict set map $field [linsert $accessor end [incr index]]
    }
    uplevel 1 [list namespace ensemble create \
        -command $recname -map $map -parameters rec]
}
```

Verwendung:

```tcl
record student {name age college}

set s {Alice 22 {College of Engineering}}

student $s name                     ;# -> Alice
student $s age                      ;# -> 22
set s [student $s age 23]           ;# -> Alice 23 {College of Engineering}
```

Das ist generisch und funktioniert für beliebige Record-Typen:

```tcl
record car {manufacturer model color}

set c {Ferrari CaliforniaT red}
car $c color                        ;# -> red
```

## Pattern: Command Objects mit Ensembles

Ensembles können "Objekte" simulieren, bei denen der Befehlsname
die Objektinstanz ist:

```tcl
namespace eval ordered_set {
    variable nextid 0
    variable sets {}

    proc add {id elem} {
        variable sets
        dict set sets $id $elem $elem
    }

    proc remove {id elem} {
        variable sets
        if {[dict exists $sets $id $elem]} {
            dict unset sets $id $elem
        }
    }

    proc contents {id} {
        variable sets
        return [dict keys [dict get $sets $id]]
    }

    proc cleanup {id args} {
        variable sets
        dict unset sets $id
    }

    proc new {} {
        variable nextid
        variable sets
        set objname "::oset#[incr nextid]"
        dict set sets $nextid [dict create]
        set map [dict create \
            add      [list add $nextid] \
            contents [list contents $nextid] \
            remove   [list remove $nextid] \
            destroy  [list ::rename $objname ""]]
        namespace ensemble create -command $objname -map $map
        trace add command $objname delete \
            [list [namespace current]::cleanup $nextid]
        return $objname
    }
}
```

Verwendung:

```tcl
set oset [ordered_set::new]   ;# -> ::oset#1
$oset add fee
$oset add fie
$oset add fo
$oset contents                 ;# -> fee fie fo
$oset add fie                  ;# Duplikat: Reihenfolge bleibt
$oset contents                 ;# -> fee fie fo
$oset remove fee
$oset contents                 ;# -> fie fo
$oset destroy                  ;# Objekt löschen
```

Das `trace add command ... delete` sorgt dafür, dass die Daten
aufgeraeumt werden wenn der Befehl gelöscht wird (auch per `rename "" ""`).

Hinweis: Für echte Objektorientierung ist TclOO besser geeignet.
Ensemble-Objekte sind nützlich für leichtgewichtige Fälle oder wenn
kein TclOO verfügbar ist.

## Verschachtelte Ensembles

Ensembles können verschachtelt werden, so dass ein Unterbefehl selbst
ein Ensemble ist. Viele Tcl-Kernbefehle nutzen dieses Muster:

```
string is integer "42"
```

Hier ist `string` ein Ensemble, `is` ein Unterbefehl der selbst ein
Ensemble ist, und `integer` ein Unterbefehl von `is`.

### Eigene verschachtelte Ensembles

```tcl
namespace eval db {
    namespace export query config

    namespace eval query {
        namespace export select insert
        namespace ensemble create

        proc select {table args} {
            return "SELECT * FROM $table"
        }

        proc insert {table data} {
            return "INSERT INTO $table ..."
        }
    }

    namespace eval config {
        namespace export get set_value
        namespace ensemble create

        variable settings [dict create host localhost port 5432]

        proc get {key} {
            variable settings
            return [dict get $settings $key]
        }

        proc set_value {key value} {
            variable settings
            dict set settings $key $value
        }
    }

    namespace ensemble create
}

db query select users        ;# -> "SELECT * FROM users"
db query insert users {a b}  ;# -> "INSERT INTO users ..."
db config get host           ;# -> "localhost"
```

### Verschachtelung über die Map

Alternativ ohne Kind-Namespaces, rein über die Map:

```tcl
namespace eval validator {
    proc isEmail {value} {
        string match "*@*.*" $value
    }
    proc isNumber {value} {
        string is double -strict $value
    }

    # Kind-Ensemble "is" als separater Namespace
    namespace eval is {
        namespace ensemble create -map {
            email  ::validator::isEmail
            number ::validator::isNumber
        }
    }

    namespace ensemble create -map {
        is ::validator::is
    }
}

validator is email "test@example.com"   ;# -> 1
validator is number "3.14"              ;# -> 1
```

## namespace ensemble exists

Prüft ob ein Befehl ein Ensemble ist:

```tcl
namespace ensemble exists string   ;# -> 1
namespace ensemble exists puts     ;# -> 0
namespace ensemble exists math     ;# -> 1 (wenn oben definiert)
```

Nützlich für generischen Code, der Ensembles dynamisch erweitern will:

```tcl
proc addSubcommand {ensemble name body} {
    if {![namespace ensemble exists $ensemble]} {
        error "$ensemble ist kein Ensemble"
    }
    set map [namespace ensemble configure $ensemble -map]
    dict set map $name [list ::apply [list args $body]]
    namespace ensemble configure $ensemble -map $map
}
```

## Ensemble vs. direkter Namespace-Aufruf

| Aspekt | Ensemble (`math add`) | Direkt (`math::add`) |
|:-------|:----------------------|:---------------------|
| Sichtbarkeit | Nur exportierte Procs | Alle Procs erreichbar |
| Abkürzungen | Prefix-Matching möglich | Nein |
| Erweiterbar | Map nachträglich änderbar | Neue Procs einfach hinzufügen |
| Fehlerbehandlung | -unknown Handler möglich | Standard: Fehler |
| Performance | Minimal langsamer (Dispatch) | Direkter Aufruf |
| API-Stil | Tcl-Kernbefehl-Stil | Namespace-Stil |

## Häufige Fehler

### Export vergessen

```tcl
# FALSCH: Ensemble ohne export hat keine Unterbefehle
namespace eval app {
    namespace ensemble create
    proc start {} { puts "start" }
}
app start   ;# Fehler: unknown subcommand "start"

# RICHTIG:
namespace eval app {
    namespace export start
    namespace ensemble create
    proc start {} { puts "start" }
}
```

Oder `-map` verwenden, dann ist kein Export nötig.

### Reihenfolge: export vor ensemble create

```tcl
# FALSCH: ensemble create vor export
namespace eval app {
    namespace ensemble create   ;# Map ist leer!
    namespace export start
    proc start {} { ... }
}

# RICHTIG: export zuerst, dann ensemble create
namespace eval app {
    proc start {} { ... }
    namespace export start
    namespace ensemble create
}
```

Alternativ funktioniert es, wenn die Procs schon existieren, weil
`namespace ensemble create` die aktuelle Export-Liste abfragt.

### rename statt namespace-qualifiziert

Beim Löschen von Ensemble-Objekten muss `rename` vollqualifiziert sein:

```tcl
# FALSCH: rename wird im aktuellen Namespace gesucht
set map [dict create destroy [list rename $objname ""]]

# RICHTIG: ::rename verwenden
set map [dict create destroy [list ::rename $objname ""]]
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `namespace ensemble create` | Ensemble aus exportierten Procs erzeugen |
| `namespace ensemble create -map dict` | Ensemble mit expliziter Zuordnung |
| `namespace ensemble create -command name` | Ensemble mit eigenem Befehlsnamen |
| `namespace ensemble configure cmd` | Konfiguration lesen |
| `namespace ensemble configure cmd -option value` | Konfiguration ändern |
| `namespace ensemble exists cmd` | Prüfen ob Befehl ein Ensemble ist |

## Siehe auch

- [Namespace](namespace.md) -- Grundlagen: `namespace eval`, `export`, `import`
- [Package](package.md) -- Pakete mit Ensemble-Interface bereitstellen
- [Prozeduren](proc.md) -- Procs als Unterbefehle eines Ensembles
- [TclOO](tcloo.md) -- Alternative: Objektorientierte Befehlsbuendelung
