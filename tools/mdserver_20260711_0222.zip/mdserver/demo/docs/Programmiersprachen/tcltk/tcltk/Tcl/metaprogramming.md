# Metaprogramming und Code-Konstruktion

*Stand: 2026-04-29*

Tcl behandelt Code als Daten. Scripts sind Strings die zur Laufzeit
konstruiert, manipuliert und ausgeführt werden können. Dieses
Kapitel behandelt Techniken zur dynamischen Code-Erzeugung und
-Ausführung.

## Command-Prefix vs. Script

Tcl-Befehle die Callbacks akzeptieren erwarten entweder ein
**Script** oder einen **Command-Prefix**. Der Unterschied ist
wichtig.

### Script-Callback

Ein Script wird als vollstaendiges Tcl-Script ausgeführt. Es kann
mehrere Befehle enthalten, getrennt durch `;` oder Zeilenumbruch:

```tcl
proc scriptCb {script} {
    uplevel 1 $script "(arg)"
}

scriptCb {puts A ; puts B}
# -> A
#    B (arg)
```

Typische Befehle die Scripts erwarten: `after`, `bind`, `if`,
`while`, `for`, `foreach`, `eval`, `uplevel`, `try`.

### Command-Prefix

Ein Command-Prefix ist eine Liste mit Befehlsname und optionalen
festen Argumenten. Zusätzliche Argumente werden beim Aufruf
angehängt:

```tcl
proc cmdCb {prefix} {
    {*}$prefix "(arg)"
}

cmdCb {puts -nonewline}
# -> (arg)
```

Typische Befehle die Command-Prefixes erwarten: `trace`, `lsort
-command`, `interp alias`, Tk-Widget `-command`-Optionen.

### Unterschiede im Überblick

| Aspekt | Script | Command-Prefix |
|:-------|:-------|:---------------|
| Format | String mit Tcl-Befehlen | Liste: `{cmd ?arg ...?}` |
| Trennzeichen | `;` und Newline trennen Befehle | Werden als Argumente behandelt |
| Substitution | Erneut geparst (Vorsicht!) | Keine erneute Substitution |
| Erzeugen | String-Operationen | `[list cmd arg ...]` |
| Ausführung | `eval`, `uplevel` | `{*}$prefix arg ...` |

### Command-Prefix erzeugen

Immer `list` verwenden um einen Command-Prefix sicher zu erzeugen:

```tcl
set value "Hallo Welt"

# RICHTIG: list schützt Leerzeichen und Sonderzeichen
set prefix [list myProc $value]

# FALSCH: String-Interpolation kann Parsing-Probleme verursachen
set prefix "myProc $value"   ;# -> myProc Hallo Welt (3 Woerter!)
```

### Anonyme Prozeduren als Command-Prefix

Statt eine benannte Prozedur zu definieren kann `apply` als
Command-Prefix verwendet werden:

```tcl
lsort -command [list apply {{a b} {
    expr {[string length $a] - [string length $b]}
}}] {abc de fghij}
# -> de abc fghij
```

Falls das `lambda`-Pattern (aus vielen Tcl-Frameworks) verfügbar ist:

```tcl
lsort -command [lambda {a b} {
    expr {[string length $a] - [string length $b]}
}] {abc de fghij}
```

## Scripts dynamisch konstruieren

### Methode 1: String-Verkettung

Flexibel, aber schlecht lesbar bei komplexen Scripts:

```tcl
set cmd "set result \[expr {"
append cmd "$a + $b"
append cmd "}\]"
eval $cmd
```

### Methode 2: String-Interpolation (Anführungszeichen)

Lesbar für einfache Scripts, aber Escaping wird schnell komplex:

```tcl
set varName "counter"
eval "incr $varName"
```

Vorsicht: Variablen und Befehle die zum generierten Script gehören
(nicht zur Erzeugung) müssen escaped werden:

```tcl
eval "proc demo {} { puts \$result }"
#                          ^-- Backslash weil $result zum
#                              generierten Script gehört
```

### Methode 3: Templates mit string map

Am besten lesbar für komplexe Scripts. Platzhalter werden durch
Werte ersetzt:

```tcl
set template {
    proc NAME {ARGS} {
        INIT
        proc NAME {ARGS} { BODY }
        tailcall {*}[info level 0]
    }
}

set replacements [list NAME $name ARGS $arglist INIT $init BODY $body]
eval [string map $replacements $template]
```

### Methode 4: Templates mit format

Alternative zu `string map` mit positionalen Platzhaltern:

```tcl
eval [format {
    proc %1$s {%2$s} {
        %3$s
        proc %1$s {%2$s} { %4$s }
        tailcall {*}[info level 0]
    }
} $name $arglist $init $body]
```

### Methode 5: subst

```tcl
set n 10
set body [subst -nocommands {
    for {set i 0} {\$i < $n} {incr i} {
        lappend result \$i
    }
}]
```

`subst` ersetzt Variablen und/oder Befehle in einem String.
Mit `-nocommands` werden nur Variablen substituiert.

## Metaprogramming-Muster

### Prozeduren mit einmaliger Initialisierung

Eine Prozedur die beim ersten Aufruf teure Initialisierung
durchführt und sich dann selbst neu definiert:

```tcl
proc proc_ex {name arglist initcode body} {
    # Namespace korrekt auflösen
    if {![string match ::* $name]} {
        set ns [uplevel 1 {namespace current}]
        set name ${ns}::$name
    }
    # Prozedur mit Selbst-Redefinition erzeugen
    set tmpl {
        proc NAME {ARGS} {
            INIT
            proc NAME {ARGS} { BODY }
            tailcall {*}[info level 0]
        }
    }
    set map [list NAME $name ARGS $arglist INIT $initcode BODY $body]
    eval [string map $map $tmpl]
}
```

Verwendung:

```tcl
proc_ex say_hello {message} {
    package require msgcat
} {
    puts [msgcat::mc $message]
}

say_hello "Hallo"   ;# Beim ersten Aufruf: package require
say_hello "Welt"    ;# Beim zweiten Aufruf: direkt
```

### Daten als Script transformieren

Strukturierte Daten können in Tcl-Scripts umgewandelt werden.
Das Script ruft für jedes Datenelement einen Callback auf:

```tcl
proc parseCSV {data callback} {
    foreach line [split $data \n] {
        if {$line eq ""} continue
        set fields [split $line ,]
        {*}$callback $fields
    }
}

parseCSV $csvData [list apply {{fields} {
    puts "Zeile: $fields"
}}]
```

### Verschachtelte Schleifen generieren

Statt feste Verschachtelungstiefe zu programmieren, kann die
Schleifenstruktur dynamisch aufgebaut werden:

```tcl
proc forall {args} {
    if {[llength $args] < 3 || [llength $args] % 2 == 0} {
        return -code error "wrong # args"
    }
    set body [lindex $args end]
    set args [lrange $args 0 end-1]
    while {[llength $args]} {
        set varName [lindex $args end-1]
        set list    [lindex $args end]
        set args    [lrange $args 0 end-2]
        set body    [list foreach $varName $list $body]
    }
    uplevel 1 $body
}

forall x {a b} y {1 2} {
    puts "$x-$y"
}
# -> a-1  a-2  b-1  b-2
```

Das Prinzip: Die innere Schleife wird zuerst als `foreach`-Befehl
konstruiert. Dann wird die nächste aeussere Schleife drum herum
gebaut. Am Ende wird das gesamte Script im Aufrufer-Kontext
ausgeführt.

### Generalisierte Tupel-Erzeugung

Aufbauend auf `forall`:

```tcl
proc tuples {args} {
    set res {}
    set listargs {}
    set body "lappend res \[list"
    foreach arg $args {
        set loopvar v[incr i]
        append body " \$$loopvar"
        lappend listargs $loopvar $arg
    }
    append body "\]"
    forall {*}$listargs $body
    return $res
}

tuples {1 2} {a b c}
# -> {1 a} {1 b} {1 c} {2 a} {2 b} {2 c}

tuples {1 2} {a b} {X Y}
# -> {1 a X} {1 a Y} {1 b X} {1 b Y} {2 a X} ...
```

## Namespace-Kontext in Callbacks

Die meisten Befehle (z.B. `after`) fuehren Script-Callbacks im
globalen Kontext aus. Um einen Callback in einem bestimmten
Namespace auszuführen:

```tcl
# Methode 1: namespace code (erzeugt ein Wrapper-Script)
namespace eval myns {
    after 1000 [namespace code { doSomething }]
}

# Methode 2: Vollqualifizierte Befehle
after 1000 [list ::myns::doSomething]

# Methode 3: namespace inscope
after 1000 [list namespace inscope ::myns { doSomething }]
```

Für Command-Prefixes reicht der vollqualifizierte Name:

```tcl
trace add variable x write [list ::myns::handler]
```

## Aufrufer-Namespace ermitteln

Wenn ein Befehl neue Befehle erzeugt, muss der Name im richtigen
Namespace angelegt werden:

```tcl
proc newobj {name} {
    if {[string match ::* $name]} {
        set cmdname $name
    } else {
        set ns [uplevel 1 {namespace current}]
        if {$ns eq "::"} {
            set cmdname ::$name
        } else {
            set cmdname ${ns}::$name
        }
    }
    if {[namespace which -command $cmdname] ne ""} {
        error "Befehl $name existiert bereits"
    }
    proc $cmdname {} "puts {Ich bin $cmdname}"
}

newobj cmd1                      ;# -> ::cmd1
namespace eval ns { newobj cmd2 } ;# -> ::ns::cmd2
newobj ::global                  ;# -> ::global
```

## Call-Frames und info frame

### Welche Befehle erzeugen Call-Frames

| Befehl | Neuer Call-Frame | Grund |
|:-------|:-----------------|:------|
| `proc`-Aufruf | Ja | Lokale Variablen |
| Methoden-Aufruf | Ja | Lokale Variablen |
| `namespace eval` | Ja | Namespace-Kontext |
| `apply` | Ja | Lokale Variablen |
| Coroutine | Ja | Eigener Kontext |
| `eval` | Nein | Kein eigener Scope |
| `source` | Nein | Kein eigener Scope |
| `try` | Nein | Kein eigener Scope |
| `if`, `while` | Nein | Kein eigener Scope |

Prüfung:

```tcl
info level                         ;# -> 0  (global)
eval {info level}                  ;# -> 0  (kein neuer Frame)
namespace eval ns {info level}     ;# -> 1  (neuer Frame)
apply {{} {info level}}            ;# -> 1  (neuer Frame)
```

### info frame

`info frame` liefert Metainformationen über versteckte Frames
die `info level` nicht zeigt. Primär für Debugger nützlich.

```tcl
proc demo {} {
    puts "level=[info level], frame=[info frame]"
    eval {
        puts "eval: level=[info level], frame=[info frame]"
    }
}

demo
# -> level=1, frame=2
#    eval: level=1, frame=3
```

`eval` erhoet den Frame-Zähler aber nicht den Level-Zähler.

```tcl
info frame 0
# Dictionary mit:
#   cmd   - Aktueller Befehl
#   type  - "source", "proc", "eval", "uplevel", "precompiled"
#   file  - Quelldatei (bei type=source)
#   line  - Zeilennummer
#   proc  - Prozedurname
#   level - Call-Stack-Level
```

## Command History

### history (interaktiver Modus)

Im interaktiven Modus speichert Tcl eine Historie aller
eingegebenen Befehle:

```tcl
history                  ;# Alle Einträge anzeigen
history info ?count?     ;# Letzte count Einträge
history nextid           ;# Nächste Sequenznummer
history event ?spec?     ;# Eintrag abrufen
history redo ?spec?      ;# Eintrag erneut ausführen
history add cmd ?exec?   ;# Eintrag hinzufügen (optional ausführen)
history change cmd ?spec? ;# Eintrag ändern
history clear            ;# Historie löschen
history keep ?count?     ;# Max. Einträge abrufen/setzen
```

Referenzierung von Eintraegen:

| Form | Bedeutung |
|:-----|:----------|
| Positive Zahl | Sequenznummer |
| Negative Zahl | Relativ zur aktuellen Position |
| String | Präfix-Suche, dann Glob-Suche |

### info cmdcount

Zaehlt alle Befehlsaufrufe seit Interpreter-Start:

```tcl
info cmdcount   ;# -> 417604

proc makeId {{prefix id}} {
    return ${prefix}[info cmdcount]
}

makeId       ;# -> id417609
makeId coro  ;# -> coro417612
```

Nützlich für eindeutige Identifier. Alternativ einen eigenen
Zähler verwenden.

## Sicherheitshinweise

### eval mit Benutzereingaben

Dynamisch konstruierte Scripts die Benutzereingaben enthalten
sind ein Sicherheitsrisiko:

```tcl
# GEFAEHRLICH: Injection möglich
eval "process $userInput"

# SICHER: list schützt den Wert
eval [list process $userInput]

# NOCH BESSER: Kein eval nötig
process $userInput
```

### Daten-zu-Script-Transformation

Wenn externe Daten in Scripts umgewandelt werden, sollte das
generierte Script in einem sicheren Interpreter ausgeführt werden:

```tcl
set safeInterp [interp create -safe]
interp eval $safeInterp $generatedScript
```

## Der unknown-Handler

Wenn Tcl einen unbekannten Befehl trifft, ruft es den `unknown`-Handler
auf. Standardmäßig versucht dieser Auto-Loading, aber er kann
überschrieben werden:

### Eigener unknown-Handler

```tcl
proc unknown {cmd args} {
    puts stderr "Unbekannter Befehl: $cmd"

    # Ähnliche Befehle vorschlagen
    set similar [info commands ${cmd}*]
    if {$similar ne ""} {
        puts stderr "Meinten Sie: [join $similar {, }]?"
    }

    return -code error "Befehl '$cmd' nicht gefunden"
}

xyz 1 2 3
# -> Unbekannter Befehl: xyz
# -> Meinten Sie: ...?
```

### Auto-Loading eigener Module

```tcl
# Original sichern
rename unknown _original_unknown

proc unknown {cmd args} {
    # Eigene Module zuerst versuchen
    set file [file join $::app_dir lib ${cmd}.tcl]
    if {[file exists $file]} {
        source $file
        if {[info commands $cmd] ne ""} {
            return [$cmd {*}$args]
        }
    }
    # Fallback auf Standard-unknown
    return [_original_unknown $cmd {*}$args]
}
```

### Abkürzungen mit unknown

```tcl
proc unknown {cmd args} {
    # Eindeutige Abkürzungen auflösen
    set matches [info commands ${cmd}*]
    if {[llength $matches] == 1} {
        return [[lindex $matches 0] {*}$args]
    }
    return -code error "Unbekannter Befehl: $cmd"
}

# Jetzt funktioniert:
stri length "test"   ;# -> string length "test" -> 4
```

**Achtung:** `unknown` in Namespaces funktioniert nicht automatisch.
Für Ensemble-Befehle gibt es stattdessen die `-unknown`-Option
(siehe [Namespace Ensemble](namespace-ensemble.md)).

## Befehl-Wrapping mit rename

Mit `rename` kann ein bestehender Befehl umbenannt und durch einen
Wrapper ersetzt werden:

### Logging-Wrapper

```tcl
# Original sichern
rename puts _original_puts

# Wrapper mit Zeitstempel
proc puts {args} {
    set ts [clock format [clock seconds] -format "%H:%M:%S"]

    # Argumente korrekt weiterleiten
    if {[llength $args] == 1} {
        _original_puts "\[$ts\] [lindex $args 0]"
    } elseif {[llength $args] == 2} {
        set chan [lindex $args 0]
        if {$chan eq "-nonewline"} {
            _original_puts -nonewline "\[$ts\] [lindex $args 1]"
        } else {
            _original_puts $chan "\[$ts\] [lindex $args 1]"
        }
    } else {
        _original_puts {*}$args
    }
}

puts "Server gestartet"
# -> [14:30:45] Server gestartet
```

### Befehle zählen

```tcl
proc wrapWithCounter {cmd} {
    set counter "::_count_$cmd"
    set counter_var [string map {:: _} $counter]
    set $counter_var 0

    rename $cmd _wrapped_$cmd

    proc $cmd {args} [string map \
        [list %CMD% _wrapped_$cmd %VAR% $counter_var] {
        incr ::%VAR%
        %CMD% {*}$args
    }]
}

wrapWithCounter string
string length "test"
string range "Hello" 0 2
puts "string wurde $::_count_string mal aufgerufen"
# -> string wurde 2 mal aufgerufen
```

### Befehl löschen

```tcl
rename gefaehrlicherBefehl ""   ;# Loescht den Befehl komplett
```

**Vorsicht bei rename:**
- Nie den Wrapper-Body so schreiben, dass er sich selbst aufruft
  (Endlosschleife)
- `rename` wirkt global -- auch Code in anderen Packages sieht den Wrapper
- In Produktion besser Execution-Traces statt rename verwenden
  (siehe [Trace](trace.md))

## Domain Specific Languages (DSL)

Tcl eignet sich hervorragend für DSLs, weil die Syntax flexibel ist
und Code = Daten gilt. Der Ansatz: Einen eigenen Interpreter erstellen,
der nur die DSL-Befehle kennt:

### Konfigurations-DSL

```tcl
proc parseConfig {body} {
    # Sicherer Interpreter (kein file, exec etc.)
    set interp [interp create -safe]

    # DSL-Befehle definieren
    $interp eval {
        set ::_config [dict create]

        proc option {name value} {
            dict set ::_config $name $value
        }
        proc enable {feature} {
            dict set ::_config $feature 1
        }
        proc disable {feature} {
            dict set ::_config $feature 0
        }
        proc section {name body} {
            set sub [dict create]
            # Temporaer innere Befehle umleiten
            proc option {k v} "dict set ::_config ${name},$k \$v"
            eval $body
        }
    }

    # DSL ausführen
    $interp eval $body

    # Ergebnis holen und aufräumen
    set result [$interp eval {set ::_config}]
    interp delete $interp
    return $result
}

# Verwendung:
set cfg [parseConfig {
    option timeout 30
    option retries 3
    enable  logging
    disable debug
}]

dict get $cfg timeout   ;# -> 30
dict get $cfg logging   ;# -> 1
```

### Test-DSL

```tcl
proc describe {name body} {
    puts "Suite: $name"
    set ::_test_pass 0
    set ::_test_fail 0
    eval $body
    puts "  Ergebnis: $::_test_pass bestanden, $::_test_fail fehlgeschlagen"
}

proc it {description body} {
    if {[catch $body result]} {
        incr ::_test_fail
        puts "  FAIL: $description -- $result"
    } else {
        incr ::_test_pass
        puts "  OK:   $description"
    }
}

proc expect {actual op expected} {
    switch $op {
        eq { if {$actual ne $expected} { error "$actual != $expected" } }
        == { if {$actual != $expected} { error "$actual != $expected" } }
        >  { if {$actual <= $expected} { error "$actual <= $expected" } }
    }
}

# Verwendung:
describe "Mathematik" {
    it "addiert korrekt" {
        expect [expr {2 + 2}] == 4
    }
    it "multipliziert korrekt" {
        expect [expr {3 * 7}] == 21
    }
}
# -> Suite: Mathematik
# ->   OK:   addiert korrekt
# ->   OK:   multipliziert korrekt
# ->   Ergebnis: 2 bestanden, 0 fehlgeschlagen
```

### DSL-Prinzipien

| Prinzip | Umsetzung |
|:--------|:----------|
| Isolation | Safe-Interpreter oder eigener Namespace |
| Einfachheit | Wenige, klare Befehle |
| Sicherheit | Kein Zugriff auf Dateisystem/exec |
| Ergebnis | Strukturierte Daten (Dict) zurückgeben |
| Fehlerbehandlung | Klare Meldungen bei Syntaxfehlern |

## Zusammenfassung

| Technik | Einsatz |
|:--------|:--------|
| `[list cmd arg ...]` | Command-Prefix sicher erzeugen |
| `string map` + Template | Komplexe Scripts aus Vorlagen generieren |
| `format` + Template | Alternative zu string map |
| `subst` | Variablen in Script-Templates ersetzen |
| `uplevel 1 $body` | Script im Aufrufer-Kontext ausführen |
| `tailcall {*}$prefix` | Command-Prefix ohne Stack-Wachstum delegieren |
| `namespace code` | Namespace-Kontext für Callbacks bewahren |
| Selbst-Redefinition | Einmalige Initialisierung |
| `unknown` | Handler für unbekannte Befehle, Auto-Loading |
| `rename` + Wrapper | Bestehende Befehle erweitern (Logging, Counting) |
| DSL mit `interp -safe` | Eigene Mini-Sprachen in isolierter Umgebung |

## Siehe auch

- [Code laden](source-eval-apply.md) -- `eval`, `uplevel`, `apply`
- [Prozeduren](proc.md) -- Procs dynamisch erzeugen und umdefinieren
- [Namespace](namespace.md) -- `namespace code`, `namespace inscope`
- [Info](info.md) -- `info frame`, `info level`, Stack-Introspektion
- [Trace](trace.md) -- Traces für Selbstmodifikation und Lazy-Init
- [Interpreter](interp.md) -- Code-Ausführung in Kind-Interpretern
- [String-Modell](string-modell.md) -- Homoikonizitaet: Code = Daten
- [Substitution](substitution-escaping.md) -- Parsing bei dynamischer Codeerzeugung
