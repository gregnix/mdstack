# Emoji und Unicode-Sonderzeichen

*Stand: 2026-04-29*

Wo Emojis und Unicode-Symbole funktionieren, wo nicht, und
welche Alternativen es gibt. Betrifft vier Schichten: Tk-Widgets,
PDF-Erzeugung, Markdown-Dokumentation und Terminals.


## Übersicht nach Schicht

| Schicht | Emojis | Unicode-Symbole | Deutsche Umlaute |
|---------|--------|-----------------|------------------|
| Tk Text-Widget | unzuverlässig | teilweise | ja |
| pdf4tcl (WinAnsi) | nein, Crash | nein, Crash | ja |
| pdf4tcllib (safeText) | ersetzt durch ASCII | ersetzt durch ASCII | ja |
| Markdown-Dateien | verboten (Regel) | verboten (Regel) | ja |
| Terminal/Console | abhängig vom System | abhängig vom System | ja |


## Tk und Emojis

Tk unterstützt Emojis nicht zuverlässig. Das Ergebnis hängt ab
von Betriebssystem, installierten Fonts, Tk-Version und Theme.

```tcl
;# unreliable -- may show empty rectangle or question mark:
ttk::button .btn -text "\U0001F4C1 Open"
ttk::label .lbl -text "\u26A1 Fast"
```

| Symptom | Ursache |
|---------|---------|
| Leeres Rechteck | Font hat kein Emoji-Glyph |
| Fragezeichen | Encoding-Problem |
| Korrektes Emoji | Zufaellig passender Font |

### Alternativen in Tk

Statt Text-Emojis:

```tcl
;# WRONG -- unreliable:
ttk::button .open -text "\U0001F4C1 Open"

;# RIGHT -- plain text:
ttk::button .open -text "Open..."

;# BEST -- icon images:
ttk::button .open -image $folderIcon -compound left -text "Open"
```

Für einfache Symbole (Haekchen, Kreuz, Pfeil) kann Canvas
verwendet werden:

```tcl
canvas .check -width 16 -height 16
.check create line 3 8 6 11 13 4 -width 2 -fill green
```

### Unicode-Escape-Syntax

```tcl
;# \u works up to U+FFFF:
set bullet "\u2022"    ;# bullet

;# \U required for higher codepoints (Tcl 8.6+):
set folder "\U0001F4C1"  ;# folder emoji -- but display unreliable
```

Wichtig: `\u` funktioniert nur bis U+FFFF. Für hoehere Codepoints
`\U` mit bis zu 8 Hex-Ziffern verwenden.


## pdf4tcl und Unicode

pdf4tcl verwendet WinAnsiEncoding (identisch mit Latin-1, U+0000
bis U+00FF). Alles darüber verursacht Crash oder Dateikorruption.

### Was in WinAnsi enthalten ist

Alle westeuropaeischen Zeichen, einschliesslich:

| Zeichen | Unicode | In WinAnsi? |
|---------|---------|-------------|
| ä ö ü ß | U+00E4, U+00F6, U+00FC, U+00DF | Ja |
| Ä Ö Ü | U+00C4, U+00D6, U+00DC | Ja |
| e a i o u (Akzente) | U+00E8 - U+00FC | Ja |
| Zeichen 0x20-0x7E | ASCII-Bereich | Ja |

### Was NICHT in WinAnsi enthalten ist

| Zeichen | Unicode | Crash? |
|---------|---------|--------|
| Pfeile (rechts, links) | U+2192, U+2190 | Ja |
| Haekchen, Kreuz | U+2713, U+2717 | Ja |
| Box-Drawing | U+2500-U+257F | Ja |
| Em-Dash, En-Dash | U+2014, U+2013 | Ja |
| Euro-Zeichen | U+20AC | Ja |
| Alle Emojis | U+1F300+ | Ja |
| Bullet | U+2022 | Ja |

### pdf4tcllib als Lösung

`pdf4tcllib::unicode::safeText` ersetzt nicht-unterstuetzte Zeichen
durch ASCII-Aequivalente:

```tcl
package require pdf4tcllib 0.1
pdf4tcllib::fonts::init

;# safe -- replaces unsupported chars with ASCII:
pdf4tcllib::unicode::safeText $pdf "Price: 25\u20AC \u2192 done" -x 50 -y 100
;# output: "Price: 25EUR -> done"
```

Ersetzungstabelle (Auszug):

| Original | Ersetzung |
|----------|-----------|
| U+2192 (Pfeil rechts) | -> |
| U+2190 (Pfeil links) | <- |
| U+2022 (Bullet) | * |
| U+2014 (Em-Dash) | -- |
| U+2013 (En-Dash) | - |
| U+20AC (Euro) | EUR |
| U+2713 (Haekchen) | [x] |
| U+2717 (Kreuz) | [ ] |

### DejaVu-Fonts erweitern den Bereich

Wenn `pdf4tcllib::fonts::init` DejaVu Sans Condensed TTF-Fonts
findet, stehen zusätzlich ~256 Zeichen zur Verfügung, darunter
Box-Drawing, Pfeile und Haekchen. Der Font wird automatisch
registriert wenn er im `-fontdir` liegt.


## Markdown-Dokumentation

Laut rules-md.md sind Emojis und Unicode-Symbole in Markdown-Dateien
verboten. Gruende:

1. mdviewer (Tk Text-Widget) rendert sie unzuverlässig
2. mdpdf (pdf4tcl) crasht oder ersetzt sie
3. Terminals können sie falsch darstellen
4. Diff-Tools und grep haben Probleme

### Was erlaubt ist

Reguläre ASCII-Interpunktion und deutsche Umlaute:

```markdown
Die Änderungen werden übernommen.
Größe: 42cm
Preis: 25 EUR (nicht 25€)
```

### Was verboten ist

```markdown
;# WRONG:
## ✅ Erledigt
## ⚡ Performance
Pfeil → zeigt auf Ergebnis

;# RIGHT:
## Erledigt
## Performance
Pfeil zeigt auf Ergebnis (-->)
```

### Alternativen in Markdown

| Statt | Verwenden |
|-------|-----------|
| -> (Pfeil) | --> oder "zeigt auf" |
| <- (Pfeil) | <-- oder "von" |
| Haekchen | [x] (Task-Liste) |
| Kreuz | [ ] (Task-Liste) |
| Bullet | - (Listenzeichen) |
| Euro | EUR |


## Nroff-Sonderzeichen

Der nroff-Parser kennt 51 Sonderzeichen-Escapes (`\(xx`), die in
Tcl/Tk-Manpages verwendet werden. Diese werden im Renderer in
Unicode umgewandelt für das Tk Text-Widget und in ASCII für
PDF/Text-Export.

| Escape | Unicode | ASCII-Fallback | Vorkommen |
|--------|---------|----------------|-----------|
| `\(bu` | U+2022 (Bullet) | * | 77x |
| `\(em` | U+2014 (Em-Dash) | -- | 12x |
| `\(en` | U+2013 (En-Dash) | - | 11x |

Nur diese drei kommen in den 229 Tcl/Tk-Seiten tatsächlich vor.
Alle 51 werden trotzdem unterstützt (siehe nroff-knowledge.md).


## Lint-Prüfung

```bash
;# Find non-ASCII characters in Markdown:
grep -P '[^\x00-\x7F]' file.md

;# Find emojis specifically:
grep -P '[\x{1F300}-\x{1F9FF}]' file.md

;# Find problematic Unicode for pdf4tcl:
grep -P '[\x{0100}-\x{FFFF}]' file.md
```

Die dritte Prüfung findet alles über Latin-1 -- das sind die
Zeichen die pdf4tcl ohne Sanitization nicht verarbeiten kann.


## string trim und BMP-Symbole (Tcl 8.6)

`string trim` ohne expliziten Charset trimmt alle Unicode-Whitespace-Zeichen,
einschliesslich U+0085 (NEL, Next Line). Viele BMP-Symbole haben `\x85`
als letztes UTF-8-Byte — sie werden von `string trim` abgeschnitten.

| Symbol | Codepoint | UTF-8 | Letztes Byte |
|--------|-----------|-------|--------------|
| ✅ | U+2705 | `E2 9C 85` | `85` = NEL — GEFAEHRLICH |
| ❌ | U+274C | `E2 9D 8C` | `8C` — sicher |
| ✓ | U+2713 | `E2 9C 93` | `93` — sicher |

```tcl
# BUG in Tcl 8.6:
string trim " ✅ "        ;# -> "â"  (FALSCH!)

# Fix: Charset explizit angeben
string trim " ✅ " " \t"   ;# -> "✅" (KORREKT)
```

**Regel:** Immer `string trim $var " \t"` statt `string trim $var`
wenn der String BMP-Symbole enthalten kann.
Betrifft besonders: Tabellenzellen, Inline-Inhalte, Konfigurationswerte
die aus Dateien gelesen werden.
