# binary scan / binary format - Fallen

*Stand: 2026-05-25*

`binary scan` (Bytes -> Tcl-Werte) und `binary format` (Tcl-Werte -> Bytes)
sind das inverse Paar für den Umgang mit Binärdaten: Bild-Header, ZIP-Records,
Netzwerk-Protokolle, Dateiformate. Sie sind mächtig, aber voller stiller Fallen
-- Vorzeichen, Byte-Reihenfolge, Encoding. Dieses Dokument sammelt die, über
die man real stolpert (Bsp. aus PNG/JPEG/GIF-Header- und ZIP-Parsing).

## Grundkonzept

```tcl
# scan: Bytes -> Variablen. Rückgabewert = Anzahl gefüllter Variablen!
set n [binary scan $bytes "format" var1 var2 …]

# format: Werte -> Byte-String
set bytes [binary format "format" wert1 wert2 …]
```

```tcl
# Beispiel: zwei 16-bit-Little-Endian-Zahlen lesen
binary scan $data ss a b      ;# a, b aus den ersten 4 Bytes
# und zurückschreiben
set data [binary format ss $a $b]
```

## Die Format-Spezifizierer (die wichtigsten)

| Spez. | Bedeutung | Größe |
|-------|-----------|-------|
| `c`   | Integer | 1 Byte |
| `s` / `S` | Integer **little** / **big**-endian | 2 Byte |
| `i` / `I` | Integer **little** / **big**-endian | 4 Byte |
| `w` / `W` | Integer little / big-endian | 8 Byte |
| `f` / `d` | float / double | 4 / 8 Byte |
| `a` / `A` | Byte-String / leerzeichen-aufgefüllt | n Byte |
| `H` / `h` | Hex (high- / low-nibble zuerst) | n Nibble |
| `x` | Null-Byte (format) / überspringen (scan) | 1 Byte |
| `X` / `@` | zurück / absolute Position | -- |

Merksatz Byte-Reihenfolge: **Großbuchstabe = Big-Endian** (`S`/`I`/`W`),
Kleinbuchstabe = Little-Endian (`s`/`i`/`w`). `c` (1 Byte) hat keine Reihenfolge.

Ein angehängter Zähler wiederholt: `s3` = drei 16-bit-Werte (in **eine** Liste),
`c*` = alle restlichen Bytes als Liste von Integers.

## Falle 1: Vorzeichen -- alles ist signed

`c`, `s`, `i` liefern **vorzeichenbehaftete** Integer. Ein Byte `0xFF` wird zu
`-1`, nicht `255`. Für vorzeichenlose Werte maskiert man.

```tcl
# FALSCH: Byte als unsigned erwartet
binary scan $data c b
puts $b            ;# -> -1  (für Byte 0xFF), nicht 255

# RICHTIG: Maske anwenden
binary scan $data c b
set b [expr {$b & 0xff}]      ;# -> 255

# 16-bit unsigned:
binary scan $data S w
set w [expr {$w & 0xffff}]

# 32-bit unsigned (in Tcl mit großen Integern problemlos):
binary scan $data I size
set size [expr {$size & 0xffffffff}]
```

Das ist *die* häufigste binary-Falle. In jedem Header-Parser (Längen, Maße,
Offsets sind nie negativ) gehört die Maske dazu.

## Falle 2: Byte-Reihenfolge ist formatabhängig

Verschiedene Formate verwenden verschiedene Endianness -- man muss sie wissen:

```tcl
# PNG: IHDR-Breite/Höhe sind BIG-endian 32-bit -> "I"
binary scan [string range $png 16 23] II width height

# GIF: Logical Screen Descriptor, Breite/Höhe LITTLE-endian 16-bit -> "s"
binary scan [string range $gif 6 9] ss width height
set width  [expr {$width  & 0xffff}]
set height [expr {$height & 0xffff}]

# ZIP: alle Mehr-Byte-Felder LITTLE-endian -> "s"/"i"
binary scan $localHeader "a2 s s s s s i i i s s" sig ver flags method t d crc cs us nl el
```

```tcl
# FALSCH: PNG mit Little-Endian gelesen -> unsinnige Maße
binary scan [string range $png 16 23] ii width height   ;# falsch herum

# RICHTIG: PNG ist Big-Endian
binary scan [string range $png 16 23] II width height
```

## Falle 3: Binärdaten als Binär lesen (Encoding!)

Liest man eine Binärdatei wie Text, mangelt das Encoding/Translation die Bytes
(CR/LF-Umwandlung, UTF-8-Interpretation) -- der Header ist dann Müll.

```tcl
# FALSCH: Standard-Translation/Encoding verfälscht Bytes
set fh [open bild.png r]
set bytes [read $fh]; close $fh

# RICHTIG (Tcl 9 / 8.6): Binärmodus
set fh [open bild.png rb]            ;# 'b' = binär
set bytes [read $fh]; close $fh
# oder explizit:
set fh [open bild.png r]
fconfigure $fh -translation binary -encoding binary
set bytes [read $fh]; close $fh
```

Gleiches gilt beim **Schreiben** von Binärdaten (`open … wb`). Wer ZIP/Bilder
ohne Binärmodus schreibt, zerstört die Datei.

## Falle 4: Rückgabewert ist die Konversionszahl, nicht die Daten

`binary scan` liefert die **Anzahl** erfolgreich gefüllter Variablen zurück --
nützlich, um abgeschnittene/zu kurze Daten zu erkennen.

```tcl
# RICHTIG: prüfen, ob alle Felder gelesen wurden
if {[binary scan $data "II" w h] != 2} {
    error "Daten zu kurz für zwei 32-bit-Werte"
}
```

```tcl
# Falsch gedacht: der Rückgabewert ist NICHT der gelesene Wert
set w [binary scan $data I w]    ;# w (das Ergebnis) ist 1, nicht der Integer!
# Der eingelesene Wert steht in der VARIABLEN, hier zufällig auch 'w' -> Verwirrung.
```

## Falle 5: a vs. A, x/@ für Positionierung

```tcl
# a: exakte Bytes inkl. Nullbytes/Spaces
# A: trailing Spaces UND Nullbytes werden entfernt
binary scan $data "a4" tag           ;# z.B. "PK\x03\x04"
binary scan $data "A8" name          ;# rechts getrimmt

# x = Byte überspringen, @N = an absolute Position springen
binary scan $data "@18 s" -> w       ;# ab Offset 18 ein 16-bit-Wert
binary scan $data "x4 i" len         ;# 4 Bytes überspringen, dann 32-bit
```

`@` ist bequemer als wiederholtes `string range`, wenn man an verschiedene
Offsets eines Headers springt.

## Praxis: Header-Parser

### PNG-Maße

```tcl
proc pngSize {bytes} {
    # Signatur prüfen
    if {[string range $bytes 1 3] ne "PNG"} { error "kein PNG" }
    # IHDR-Breite/Höhe: Big-Endian 32-bit ab Offset 16
    binary scan [string range $bytes 16 23] II w h
    return [list $w $h]      ;# PNG-Maße sind nie negativ -> Maske unnötig
}
```

### GIF-Maße

```tcl
proc gifSize {bytes} {
    if {[string range $bytes 0 2] ne "GIF"} { error "kein GIF" }
    binary scan [string range $bytes 6 9] ss w h     ;# Little-Endian 16-bit
    return [list [expr {$w & 0xffff}] [expr {$h & 0xffff}]]
}
```

### JPEG-Maße (Marker-Lauf)

```tcl
proc jpegSize {bytes} {
    set n [string length $bytes]; set i 2
    while {$i < $n - 1} {
        binary scan [string index $bytes $i] c b; set b [expr {$b & 0xff}]
        if {$b != 0xFF} { incr i; continue }
        binary scan [string index $bytes [expr {$i+1}]] c m; set m [expr {$m & 0xff}]
        incr i 2
        # SOF0..SOF15 (außer DHT/JPG/DAC) tragen die Maße
        if {($m >= 0xC0 && $m <= 0xCF) && $m != 0xC4 && $m != 0xC8 && $m != 0xCC} {
            binary scan [string range $bytes [expr {$i+3}] [expr {$i+6}]] SS h w
            return [list [expr {$w & 0xffff}] [expr {$h & 0xffff}]]
        }
        # sonst: Segmentlänge (Big-Endian 16-bit) lesen und überspringen
        binary scan [string range $bytes $i [expr {$i+1}]] S len
        incr i [expr {$len & 0xffff}]
    }
    error "kein SOF-Marker gefunden"
}
```

Beachte: JPEG-Längen und -Maße sind **Big-Endian** (`S`), die Marker werden
Byte für Byte abgelaufen.

## Praxis: binary format zum Schreiben

```tcl
# DOS-Zeitstempel (ZIP) packen: little-endian 16-bit
set dostime [expr {($h<<11) | ($min<<5) | ($sec>>1)}]
set dosdate [expr {(($year-1980)<<9) | ($month<<5) | $day}]
set header [binary format "ss" $dostime $dosdate]

# Ein 32-bit-Little-Endian-Feld (z.B. CRC, Größe):
append rec [binary format i $crc]

# Mehrere Felder + Name in einem Rutsch:
set local [binary format "a4 s s s s s i i i s s a*" \
    "PK\x03\x04" 20 0 0 $dostime $dosdate $crc $csize $usize \
    [string length $name] 0 $name]
```

`a*` schreibt einen String variabler Länge -- praktisch für Dateinamen/Inhalt
am Ende eines Records.

## Häufige Fehler (Kurzübersicht)

```
1) Vorzeichen vergessen: 0xFF -> -1 statt 255   -> & 0xff / & 0xffff
2) Falsche Endianness (S/I vs s/i)              -> Format zum Datenformat passend
3) Binärdatei ohne Binärmodus gelesen/geschrieben -> open … rb/wb
4) Rückgabewert von scan mit den Daten verwechselt (= Anzahl Konversionen)
5) a statt A (oder umgekehrt) -> ungewolltes Trimmen/Nullbytes
6) Offset/Länge per string range statt @/x -> fehleranfällig bei vielen Feldern
7) string length auf Binärdaten: zählt Bytes -- ok, solange wirklich binär gelesen
```

## Siehe auch

- `odf-erzeugen-fallen.md` -- nutzt diese Parser (Bild-Maße, ZIP-Records)
- ZIP-Format / `zipfs` -- Local-Header/Central-Directory mit `binary format` bauen
- `encoding-unicode.md` -- warum Binärmodus nötig ist
- `channels-io.md` -- `fconfigure -translation binary`

## Referenzen

- [Tcl: binary Manual](https://www.tcl.tk/man/tcl9.0/TclCmd/binary.html)
- [PNG-Spezifikation (IHDR)](https://www.w3.org/TR/png/)
- [JPEG/JFIF Marker](https://www.w3.org/Graphics/JPEG/itu-t81.pdf)

---

*Letzte Aktualisierung: Mai 2026*
