# Substitution und Escaping

*Stand: 2026-05-29*

Tcl verarbeitet jede Zeile in zwei Phasen: Zuerst wird der String
geparst und substituiert, dann wird der resultierende Befehl ausgeführt.
Das Verstaendnis dieser Parsing-Regeln ist fundamental -- die meisten
Tcl-Fehler entstehen durch falsche Erwartungen an die Substitution.

## Die drei Substitutionsarten

Bevor Tcl einen Befehl ausfuehrt, durchläuft es den Quelltext und
führt drei Arten von Substitution durch:

### Variablen-Substitution ($)

```tcl
set name "Alice"
puts "Hallo $name"
# -> Hallo Alice

# Begrenzt mit geschweiften Klammern:
set x 10
puts "Wert: ${x}px"
# -> Wert: 10px (ohne {} würde Tcl $xpx suchen)
```

**Regeln für Variablennamen nach `$`:**

```tcl
$name           ;# Einfache Variable
${name}         ;# Explizit begrenzt (nötig vor Buchstaben/Ziffern)
$arr(key)       ;# Array-Element
${arr(key)}     ;# Array-Element, explizit begrenzt
$::ns::var      ;# Namespace-qualifiziert
```

### Befehls-Substitution ([...])

```tcl
set result [expr {2 + 2}]
puts "Ergebnis: $result"
# -> Ergebnis: 4

# Verschachtelt:
puts "Länge: [string length [info hostname]]"
# Innere [...] zuerst, dann aeussere
```

**Wichtig:** Die Befehls-Substitution wird komplett ausgeführt, bevor
der aeussere Befehl die Argumente sieht. Das bedeutet:

```tcl
puts [error "Fehler!"]
# Der error wird ZUERST ausgeführt
# puts bekommt nie ein Argument -- das Programm bricht ab
```

### Backslash-Substitution

```tcl
puts "Zeile 1\nZeile 2"     ;# Zeilenumbruch
puts "Tab:\there"            ;# Tabulator
puts "Backslash: \\"         ;# Literaler Backslash
```

**Vollständige Backslash-Sequenzen:**

| Sequenz    | Bedeutung                          | Beispiel              |
|------------|------------------------------------|-----------------------|
| `\n`       | Zeilenumbruch (Newline)            | `"Zeile 1\nZeile 2"` |
| `\t`       | Tabulator                          | `"Name:\tAlice"`      |
| `\r`       | Carriage Return                    | Selten benötigt      |
| `\\`       | Literaler Backslash                | `"C:\\Pfad\\Datei"`   |
| `\$`       | Literales Dollarzeichen            | `"Preis: \$10"`       |
| `\[`  `\]` | Literale eckige Klammern          | `"Status: \[OK\]"`    |
| `\"`       | Literales Anführungszeichen       | `"Er sagte: \"Ja\""`  |
| `\{`  `\}` | Literale geschweifte Klammern     | `"JSON: \{\"k\":1\}"` |
| `\;`       | Literales Semikolon                | `"a\;b"`              |
| `\a`       | Bell (Alarm)                       | Terminal-Beep         |
| `\b`       | Backspace                          | Selten benötigt      |
| `\f`       | Formfeed                           | Drucksteuerung        |
| `\v`       | Vertikaler Tabulator               | Selten benötigt      |
| `\0`       | Null-Byte                          | Binärdaten           |
| `\ooo`     | Oktal (1-3 Ziffern)               | `\110` -> "H"         |
| `\xhh`     | Hexadezimal (1-2 Ziffern)         | `\x48` -> "H"         |
| `\uhhhh`   | Unicode (1-4 Hex-Ziffern)         | `\u00e4` -> ae        |
| `\Uhhhhhhhh` | Unicode (1-8 Hex, Tcl 8.7+)     | `\U0001F600` -> Emoji |
| `\<newline>` | Zeilenfortsetzung (+ Whitespace) | Siehe unten           |

### Zeilenfortsetzung

Ein Backslash am Zeilenende verbindet die nächste Zeile. Der Backslash,
der Zeilenumbruch und fuehrendes Whitespace der Folgezeile werden durch
ein einzelnes Leerzeichen ersetzt:

```tcl
set ergebnis [expr {
    $a + \
    $b + \
    $c
}]

# Oder bei langen Befehlszeilen:
set widget [ttk::button .f.btn \
    -text "Klick mich" \
    -command {doSomething}]
```

**Achtung:** Innerhalb von `{}` findet **keine** Backslash-Substitution
statt -- aber die Zeilenfortsetzung funktioniert trotzdem, weil sie
auf Parser-Ebene (nicht Substitutions-Ebene) verarbeitet wird:

```tcl
if {$x > 10 && \
    $y < 20} {
    # Funktioniert, obwohl in {} (Parser-Feature)
}
```

## Quoting: Drei Gruppierungsarten

Die Art der Gruppierung bestimmt, welche Substitutionen stattfinden:

### Doppelte Anführungszeichen ("...")

Alle drei Substitutionen werden durchgeführt. Whitespace innerhalb
der Anführungszeichen trennt keine Argumente:

```tcl
set x 10
set y 20
puts "x=$x, y=$y, Summe=[expr {$x + $y}]"
# -> x=10, y=20, Summe=30
```

### Geschweifte Klammern ({...})

**Keine** Substitution findet statt. Der Inhalt wird literal genommen:

```tcl
set x 10
puts {x=$x, Befehl=[expr {1+1}], Escape=\n}
# -> x=$x, Befehl=[expr {1+1}], Escape=\n
```

**Wichtig:** Klammern müssen balanced sein:

```tcl
puts {oeffnende \{ und schliessende \} Klammer}
# -> oeffnende \{ und schliessende \} Klammer
# (die Backslashes sind TEIL des Strings, kein Escaping!)
```

Das ist ein häufiger Irrtum: Innerhalb von `{}` gibt es kein
Escaping von Klammern mit Backslash. Der Backslash verhindert nur,
dass der Parser die Klammer als Gruppen-Ende interpretiert. Der
Backslash bleibt aber im String!

```tcl
set text {abc \{ def}
string length $text     ;# -> 11 (der \ ist drin!)
puts $text              ;# -> abc \{ def
```

### Ohne Quoting

Substitution findet statt, aber Whitespace trennt Argumente:

```tcl
set x 10
puts Ergebnis:$x
# -> Ergebnis:10 (ein Argument, kein Whitespace dazwischen)

puts Ergebnis: $x
# -> Fehler: "Ergebnis:" und "10" sind zwei Argumente,
#    aber puts erwartet maximal 2 (Channel + String)
```

### Übersicht

| Quoting         | Variable `$` | Befehl `[..]` | Backslash `\` | Whitespace    |
|-----------------|:------------:|:--------------:|:-------------:|:-------------:|
| `"..."`         | Ja           | Ja             | Ja            | Kein Trenner  |
| `{...}`         | Nein         | Nein           | Nein*         | Kein Trenner  |
| Ohne            | Ja           | Ja             | Ja            | Trennt Args   |

*) Ausnahme: `\<newline>` für Zeilenfortsetzung funktioniert auch in `{}`.

## Die 12 Parsing-Regeln

Tcl's Parser folgt exakt diesen Regeln (aus der Tcl-Dokumentation,
vereinfacht):

1. **Befehle** werden durch Newline oder `;` getrennt.
2. **Argumente** werden durch Whitespace getrennt.
3. **Erstes Wort** ist der Befehlsname, Rest sind Argumente.
4. `"..."` gruppiert ein Argument (mit Substitution).
5. `{...}` gruppiert ein Argument (ohne Substitution).
6. `$name` wird durch den Variablenwert ersetzt.
7. `[cmd]` wird durch das Befehlsergebnis ersetzt.
8. `\x` wird durch die Escape-Bedeutung ersetzt.
9. `#` am Zeilenanfang leitet einen Kommentar ein.
10. Substitutionsergebnisse werden **nicht** erneut geparst.
11. Jeder Befehl wird nach vollständiger Substitution ausgeführt.
12. `{*}` (Expansion) ist ein spezielles Präfix (Tcl 8.5+).

**Regel 10 ist entscheidend:** Wenn `$x` den Wert `{a b c}` hat,
dann ist `puts $x` ein Aufruf mit **einem** Argument `{a b c}`,
nicht mit drei Argumenten. Die Substitution erzeugt keine neuen
Wort-Grenzen.

```tcl
set x "a b c"
llength $x        ;# -> 3 (lindex parst den Wert als Liste)
# Aber:
puts $x           ;# Ein Argument: "a b c" (kein Re-Parsing!)
```

## Der häufigste Fehler: Eckige Klammern in Strings

Dieser Fehler ist in fast jedem groesseren Tcl-Projekt zu finden:

### Das Problem

```tcl
set msg "[Fehler] Datei nicht gefunden: $filename"
# -> invalid command name "Fehler"
```

Tcl interpretiert `[Fehler]` als Befehls-Substitution und versucht,
einen Befehl namens "Fehler" auszuführen.

### Lösungen

```tcl
# Lösung 1: Backslash-Escaping
set msg "\[Fehler\] Datei nicht gefunden: $filename"

# Lösung 2: format (sauberer bei komplexen Strings)
set msg [format {[Fehler] Datei nicht gefunden: %s} $filename]

# Lösung 3: string map
set tpl {[Fehler] Datei nicht gefunden: @FILE@}
set msg [string map [list @FILE@ $filename] $tpl]
```

### Variante: Klammern in Fehlermeldungen

Besonders tueckisch, weil die Fehlermeldung selbst einen Fehler auslöst:

```tcl
# FALSCH (Fehler im Fehler):
error "[DB] Verbindung fehlgeschlagen: $host"
# -> invalid command name "DB"

# RICHTIG:
error "\[DB\] Verbindung fehlgeschlagen: $host"
```

## Regex und Substitution

Reguläre Ausdrücke enthalten oft Zeichen, die Tcl als Substitution
interpretieren würde. Geschweifte Klammern sind die Lösung:

```tcl
# FALSCH (Tcl sieht [0-9] als Befehlsaufruf):
regexp "[0-9]+" "test123" match

# RICHTIG (keine Substitution in {}):
regexp {[0-9]+} "test123" match
puts $match     ;# -> 123
```

### Regex mit Variablen

Wenn der Pattern eine Variable enthalten soll, gibt es zwei Ansaetze:

```tcl
# Ansatz 1: String-Konkatenation (Vorsicht!)
set prefix "test"
regexp "${prefix}\\d+" "test123 other" match
# Doppelter Backslash nötig, weil "" Substitution durchführt

# Ansatz 2: Variablen einbauen (bevorzugt)
set prefix "test"
set pattern "${prefix}\[0-9\]+"
regexp $pattern "test123 other" match

# Ansatz 3: Pattern vorbauen
set prefix "test"
set pattern [string cat $prefix {[0-9]+}]
regexp $pattern "test123 other" match
```

## expr und Quoting

`expr` hat eigene Parsing-Regeln. Ausdrücke sollten **immer** in
geschweiften Klammern stehen:

```tcl
# FALSCH (doppelte Substitution):
set x 10
set result [expr $x + 1]
# 1. Tcl substituiert: expr 10 + 1
# 2. expr parst: 10 + 1
# Funktioniert, aber: Security-Risiko + langsamer

# RICHTIG (einfache Substitution):
set result [expr {$x + 1}]
# 1. Tcl gibt {$x + 1} unsubstituiert an expr
# 2. expr substituiert $x intern und compiliert den Ausdruck
# Schneller (kann bytecoded werden) + sicher
```

### Warum `{}` bei expr wichtig ist

```tcl
# Security-Problem ohne {}:
set input "1; exec rm -rf /"
set result [expr $input + 1]
# Tcl substituiert zu: expr 1; exec rm -rf / + 1
# expr führt aus: 1 (und dann exec!)

# Mit {} kein Problem:
set result [expr {$input + 1}]
# expr bekommt: $input + 1
# $input wird intern substituiert, aber NICHT als Befehl interpretiert
# -> Fehler: "1; exec rm -rf /" ist keine gueltige Zahl
```

### Performance-Unterschied

```tcl
# Ohne {}: Bei jedem Aufruf neu geparst
proc slow {x} { expr $x * 2 }

# Mit {}: Einmal compiliert, danach Bytecode
proc fast {x} { expr {$x * 2} }

# Faktor 2-10x Unterschied in Schleifen!
```

## Substitution in verschiedenen Kontexten

### if/while/for -- Bedingungen in {}

```tcl
# RICHTIG: Bedingung in {} (wird an expr weitergereicht)
if {$x > 10} {
    puts "gross"
}

# FALSCH (funktioniert, aber doppelte Substitution):
if "$x > 10" {
    puts "gross"
}
```

### switch -- Patterns in {}

```tcl
# RICHTIG: Keine Substitution in Patterns gewünscht
switch $input {
    "help"  { showHelp }
    "quit"  { exit }
    default { puts "Unbekannt: $input" }
}

# Achtung bei -glob oder -regexp Patterns:
switch -glob $filename {
    {*.tcl}   { puts "Tcl-Datei" }
    {*.txt}   { puts "Text-Datei" }
}
```

### proc -- Body in {}

```tcl
# RICHTIG: Body wird NICHT substituiert bei Definition
proc greet {name} {
    puts "Hallo $name"
}
# $name wird erst beim AUFRUF substituiert

# FALSCH (body wird bei Definition substituiert):
proc greet {name} "puts \"Hallo $name\""
# $name wird SOFORT substituiert (auf den aktuellen Wert!)
# Der Body ist dann z.B.: puts "Hallo Alice"
# name-Parameter wird ignoriert!
```

### bind -- Substitution in zwei Phasen

Tk-Bindings haben eine besondere Substitution mit `%`-Codes:

```tcl
# Phase 1: Tcl substituiert bei Definition
set msg "Geklickt"
bind .btn <Button-1> {puts "$msg bei %x,%y"}
# FEHLER: $msg wird erst beim Event substituiert,
#         aber dann existiert es evtl. nicht mehr

# Lösung 1: Wert einbetten
bind .btn <Button-1> [list puts "$msg bei %x,%y"]
# "Geklickt bei %x,%y" wird fest eingebaut

# Lösung 2: Namespace-Variable
bind .btn <Button-1> {puts "$::msg bei %x,%y"}
# $::msg wird beim Klick aufgelöst (muss dann existieren)
```

## Fortgeschrittene Techniken

### Der Expansion-Operator {*}

Seit Tcl 8.5 kann eine Liste in einzelne Argumente expandiert werden:

```tcl
set options {-fill both -expand 1}
pack .widget {*}$options
# Aequivalent zu: pack .widget -fill both -expand 1

# Praktisch für dynamische Argument-Listen:
set cmd [list puts -nonewline]
{*}$cmd "Hello "
{*}$cmd "World"
puts ""
# -> Hello World
```

### subst -- Selektive Substitution

Der `subst`-Befehl führt Substitution auf einem String durch, mit
Kontrolle über die Substitutionsarten:

```tcl
# Alle Substitutionen:
set x 10
subst {x=$x, cmd=[expr {$x+1}], nl=\n}
# -> x=10, cmd=11, nl=<newline>

# Nur Variablen, keine Befehle:
subst -nocommands {x=$x, cmd=[expr {$x+1}]}
# -> x=10, cmd=[expr {10+1}]

# Nur Backslash:
subst -novariables -nocommands {x=$x, nl=\n}
# -> x=$x, nl=<newline>
```

**Anwendung:** Template-Systeme:

```tcl
proc renderTemplate {template vars} {
    dict for {name value} $vars {
        set $name $value
    }
    subst $template
}

set html [renderTemplate {
    <h1>$title</h1>
    <p>$content</p>
    <footer>Erstellt: [clock format [clock seconds]]</footer>
} {title "Willkommen" content "Hallo Welt"}]
```

### format -- Printf-artige Formatierung

Wenn die Substitution komplex wird, ist `format` oft lesbarer:

```tcl
# Statt verschachtelter Escapes:
set msg [format {[%s] Zeile %d: %s} $level $line $text]
# -> [ERROR] Zeile 42: Datei nicht gefunden

# Zahlenformatierung:
format "%.2f EUR"  99.5     ;# -> 99.50 EUR
format "%05d"      42       ;# -> 00042
format "%-20s %s"  $key $val ;# -> Links-ausgerichtet
```

## Häufige Fehler und Debugging

### Fehler 1: Unescapte eckige Klammern

```tcl
# Symptom: "invalid command name ..."
puts "Range: [0-9]"
# Fix:
puts "Range: \[0-9\]"
```

### Fehler 2: Doppelte Substitution

```tcl
# Symptom: Unerwartete Werte oder Sicherheitsluecken
set x {$y}
set y 10
eval "puts $x"     ;# Substituiert $x zu "$y", dann $y zu "10"
# Fix: geschweifte Klammern oder list verwenden
```

### Fehler 3: proc-Body mit ""

```tcl
# Symptom: Parameter werden ignoriert
set default "Welt"
proc greet {name} "puts {Hallo $default}"
# Body ist fest: puts {Hallo Welt}
# Fix: {} für Body verwenden
proc greet {name} {puts "Hallo $name"}
```

### Fehler 4: Vergessenes $ bei Variablen

```tcl
# Symptom: Variablenname statt Wert
set x 10
if {x > 5} { ... }      ;# FALSCH: "x" ist String, nicht Zahl
if {$x > 5} { ... }     ;# RICHTIG
```

### Fehler 5: Newline in Strings mit ""

```tcl
# Symptom: "extra characters after close-quote"
set text "Zeile 1
Zeile 2"
# Funktioniert (Newline ist in "" erlaubt)

# Aber:
puts "Zeile 1
" Zeile 2"
# FEHLER: Tcl sieht das " nach Zeile 1 als Ende
```

### Fehler 6: Fehlendes Leerzeichen zwischen `}` und `{`

```tcl
# Symptom: "extra characters after close-brace"
if {$x ne ""}{ puts "set" }
#            ^ kein Leerzeichen vor {

# Tcl sieht die schliessende Klammer des if-Conditions
# und erwartet danach Wortgrenze (Whitespace). Das direkt
# folgende { ist kein neues Wort, sondern "extra".

# RICHTIG: Leerzeichen zwischen } und {
if {$x ne ""} { puts "set" }
#             ^

# Tritt typisch bei Bulk-Edits und if-Ketten auf:
if {$a}{ ... } elseif {$b}{ ... }         ;# alle drei Stellen broken
if {$a} { ... } elseif {$b} { ... }       ;# alle drei korrekt

# Schwesterfehler zu Fehler 5 (close-quote): gleicher
# Symptom-Anfang "extra characters after close-...", aber
# der schliessende Token ist }, nicht ".
```

### Fehler 7: `string match`-Pattern mit `{` im Such-String

```tcl
# Symptom: "missing close-brace" oder "extra characters after close-brace"

# Will pruefen, ob eine Fehlermeldung mit "need {text" beginnt:
if {[string match "need {text*" $err]} { ... }
#                      ^
# FEHLER: Tcl-Parser zaehlt Braces ZUERST, bevor das Pattern
# als String erkannt wird. Das unbalancierte { im Pattern
# bricht das Brace-Matching der gesamten Zeile.

# RICHTIG: Pattern ohne { schreiben
if {[string match "need*text*" $err]} { ... }

# Oder: ein Backslash-Escape im Pattern (weniger lesbar)
if {[string match {need \{text*} $err]} { ... }
# Hier ist das Pattern selbst in {} -- dann muss das innere
# { backslash-escaped sein, damit es nicht den Brace-Zaehler
# beeinflusst.

# Wirklich tueckisch: kompiliert beim ersten Test ohne Fehler,
# wenn die Datei eine PASSENDE Zahl von { und } enthaelt --
# dann verschiebt sich der Fehler nur auf eine spaetere Zeile.
```

### Debugging: Was wird substituiert?

```tcl
# Trick: puts mit geschweiften Klammern zum Testen
set x 10
set cmd {puts "Wert: $x und [expr {$x+1}]"}
puts "Befehl: $cmd"
# Zeigt den unsubstituierten Befehl

# Oder: trace für Variablen
trace add variable x write {apply {{n1 n2 op} {
    upvar 1 $n1 val
    puts "  $n1 = $val (nach $op)"
}}}
```

## Zusammenfassung

Tcl's Substitutionssystem ist einfach, aber die Konsequenzen sind
weitreichend:

- **Drei Substitutionsarten:** `$` (Variablen), `[...]` (Befehle),
  `\` (Backslash) -- alle vor der Befehlsausfuehrung.
- **`"..."` vs. `{...}`:** Anführungszeichen erlauben Substitution,
  geschweifte Klammern verhindern sie.
- **Kein Re-Parsing:** Substitutionsergebnisse werden nicht erneut
  als Wort-Grenzen interpretiert (Regel 10).
- **expr immer mit `{}`:** Sicherheit und Performance.
- **`\[` `\]` in Strings:** Der häufigste Fehler, immer escapen
  wenn literal gemeint.
- **`{*}` Expansion:** Wandelt eine Liste in einzelne Argumente um.

## Siehe auch

- [Das String-Modell](string-modell.md) -- das zugrundeliegende Datenmodell,
  auf dem die Substitutionsregeln aufbauen
- [Prozeduren](proc.md) -- wie proc-Bodies gespeichert und später
  substituiert werden
- [Source, Eval, Apply](source-eval-apply.md) -- eval und seine
  Substitutionseigenheiten
- [Metaprogrammierung](metaprogramming.md) -- fortgeschrittene Techniken
  mit dynamischer Code-Erzeugung
- [Error-Handling](error-handling.md) -- Fehlerbehandlung bei
  Substitutionsfehlern
- [Text-Widget und Tags](text-widget-tags.md) -- Substitution in
  Tk-Bindings und Widget-Befehlen
