# Tk Text-Widget - Referenzhandbuch

*Stand: 2026-04-29*

Umfassendes deutsches Handbuch zum Tk Text-Widget für Tcl/Tk 8.6 und 9.x.

---

## Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Widget erstellen](#widget-erstellen)
3. [Konfigurationsoptionen](#konfigurationsoptionen)
4. [Indizes](#indizes)
5. [Text einfügen und löschen](#text-einfügen-und-löschen)
6. [Text abfragen](#text-abfragen)
7. [Tags](#tags)
8. [Marks](#marks)
9. [Embedded Windows](#embedded-windows)
10. [Embedded Images](#embedded-images)
11. [Scrolling und Navigation](#scrolling-und-navigation)
12. [Selektion](#selektion)
13. [Suchen](#suchen)
14. [Undo/Redo](#undoredo)
15. [Bindings und Events](#bindings-und-events)
16. [Peer Widgets](#peer-widgets)
17. [Tk-Fenster einbetten (Container/Use)](#tk-fenster-einbetten-containeruse)
18. [Performance](#performance)
19. [Bekannte Probleme und Lösungen](#bekannte-probleme-und-loesungen)
20. [Named Fonts](#named-fonts)
21. [Pixel-Positionen und Geometrie](#pixel-positionen-und-geometrie)
22. [Fortgeschrittene Techniken](#fortgeschrittene-techniken)
23. [Praxisbeispiele](#praxisbeispiele)

---

## Überblick

Das Text-Widget ist eines der maechtigsten Widgets in Tk. Es kann:

- Mehrzeiligen Text anzeigen und bearbeiten
- Rich-Text-Formatierung mit Tags
- Bilder und andere Widgets einbetten
- Hyperlinks und interaktive Bereiche
- Undo/Redo
- Syntax-Highlighting

### Grundstruktur

```tcl
text .t -width 80 -height 25
pack .t -fill both -expand 1
```

### Wichtige Konzepte

| Konzept | Beschreibung |
|---------|--------------|
| Index | Position im Text (z.B. `1.0`, `end`) |
| Tag | Benannte Formatierung für Textbereiche |
| Mark | Benannte Position (bewegt sich mit dem Text) |
| Embedded Window | Eingebettetes Widget |
| Embedded Image | Eingebettetes Bild |

---

## Widget erstellen

### Syntax

```tcl
text pathName ?options?
```

### Minimales Beispiel

```tcl
package require Tk

text .t
pack .t -fill both -expand 1

.t insert end "Hallo Welt!"
```

### Mit Scrollbar

```tcl
ttk::frame .f
text .f.t -wrap word -yscrollcommand {.f.sb set}
ttk::scrollbar .f.sb -orient vertical -command {.f.t yview}

pack .f.sb -side right -fill y
pack .f.t -side left -fill both -expand 1
pack .f -fill both -expand 1
```

### Mit horizontaler und vertikaler Scrollbar

```tcl
ttk::frame .f
text .f.t -wrap none \
    -xscrollcommand {.f.xsb set} \
    -yscrollcommand {.f.ysb set}
ttk::scrollbar .f.ysb -orient vertical -command {.f.t yview}
ttk::scrollbar .f.xsb -orient horizontal -command {.f.t xview}

grid .f.t   -row 0 -column 0 -sticky nsew
grid .f.ysb -row 0 -column 1 -sticky ns
grid .f.xsb -row 1 -column 0 -sticky ew
grid columnconfigure .f 0 -weight 1
grid rowconfigure .f 0 -weight 1
pack .f -fill both -expand 1
```

---

## Konfigurationsoptionen

### Geometrie

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-width` | 80 | Breite in Zeichen |
| `-height` | 24 | Höhe in Zeilen |
| `-wrap` | char | Zeilenumbruch: `none`, `char`, `word` |

```tcl
text .t -width 100 -height 30 -wrap word
```

### Aussehen

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-background` | white | Hintergrundfarbe |
| `-foreground` | black | Textfarbe |
| `-font` | TkFixedFont | Schriftart |
| `-relief` | sunken | Rahmenart |
| `-borderwidth` | 1 | Rahmenbreite |
| `-padx` | 1 | Horizontaler Innenabstand |
| `-pady` | 1 | Vertikaler Innenabstand |

```tcl
text .t -background white -foreground black \
    -font {Consolas 11} -padx 10 -pady 5
```

**Wichtig:** `-padx` akzeptiert beim Text-Widget nur **einen** Wert
(symmetrisch links und rechts). Anders als bei `pack -padx {5 10}`
ist eine Liste mit zwei Werten nicht erlaubt:

```tcl
# FALSCH -- "bad screen distance" Fehler:
text .t -padx [list 67 12]
text .t -padx {67 12}

# RICHTIG -- ein Wert (gilt für beide Seiten):
text .t -padx 10
```

Für asymmetrisches Padding (`-padx` links anders als rechts)
gibt es beim Text-Widget keine Lösung. Alternative: einen Frame
mit `pack -padx {left right}` um das Text-Widget legen.

### Verhalten

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-state` | normal | `normal` oder `disabled` |
| `-undo` | false | Undo/Redo aktivieren |
| `-autoseparators` | true | Automatische Undo-Separatoren |
| `-maxundo` | 0 | Max. Undo-Schritte (0 = unbegrenzt) |

```tcl
text .t -state normal -undo true -maxundo 100
```

### Cursor

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-insertbackground` | black | Cursorfarbe |
| `-insertwidth` | 2 | Cursorbreite in Pixeln |
| `-insertofftime` | 300 | Cursor-Blink aus (ms) |
| `-insertontime` | 600 | Cursor-Blink an (ms) |
| `-blockcursor` | false | Block-Cursor statt Linie |
| `-insertunfocussed` | none | Cursor-Darstellung ohne Fokus |

```tcl
text .t -insertbackground blue -insertwidth 3 -blockcursor true
```

`-blockcursor` zeigt einen ausgefuellten Block statt der duennen Linie.
Nützlich für vi-ähnliche Editoren oder wenn der Cursor besser
sichtbar sein soll.

`-insertunfocussed` (ab Tk 8.6.9) steuert wie der Cursor aussieht
wenn das Widget keinen Fokus hat:

| Wert | Verhalten |
|------|-----------|
| `none` | Cursor unsichtbar (Standard) |
| `hollow` | Cursor als leerer Rahmen sichtbar |
| `solid` | Cursor voll sichtbar (kein Blink) |

```tcl
# Cursor auch ohne Fokus als Rahmen zeigen
text .t -insertunfocussed hollow

# Nützlich für Multi-Panel-Editoren:
# Der Benutzer sieht wo der Cursor steht,
# auch im inaktiven Panel
```

### Spacing

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-spacing1` | 0 | Abstand über erster Zeile eines Absatzes |
| `-spacing2` | 0 | Abstand zwischen Zeilen eines Absatzes |
| `-spacing3` | 0 | Abstand unter letzter Zeile eines Absatzes |

```tcl
text .t -spacing1 5 -spacing2 2 -spacing3 5
```

### Tabs

| Option | Default | Beschreibung |
|--------|---------|--------------|
| `-tabs` | {} | Tab-Positionen |
| `-tabstyle` | tabular | `tabular` oder `wordprocessor` |

```tcl
# Tabs alle 4 Zeichen
text .t -tabs {4c}

# Unterschiedliche Positionen und Ausrichtung
text .t -tabs {2c left 5c center 8c right}
```

### tabstyle: tabular vs wordprocessor

| Stil | Verhalten |
|------|-----------|
| `tabular` | Tab-Position relativ zum vorherigen Tabulatorstop (Standard) |
| `wordprocessor` | Tab-Position absolut vom linken Rand (wie Word/Writer) |

Für Spalten-Layouts ist `wordprocessor` fast immer besser:

```tcl
$t configure -tabstyle wordprocessor
# Tabs sind jetzt absolute Positionen vom linken Textrand
```

### Tab-Werte: Pixel, Points und Listen

Ohne Suffix ist ein Tab-Wert in **Pixeln**. Mit `p` in Points,
mit `c` in Zentimetern, mit `i` in Inch. Für praezise
Spaltenausrichtung (z.B. mit `place -x`) sind Pixel am besten:

```tcl
# FALSCH -- "138p left" = Points, skaliert unvorhersehbar:
lappend tabs "${pos}p left"

# FALSCH -- ein String statt zwei List-Elemente:
lappend tabs "${pos} left"

# RICHTIG -- zwei separate Elemente, bare number = Pixel:
lappend tabs $pos left
```

Die `-tabs`-Liste besteht aus Paaren: `position ausrichtung`.
Jedes Paar muss als **zwei separate Listenelemente** übergeben
werden, nicht als ein String.

---

## Indizes

Ein Index beschreibt eine Position im Text-Widget. Das Format ist vielfaeltig.

### Basis-Indizes

| Index | Beschreibung |
|-------|--------------|
| `line.char` | Zeile.Spalte (beide ab 0, Zeilen ab 1) |
| `end` | Ende des Textes (nach letztem Newline) |
| `insert` | Cursor-Position |
| `current` | Position unter Mauszeiger |
| `@x,y` | Position bei Pixel-Koordinaten |
| `mark` | Position eines Marks |
| `tag.first` | Erstes Zeichen eines Tags |
| `tag.last` | Letztes Zeichen eines Tags |

### Beispiele

```tcl
# Zeile 1, erstes Zeichen
set idx "1.0"

# Zeile 5, zehntes Zeichen
set idx "5.9"

# Ende der ersten Zeile
set idx "1.end"

# Position unter Maus
set idx "@$x,$y"

# Cursor-Position
set idx "insert"
```

### Modifikatoren

| Modifikator | Beschreibung |
|-------------|--------------|
| `+ N chars` | N Zeichen vorwärts |
| `- N chars` | N Zeichen rückwärts |
| `+ N lines` | N Zeilen vorwärts |
| `- N lines` | N Zeilen rückwärts |
| `linestart` | Anfang der Zeile |
| `lineend` | Ende der Zeile |
| `wordstart` | Anfang des Wortes |
| `wordend` | Ende des Wortes |

### Beispiele mit Modifikatoren

```tcl
# 5 Zeichen nach Cursor
set idx "insert + 5 chars"

# Anfang der aktuellen Zeile
set idx "insert linestart"

# Ende der nächsten Zeile
set idx "insert + 1 lines lineend"

# Wort unter Cursor
set wordStart [$t index "insert wordstart"]
set wordEnd [$t index "insert wordend"]
set word [$t get $wordStart $wordEnd]
```

### Der end-Index Gotcha

**Wichtig:** Das Text-Widget hat immer ein implizites Newline am Ende!

```tcl
# Widget scheint leer, aber:
puts [$t get 1.0 end]   ;# -> "\n"
puts [$t index end]     ;# -> "2.0"
```

Für das letzte echte Zeichen `end-1c` verwenden:

```tcl
set lastChar [$t index "end-1c"]
```

### Index normalisieren

```tcl
# Beliebigen Index in line.char umwandeln
set normalized [$t index "insert + 10 chars"]
puts $normalized  ;# -> z.B. "3.5"
```

### Indizes vergleichen

```tcl
$t compare $idx1 < $idx2   ;# Kleiner
$t compare $idx1 <= $idx2  ;# Kleiner oder gleich
$t compare $idx1 == $idx2  ;# Gleich
$t compare $idx1 >= $idx2  ;# Groesser oder gleich
$t compare $idx1 > $idx2   ;# Groesser
$t compare $idx1 != $idx2  ;# Ungleich
```

---

## Text einfügen und löschen

### insert

```tcl
$t insert index chars ?tagList? ?chars tagList ...?
```

Fügt Text an der angegebenen Position ein.

```tcl
# Einfacher Text
$t insert end "Hallo Welt\n"

# Mit Tag
$t insert end "Wichtig!" important

# Mit mehreren Tags
$t insert end "Fett und rot" {bold red}

# Mehrere Segmente
$t insert end "Normal " {} "Fett" bold " wieder normal" {}
```

### delete

```tcl
$t delete index1 ?index2?
```

Loescht Text zwischen index1 und index2 (index2 exklusiv).

```tcl
# Ein Zeichen löschen
$t delete "insert"

# Bereich löschen
$t delete "1.0" "1.10"

# Ganze Zeile löschen
$t delete "3.0" "4.0"

# Alles löschen
$t delete "1.0" "end"
```

### replace

```tcl
$t replace index1 index2 chars ?tagList ...?
```

Ersetzt Text. Effizienter als delete + insert.

```tcl
$t replace "1.0" "1.5" "Neuer Text"
```

**Warum replace statt delete + insert?**

`replace` ist eine atomare Operation. Das Widget rendert nur einmal,
während `delete` + `insert` zwei Render-Zyklen auslöst und
sichtbares Flickern verursachen kann:

```tcl
# SCHLECHT: Zwei Operationen, Flickern möglich
$t delete 1.0 end
$t insert 1.0 $newContent
# Zwischen delete und insert ist das Widget kurz leer!

# BESSER: Atomare Ersetzung, kein Flickern
$t replace 1.0 end $newContent
```

`replace` akzeptiert dieselbe Tag-Syntax wie `insert`:

```tcl
$t replace 1.0 end "Neuer Inhalt" bold
$t replace 1.0 end "Normal " {} "Fett" bold " kursiv" em
```

### Readonly-Text-Widget: Muster für programmgesteuerte Anzeige

Für Widgets die Inhalt anzeigen, aber nicht editierbar sein sollen,
ist das Readonly-Pattern gaengig. Der `-state disabled` verhindert
Eingaben, muss aber für programmgesteuerte Änderungen temporär
aufgehoben werden:

```tcl
# Widget erstellen
text .t -wrap word -state disabled

# Inhalt setzen (Utility-Proc)
proc setText {w text} {
    $w configure -state normal
    $w replace 1.0 end $text
    $w configure -state disabled
}

# Inhalt mit Tags setzen
proc setFormattedText {w args} {
    $w configure -state normal
    $w delete 1.0 end
    $w insert 1.0 {*}$args
    $w configure -state disabled
}

# Verwendung:
setText .t "Aktualisierter Inhalt"
setFormattedText .t "Normal " {} "Wichtig!" bold
```

**Achtung:** `replace` im disabled-State funktioniert nicht.
Der State muss *immer* temporär auf normal gesetzt werden.

Für wiederholte Updates (z.B. Log-Viewer, Timeline, Status-Anzeige)
ist dieses Pattern essentiell:

```tcl
proc appendLine {w text {tag {}}} {
    $w configure -state normal
    if {$tag ne ""} {
        $w insert end "$text\n" $tag
    } else {
        $w insert end "$text\n"
    }
    $w configure -state disabled
    $w see end  ;# Auto-Scroll
}
```

---

## Text abfragen

### get

```tcl
$t get index1 ?index2?
```

Gibt Text zwischen den Indizes zurück.

```tcl
# Ein Zeichen
set char [$t get "1.5"]

# Bereich
set text [$t get "1.0" "1.end"]

# Alles (ohne letztes Newline)
set all [$t get "1.0" "end-1c"]

# Aktuelle Zeile
set line [$t get "insert linestart" "insert lineend"]
```

### get -displaychars

Ignoriert elided (versteckten) Text:

```tcl
set visible [$t get -displaychars "1.0" "end"]
```

### count

Zaehlt verschiedene Elemente:

```tcl
# Zeichen zählen
set chars [$t count -chars "1.0" "end"]

# Zeilen zählen
set lines [$t count -lines "1.0" "end"]

# Display-Zeilen (mit Umbruch)
set displayLines [$t count -displaylines "1.0" "end"]

# Pixel vertikal
set pixels [$t count -ypixels "1.0" "end"]
```

### dump

Gibt Inhalt mit Metadaten zurück:

```tcl
# Alles dumpen
set dump [$t dump -all "1.0" "end"]

# Nur Text
set textDump [$t dump -text "1.0" "end"]

# Tags
set tagDump [$t dump -tag "1.0" "end"]

# Mit Callback
$t dump -command myHandler -all "1.0" "end"

proc myHandler {key value index} {
    puts "$key: $value at $index"
}
```

---

## Tags

Tags sind benannte Formatierungen, die auf Textbereiche angewendet werden.

### Tag konfigurieren

```tcl
$t tag configure tagName ?option value ...?
```

#### Schrift-Optionen

| Option | Beschreibung |
|--------|--------------|
| `-font` | Schriftart |
| `-foreground` | Textfarbe |
| `-background` | Hintergrundfarbe |
| `-underline` | Unterstrichen (boolean) |
| `-underlinefg` | Farbe der Unterstreichung |
| `-overstrike` | Durchgestrichen (boolean) |
| `-overstrikefg` | Farbe der Durchstreichung |

```tcl
$t tag configure bold -font {TkDefaultFont 12 bold}
$t tag configure red -foreground red
$t tag configure highlight -background yellow
$t tag configure link -foreground blue -underline true
$t tag configure deleted -overstrike true -foreground gray
```

**Achtung Font-Ambiguität:** Bei Fontfamilien mit Leerzeichen (z.B. "DejaVu Sans",
"Noto Sans") funktioniert das Listen-Format nicht zuverlässig:

```tcl
# PROBLEMATISCH: "DejaVu Sans" wird als zwei Token gelesen
$t tag configure h1 -font {DejaVu Sans 16 bold}

# SICHER: Option-Format oder Named Fonts verwenden
$t tag configure h1 -font [list -family "DejaVu Sans" -size 16 -weight bold]

# AM BESTEN: Named Font (siehe Abschnitt Named Fonts)
font create h1Font -family "DejaVu Sans" -size 16 -weight bold
$t tag configure h1 -font h1Font
```

#### Layout-Optionen

| Option | Beschreibung |
|--------|--------------|
| `-justify` | Ausrichtung: `left`, `center`, `right` |
| `-lmargin1` | Linker Rand erste Zeile |
| `-lmargin2` | Linker Rand Folgezeilen |
| `-rmargin` | Rechter Rand |
| `-spacing1` | Abstand oben |
| `-spacing2` | Zeilenabstand |
| `-spacing3` | Abstand unten |
| `-tabs` | Tab-Positionen |
| `-wrap` | Umbruch: `none`, `char`, `word` |

```tcl
$t tag configure quote \
    -lmargin1 20 -lmargin2 20 -rmargin 20 \
    -foreground gray -font {TkDefaultFont 11 italic}

$t tag configure code \
    -font {Consolas 10} -background #f0f0f0 \
    -lmargin1 10 -lmargin2 10
```

#### Spezial-Optionen

| Option | Beschreibung |
|--------|--------------|
| `-elide` | Text verstecken (boolean) |
| `-relief` | Rahmenart |
| `-borderwidth` | Rahmenbreite |
| `-offset` | Vertikaler Offset (für Sub/Superscript) |

```tcl
$t tag configure hidden -elide true
$t tag configure superscript -offset 5 -font {TkDefaultFont 8}
$t tag configure subscript -offset -3 -font {TkDefaultFont 8}
```

### Tag hinzufügen

```tcl
$t tag add tagName index1 ?index2?
```

```tcl
# Auf Bereich anwenden
$t tag add bold "1.0" "1.10"

# Auf mehrere Bereiche
$t tag add highlight "1.5" "1.10" "2.0" "2.5"

# Beim Insert
$t insert end "Fetter Text" bold
```

### Tag entfernen

```tcl
$t tag remove tagName index1 ?index2?
```

```tcl
$t tag remove bold "1.0" "1.10"
```

### Tag löschen

Loescht den Tag komplett (inkl. Konfiguration):

```tcl
$t tag delete tagName
```

### Tag-Bereiche abfragen

```tcl
# Alle Bereiche eines Tags
set ranges [$t tag ranges bold]
# -> {1.0 1.10 3.5 3.15}

# Nächster Bereich ab Index
set next [$t tag nextrange bold "1.0"]
# -> {1.0 1.10}

# Vorheriger Bereich
set prev [$t tag prevrange bold "end"]
```

### Tags an Position abfragen

```tcl
# Alle Tags an Index
set tags [$t tag names "1.5"]
# -> {bold red}

# Alle existierenden Tags
set allTags [$t tag names]
```

### Tag-Priorität

Wenn mehrere Tags kollidieren, gewinnt der mit hoeherer Priorität:

```tcl
# Tag nach oben verschieben
$t tag raise important

# Tag nach unten verschieben
$t tag lower background

# Relativ zu anderem Tag
$t tag raise highlight bold
```

### Tag-Bindings

Tags können Events empfangen:

```tcl
$t tag bind link <Enter> {%W configure -cursor hand2}
$t tag bind link <Leave> {%W configure -cursor xterm}
$t tag bind link <Button-1> {onLinkClick %W %x %y}
```

Verfügbare Events: Mouse-Events, Keyboard-Events (wenn Fokus)

**Wichtig:** Mit `break` Event-Propagation stoppen:

```tcl
$t tag bind link <Button-1> {onLinkClick %W %x %y; break}
```

---

## Marks

Marks sind benannte Positionen, die sich mit dem Text bewegen.

### Spezielle Marks

| Mark | Beschreibung |
|------|--------------|
| `insert` | Cursor-Position |
| `current` | Position unter Mauszeiger |

Diese können nicht gelöscht werden.

### Mark setzen

```tcl
$t mark set markName index
```

```tcl
$t mark set myMark "3.0"
$t mark set bookmark "insert"
```

### Mark abfragen

```tcl
# Position eines Marks
set pos [$t index myMark]

# Alle Marks
set marks [$t mark names]

# Nächster Mark ab Index
set next [$t mark next "1.0"]

# Vorheriger Mark
set prev [$t mark previous "end"]
```

### Mark löschen

```tcl
$t mark unset myMark
```

### Gravity

Bestimmt, auf welcher Seite neu eingefuegter Text landet:

```tcl
# Standard: right (neuer Text kommt links vom Mark)
$t mark gravity myMark right

# Left: neuer Text kommt rechts vom Mark
$t mark gravity myMark left

# Abfragen
set grav [$t mark gravity myMark]
```

### Anwendungsbeispiele

```tcl
# Lesezeichen
$t mark set bookmark "insert"
# ... später ...
$t see bookmark

# Bereich markieren
$t mark set regionStart "insert"
# ... Benutzer bewegt Cursor ...
set regionEnd [$t index "insert"]
set text [$t get regionStart $regionEnd]
```

---

## Embedded Windows

Widgets können in den Text eingebettet werden.

### Window erstellen

```tcl
$t window create index ?options?
```

| Option | Beschreibung |
|--------|--------------|
| `-window` | Widget-Pfad |
| `-create` | Script zum Erstellen |
| `-align` | Ausrichtung: `top`, `center`, `bottom`, `baseline` |
| `-padx` | Horizontaler Abstand |
| `-pady` | Vertikaler Abstand |
| `-stretch` | Auf Zeilenhöhe dehnen (boolean) |

### Beispiele

```tcl
# Button einbetten
ttk::button .t.btn -text "Klick mich" -command {puts "Geklickt!"}
$t window create end -window .t.btn

# Mit Create-Script (für Peer-Widgets)
$t window create end -create {
    ttk::button %W.btn[incr ::btnNum] -text "Button $::btnNum"
}

# Ausgerichtet
ttk::label .t.lbl -text "Zentriert"
$t window create "1.0" -window .t.lbl -align center -padx 5 -pady 5
```

### Window-Informationen abfragen

```tcl
# Alle eingebetteten Windows
set windows [$t window names]

# Konfiguration
set align [$t window cget .t.btn -align]

# Konfiguration ändern
$t window configure .t.btn -padx 10
```

### Lazy-Erzeugung mit -create

Die `-create`-Option ist mächtig: Das Widget wird erst erzeugt
wenn es sichtbar wird. Bei Dokumenten mit hunderten eingebetteten
Widgets spart das erheblich Speicher und Startzeit:

```tcl
# EAGER: Alle Widgets sofort erzeugen (langsam bei vielen)
for {set i 0} {$i < 500} {incr i} {
    ttk::checkbutton .t.cb$i -text "Aufgabe $i"
    $t window create end -window .t.cb$i
    $t insert end "\n"
}

# LAZY: Widgets erst erzeugen wenn sichtbar (schnell)
for {set i 0} {$i < 500} {incr i} {
    $t window create end -create [list apply {{t i} {
        set w $t.cb$i
        ttk::checkbutton $w -text "Aufgabe $i"
        return $w
    }} $t $i]
    $t insert end "\n"
}
```

**Wichtig:** Das `-create`-Script muss den Widget-Pfad zurückgeben.
`%W` wird durch den Text-Widget-Pfad ersetzt.

Das `-create`-Script wird erneut aufgerufen wenn das Widget
zerstört und später wieder sichtbar wird (z.B. nach Scrollen).
Für Widgets mit Zustand (Checkbuttons, Eingabefelder) muss der
Zustand extern gespeichert werden:

```tcl
# Zustand extern verwalten
namespace eval ::tasks { variable state }

for {set i 0} {$i < 500} {incr i} {
    set ::tasks::state($i) 0
    $t window create end -create [format {
        set w %%W.cb%d
        catch {destroy $w}
        ttk::checkbutton $w -text "Aufgabe %d" \
            -variable ::tasks::state(%d)
        set w
    } $i $i $i]
    $t insert end "\n"
}
```

### Eingebettete Widgets und delete

Wenn Text mit eingebetteten Widgets gelöscht wird, werden die
Widgets automatisch zerstört. Das ist normalerweise gewünscht,
kann aber zu Problemen fuehren wenn Referenzen auf die Widgets
noch existieren:

```tcl
# Widget einbetten
ttk::button .t.btn -text "Test"
$t window create end -window .t.btn

# Text löschen -> .t.btn wird zerstört!
$t delete 1.0 end

# .t.btn existiert jetzt NICHT mehr
# Jeder Zugriff erzeugt einen Fehler:
# .t.btn configure ...  -> ERROR: bad window path name ".t.btn"
```

---

## Embedded Images

Bilder können direkt in den Text eingebettet werden.

### Image erstellen

```tcl
$t image create index ?options?
```

| Option | Beschreibung |
|--------|--------------|
| `-image` | Tk-Image-Name |
| `-name` | Eindeutiger Name für dieses Vorkommen |
| `-align` | Ausrichtung: `top`, `center`, `bottom`, `baseline` |
| `-padx` | Horizontaler Abstand |
| `-pady` | Vertikaler Abstand |

### Beispiele

```tcl
# Image laden
image create photo myPhoto -file "bild.png"

# In Text einfügen
$t image create end -image myPhoto -padx 5 -pady 5

# Mit Name (für spaetere Referenz)
$t image create "1.0" -image myPhoto -name "header_image"
```

### Image-Informationen abfragen

```tcl
# Alle eingebetteten Images
set images [$t image names]

# Konfiguration
set img [$t image cget header_image -image]

# Konfiguration ändern
$t image configure header_image -padx 10
```

### Wichtig: Garbage Collection

Images müssen referenziert bleiben, sonst werden sie gelöscht:

```tcl
# FALSCH - Image wird am Proc-Ende gelöscht
proc addImage {t file} {
    set img [image create photo -file $file]
    $t image create end -image $img
}

# RICHTIG - Referenz behalten
namespace eval myapp { variable images {} }

proc addImage {t file} {
    set img [image create photo -file $file]
    $t image create end -image $img
    lappend ::myapp::images $img
}
```

---

## Scrolling und Navigation

### yview - Vertikales Scrolling

```tcl
# Aktuelle Position abfragen (Fraktion 0.0-1.0)
set pos [$t yview]
# -> {0.0 0.3} bedeutet: 0-30% sichtbar

# Zu Fraktion scrollen
$t yview moveto 0.5  ;# Mitte

# Um Einheiten scrollen
$t yview scroll 5 units   ;# 5 Zeilen runter
$t yview scroll -3 units  ;# 3 Zeilen hoch
$t yview scroll 1 pages   ;# Eine Seite runter

# Zu Index scrollen (Index oben)
$t yview "50.0"
```

### xview - Horizontales Scrolling

Analog zu yview:

```tcl
$t xview moveto 0.0
$t xview scroll 10 units
```

### see - Index sichtbar machen

```tcl
$t see index
```

`see` scrollt minimal, damit der Index sichtbar wird:
- Wenn bereits sichtbar: nichts tun
- Wenn nah am Rand: an den Rand scrollen
- Wenn weit weg: zentrieren

### Unterschied see vs. yview

| Methode | Verhalten |
|---------|-----------|
| `$t see $idx` | Index sichtbar machen (minimal scrollen) |
| `$t yview $idx` | Index nach oben scrollen |

```tcl
# Für "Gehe zu Zeile" - Index oben
$t yview "100.0"

# Für "Cursor sichtbar halten" - minimal scrollen
$t see "insert"
```

### Scroll-Position speichern und wiederherstellen

```tcl
# FALSCH - Prozentual (ungenau bei Größenänderung)
set pos [lindex [$t yview] 0]
# ... später ...
$t yview moveto $pos

# RICHTIG - Zeilen-Index
set pos [$t index @0,0]  ;# Erste sichtbare Zeile
# ... später ...
$t yview $pos
```

### Mit Scrollbar verbinden

```tcl
text .t -yscrollcommand {.sb set}
ttk::scrollbar .sb -command {.t yview}
```

### scan -- Schnelles Maus-Scrolling

Der `scan`-Befehl ermöglicht schnelles Scrollen durch Ziehen mit der
mittleren Maustaste. Ein Pattern das in professionellen Widgets wie
Tablelist standardmäßig eingesetzt wird:

```tcl
$t scan mark x y      ;# Startpunkt setzen
$t scan dragto x y    ;# Zu neuer Position scrollen
```

`scan mark` setzt den Referenzpunkt. `scan dragto` scrollt das Widget
proportional zur Differenz zwischen aktuellem und gespeichertem Punkt.
Die Bewegung ist **verstaerkt** (Faktor 10 standardmäßig), sodass
kleine Mausbewegungen grosse Scroll-Distanzen erzeugen:

```tcl
# Standard-Bindings für Maus-Drag-Scrolling
bind .t <Button-2>  {%W scan mark %x %y}
bind .t <B2-Motion> {%W scan dragto %x %y}
```

Das funktioniert sowohl horizontal als auch vertikal gleichzeitig.
Besonders nützlich bei grossen Dokumenten oder breiten Tabellen.

**Gain anpassen:**

```tcl
# scan dragto hat einen optionalen gain-Parameter
$t scan dragto $x $y 5   ;# Faktor 5 statt Standard 10
$t scan dragto $x $y 1   ;# 1:1 Bewegung (kein Verstaerker)
```

---

## Selektion

Die Selektion wird über den speziellen Tag `sel` verwaltet.

### Selektion setzen

```tcl
# Bereich selektieren
$t tag add sel "1.0" "1.10"

# Alte Selektion löschen, neue setzen
$t tag remove sel "1.0" "end"
$t tag add sel "2.0" "2.end"
```

### Selektion abfragen

```tcl
# Selektionsgrenzen
set ranges [$t tag ranges sel]
# -> {1.0 1.10} oder {} wenn keine

# Selektierten Text
if {[llength [$t tag ranges sel]] > 0} {
    set selected [$t get sel.first sel.last]
}
```

### Selektion-Optionen

```tcl
# Selektionsfarbe
$t configure -selectbackground blue -selectforeground white

# Selektion auch ohne Fokus zeigen
$t configure -inactiveselectbackground lightblue
```

**inactiveselectbackground im Detail:**

Standardmäßig verschwindet die Selektion optisch wenn das Widget
den Fokus verliert. Mit `-inactiveselectbackground` bleibt sie sichtbar:

| Option | Wert | Verhalten |
|--------|------|-----------|
| `-selectbackground` | Farbe | Selektionsfarbe MIT Fokus |
| `-inactiveselectbackground` | Farbe | Selektionsfarbe OHNE Fokus |
| `-inactiveselectbackground` | `""` (leer) | Selektion unsichtbar ohne Fokus (Standard) |

```tcl
# Multi-Panel-Editor: Selektion in beiden Panels sichtbar
text .editor  -inactiveselectbackground #d0d0ff
text .preview -inactiveselectbackground #d0d0ff

# Suchen-Dialog: Selektion im Editor bleibt sichtbar
# während der Fokus im Suchfeld ist
text .t -inactiveselectbackground lightblue
```

### sel-Tag: Besonderheiten

Der `sel`-Tag hat einige Sonderregeln:

```tcl
# 1. sel kann NICHT gelöscht werden
$t tag delete sel  ;# Wird ignoriert

# 2. sel hat eigene Farb-Konfiguration (nicht über tag configure)
$t configure -selectbackground blue     ;# RICHTIG
$t tag configure sel -background blue   ;# Hat KEINEN Effekt auf Selektion!

# 3. sel.first und sel.last sind spezielle Indizes
set start [$t index sel.first]  ;# Anfang der Selektion
set end   [$t index sel.last]   ;# Ende der Selektion
# Erzeugt Fehler wenn keine Selektion existiert!

# 4. Sichere Abfrage:
if {![catch {$t index sel.first} start]} {
    set end [$t index sel.last]
    set selected [$t get $start $end]
}

# 5. Mehrfach-Selektion ist möglich (aber ungewoehnlich)
$t tag add sel 1.0 1.5 3.0 3.8
# Selektiert zwei separate Bereiche
```

### Export-Selection

```tcl
# Selektion in X11-Clipboard exportieren
$t configure -exportselection true  ;# Standard

# Nicht exportieren
$t configure -exportselection false
```

### Clipboard-Operationen

```tcl
# Kopieren
tk_textCopy .t

# Ausschneiden
tk_textCut .t

# Einfügen
tk_textPaste .t
```

---

## Suchen

### search

```tcl
$t search ?options? pattern index ?stopIndex?
```

#### Optionen

| Option | Beschreibung |
|--------|--------------|
| `-forwards` | Vorwärts suchen (Standard) |
| `-backwards` | Rückwärts suchen |
| `-exact` | Exakte Übereinstimmung (Standard) |
| `-regexp` | Regulaerer Ausdruck |
| `-nocase` | Gross/Klein ignorieren |
| `-count varName` | Länge des Treffers speichern |
| `-all` | Alle Treffer finden |
| `-elide` | Auch in verstecktem Text suchen |
| `--` | Ende der Optionen |

#### Beispiele

```tcl
# Einfache Suche
set pos [$t search "Hallo" "1.0"]

# Rückwärts
set pos [$t search -backwards "Hallo" "end"]

# Mit Länge
set pos [$t search -count len "Hallo" "1.0"]
puts "Gefunden bei $pos, Länge $len"

# Gross/Klein ignorieren
set pos [$t search -nocase "hallo" "1.0"]

# Regulaerer Ausdruck
set pos [$t search -regexp {\d{4}-\d{2}-\d{2}} "1.0"]

# Alle Treffer
set all [$t search -all "Hallo" "1.0"]
foreach pos $all {
    puts "Treffer bei $pos"
}
```

### Suchen und Hervorheben

```tcl
proc highlightAll {t pattern} {
    $t tag remove highlight "1.0" "end"
    
    set pos "1.0"
    while {1} {
        set pos [$t search -count len $pattern $pos "end"]
        if {$pos eq ""} break
        
        set endPos [$t index "$pos + $len chars"]
        $t tag add highlight $pos $endPos
        set pos $endPos
    }
}

$t tag configure highlight -background yellow
highlightAll .t "wichtig"
```

### Suchen und Ersetzen

```tcl
proc replaceAll {t pattern replacement} {
    set count 0
    set pos "1.0"
    
    while {1} {
        set pos [$t search -count len $pattern $pos "end"]
        if {$pos eq ""} break
        
        set endPos [$t index "$pos + $len chars"]
        $t delete $pos $endPos
        $t insert $pos $replacement
        
        incr count
        set pos [$t index "$pos + [string length $replacement] chars"]
    }
    
    return $count
}
```

### search -all mit -count

Die Kombination `-all -count` gibt alle Treffer-Positionen zurück
und speichert die Längen als Liste:

```tcl
# Alle Treffer mit ihren Längen
set positions [$t search -all -count lengths -regexp {\w+} 1.0 end]

foreach pos $positions len $lengths {
    puts "Wort bei $pos, Länge $len"
}
```

### search -overlap

Bei `-all -regexp` können sich Treffer normalerweise nicht
überlappen. Mit `-overlap` werden auch überlappende Treffer gefunden:

```tcl
# Ohne -overlap: "aaa" findet nur 1 Treffer in "aaaa"
set hits [$t search -all -regexp "aaa" 1.0 end]

# Mit -overlap: findet 2 Treffer (Position 0 und 1)
set hits [$t search -all -overlap -regexp "aaa" 1.0 end]
```

### Suche in Tags einschränken

Eine nuetzliche Technik -- nur innerhalb bestimmter Tag-Bereiche suchen:

```tcl
proc searchInTag {t pattern tagName} {
    set results {}
    set ranges [$t tag ranges $tagName]
    foreach {start end} $ranges {
        set pos $start
        while {1} {
            set pos [$t search -count len $pattern $pos $end]
            if {$pos eq ""} break
            lappend results $pos
            set pos [$t index "$pos + $len chars"]
        }
    }
    return $results
}

# Nur in Code-Bloecken suchen
set hits [searchInTag .t "TODO" codeblock]
```

---

## Undo/Redo

### Aktivieren

```tcl
text .t -undo true
```

### Undo/Redo ausführen

```tcl
$t edit undo
$t edit redo
```

### Undo-Stack verwalten

```tcl
# Separator einfügen (gruppiert Aktionen)
$t edit separator

# Stack leeren
$t edit reset

# Prüfen ob Undo/Redo möglich
if {[$t edit canundo]} {
    $t edit undo
}
if {[$t edit canredo]} {
    $t edit redo
}
```

### Modified-Flag

```tcl
# Abfragen
set modified [$t edit modified]

# Setzen
$t edit modified false  ;# "Gespeichert"
$t edit modified true   ;# "Geaendert"
```

### Modified-Flag: Gotchas bei programmgesteuerten Änderungen

**Problem 1:** Jeder `insert` und `delete` setzt das Modified-Flag,
auch wenn die Änderung programmgesteuert ist (z.B. beim Laden einer Datei
oder beim Setzen von Inhalt in einem Readonly-Widget):

```tcl
# FALSCH: Nach dem Laden ist modified=true
set f [open "datei.txt" r]
$t delete 1.0 end
$t insert 1.0 [read $f]
close $f
# Modified-Flag ist jetzt true -- obwohl nichts "geändert" wurde!

# RICHTIG: Modified nach dem Laden zurücksetzen
$t delete 1.0 end
$t insert 1.0 [read $f]
close $f
$t edit modified false
$t edit reset  ;# Optional: Undo-Stack leeren (Laden ist kein Undo-Schritt)
```

**Problem 2:** `<<Modified>>` feuert bei *jedem* Wechsel des Flags,
nicht nur bei Benutzeraktionen. Wenn man in einem `<<Modified>>`-Handler
das Flag zuruecksetzt, feuert das Event erneut (Endlosschleife):

```tcl
# FALSCH: Endlosschleife
bind .t <<Modified>> {
    updateTitle
    %W edit modified false  ;# Loest <<Modified>> erneut aus!
}

# RICHTIG: Nur reagieren wenn Flag auf true wechselt
bind .t <<Modified>> {
    if {[%W edit modified]} {
        updateTitle
    }
}
```

**Problem 3:** Readonly-Widgets mit `-undo true`:
Wenn ein Readonly-Widget (state disabled) programmgesteuert befuellt wird,
sollte Undo deaktiviert sein, da sonst der Undo-Stack wächst:

```tcl
# Readonly-Widget: Undo deaktiviert
text .t -state disabled -undo false
```

### Undo-Gruppen

```tcl
# Mehrere Operationen als eine Undo-Aktion
$t edit separator
$t insert end "Zeile 1\n"
$t insert end "Zeile 2\n"
$t insert end "Zeile 3\n"
$t edit separator
# Ein Undo macht alle drei Inserts rückgängig
```

### Automatische Separator-Logik

Tk fügt automatisch Separatoren zwischen bestimmten Aktionen ein.
Das Verhalten hängt davon ab, welche Operationen aufeinander folgen:

```tcl
# Aufeinanderfolgende Zeichen werden AUTOMATISCH gruppiert:
# User tippt "Hallo" -> 5 Inserts -> EIN Undo-Schritt

# Ein delete nach inserts erzeugt AUTOMATISCH einen Separator:
# User tippt "Hallo", drueckt Backspace
# -> Undo 1: Backspace rückgängig
# -> Undo 2: "Hallo" rückgängig
```

Für programmgesteuerte Änderungen ist das Auto-Verhalten
oft unerwuenscht:

```tcl
# PROBLEM: Suchen/Ersetzen erzeugt viele Undo-Schritte
proc replaceAll {t pattern replacement} {
    # Jedes delete+insert wird ein eigener Undo-Schritt!
    set pos "1.0"
    while {1} {
        set pos [$t search -count len $pattern $pos end]
        if {$pos eq ""} break
        $t delete $pos "$pos + $len chars"
        $t insert $pos $replacement
        set pos [$t index "$pos + [string length $replacement] chars"]
    }
}

# LOESUNG: Manuell gruppieren
proc replaceAll {t pattern replacement} {
    $t edit separator
    set pos "1.0"
    while {1} {
        set pos [$t search -count len $pattern $pos end]
        if {$pos eq ""} break
        $t delete $pos "$pos + $len chars"
        $t insert $pos $replacement
        set pos [$t index "$pos + [string length $replacement] chars"]
    }
    $t edit separator
    # Ein einziges Undo macht ALLE Ersetzungen rückgängig
}
```

### maxundo -- Undo-Stack begrenzen

```tcl
# Maximale Anzahl von Undo-Schritten (0 = unbegrenzt)
text .t -undo true -maxundo 100

# Ändern
$t configure -maxundo 50
```

Bei grossen Dokumenten verhindert ein begrenzter Undo-Stack
unkontrollierten Speicherverbrauch.

### Events

```tcl
bind .t <<Modified>> {
    if {[%W edit modified]} {
        wm title . "* Dokument (geändert)"
    } else {
        wm title . "Dokument"
    }
}

bind .t <<UndoStack>> {
    # Undo-Stack hat sich geändert
    updateUndoButtons
}
```

---

## Bindings und Events

### Standard-Bindings

Das Text-Widget hat umfangreiche Standard-Bindings:

| Taste | Aktion |
|-------|--------|
| Pfeiltasten | Cursor bewegen |
| Ctrl+Pfeile | Wortweise bewegen |
| Home/End | Zeilenanfang/-ende |
| Ctrl+Home/End | Dokumentanfang/-ende |
| PageUp/Down | Seitenweise scrollen |
| Backspace | Zeichen links löschen |
| Delete | Zeichen rechts löschen |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Ctrl+C | Kopieren |
| Ctrl+X | Ausschneiden |
| Ctrl+V | Einfügen |
| Ctrl+A | Alles markieren |

### Eigene Bindings

```tcl
# Taste abfangen
bind .t <Control-s> {saveDocument; break}

# Doppelklick auf Wort
bind .t <Double-Button-1> {
    set word [%W get "insert wordstart" "insert wordend"]
    puts "Doppelklick auf: $word"
}

# Rechtsklick-Menue
bind .t <Button-3> {showContextMenu %W %X %Y}
```

### Virtuelle Events

```tcl
bind .t <<Modified>> {onModified %W}
bind .t <<Selection>> {onSelection %W}
bind .t <<UndoStack>> {onUndoStack %W}
```

### Event-Substitutionen

| Substitution | Beschreibung |
|--------------|--------------|
| `%W` | Widget-Pfad |
| `%x`, `%y` | Mausposition relativ zum Widget |
| `%X`, `%Y` | Mausposition absolut (Bildschirm) |
| `%k` | Keycode |
| `%K` | Keysym (z.B. "Return") |
| `%A` | ASCII-Zeichen |

### Break und Continue

```tcl
# Event nicht weiter verarbeiten
bind .t <Return> {handleReturn %W; break}

# Zur nächsten Binding-Ebene
bind .t <Key> {logKey %K; continue}
```

### Bindtags und Text-Widget

Jedes Text-Widget hat eine Binding-Kette (bindtags), die bestimmt
in welcher Reihenfolge Events verarbeitet werden:

```tcl
bindtags .t
# -> {.t Text . all}
# 1. .t     -- Widget-spezifische Bindings
# 2. Text   -- Klassen-Bindings (Standard-Verhalten)
# 3. .       -- Toplevel-Bindings
# 4. all    -- Globale Bindings
```

Das ist wichtig weil `break` die Verarbeitung an dieser Stelle stoppt.
Ein `break` in einem Widget-Binding (Ebene 1) verhindert, dass
die Klassen-Bindings (Ebene 2) ausgeführt werden:

```tcl
# Return abfangen OHNE Standard-Verhalten (kein Newline)
bind .t <Return> {handleReturn %W; break}

# Return abfangen MIT Standard-Verhalten (Newline wird eingefügt)
bind .t <Return> {handleReturn %W}
# Ohne break -> Klassen-Binding fügt Newline ein
```

**Readonly ohne `-state disabled`:**

Eine Alternative zu `-state disabled` ist das Entfernen der
Text-Klasse aus den bindtags. Das Widget reagiert nicht mehr
auf Tastatur, erlaubt aber noch Selektion und Mausklicks:

```tcl
# Text-Klasse entfernen = keine Tastatureingabe
bindtags .t [list .t . all]
# Standard-Maus-Bindings (Selektion etc.) funktionieren noch

# Wiederherstellen
bindtags .t [list .t Text . all]
```

Unterschied zu `-state disabled`:

| Eigenschaft | `-state disabled` | Klasse entfernt |
|-------------|-------------------|-----------------|
| Tastatureingabe | Nein | Nein |
| Maus-Selektion | Nein | Ja |
| Text kopierbar | Nein | Ja |
| Cursor sichtbar | Nein | Optional |
| Tag-Bindings | Funktionieren | Funktionieren |
| Programmgesteuerte Änderung | Nein (state normal nötig) | Ja |

```tcl
# Readonly-Widget das kopierbar bleibt
proc makeReadonly {w} {
    set tags [bindtags $w]
    set idx [lsearch $tags Text]
    if {$idx >= 0} {
        bindtags $w [lreplace $tags $idx $idx]
    }
}

proc makeEditable {w} {
    set tags [bindtags $w]
    if {"Text" ni $tags} {
        set idx [lsearch $tags [winfo class $w]]
        if {$idx < 0} { set idx 0 }
        bindtags $w [linsert $tags [expr {$idx + 1}] Text]
    }
}
```

---

## Peer Widgets

Peer Widgets teilen sich denselben Textinhalt.

### Peer erstellen

```tcl
$t peer create .t2 ?options?
```

```tcl
text .t -undo true
pack .t -side left -fill both -expand 1

# Peer erstellen
.t peer create .t2
pack .t2 -side right -fill both -expand 1

# Peers haben unterschiedliche:
# - Scroll-Position
# - Selektion
# - Cursor-Position
# - Konfiguration (Schrift, Farben, etc.)
```

### Peers abfragen

```tcl
set peers [.t peer names]
```

### Teilbereich anzeigen

```tcl
# Nur Zeilen 10-50 anzeigen
.t peer create .t2 -startline 10 -endline 50
```

---

## Tk-Fenster einbetten (Container/Use)

Tk kennt einen Mechanismus um ein Toplevel-Fenster innerhalb eines
Frame-Widgets anzuzeigen. Das ist nützlich für:
Vorschau-Panels, eingebettete Interpreter, Plugin-Fenster.

### Grundprinzip

```tcl
# 1. Container-Frame erzeugen
frame .preview -container 1
pack .preview -fill both -expand 1

# 2. Toplevel mit -use einbetten
set wid [winfo id .preview]  ;# X11 Window-ID
toplevel .embed -use $wid
# .embed ist jetzt innerhalb von .preview sichtbar
```

### Mit Slave-Interpreter (Sandbox)

Ein häufiger Anwendungsfall: Ein separater Interpreter
zeigt seine GUI im Hauptfenster an:

```tcl
# Master-Seite: Container vorbereiten
frame .preview -container 1
pack .preview -fill both -expand 1
set containerId [winfo id .preview]

# Slave-Interpreter erstellen
set slave [interp create]

# Tk im Slave laden
load {} Tk $slave

# Slave-Fenster verstecken und in Container einbetten
interp eval $slave [list wm withdraw .]
interp eval $slave [list toplevel .embed -use $containerId]

# Slave kann jetzt Widgets in .embed erstellen
interp eval $slave {
    ttk::button .embed.btn -text "Im Container!" \
        -command {puts "Klick aus dem Slave!"}
    pack .embed.btn -padx 10 -pady 10
}
```

### Cleanup beim Reset

Wenn der Slave-Interpreter neugestartet wird, muss das
eingebettete Fenster sauber aufgeraeumt werden:

```tcl
proc resetSlave {} {
    variable slave
    variable containerId
    
    # Alten Interpreter zerstören
    catch {interp delete $slave}
    
    # Container-Frame neu erstellen
    catch {destroy .preview}
    frame .preview -container 1
    pack .preview -fill both -expand 1
    set containerId [winfo id .preview]
    
    # Neuen Slave erstellen
    set slave [interp create]
    load {} Tk $slave
    interp eval $slave [list wm withdraw .]
    interp eval $slave [list toplevel .embed -use $containerId]
}
```

### Einschränkungen

| Einschränkung | Beschreibung |
|----------------|--------------|
| Plattform | Funktioniert zuverlässig auf X11 (Linux). macOS und Windows haben Einschränkungen |
| Resizing | Container muss gross genug sein; das eingebettete Fenster passt sich an die Container-Größe an |
| Fokus | Fokus-Handling zwischen Container und eingebettetem Fenster kann kompliziert sein |
| Menus | Menubar des eingebetteten Fensters wird nicht in die Hauptanwendung integriert |

**Empfehlung:** Für einfache Fälle (Vorschau, Lernumgebungen)
ist die einfachere Alternative oft ausreichend: den Slave sein
eigenes Toplevel oeffnen lassen und es mit `wm transient` an
das Hauptfenster binden:

```tcl
# Einfacher: Slave-Fenster als abhaengiges Fenster
interp eval $slave [list wm transient . [winfo pathname [winfo id .]]]
# Das Slave-Fenster bleibt immer über dem Hauptfenster
```

---

## Performance

### Grosse Dokumente

Tipps für optimale Performance:

```tcl
# 1. Batch-Inserts
# Langsam:
foreach line $lines {
    $t insert end "$line\n"
}
# Schnell:
$t insert end [join $lines "\n"]

# 2. Tags am Ende hinzufügen
$t insert end $text
$t tag add myTag "1.0" "end"

# 3. Updates buendeln
$t configure -state normal
# Viele Operationen...
update idletasks  ;# Einmal
$t configure -state disabled

# 4. Elide statt Delete für temporäres Verstecken
$t tag configure hidden -elide true
$t tag add hidden $start $end
# Später:
$t tag remove hidden $start $end
```

### Asynchrone Zeilenhöhen

Bei sehr grossen Dokumenten werden Zeilenhöhen asynchron berechnet:

```tcl
# Auf Berechnung warten
$t sync

# Callback wenn fertig
$t sync -command {puts "Fertig!"}

# Prüfen ob Berechnung läuft
if {[$t pendingsync]} {
    puts "Noch nicht fertig..."
}
```

### Rendering während Bulk-Operationen pausieren

Bei vielen Änderungen kann das Widget versteckt werden,
um Zwischen-Renderings zu vermeiden:

```tcl
proc bulkUpdate {t script} {
    # Widget unsichtbar machen während der Änderungen
    set oldState [$t cget -state]
    
    # Variante 1: pack forget / re-pack
    set packInfo [pack info $t]
    pack forget $t
    
    # Änderungen ausführen
    uplevel 1 $script
    
    # Widget wieder anzeigen
    pack {*}$packInfo
    update idletasks
}

# Verwendung:
bulkUpdate .t {
    .t delete 1.0 end
    foreach line $largeDocument {
        .t insert end "$line\n" body
    }
}
```

### Tags direkt beim Insert statt nachträglich

```tcl
# LANGSAM: Insert + tag add (zwei Operationen pro Zeile)
foreach {text tag} $formattedContent {
    set start [$t index end]
    $t insert end $text
    $t tag add $tag $start end
}

# SCHNELL: Tag direkt beim Insert (eine Operation)
foreach {text tag} $formattedContent {
    $t insert end $text $tag
}
```

### update idletasks vs. update

Zwei häufig verwechselte Befehle mit sehr unterschiedlichem Verhalten:

```tcl
update idletasks
# Verarbeitet NUR aufgestaute idle-Events:
# - Display-Updates (Rendering)
# - after idle Callbacks
# - Geometry-Berechnungen
# NICHT: Timer-Events, Maus-Events, Keyboard-Events
# SICHER: Keine überraschenden Callbacks

update
# Verarbeitet ALLE anstehenden Events:
# - Alles von idletasks PLUS
# - Timer (after N)
# - Maus-Events (Button, Motion)
# - Keyboard-Events
# - Window-Events (Configure, Destroy)
# GEFAEHRLICH: Kann rekursive Event-Loops auslösen!
```

**Faustregel:**

```tcl
# In Batch-Operationen: IMMER idletasks, NIE update
proc loadDocument {t content} {
    $t configure -state normal
    $t delete 1.0 end
    $t insert 1.0 $content
    $t configure -state disabled
    update idletasks  ;# Rendering erzwingen, SICHER
}

# GEFAEHRLICH: update kann Callbacks auslösen
proc loadDocumentBad {t content} {
    $t configure -state normal
    $t delete 1.0 end
    $t insert 1.0 $content
    update  ;# SCHLECHT: Ein Timer oder Button-Click könnte
            ;# dieselbe Prozedur erneut aufrufen!
    $t configure -state disabled
}
```

**Warum update gefaehrlich ist:**

```tcl
# Szenario: User klickt zweimal schnell auf "Laden"
proc onLoadClick {} {
    set content [readFile]
    .t configure -state normal
    .t delete 1.0 end
    .t insert 1.0 $content
    update  ;# <-- Hier wird der ZWEITE Klick verarbeitet!
            ;# onLoadClick wird rekursiv aufgerufen
            ;# während der erste noch läuft!
    .t configure -state disabled
}
```

### count mit -update Flag

Der `count`-Befehl kann mit `-update` die asynchrone Zeilenhöhen-
Berechnung erzwingen, bevor gezaehlt wird:

```tcl
# Ohne -update: Kann ungenaue Werte liefern bei grossen Dokumenten
set lines [$t count -displaylines 1.0 end]

# Mit -update: Wartet auf vollständige Berechnung
set lines [$t count -displaylines -update 1.0 end]

# Nützlich für exakte Scroll-Berechnungen
set totalPixels [$t count -ypixels -update 1.0 end]
```

### Wiederholt aktualisierte Widgets: Flicker vermeiden

Bei Widgets die häufig aktualisiert werden (Timeline, Logviewer,
Status-Anzeige) entsteht Flickern wenn bei jedem Update der gesamte
Inhalt gelöscht und neu eingefügt wird:

```tcl
# SCHLECHT: Flickert bei häufigen Updates
proc updateTimeline {t events} {
    $t configure -state normal
    $t delete 1.0 end          ;# <-- Widget ist kurz leer = Flicker!
    foreach ev $events {
        $t insert end "$ev\n"
    }
    $t configure -state disabled
}

# BESSER: replace statt delete+insert
proc updateTimeline {t events} {
    $t configure -state normal
    $t replace 1.0 end [join $events "\n"]
    $t configure -state disabled
}

# NOCH BESSER: Nur ändern was sich geändert hat (inkrementell)
proc appendTimeline {t newEvent} {
    $t configure -state normal
    $t insert end "$newEvent\n"
    $t configure -state disabled
    $t see end
}
```

---

## Bekannte Probleme und Lösungen

### 1. end-Index zeigt auf falsches Zeichen

**Problem:** `end` zeigt nach dem impliziten Newline.

**Lösung:** `end-1c` verwenden.

```tcl
set lastChar [$t index "end-1c"]
```

### 2. Index vor/nach Insert identisch

**Problem:**
```tcl
set start [$t index end]
$t insert end "Text"
set end [$t index end]
# start == end!
```

**Lösung:**
```tcl
set start [$t index "end-1c"]
$t insert end "Text"
set end [$t index "end-1c"]
```

### 3. Scroll-Position ungenau nach Resize

**Problem:** `yview moveto` ist prozentual.

**Lösung:** Zeilen-Index speichern.

```tcl
set pos [$t index @0,0]
# ... resize ...
$t yview $pos
```

### 4. Tag-Bindings kollidieren mit Widget-Bindings

**Problem:** Beide werden ausgeführt.

**Lösung:** `break` verwenden.

```tcl
$t tag bind link <Button-1> {onClick %W; break}
```

### 5. Eingebettete Images verschwinden

**Problem:** Garbage Collection loescht unreferenzierte Images.

**Lösung:** Referenzen behalten.

```tcl
lappend ::myImages $img
```

### 6. State disabled blockiert Insert

**Problem:** Im disabled-State funktioniert insert nicht.

**Lösung:** State temporär ändern.

```tcl
$t configure -state normal
$t insert end "Text"
$t configure -state disabled
```

### 7. Wiederholtes delete+insert verursacht Flickern

**Problem:** Bei häufig aktualisierten Widgets (Timer-Updates, Live-Logs)
flackert die Anzeige, weil zwischen `delete` und `insert` das Widget
kurzzeitig leer ist.

**Lösung:** `replace` statt `delete` + `insert` verwenden:

```tcl
# SCHLECHT: Flickert
$t delete 1.0 end
$t insert 1.0 $newContent

# GUT: Atomare Ersetzung
$t replace 1.0 end $newContent
```

Für inkrementelle Updates (z.B. Log-Viewer) nur neue Inhalte anhängen
statt alles neu zu schreiben.

### 8. @x,y-Index nach Scrollen falsch interpretiert

**Problem:** `@x,y` bezieht sich auf Widget-Koordinaten, nicht auf
Dokument-Koordinaten. Nach dem Scrollen zeigt `@0,0` nicht auf
Zeile 1, sondern auf die erste sichtbare Zeile.

```tcl
# @0,0 ist IMMER die linke obere Ecke des SICHTBAREN Bereichs
set firstVisible [$t index @0,0]
# -> Kann "35.0" sein, wenn nach unten gescrollt

# Für die erste Zeile des Dokuments immer "1.0" verwenden
set firstLine [$t index 1.0]
```

### 9. sel-Tag und Peer Widgets

**Problem:** Jedes Peer-Widget hat seinen eigenen `sel`-Tag.
Selektion in einem Peer beeinflusst nicht die Selektion im anderen.
Das kann verwirrend sein, wenn Code annimmt, dass `sel` global ist.

**Lösung:** Explizit das Widget angeben:

```tcl
# Selektion aus einem bestimmten Peer lesen
set selected [$peerWidget get sel.first sel.last]

# Nicht: "sel" als globalen Zustand behandeln
```

### 10. -exportselection und mehrere Text-Widgets

**Problem:** Wenn `-exportselection true` (Standard) gesetzt ist,
loescht eine Selektion in einem Text-Widget die Selektion in
allen anderen Widgets (weil die X11/System-Selektion übernommen wird).

**Lösung:** Für sekundaere Panels `-exportselection false` setzen:

```tcl
# Haupt-Editor: Selektion exportieren (Standard)
text .editor -exportselection true

# Sekundaere Anzeige: Selektion NICHT exportieren
text .preview -exportselection false
text .output  -exportselection false
```

### 11. Grosse Dokumente: Scroll-Position springt bei Zeileneinfuegung

**Problem:** Wenn oberhalb des sichtbaren Bereichs Zeilen eingefügt
werden, verschiebt sich der sichtbare Bereich nach unten.

**Lösung:** Sichtbare Position speichern und wiederherstellen:

```tcl
proc insertAbove {t lineNum text} {
    # Position merken
    set visible [$t index @0,0]
    
    # Oberhalb einfügen
    $t insert "$lineNum.0" "$text\n"
    
    # Position wiederherstellen
    $t yview $visible
}
```

### 12. Linien zwischen Textzeilen positionieren (Overlay)

**Problem:** Man moechte horizontale Linien (1px Frames) über dem
Text-Widget schweben lassen, zwischen den Textzeilen -- wie auf
Schreibblockpapier.

**Lösung:** Frames als Kinder des Text-Widgets erstellen und mit
`place -in` positionieren. Faktor 1.5 auf `font metrics -linespace`
setzt die Linien genau zwischen die Textzeilen:

```tcl
set txt .ed.txt
set ls [font metrics [$txt cget -font] -linespace]

# Frame als Kind des Text-Widgets
frame $txt._line0 -height 1 -bg "#c8d8e8"

# Linie zwischen Zeile 1 und 2 (Faktor 1.5)
set ypos [expr {int($ls * 1.5)}]
::place $txt._line0 -in $txt -x 0 -y $ypos \
    -relwidth 1.0 -height 1
raise $txt._line0
```

**Wichtig:**
- `::place` statt `place` verwenden wenn der Code in einem
  Namespace liegt (vermeidet Namenskollision)
- `raise` nach `place` damit die Linie über dem Text liegt
- `-in $txt` ist nötig weil der Frame Kind des Text-Widgets ist
- `$txt sync` vor `dlineinfo` aufrufen wenn Zeilenpositionen
  abgefragt werden (Layout-Race verhindern)

### 13. place und Namenskollision

**Problem:** `place` kollidiert mit eigenem Proc-Namen in Namespaces.

**Lösung:** `::place` (global qualifiziert) verwenden:

```tcl
namespace eval mywidget {
    proc draw {path} {
        # FALSCH -- kann eigene "place"-Proc aufrufen:
        place $path._line -x 10 -y 20

        # RICHTIG -- Tk-Befehl explizit:
        ::place $path._line -x 10 -y 20
    }
}
```

Die FAQ (Abschnitt 13) dokumentiert `::info`, `::set`, `::list`.
Auch `::place`, `::raise` und `::lower` gehören dazu wenn
Namespaces Geometrie-Management durchführen.

---

## Named Fonts

Named Fonts sind ein zentraler Mechanismus für konsistente Schriftarten.
Sie loesen das Font-Ambiguitätsproblem und erlauben zentrale Änderungen.

### Font erstellen

```tcl
font create myFont -family "DejaVu Sans" -size 11 -weight normal
font create myBold -family "DejaVu Sans" -size 11 -weight bold
font create myMono -family "DejaVu Sans Mono" -size 10
```

### Font in Widgets und Tags verwenden

```tcl
text .t -font myFont
$t tag configure strong -font myBold
$t tag configure code -font myMono
```

Named Fonts können zentral geändert werden -- alle Widgets und Tags
die den Font referenzieren aktualisieren sich automatisch:

```tcl
# Schriftgröße global ändern
font configure myFont -size 14
font configure myBold -size 14
# Alle Widgets und Tags die myFont/myBold nutzen
# passen sich sofort an
```

### Das Font-Ambiguitätsproblem

Tk's Listen-Format für Fonts ist mehrdeutig bei Familien mit Leerzeichen:

```tcl
# FALSCH: Mehrdeutig bei "DejaVu Sans"
$t tag configure h1 -font {DejaVu Sans 16 bold}
# Tk liest: family="DejaVu", size="Sans", weight="16" ... Fehler!

# Workaround 1: Option-Format (eindeutig, aber verbose)
$t tag configure h1 -font [list -family "DejaVu Sans" -size 16 -weight bold]

# Workaround 2: Named Font (sauber, wiederverwendbar)
font create h1Font -family "DejaVu Sans" -size 16 -weight bold
$t tag configure h1 -font h1Font
```

### Font-Informationen abfragen

```tcl
# Aktuelle Eigenschaften eines Named Fonts
font configure myFont
# -> -family {DejaVu Sans} -size 11 -weight normal ...

# Einzelne Eigenschaft
font configure myFont -family
# -> DejaVu Sans

# Tatsächliche Werte (nach Plattform-Auflösung)
font actual myFont
font actual myFont -family

# Auch für Ad-hoc-Fonts
font actual {Helvetica 12 bold}
# -> Was das System tatsächlich verwendet
```

### Font-Metriken

```tcl
# Schriftmetriken abfragen
font metrics myFont
# -> -ascent 14 -descent 4 -linespace 18 -fixed 0

# Einzeln
set lineHeight [font metrics myFont -linespace]
set isFixed    [font metrics myFont -fixed]
```

### Textbreite in Pixeln messen

```tcl
# Breite eines Strings in einem Font (in Pixeln)
set width [font measure myFont "Beispieltext"]
# -> z.B. 87

# Nützlich für:
# - Tabellenspalten-Berechnung
# - Dynamische Widget-Breiten
# - Zentrierung von Text
```

### Verfügbare Fonts auflisten

```tcl
# Alle auf dem System verfügbaren Font-Familien
set families [lsort -unique [font families]]
foreach f $families { puts $f }

# Prüfen ob eine Familie existiert
if {"Consolas" in [font families]} {
    font create codeFnt -family Consolas -size 10
} else {
    font create codeFnt -family TkFixedFont -size 10
}
```

### Named Fonts löschen

```tcl
font delete myFont
```

**Achtung:** Löschen eines Named Fonts während er noch referenziert wird
erzeugt einen Fehler. Named Fonts sollen normalerweise die gesamte
Anwendungs-Lebensdauer bestehen.

### Empfohlenes Muster: Font-Hierarchie

```tcl
namespace eval ::app {
    proc initFonts {baseSize} {
        catch { font delete appBody appBold appItalic appMono appH1 appH2 }
        
        set family [font actual TkDefaultFont -family]
        set monoFamily [font actual TkFixedFont -family]
        
        font create appBody   -family $family     -size $baseSize
        font create appBold   -family $family     -size $baseSize -weight bold
        font create appItalic -family $family     -size $baseSize -slant italic
        font create appMono   -family $monoFamily -size $baseSize
        font create appH1     -family $family     -size [expr {int($baseSize * 1.6)}] -weight bold
        font create appH2     -family $family     -size [expr {int($baseSize * 1.4)}] -weight bold
    }
    
    proc setFontSize {newSize} {
        font configure appBody   -size $newSize
        font configure appBold   -size $newSize
        font configure appItalic -size $newSize
        font configure appMono   -size $newSize
        font configure appH1    -size [expr {int($newSize * 1.6)}]
        font configure appH2    -size [expr {int($newSize * 1.4)}]
        # Alle Widgets/Tags passen sich automatisch an!
    }
}

::app::initFonts 11
text .t -font appBody
$t tag configure strong -font appBold
$t tag configure em -font appItalic
$t tag configure code -font appMono
```

---

## Pixel-Positionen und Geometrie

Das Text-Widget bietet Methoden um Pixel-Koordinaten von Zeichen
und Zeilen abzufragen. Nützlich für Tooltips, Popup-Menues,
Cursor-Positionierung und Scroll-Berechnungen.

### bbox -- Bounding Box eines Zeichens

```tcl
lassign [$t bbox index] x y width height
```

Gibt die Pixel-Koordinaten eines einzelnen Zeichens zurück
(relativ zum Widget). Gibt leere Liste zurück wenn das Zeichen
nicht sichtbar ist.

```tcl
# Position des Cursors in Pixeln
lassign [$t bbox insert] cx cy cw ch
if {$cx ne ""} {
    puts "Cursor bei x=$cx y=$cy, Zeichen ${cw}x${ch} Pixel"
}

# Tooltip an Cursor-Position zeigen
lassign [$t bbox insert] x y w h
if {$x ne ""} {
    set wx [expr {[winfo rootx $t] + $x}]
    set wy [expr {[winfo rooty $t] + $y + $h}]
    showTooltip $wx $wy "Info-Text"
}
```

### dlineinfo -- Display-Zeilen-Information

```tcl
lassign [$t dlineinfo index] x y width height baseline
```

Gibt Informationen über die gesamte Display-Zeile zurück
(nicht die logische Zeile -- bei Umbruch sind das mehrere):

```tcl
lassign [$t dlineinfo 1.0] x y w h bl
puts "Zeile 1: Position $x,$y  Größe ${w}x${h}  Baseline $bl"

# Sichtbarkeit prüfen
if {[$t dlineinfo 50.0] eq ""} {
    puts "Zeile 50 ist nicht sichtbar"
}
```

### Tooltip für Links mit bbox

Ein praxisnahes Beispiel -- URL-Anzeige beim Hover über Links:

```tcl
namespace eval ::linkTooltip {
    variable tipWin ""
    variable afterId ""
}

proc ::linkTooltip::show {widget x y url} {
    variable tipWin
    variable afterId
    
    cancel
    
    set afterId [after 500 [list apply {{w x y url} {
        set ::linkTooltip::tipWin $w.tip
        catch {destroy $::linkTooltip::tipWin}
        
        set wx [expr {[winfo rootx $w] + $x}]
        set wy [expr {[winfo rooty $w] + $y + 20}]
        
        toplevel $::linkTooltip::tipWin
        wm overrideredirect $::linkTooltip::tipWin 1
        wm geometry $::linkTooltip::tipWin "+$wx+$wy"
        
        ttk::label $::linkTooltip::tipWin.l -text $url \
            -background "#ffffe0" -padding {4 2}
        pack $::linkTooltip::tipWin.l
    }} $widget $x $y $url]]
}

proc ::linkTooltip::cancel {} {
    variable tipWin
    variable afterId
    catch {after cancel $afterId}
    catch {destroy $tipWin}
}

# Verwendung:
$t tag bind link <Enter> {
    ::linkTooltip::show %W %x %y [getUrlAt %W %x %y]
    %W configure -cursor hand2
}
$t tag bind link <Leave> {
    ::linkTooltip::cancel
    %W configure -cursor {}
}
```

### Sichtbaren Bereich ermitteln

```tcl
# Erste und letzte sichtbare Zeile
set firstVisible [$t index @0,0]
set lastVisible  [$t index @0,[winfo height $t]]
puts "Sichtbar: Zeile $firstVisible bis $lastVisible"

# Anzahl sichtbarer Display-Zeilen
set visibleLines [$t count -displaylines @0,0 @0,[winfo height $t]]
```

### Pixel-Höhe des Inhalts

```tcl
# Gesamte Pixel-Höhe (auch nicht-sichtbarer Bereich)
set totalPixels [$t count -ypixels 1.0 end]

# Achtung: Bei grossen Dokumenten ist die Berechnung asynchron
# Warten bis Berechnung fertig:
$t sync
set totalPixels [$t count -ypixels 1.0 end]
```

---

## Fortgeschrittene Techniken

Aus der Analyse von Tablelist 7.9 (Csaba Nemethi), dem komplexesten
Megawidget auf Basis des Text-Widgets, ergeben sich zahlreiche
fortgeschrittene Techniken.

### Cursor komplett verstecken

Für Widgets die keine Texteingabe erlauben (Tabellen, Viewer, Listen)
kann der Cursor mit `-insertwidth 0` unsichtbar gemacht werden:

```tcl
# Cursor komplett unsichtbar
text .t -insertwidth 0 -highlightthickness 0

# Kombination: Kein Cursor, kein Highlight, keine Selektion-Export
text .table -insertwidth 0 -highlightthickness 0 \
    -exportselection 0 -padx 0 -pady 0
```

Tablelist nutzt `-insertwidth 0` auf allen seinen internen
Text-Widgets (Body und Header).

### sel-Tag vermeiden (Windows-Workaround)

**Problem:** Auf Windows wird die `sel`-Tag-Selektion nur sichtbar
wenn das Text-Widget den Input-Fokus hat. In komplexen Widgets
mit mehreren fokussierbaren Komponenten verschwindet die Selektion
staendig.

**Lösung:** Eigenen Selektions-Tag verwenden statt `sel`:

```tcl
# Tablelist-Pattern: Eigener select-Tag statt sel
$t tag configure mySelect -background #0078d7 -foreground white

proc selectRange {t from to} {
    $t tag remove mySelect 1.0 end
    $t tag add mySelect $from $to
}

proc getSelection {t} {
    set ranges [$t tag ranges mySelect]
    if {[llength $ranges] == 0} { return "" }
    return [$t get [lindex $ranges 0] [lindex $ranges 1]]
}
```

Vorteile gegenüber `sel`:
- Sichtbar ohne Fokus (keine `-inactiveselectbackground` nötig)
- Volle Kontrolle über Farben via `tag configure`
- Kein Konflikt mit `-exportselection`
- Funktioniert identisch auf allen Plattformen

### Tag-Erstellungsreihenfolge bestimmt Priorität

Die Reihenfolge der Tag-Erstellung bestimmt die initiale Priorität:
später erstellte Tags haben hoehere Priorität. Das ist wichtig
für Widgets mit vielen Tags:

```tcl
# Tablelist erstellt Tags in dieser Reihenfolge (niedrig -> hoch):
# "DO NOT CHANGE the order of creation of these tags!"

$t tag configure itembg   -background ""           ;# Zeilen-Hintergrund
$t tag configure stripe   -background "" -foreground ""  ;# Zebra-Streifen
$t tag configure select   -relief raised           ;# Selektion
$t tag configure curRow   -borderwidth 1 -relief raised  ;# Aktive Zeile
$t tag configure active   -borderwidth ""          ;# Aktive Zelle
$t tag configure disabled -foreground ""           ;# Deaktiviert
$t tag configure redraw   -relief sunken           ;# Redraw-Marker
$t tag configure hiddenRow -elide 1                ;# Zeile versteckt
$t tag configure elidedRow -elide 1                ;# Baum-Knoten eingeklappt
$t tag configure hiddenCol -elide 1                ;# Spalte versteckt
$t tag configure elidedCol -elide 1                ;# Horizontales Scrolling

# Erstellungsreihenfolge:
# itembg < stripe < select < curRow < active < disabled < ...
```

**Wichtig:** `tag raise` und `tag lower` verschieben Tags in der
Prioritaetsliste. Aber die initiale Reihenfolge bei der Erstellung
bestimmt die Default-Priorität. Bei Widgets mit vielen Tags
ist es sicherer, die Erstellungsreihenfolge bewusst zu gestalten
statt nachträglich mit raise/lower zu korrigieren.

### Unsichtbarer Strukturtext mit Minimal-Font

Tablelist nutzt einen Font mit Größe -1 (1 Pixel), um
strukturellen Text unsichtbar zu machen, der aber für die
interne Logik gebraucht wird:

```tcl
# Font mit minimaler Größe für unsichtbaren Strukturtext
$t tag configure tinyFont -font "Courier -1"
$t tag add tinyFont 1.0 end

# Das Tag noSpacings eliminiert Spacing für die Header-Zeile
$t tag configure noSpacings -spacing1 0 -spacing3 0
$t tag add noSpacings 1.0
```

**Anwendungsfall:** Wenn das Text-Widget strukturelle Zeichen
enthält (Trennzeichen, Marker), die für die interne Logik
benötigt werden, aber nicht sichtbar sein sollen. Alternative zu
`elide` wenn der Text noch auffindbar bleiben soll (z.B. mit
`search -elide`).

### Mehrere Elide-Tags für verschiedene Zwecke

Tablelist nutzt 5 separate Elide-Tags für unterschiedliche
Versteck-Gruende. Das erlaubt unabhängige Steuerung:

```tcl
# Jeder Grund hat seinen eigenen Tag
$t tag configure hiddenRow -elide 1   ;# User versteckt Zeile
$t tag configure elidedRow -elide 1   ;# Baum-Knoten eingeklappt
$t tag configure hiddenCol -elide 1   ;# User versteckt Spalte
$t tag configure elidedCol -elide 1   ;# Horizontales Scrolling
$t tag configure elidedWin -elide 1   ;# Widget temporär versteckt
```

**Warum nicht ein einziger elide-Tag?**

Wenn ein einziger Tag für alles verwendet wird, kann man nicht
zwischen den Gruenden unterscheiden. Beim Aufklappen eines
Baum-Knotens darf nur `elidedRow` entfernt werden, nicht
`hiddenRow` (das der User explizit gesetzt hat):

```tcl
# Pattern: Unabhaengige Elide-Steuerung
proc expandNode {t row} {
    # Nur elidedRow entfernen, hiddenRow bleibt!
    $t tag remove elidedRow "$row.0" "$row.end+1c"
}

proc hideRow {t row} {
    # hiddenRow setzen (unabhängig von elidedRow)
    $t tag add hiddenRow "$row.0" "$row.end+1c"
}

proc showRow {t row} {
    # Nur hiddenRow entfernen
    $t tag remove hiddenRow "$row.0" "$row.end+1c"
    # Wenn elidedRow noch gesetzt ist, bleibt die Zeile versteckt!
}
```

### Elide für horizontales Spalten-Scrolling

Tablelist nutzt `elidedCol`, um Spalten links des sichtbaren
Bereichs zu verstecken. Das ist schneller als `xview` für
tabellarische Layouts:

```tcl
# Spalte 0 bis 2 verstecken (links rausscrollen)
proc hideColumns {t fromCol toCol} {
    foreach line [getDataLines $t] {
        set tabs [findTabs $t $line]
        set startIdx [lindex $tabs $fromCol]
        set endIdx   [lindex $tabs [expr {$toCol + 1}]]
        $t tag add elidedCol $startIdx $endIdx
    }
}
```

### dump -window: Embedded Widgets finden

`dump -window` gibt alle eingebetteten Widgets in einem Bereich
zurück. Tablelist nutzt das intensiv um Widgets an bestimmten
Positionen zu lokalisieren:

```tcl
# Widget an einem bestimmten Index finden
set path [lindex [$t dump -window $index] 1]
# -> Gibt Widget-Pfad zurück, z.B. ".t.f.btn"

# Alle Widgets in einem Bereich finden
foreach {dummy path textIdx} [$t dump -window 1.0 end] {
    puts "Widget $path bei $textIdx"
}

# Praktisch: Widget in einer bestimmten Zelle finden
proc widgetAt {t lineIdx colIdx} {
    set startIdx "$lineIdx.$colIdx"
    set result [$t dump -window $startIdx "$startIdx + 1 chars"]
    if {[llength $result] >= 2} {
        return [lindex $result 1]
    }
    return ""
}
```

### search -elide: In verstecktem Text suchen

Standardmäßig ignoriert `search` elidierten (versteckten) Text.
Mit `-elide` wird auch in verstecktem Text gesucht:

```tcl
# Standard: Nur sichtbaren Text durchsuchen
set pos [$t search "Suchtext" 1.0 end]

# Mit -elide: Auch versteckten Text durchsuchen
set pos [$t search -elide "Suchtext" 1.0 end]
```

Tablelist nutzt `search -elide "\t"` um Tab-Trennzeichen
zwischen Spalten zu finden, auch wenn Spalten versteckt
(elidiert) sind:

```tcl
# Tab-Positionen in einer Zeile finden (auch in versteckten Spalten)
set tabPos [$t search -elide "\t" $lineStart $lineEnd]
```

### Index-Einheiten: chars vs. indices (Unicode-Portabilitaet)

Seit Tk 8.5 unterscheidet das Text-Widget zwischen `chars`
(Unicode-Zeichen) und `indices` (interne Positionen, die auch
eingebettete Widgets und Images zählen). Das ist wichtig für
Widgets mit eingebetteten Elementen:

```tcl
# "chars" zählt nur Textzeichen
$t index "1.0 + 5 chars"    ;# 5 Unicode-Zeichen weiter

# "indices" zählt Textzeichen UND eingebettete Widgets/Images
$t index "1.0 + 5 indices"  ;# 5 Positionen weiter (inkl. Widgets)
```

Tablelist verwendet eine Variable `pu` (position unit) die je
nach Tk-Version "chars" oder "indices" enthält:

```tcl
# Portabler Code für verschiedene Tk-Versionen
if {$::tk_version >= 8.5} {
    set pu "indices"
} else {
    set pu "chars"
}

# Verwendung:
set nextPos [$t index "$pos + 1 $pu"]
set prevPos [$t index "$pos - 1 $pu"]
```

**Wann ist der Unterschied relevant?**

Nur wenn das Text-Widget eingebettete Widgets oder Images enthält.
Für reinen Text sind `chars` und `indices` identisch.

```tcl
# Zeile: "Text[WIDGET]mehr"
# chars:   T=0 e=1 x=2 t=3 [WIDGET wird übersprungen] m=4 e=5 h=6 r=7
# indices: T=0 e=1 x=2 t=3 [WIDGET]=4 m=5 e=6 h=7 r=8
```

### Bindtags-Ersetzung für Megawidgets

Tablelist ersetzt den Standard-Binding-Tag `Text` durch eigene Tags.
Das gibt volle Kontrolle über das Verhalten:

```tcl
# Standard-Bindtags: {.t Text . all}
# Tablelist ersetzt Text mit eigenen Tags:
bindtags $body [list $body $bodyTag TablelistBody $topWin \
                TablelistKeyNav all]

# $bodyTag  = instanz-spezifische Bindings
# TablelistBody = klassen-spezifische Bindings (statt Text)
# TablelistKeyNav = Tastaturnavigation
```

Das ermöglicht unterschiedliche Binding-Klassen für verschiedene
Instanzen desselben Megawidgets. Ein Pattern das für alle
Text-Widget-basierten Megawidgets nützlich ist:

```tcl
# Pattern: Eigene Binding-Klasse für ein Megawidget
proc createViewer {w} {
    text $w -wrap word -insertwidth 0
    
    set instanceTag "viewer_$w"
    bindtags $w [list $w $instanceTag ViewerClass [winfo toplevel $w] all]
    
    # Klassen-Bindings (gelten für alle Viewer-Instanzen)
    bind ViewerClass <Up>    {viewerScroll %W -1}
    bind ViewerClass <Down>  {viewerScroll %W 1}
    bind ViewerClass <space> {viewerPageDown %W}
    
    # Instanz-Bindings (nur für diese Instanz)
    bind $instanceTag <Button-3> [list viewerContextMenu $w %X %Y]
    
    return $w
}
```

---

## Praxisbeispiele

### Einfacher Editor

```tcl
package require Tk

# Hauptfenster
wm title . "Editor"

# Menue
menu .menu
.menu add cascade -label "Datei" -menu .menu.file
menu .menu.file
.menu.file add command -label "Neu" -command newFile
.menu.file add command -label "Oeffnen..." -command openFile
.menu.file add command -label "Speichern" -command saveFile
.menu.file add separator
.menu.file add command -label "Beenden" -command exit
. configure -menu .menu

# Text mit Scrollbar
ttk::frame .f
text .f.t -wrap word -undo true \
    -yscrollcommand {.f.sb set}
ttk::scrollbar .f.sb -command {.f.t yview}
pack .f.sb -side right -fill y
pack .f.t -fill both -expand 1
pack .f -fill both -expand 1

# Funktionen
set currentFile ""

proc newFile {} {
    global currentFile
    .f.t delete 1.0 end
    set currentFile ""
    .f.t edit reset
    .f.t edit modified false
    wm title . "Editor - Neu"
}

proc openFile {} {
    global currentFile
    set file [tk_getOpenFile -filetypes {
        {"Textdateien" {.txt}}
        {"Alle Dateien" *}
    }]
    if {$file ne ""} {
        set f [open $file r]
        .f.t delete 1.0 end
        .f.t insert 1.0 [read $f]
        close $f
        set currentFile $file
        .f.t edit reset
        .f.t edit modified false
        wm title . "Editor - [file tail $file]"
    }
}

proc saveFile {} {
    global currentFile
    if {$currentFile eq ""} {
        set currentFile [tk_getSaveFile -filetypes {
            {"Textdateien" {.txt}}
            {"Alle Dateien" *}
        }]
    }
    if {$currentFile ne ""} {
        set f [open $currentFile w]
        puts -nonewline $f [.f.t get 1.0 "end-1c"]
        close $f
        .f.t edit modified false
        wm title . "Editor - [file tail $currentFile]"
    }
}

# Modified-Anzeige
bind .f.t <<Modified>> {
    if {[.f.t edit modified]} {
        wm title . "* Editor"
    }
}

# Tastenkuerzel
bind . <Control-n> newFile
bind . <Control-o> openFile
bind . <Control-s> saveFile
```

### Syntax-Highlighting

```tcl
package require Tk

text .t -wrap none -font {Consolas 11}
pack .t -fill both -expand 1

# Tags definieren
.t tag configure keyword -foreground blue
.t tag configure string -foreground green
.t tag configure comment -foreground gray
.t tag configure number -foreground orange

# Tcl-Keywords
set keywords {
    proc return if else elseif while for foreach
    switch set unset expr puts package require
    namespace variable global upvar uplevel
}

proc highlight {t} {
    # Alle Tags entfernen
    foreach tag {keyword string comment number} {
        $t tag remove $tag 1.0 end
    }
    
    set content [$t get 1.0 end]
    
    # Keywords
    foreach kw $::keywords {
        set pos "1.0"
        while {1} {
            set pos [$t search -regexp "\\m$kw\\M" $pos end]
            if {$pos eq ""} break
            set endPos [$t index "$pos + [string length $kw] chars"]
            $t tag add keyword $pos $endPos
            set pos $endPos
        }
    }
    
    # Strings
    set pos "1.0"
    while {1} {
        set pos [$t search -regexp {"[^"]*"} $pos end]
        if {$pos eq ""} break
        set match [$t get $pos "$pos lineend"]
        regexp {"[^"]*"} $match m
        set endPos [$t index "$pos + [string length $m] chars"]
        $t tag add string $pos $endPos
        set pos $endPos
    }
    
    # Kommentare
    set pos "1.0"
    while {1} {
        set pos [$t search "#" $pos end]
        if {$pos eq ""} break
        set endPos [$t index "$pos lineend"]
        $t tag add comment $pos $endPos
        set pos [$t index "$endPos + 1 char"]
    }
    
    # Zahlen
    set pos "1.0"
    while {1} {
        set pos [$t search -regexp {\m\d+\.?\d*\M} $pos end]
        if {$pos eq ""} break
        set match [$t get $pos "$pos + 20 chars"]
        regexp {\m\d+\.?\d*\M} $match m
        set endPos [$t index "$pos + [string length $m] chars"]
        $t tag add number $pos $endPos
        set pos $endPos
    }
}

# Bei jeder Änderung
bind .t <KeyRelease> {after cancel highlight .t; after 300 highlight .t}

# Test-Code
.t insert end {# Beispiel-Code
proc hello {name} {
    set greeting "Hallo"
    puts "$greeting $name!"
    return 42
}

hello "Welt"
}

highlight .t
```

### Log-Viewer mit Auto-Scroll

```tcl
package require Tk

text .t -wrap word -state disabled \
    -yscrollcommand {.sb set}
ttk::scrollbar .sb -command {.t yview}
pack .sb -side right -fill y
pack .t -fill both -expand 1

# Tags
.t tag configure error -foreground red
.t tag configure warn -foreground orange
.t tag configure info -foreground blue
.t tag configure debug -foreground gray

set autoScroll true

proc addLog {level message} {
    global autoScroll
    
    set timestamp [clock format [clock seconds] -format "%H:%M:%S"]
    set line "\[$timestamp\] \[$level\] $message\n"
    
    .t configure -state normal
    .t insert end $line [string tolower $level]
    .t configure -state disabled
    
    if {$autoScroll} {
        .t see end
    }
}

# Test
after 1000 {addLog INFO "Anwendung gestartet"}
after 2000 {addLog DEBUG "Verbindung wird aufgebaut..."}
after 3000 {addLog INFO "Verbindung hergestellt"}
after 4000 {addLog WARN "Hohe Auslastung"}
after 5000 {addLog ERROR "Verbindung verloren!"}
```

### 15. string trim entfernt BMP-Symbole (Tcl 8.6)

**Problem:** `string trim` ohne expliziten Charset trimmt alle
Unicode-Whitespace-Zeichen, einschliesslich U+0085 (NEL, Next Line).
Viele BMP-Symbole haben `\x85` (= U+0085) als letztes UTF-8-Byte:

| Symbol | Codepoint | UTF-8 | Letztes Byte |
|--------|-----------|-------|--------------|
| ✅ | U+2705 | `E2 9C 85` | `85` = NEL |
| ✓ | U+2713 | `E2 9C 93` | sicher |
| → | U+2192 | `E2 86 92` | sicher |

```tcl
# BUG in Tcl 8.6:
string trim " ✅ "    ;# -> "â"  (FALSCH -- NEL-Byte abgetrimmt)
string trim " ✓ "    ;# -> "✓"  (sicher, kein 0x85 am Ende)
```

**Lösung:** Charset explizit angeben:

```tcl
# RICHTIG:
string trim $var " \t"    ;# nur ASCII-Whitespace
```

Diese Regel gilt überall wo Text-Zellinhalte oder Inline-Inhalte
getrimmt werden: Tabellenzellen, Fussnoten, Link-Titel, Listen-Items.
In Tcl 9 ist das Problem nicht vorhanden (UTF-8-Handling verbessert).


---

## Referenzen

- [Tk text Manual (offiziell)](https://www.tcl.tk/man/tcl8.6/TkCmd/text.html)
- [Tkdocs Text Widget](https://tkdocs.com/tutorial/text.html)
- [Tcl Wiki: Text Widget](https://wiki.tcl-lang.org/page/text)

---

*Letzte Aktualisierung: Maerz 2026*
