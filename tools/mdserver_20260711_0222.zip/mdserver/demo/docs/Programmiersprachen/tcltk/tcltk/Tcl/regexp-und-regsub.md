# Reguläre Ausdrücke in Tcl -- regexp, regsub, re_syntax

*Stand: 2026-04-29*

Tcl implementiert "Advanced Regular Expressions" (ARE), die über POSIX ERE
hinausgehen und Features wie Lookaheads, nicht-gierige Quantifizierer und
Wortgrenzen-Constraints bieten. Die Befehle `regexp` und `regsub` sind die
beiden Hauptwerkzeuge für Mustersuche und -ersetzung. Die vollständige
Syntax ist in `re_syntax` dokumentiert.

---

## regexp -- Muster suchen und extrahieren

### Syntax

```tcl
regexp ?optionen? RE STRING ?matchVar ?subVar subVar ...??
```

`regexp` prüft, ob der reguläre Ausdruck `RE` auf einen Teil von `STRING`
passt. Ohne Optionen gibt der Befehl `1` bei Treffer und `0` bei Nicht-Treffer
zurück. Es genügt, wenn irgendein Teilstring passt -- der gesamte String
muss nicht übereinstimmen (dafür braucht man Anker).

### Grundformen

```tcl
# Einfaches Matching: Ist "xy" irgendwo im String?
regexp {xy} "abxycd"
# -> 1

# Kein Treffer
regexp {xy} "abcd"
# -> 0

# Gross/Klein wird unterschieden
regexp {xy} "ABXY"
# -> 0
```

Reguläre Ausdrücke sollten fast immer in geschweifte Klammern `{}` gesetzt
werden, damit der Tcl-Parser keine Backslash- oder Variablen-Substitution
durchführt. Ohne Klammern muesste man Backslashes verdoppeln:

```tcl
# Richtig: Klammern schützen den Ausdruck
regexp {\d+} "abc123"
# -> 1

# Falsch: ohne Klammern braucht man doppelte Backslashes
regexp "\\d+" "abc123"
# -> 1 (funktioniert, aber fehleranfällig)
```

---

## RE-Syntax: Zeichen und Klassen

### Einzelne Zeichen

Jedes Zeichen, das kein Metazeichen ist, steht für sich selbst. Die
Metazeichen sind: `. * + ? ( ) [ ] { } | ^ $ \`

Um ein Metazeichen literal zu verwenden, stellt man `\` voran:

```tcl
regexp {\.} "datei.txt"    ;# Punkt literal
# -> 1
regexp {\.} "dateitxt"     ;# Kein Punkt
# -> 0
```

### Der Punkt: beliebiges Zeichen

Der Punkt `.` matcht genau ein beliebiges Zeichen (ausser Newline im
`-linestop`-Modus):

```tcl
regexp {a.c} "abc"   ;# -> 1
regexp {a.c} "aXc"   ;# -> 1
regexp {a.c} "ac"    ;# -> 0 (kein Zeichen zwischen a und c)
regexp {a.c} "aXYc"  ;# -> 0 (zwei Zeichen statt einem)
```

### Zeichenklassen in eckigen Klammern

```tcl
# Eines der Zeichen X, Y, Z
regexp {[XYZ]} "aYb"        ;# -> 1

# Bereich: Kleinbuchstaben
regexp {[a-z]} "ABC5"       ;# -> 0
regexp {[a-z]} "ABCd"       ;# -> 1

# Kombination: Buchstaben und Ziffern
regexp {[a-zA-Z0-9]} "!"    ;# -> 0

# Negation: alles AUSSER Ziffern
regexp {[^0-9]} "123"       ;# -> 0
regexp {[^0-9]} "12a3"      ;# -> 1

# Bindestrich am Anfang = literal
regexp {[-abc]} "x-y"       ;# -> 1
```

Innerhalb von `[]` verlieren die meisten Metazeichen ihre Bedeutung. Der
Punkt `.` matcht nur einen echten Punkt:

```tcl
regexp {[.]} "abc"    ;# -> 0
regexp {[.]} "a.c"    ;# -> 1
```

### Benannte Zeichenklassen (POSIX)

| Klasse | Beschreibung | Aequivalent |
|--------|-------------|-------------|
| `[:alnum:]` | Buchstaben und Ziffern | |
| `[:alpha:]` | Buchstaben | |
| `[:blank:]` | Leerzeichen und Tab | |
| `[:cntrl:]` | Steuerzeichen | |
| `[:digit:]` | Ziffern (Unicode-weit) | `\d` |
| `[:graph:]` | Druckbare Zeichen (ohne Leerzeichen) | |
| `[:lower:]` | Kleinbuchstaben | |
| `[:print:]` | Druckbare Zeichen (mit Leerzeichen) | |
| `[:punct:]` | Satzzeichen | |
| `[:space:]` | Whitespace | `\s` |
| `[:upper:]` | Grossbuchstaben | |
| `[:xdigit:]` | Hexadezimale Ziffern | |

Benannte Klassen stehen in doppelten Klammern, weil die aeusseren `[]` die
Zeichenklasse bilden und die inneren `[:..:]` die benannte Klasse bezeichnen:

```tcl
regexp {[[:digit:]]} "abc"     ;# -> 0
regexp {[[:digit:]]} "a5c"     ;# -> 1

# Kombination: Buchstaben, Ziffern ODER Unterstrich
regexp {[[:alnum:]_]+} "var_1" ;# -> 1
```

Wichtig: `[:digit:]` matcht auch Unicode-Ziffern (z.B. Devanagari), während
`[0-9]` nur ASCII-Ziffern matcht.

### Kurzformen für Zeichenklassen

| Kurzform | Klasse | Beschreibung |
|----------|--------|-------------|
| `\d` | `[[:digit:]]` | Ziffer |
| `\D` | `[^[:digit:]]` | Keine Ziffer |
| `\s` | `[[:space:]]` | Whitespace |
| `\S` | `[^[:space:]]` | Kein Whitespace |
| `\w` | Wortzeichen | Buchstaben, Ziffern, Unterstrich |
| `\W` | Nicht-Wortzeichen | Komplement von `\w` |

```tcl
regexp {\d+} "abc123def"      ;# -> 1 (Ziffernfolge)
regexp {\s+} "kein leerzeichen"   ;# -> 1
regexp {\w+} "hallo"          ;# -> 1
```

Die Kurzformen `\d`, `\s`, `\w` können in `[]` verwendet werden. Die
negierten Formen `\D`, `\S`, `\W` können dort aber nicht stehen -- man
verwendet stattdessen `[^\d]` etc.

```tcl
# Erlaubt: \d und \s in Klammern
regexp {[\d\s]} "a 5"     ;# -> 1

# Nicht erlaubt: \D in Klammern
# Stattdessen:
regexp {[^\d]} "123"      ;# -> 0
```

---

## Quantifizierer

Quantifizierer bestimmen, wie oft ein Atom wiederholt werden darf.

| Quantifizierer | Beschreibung |
|----------------|-------------|
| `*` | 0 oder mehr |
| `+` | 1 oder mehr |
| `?` | 0 oder 1 |
| `{n}` | Genau n |
| `{n,}` | n oder mehr |
| `{n,m}` | n bis m (inklusive) |

```tcl
regexp {aX*b} "ab"       ;# -> 1 (0 mal X)
regexp {aX*b} "aXXb"     ;# -> 1 (2 mal X)

regexp {aX+b} "ab"       ;# -> 0 (mindestens 1 X nötig)
regexp {aX+b} "aXb"      ;# -> 1
regexp {aX+b} "aXXb"     ;# -> 1

regexp {aX?b} "ab"       ;# -> 1 (0 mal X)
regexp {aX?b} "aXb"      ;# -> 1
regexp {aX?b} "aXXb"     ;# -> 0 (hoechstens 1 X)

regexp {aX{3}b} "aXXb"   ;# -> 0
regexp {aX{3}b} "aXXXb"  ;# -> 1

regexp {aX{2,4}b} "aXb"      ;# -> 0
regexp {aX{2,4}b} "aXXXb"    ;# -> 1
regexp {aX{2,4}b} "aXXXXXb"  ;# -> 0
```

### Gierig vs. nicht-gierig

Standardmäßig sind Quantifizierer gierig: sie matchen so viel wie möglich.
Hängt man `?` an, werden sie nicht-gierig und matchen das Minimum:

```tcl
# Gierig: x+ nimmt so viele x wie möglich
regexp -inline {^(x+)(.*y)$} "xxyy"
# -> {xxyy xx yy}

# Nicht-gierig: x+? nimmt so wenige wie möglich
regexp -inline {^(x+?)(.*y)$} "xxyy"
# -> {xxyy x xyy}
```

Klassisches Problem -- Inhalt zwischen Tags extrahieren:

```tcl
# Gierig: .* frisst über das erste </Item> hinweg
regexp {<Item>(.*)</Item>} \
    "<Item>Eins</Item><Item>Zwei</Item>" -> inhalt
puts $inhalt
# -> Eins</Item><Item>Zwei

# Nicht-gierig: .*? stoppt beim ersten </Item>
regexp {<Item>(.*?)</Item>} \
    "<Item>Eins</Item><Item>Zwei</Item>" -> inhalt
puts $inhalt
# -> Eins
```

---

## Gruppen und Captures

### Capturing Groups

Klammern `()` gruppieren Teilausdruecke und "fangen" den gematchten Text
ein, sodass er in Variablen oder per Backreference verfügbar ist:

```tcl
regexp {(\d+)-(\d+)} "Seite 10-20" gesamt von bis
# gesamt = "10-20", von = "10", bis = "20"
```

Die erste Variable nach dem String erhält den gesamten Match, jede weitere
Variable den Inhalt der n-ten Capture-Gruppe.

### Non-Capturing Groups

Wenn man nur gruppieren will, ohne den Text einzufangen, verwendet man
`(?:...)`:

```tcl
# Capturing: XY wird in Variable gespeichert
regexp {a(XY)+b} "aXYXYb" gesamt teil
# teil = "XY"

# Non-Capturing: kein Speichern
regexp {a(?:XY)+b} "aXYXYb"
# -> 1 (aber kein Capture)
```

### Backreferences

`\N` referenziert den Inhalt der N-ten Capture-Gruppe. Damit kann man z.B.
wiederholte Woerter erkennen:

```tcl
# Doppelte Woerter finden
regexp {\m(\w+)\s+\1\M} "Das hat hat sich wiederholt"
# -> 1

# Kein doppeltes Wort
regexp {\m(\w+)\s+\1\M} "Das hat sich nicht wiederholt"
# -> 0
```

Die Zaehlweise: `\1` ist die erste oeffnende Klammer, `\2` die zweite usw.

---

## Anker und Constraints

### Zeilenanfang und -ende

```tcl
# ^ matcht den Stringanfang
regexp {^Hallo} "Hallo Welt"    ;# -> 1
regexp {^Hallo} "Sag Hallo"     ;# -> 0

# $ matcht das Stringende
regexp {Ende$} "Das Ende"        ;# -> 1
regexp {Ende$} "Ende gut"        ;# -> 0

# Beides: gesamter String muss matchen
regexp {^\d+$} "12345"           ;# -> 1
regexp {^\d+$} "123abc"          ;# -> 0
```

### Wortgrenzen (Tcl-spezifisch)

Tcl bietet eigene Wortgrenzen-Constraints, die sich von `\b` in anderen
Regex-Dialekten unterscheiden:

| Constraint | Beschreibung |
|------------|-------------|
| `\m` | Wortanfang (beginning of word) |
| `\M` | Wortende (end of word) |
| `\y` | Wortgrenze (Anfang oder Ende) |
| `\Y` | KEINE Wortgrenze |

```tcl
# \m: nur am Wortanfang
regexp {\mX} "aXb"    ;# -> 0 (X mitten im Wort)
regexp {\mX} "a Xb"   ;# -> 1 (X nach Leerzeichen = Wortanfang)

# \M: nur am Wortende
regexp {X\M} "Xb"     ;# -> 0 (b folgt direkt)
regexp {X\M} "X b"    ;# -> 1 (Leerzeichen folgt = Wortende)

# \y: beliebige Wortgrenze
regexp {\yX\y} "a X b" ;# -> 1 (X ist eigenstaendiges Wort)

# Ganzes Wort matchen
regexp {\mtest\M} "testing"   ;# -> 0 (test ist Teil von testing)
regexp {\mtest\M} "ein test"  ;# -> 1 (test als ganzes Wort)
```

### Absolute Anker

| Constraint | Beschreibung |
|------------|-------------|
| `\A` | Stringanfang (ignoriert `-lineanchor`) |
| `\Z` | Stringende (ignoriert `-lineanchor`) |

Im Mehrzeilenmodus (`-line`) verhalten sich `^` und `$` als Zeilenanker.
`\A` und `\Z` matchen dagegen immer den absoluten String-Anfang/Ende.

### Lookahead-Constraints

Lookaheads prüfen eine Bedingung an der aktuellen Position, ohne Zeichen
zu "verbrauchen":

```tcl
# Positiver Lookahead: (?=...) -- Muster MUSS folgen
# Artikelnummer: 2-10 Zeichen, Buchstaben gefolgt von Ziffern
set re {^(?=.{2,10}$)[A-Z]+[0-9]+$}
regexp $re "ABC123"       ;# -> 1
regexp $re "A1"           ;# -> 1
regexp $re "ABC12345678"  ;# -> 0 (zu lang)
regexp $re "1234"         ;# -> 0 (keine Buchstaben am Anfang)

# Negativer Lookahead: (?!...) -- Muster darf NICHT folgen
# Wort das NICHT mit "un" beginnt
regexp {\m(?!un)\w+} "unbekannt"  ;# -> 0
```

Tcl unterstützt keine Lookbehinds (`(?<=...)` und `(?<!...)`).

---

## Alternation

Der `|`-Operator verbindet Alternativen. Er bindet schwach:

```tcl
# apple ODER banana
regexp {apple|banana} "Ich mag banana"  ;# -> 1

# Gemeinsame Teile ausklammern
regexp {(Mon|Diens|Donners|Frei|Sams|Sonn)tag} "Freitag"
# -> 1

# ACHTUNG: | bindet schwach
# "abc|def" = "(abc)|(def)", NICHT "ab(c|d)ef"
regexp {abc|def} "def"   ;# -> 1
regexp {abc|def} "abdef" ;# -> 1 (matcht "def" in "abdef")
```

---

## regexp-Optionen

### -nocase: Gross/Klein ignorieren

```tcl
regexp -nocase {hello} "HELLO World"  ;# -> 1
```

### -all: Alle Treffer zählen

```tcl
regexp -all {\d+} "10 Aepfel, 20 Birnen, 30 Kirschen"
# -> 3
```

### -inline: Treffer als Liste zurückgeben

Statt Treffer in Variablen zu speichern, gibt `-inline` eine Liste zurück.
Die erste Element ist der gesamte Match, dann die Captures:

```tcl
regexp -inline {(\w+)@(\w+)} "user@host"
# -> {user@host user host}

# Mit -all: alle Treffer als flache Liste
regexp -all -inline {(\d+)} "10 und 20 und 30"
# -> {10 10 20 20 30 30}
# (jeder Treffer: Gesamtmatch + Capture)
```

### -indices: Positionen statt Inhalte

```tcl
regexp -indices {(\d+)} "abc123def" gesamt ziffern
# gesamt = {3 5}  (Index 3 bis 5)
# ziffern = {3 5}
```

Nützlich beim Parsen grosser Texte -- man speichert nur Positionen statt
Kopien der Teilstrings.

### -start: Ab bestimmter Position suchen

```tcl
regexp -inline -all {\d+} "12ab34cd56"
# -> {12 34 56}

regexp -start 4 -inline -all {\d+} "12ab34cd56"
# -> {34 56}
```

Häufig zusammen mit `-indices` für inkrementelles Parsen.

### -line, -lineanchor, -linestop: Mehrzeilenmodus

```tcl
set text "Zeile 1\nZeile 2\nZeile 3"

# Ohne -line: ^ und $ matchen nur String-Anfang/Ende
regexp -all {^\w+} $text
# -> 1 (nur "Zeile" am Stringanfang)

# Mit -line: ^ und $ matchen auch Zeilenanfang/-ende
regexp -all -line {^\w+} $text
# -> 3 (jede Zeile beginnt mit einem Wort)
```

Die drei Unteroptionen:

| Option | Wirkung |
|--------|---------|
| `-lineanchor` | `^` und `$` matchen Zeilenanfang/-ende |
| `-linestop` | `.` und `[^...]` matchen kein Newline |
| `-line` | Kombiniert beides |

```tcl
# Zeilen mit Whitespace am Ende zählen
set content "Zeile 1\nZeile 2 \nZeile 3\t"
regexp -all {\s+$} $content          ;# -> 1 (nur am Stringende)
regexp -all -line {\s+$} $content    ;# -> 2 (Zeile 2 und 3)
```

### -expanded: Lesbare Ausdrücke mit Kommentaren

```tcl
regexp -expanded {
    \m          # Wortanfang
    (\w+)\s+    # Ein Wort gefolgt von Whitespace
    \1          # Dasselbe Wort nochmal
    \M          # Wortende
} "Das hat hat sich wiederholt"
# -> 1
```

Im expanded-Modus werden Whitespace und `#`-Kommentare ignoriert. Um ein
Leerzeichen oder `#` literal zu matchen, muss man `\ ` oder `\#` schreiben.

### -about: Ausdruck analysieren (ohne zu matchen)

```tcl
regexp -about {(\d+)-(\w+)}
# -> {2 {REG_NOSUB REG_USEONLYFMME}}
# Erstes Element: Anzahl Unterausdruecke
```

### -- : Ende der Optionen

Wenn der reguläre Ausdruck mit `-` beginnen könnte:

```tcl
regexp -- {-\d+} "Wert: -42"
# -> 1
```

---

## Eingebettete Optionen: (?...)

Statt Kommandozeilen-Optionen kann man Optionen in den Ausdruck einbetten:

| Metasyntax | Aequivalent |
|------------|-------------|
| `(?i)` | `-nocase` |
| `(?c)` | Gross/Klein beachten (Standard) |
| `(?x)` | `-expanded` |
| `(?n)` | `-line` |
| `(?w)` | `-lineanchor` |
| `(?p)` | `-linestop` |

```tcl
# Gross/Klein ignorieren per Metasyntax
regexp {(?i)hello} "HELLO"  ;# -> 1

# Mehrzeilenmodus per Metasyntax
regexp -all {(?n)\s+$} $content
```

Wichtig: Die Metasyntax muss ganz am Anfang des Ausdrucks stehen.

---

## Literale Strings in Ausdruecken: ***=

Wenn man einen String literal suchen will, ohne sich um Metazeichen zu
kuemmern, stellt man `***=` voran:

```tcl
set suche "X.Y"

# Ohne ***= : der Punkt matcht beliebige Zeichen
regexp -all $suche "X.YaXbY"    ;# -> 2

# Mit ***= : der Punkt ist literal
regexp -all "***=$suche" "X.YaXbY"   ;# -> 1
```

Alternativ kann man Metazeichen mit `regsub` escapen:

```tcl
regsub -all {[][*+?{}()<>|.^$\\]} $literal {\\&}
```

---

## Treffer extrahieren -- Zusammenfassung der Formen

| Form | Rückgabe | Treffer-Zugriff |
|------|-----------|----------------|
| `regexp RE str` | 0 oder 1 | Nur ja/nein |
| `regexp RE str m s1 s2` | 0 oder 1 | Match in `m`, Captures in `s1`, `s2` |
| `regexp -inline RE str` | Liste | `{match capture1 capture2 ...}` |
| `regexp -all RE str` | Anzahl | Zahl der Treffer |
| `regexp -all -inline RE str` | Liste | Alle Treffer als flache Liste |
| `regexp -indices RE str m s1` | 0 oder 1 | Index-Paare in `m`, `s1` |

Konvention: Wenn man den Gesamtmatch nicht braucht, verwendet man `-` oder
`->` als Platzhalter-Variable:

```tcl
regexp {(\w+)@(\w+)} "user@host" -> name domain
# name = "user", domain = "host"
# -> enthält den Gesamtmatch, wird aber nicht verwendet
```

---

## regsub -- Muster ersetzen

### Syntax

```tcl
regsub ?optionen? RE STRING SUBSPEC ?VARNAME?
```

`regsub` sucht in `STRING` nach dem regulaeren Ausdruck `RE` und ersetzt den
Treffer durch `SUBSPEC`. Ohne `VARNAME` wird das Ergebnis direkt
zurückgegeben. Mit `VARNAME` wird das Ergebnis in die Variable geschrieben
und die Anzahl der Ersetzungen zurückgegeben.

### Grundformen

```tcl
# Direkte Rückgabe (Tcl 8.6+)
set result [regsub {\d+} "abc123def" "XXX"]
# result = "abcXXXdef"

# In Variable speichern + Anzahl
set count [regsub -all {\d} "a1b2c3" "X" result]
# count = 3, result = "aXbXcX"
```

### Backreferences in SUBSPEC

In der Ersetzung kann man auf Captures verweisen:

| Syntax | Bedeutung |
|--------|-----------|
| `\0` oder `&` | Gesamter Match |
| `\1` ... `\9` | N-te Capture-Gruppe |
| `\\` | Literaler Backslash |

```tcl
# Vorname Nachname -> Nachname, Vorname
regsub {(\w+) (\w+)} "Max Mustermann" {\2, \1}
# -> "Mustermann, Max"

# Zahl verdoppeln (als Text)
regsub {(\d+)} "Preis: 50" {& (war \1)}
# -> "Preis: 50 (war 50)"
```

Achtung: Die Ersetzung muss in geschweiften Klammern stehen, damit Tcl die
Backslashes nicht interpretiert.

### regsub-Optionen

`regsub` akzeptiert dieselben Optionen wie `regexp`:

| Option | Wirkung |
|--------|---------|
| `-all` | Alle Vorkommen ersetzen (nicht nur das erste) |
| `-nocase` | Gross/Klein ignorieren beim Suchen |
| `-expanded` | Lesbare Ausdrücke mit Kommentaren |
| `-line` | Mehrzeilenmodus |
| `-lineanchor` | `^` / `$` als Zeilenanker |
| `-linestop` | `.` matcht kein Newline |
| `-start N` | Ab Position N suchen |
| `-command` | Ersetzung per Callback-Prozedur (Tcl 9.0) |
| `--` | Ende der Optionen |

### -command: Ersetzung per Callback (Tcl 9.0)

Ab Tcl 9.0 (eingeführt in 8.7a) kann `regsub` eine Prozedur als
Ersetzungslogik aufrufen. Statt einer statischen SUBSPEC wird ein
Befehlspraefix angegeben, das für jeden Treffer aufgerufen wird. Der Befehl
erhält den gesamten Match und alle Capturing Groups als Argumente und gibt
die Ersetzung als Rückgabewert zurück.

```tcl
# Syntax mit -command:
regsub -all -command RE STRING CMDPREFIX ?VARNAME?

# CMDPREFIX wird aufgerufen als:
#   CMDPREFIX match ?sub1 sub2 ...?
# und muss den Ersetzungstext zurückgeben.
```

Grundlegendes Beispiel -- Zahlen verdoppeln:

```tcl
proc verdopple {match} {
    return [expr {$match * 2}]
}

regsub -all -command {\d+} "Breite 10, Höhe 20" verdopple
# -> "Breite 20, Höhe 40"
```

Mit Capturing Groups:

```tcl
proc formatiere_name {match vorname nachname} {
    return "[string toupper $nachname], $vorname"
}

regsub -all -command {(\w+)\s+(\w+)} "Max Muster" formatiere_name
# -> "MUSTER, Max"
```

Mit anonymem Lambda (apply):

```tcl
regsub -all -command {\d+} "a1 b22 c333" {apply {match {
    format "%03d" $match
}}}
# -> "a001 b022 c333"
```

Der entscheidende Vorteil gegenüber der klassischen SUBSPEC-Methode: Mit
`-command` kann beliebige Tcl-Logik in die Ersetzung einfliessen --
Berechnungen, Datenbankabfragen, Formatierungen. Ohne `-command` braucht man
umstaendliche Konstruktionen mit `uplevel` und `subst`.

---

## Praxisrezepte

### Whitespace normalisieren

```tcl
# Mehrfache Leerzeichen auf eines reduzieren
set clean [regsub -all {\s+} $text " "]

# Fuehrende und folgende Leerzeichen entfernen
set trimmed [regsub {^\s+|\s+$} $text ""]

# Beides zusammen (erst trimmen, dann normalisieren)
set trimmed [string trim $text " \t"]  ;# " \t" vermeidet U+0085-Bug (Tcl 8.6)
set clean [regsub -all {\s+} $trimmed " "]
```

### Zahlen extrahieren

```tcl
# Alle Ganzzahlen aus einem Text
set zahlen [regexp -all -inline {\d+} "10 Aepfel, 20 Birnen"]
# -> {10 20}

# Dezimalzahlen (mit optionalem Punkt)
set dezimal [regexp -all -inline {\d+\.?\d*} "3.14 und 42"]
# -> {3.14 42}

# Negative Zahlen auch
set alle [regexp -all -inline -- {-?\d+\.?\d*} "von -5 bis 3.7"]
# -> {-5 3.7}
```

### Schlüssel-Wert-Paare parsen

```tcl
set text "name=Max alter=30 ort=Berlin"
set paare [regexp -all -inline {(\w+)=(\S+)} $text]
# -> {name=Max name Max alter=30 alter 30 ort=Berlin ort Berlin}

# Als Dictionary aufbauen
set d [dict create]
foreach {match key val} $paare {
    dict set d $key $val
}
# d = {name Max alter 30 ort Berlin}
```

### IP-Adresse validieren

```tcl
proc isIPv4 {str} {
    set octet {(?:25[0-5]|2[0-4]\d|[01]?\d\d?)}
    return [regexp "^${octet}\\.${octet}\\.${octet}\\.${octet}$" $str]
}

isIPv4 "192.168.1.1"    ;# -> 1
isIPv4 "256.1.1.1"      ;# -> 0
isIPv4 "192.168.1"      ;# -> 0
```

### Doppelte Woerter korrigieren

```tcl
set text "Das hat hat sich sich wiederholt"
set fixed [regsub -all {\m(\w+)\s+\1\M} $text {\1}]
# -> "Das hat sich wiederholt"
```

### Datumsformat umwandeln

```tcl
# DD.MM.YYYY -> YYYY-MM-DD
set iso [regsub {(\d{2})\.(\d{2})\.(\d{4})} "24.12.2025" {\3-\2-\1}]
# -> "2025-12-24"
```

### Tcl-Variablen aus Konfigurationsdatei

```tcl
set config "
timeout = 30
host = localhost
port = 8080
"

set paare [regexp -all -inline -line {^\s*(\w+)\s*=\s*(.+)$} $config]
foreach {match key val} $paare {
    set cfg($key) [string trim $val " \t"]  ;# " \t" sicher bei Unicode-Werten
}
# cfg(timeout) = "30", cfg(host) = "localhost", cfg(port) = "8080"
```

### Kommentare aus Code entfernen

```tcl
# Einzeilige Tcl-Kommentare (Zeilen die mit # beginnen)
set code [regsub -all -line {^\s*#.*$} $source ""]

# Vorsicht: # in Strings nicht entfernen!
# Für robustes Parsing ist regexp allein nicht ausreichend.
```

### Mehrere Ersetzungen nacheinander

Für mehrere verschiedene Ersetzungen ist `string map` oft besser als
mehrere `regsub`-Aufrufe:

```tcl
# string map: schneller, keine Regex nötig
set result [string map {& &amp; < &lt; > &gt;} $html]

# regsub: nur wenn Muster nötig sind
set result [regsub -all {[<>&]} $html {\\&}]
```

### Log-Zeilen parsen

```tcl
set logline "2025-01-15 14:30:22 ERROR Server nicht erreichbar"

regexp {^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})\s+(\w+)\s+(.+)$} \
    $logline -> datum zeit level nachricht
# datum = "2025-01-15"
# zeit = "14:30:22"
# level = "ERROR"
# nachricht = "Server nicht erreichbar"
```

### PipeWire/PulseAudio-Ausgabe parsen

Beispiel aus der Praxis -- Audio-Geräte aus `wpctl status` extrahieren:

```tcl
proc parseWpctlDevices {output} {
    set devices [list]
    set lines [split $output \n]
    foreach line $lines {
        # Zeilen wie: "  42. Headset Mono  [vol: 0.75]"
        if {[regexp {^\s+(\d+)\.\s+(.+?)\s+\[vol:\s+([\d.]+)\]} \
                 $line -> id name vol]} {
            lappend devices [dict create id $id name $name vol $vol]
        }
    }
    return $devices
}
```

### Template-Platzhalter ersetzen mit -command (Tcl 9.0)

Ein reales Beispiel aus dem Wapp-Web-Framework von D. Richard Hipp. Wapp
verwendet Template-Ausdrücke wie `%html(...)` oder `%url(...)`, die in der
Ausgabe HTML- oder URL-kodiert werden sollen.

In Tcl 8.6 musste man dafür umstaendlich mit `subst` und `uplevel` arbeiten:

```tcl
# Tcl 8.6: Ersetzung durch Erzeugung von [cmd]-Aufrufen im Text
proc wapp-subst-86 {txt} {
    global wapp
    regsub -all \
        {%(html|url|qp|string|unsafe){1,1}?(|%)\((.+)\)\2} $txt \
        {[wappInt-enc-\1 "\3"]} txt
    dict append wapp .reply [uplevel 1 [list subst -novariables $txt]]
}
```

Mit `-command` in Tcl 9.0 wird daraus eine elegante, sichere Lösung:

```tcl
# Tcl 9.0: Direkte Verarbeitung per Callback
proc wapp-subst-90 {txt} {
    global wapp
    regsub -all -command \
        {%(html|url|qp|string|unsafe){1,1}?(|%)\((.+)\)\2} \
        $txt wappInt-enc txt
    dict append wapp .reply [subst -novariables -nocommand $txt]
}
```

Vorteile: Kein `uplevel` nötig, kein dynamisches Erzeugen von
`[cmd]`-Strings, keine Injection-Gefahr durch unerwartete Substitution.

Dasselbe Muster lässt sich auf eigene Template-Systeme übertragen:

```tcl
proc tmpl_encode {match typ _paren inhalt _paren2} {
    switch $typ {
        html   { return [string map {& &amp; < &lt; > &gt; \" &quot;} $inhalt] }
        url    { return [::http::formatQuery dummy $inhalt] }
        raw    { return $inhalt }
    }
}

set template "Hallo %html(Welt <b>test</b>), Link: %url(a b c)"
regsub -all -command {%(html|url|raw)\(([^)]+)\)} $template tmpl_encode
# -> "Hallo Welt &lt;b&gt;test&lt;/b&gt;, Link: ..."
```

---

## regexp vs. string match vs. string map

Nicht jede Textoperation braucht reguläre Ausdrücke. Tcl bietet einfachere
Alternativen, die für viele Fälle ausreichen:

| Aufgabe | Bester Befehl | Grund |
|---------|---------------|-------|
| Einfaches Teilstring-Suchen | `string match` mit `*` | Schneller, einfacher |
| Festes Präfix/Suffix prüfen | `string match` | `{prefix*}` oder `{*suffix}` |
| Exaktes Ersetzen | `string map` | Kein Regex-Overhead |
| Mehrere feste Ersetzungen | `string map` | Ein Aufruf für alles |
| Muster mit Wiederholungen | `regexp` | `string match` kann kein `+` oder `{n}` |
| Captures / Teilstrings extrahieren | `regexp` | `string match` kann das nicht |
| Komplexe bedingte Ersetzung | `regsub` | Backreferences nötig |
| Validierung (Format prüfen) | `regexp` oder `string is` | `string is` für einfache Typen |

```tcl
# string match: schnelles Glob-Pattern
string match {*.tcl} "script.tcl"  ;# -> 1

# string map: feste Ersetzungen
string map {ae ae oe oe ue ue} "Aeussere Oeffnung"

# string is: Typ-Prüfung
string is integer "42"    ;# -> 1
string is double "3.14"   ;# -> 1
string is alpha "hallo"   ;# -> 1
```

---

## Häufige Fehler

### Klammern vergessen

```tcl
# FALSCH: Tcl substituiert \d als unbekannte Escape-Sequenz
regexp "\d+" "123"    ;# Unberechenbar

# RICHTIG: Klammern schützen
regexp {\d+} "123"    ;# -> 1
```

### Eckige Klammern nicht escaped

Eckige Klammern sind Metazeichen sowohl in Tcl als auch in Regex:

```tcl
# FALSCH: Tcl versucht [0-9] als Befehl auszuführen
regexp [0-9] "abc5"

# RICHTIG: In Klammern setzen
regexp {[0-9]} "abc5"   ;# -> 1

# Auch richtig: Backslash-Escape (haesslicher)
regexp "\[0-9\]" "abc5" ;# -> 1
```

### Punkt als Literal verwechselt

```tcl
# FALSCH: . matcht JEDES Zeichen
regexp {datei.txt} "dateiXtxt"   ;# -> 1 (ungewollt!)

# RICHTIG: Punkt escapen
regexp {datei\.txt} "dateiXtxt"  ;# -> 0
regexp {datei\.txt} "datei.txt"  ;# -> 1
```

### Gierige Quantifizierer bei verschachtelten Strukturen

```tcl
# FALSCH: .* ist gierig, frisst über Grenzen hinweg
regexp {"(.*)"} {"a" und "b"} -> inhalt
# inhalt = {a" und "b}

# RICHTIG: Nicht-gierig oder Zeichenklasse
regexp {"(.*?)"} {"a" und "b"} -> inhalt
# inhalt = "a"

# Noch besser: Zeichenklasse [^"]
regexp {"([^"]*)"} {"a" und "b"} -> inhalt
# inhalt = "a"
```

### -all -inline: Flache Liste beachten

```tcl
# Mit Captures ist die Liste Gesamtmatch + Captures, wiederholt
regexp -all -inline {(\d+)} "10 und 20"
# -> {10 10 20 20}
#    ^Gesamt ^Capture ^Gesamt ^Capture

# Zum Extrahieren nur der Captures:
foreach {match capture} [regexp -all -inline {(\d+)} "10 und 20"] {
    puts $capture
}
# 10
# 20
```

### regsub: Ersetzung nicht in Klammern

```tcl
# FALSCH: Tcl interpretiert \1 als Sonderzeichen
regsub {(\w+)} "hallo" "\1_neu" result
# result = unvorhersehbar

# RICHTIG: Geschweifte Klammern
regsub {(\w+)} "hallo" {\1_neu} result
# result = "hallo_neu"
```

---

## Metazeichen-Referenz

### Zeichen

| Zeichen | Bedeutung |
|---------|-----------|
| `.` | Beliebiges Zeichen (ausser Newline im linestop-Modus) |
| `\d` | Ziffer |
| `\D` | Keine Ziffer |
| `\s` | Whitespace |
| `\S` | Kein Whitespace |
| `\w` | Wortzeichen |
| `\W` | Kein Wortzeichen |
| `\t` | Tab |
| `\n` | Newline |
| `\r` | Carriage Return |
| `\uhhhh` | Unicode-Zeichen (4 Hex-Stellen) |
| `\Uhhhhhhhh` | Unicode-Zeichen (8 Hex-Stellen) |

### Quantifizierer

| Quantifizierer | Gierig | Nicht-gierig |
|----------------|--------|-------------|
| 0 oder mehr | `*` | `*?` |
| 1 oder mehr | `+` | `+?` |
| 0 oder 1 | `?` | `??` |
| Genau n | `{n}` | -- |
| n oder mehr | `{n,}` | `{n,}?` |
| n bis m | `{n,m}` | `{n,m}?` |

### Anker und Constraints

| Constraint | Beschreibung |
|------------|-------------|
| `^` | Stringanfang (oder Zeilenanfang mit `-lineanchor`) |
| `$` | Stringende (oder Zeilenende mit `-lineanchor`) |
| `\A` | Absoluter Stringanfang |
| `\Z` | Absolutes Stringende |
| `\m` | Wortanfang |
| `\M` | Wortende |
| `\y` | Wortgrenze |
| `\Y` | Keine Wortgrenze |
| `(?=RE)` | Positiver Lookahead |
| `(?!RE)` | Negativer Lookahead |

### Gruppen

| Syntax | Beschreibung |
|--------|-------------|
| `(RE)` | Capturing Group |
| `(?:RE)` | Non-Capturing Group |
| `\N` | Backreference auf N-te Gruppe |

### Sonstiges

| Syntax | Beschreibung |
|--------|-------------|
| `\|` | Alternation |
| `***=TEXT` | Literal-Modus (keine Metazeichen) |
| `(?i)` | Case-insensitive |
| `(?x)` | Expanded/Kommentar-Modus |
| `(?n)` | Newline-sensitive |

---

## Verwandte Befehle

| Befehl | Beschreibung |
|--------|-------------|
| `regexp` | Muster suchen und extrahieren |
| `regsub` | Muster ersetzen |
| `string match` | Glob-Pattern-Matching (einfacher, schneller) |
| `string map` | Feste Textersetzungen (kein Regex) |
| `string first` / `string last` | Teilstring suchen (Position) |
| `string is` | Typ-Validierung (integer, double, alpha, ...) |
| `scan` | Formatiertes Parsen (ähnlich wie C scanf) |
| `split` | String an Trennzeichen aufteilen |
