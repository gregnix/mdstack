# Coroutinen (coroutine, yield, yieldto)

*Stand: 2026-04-29*

Tcl 8.6+. Kategorie: Nebenläufigkeit, Kontrollfluss.

---

## Das Problem: Zustand über mehrere Aufrufe hinweg

Eine Folge von Werten liefern — zum Beispiel die
Fibonacci-Zahlen — aber der Aufrufer bestimmt, wann der nächste Wert
gebraucht wird.

Mit einer normalen Proc geht das nicht elegant: Beim Rücksprung ist der lokale
Zustand (die letzten zwei Werte) weg. Man braucht globale Variablen oder ein
Dictionary als Workaround — beides ist hässlich.

Coroutinen lösen genau dieses Problem: Sie können mitten in einer laufenden Proc
*pausieren* und den gesamten Aufruf-Stack eingefroren halten, bis der Aufrufer
sie wieder aufruft.

---

## Das Modell: gefrorener Aufruf-Stack

Eine normale Proc:
```
Aufrufer ruft proc auf
  → Proc läuft
  → Proc gibt Wert zurück
  → Stack wird gelöscht
```

Eine Coroutine:
```
Aufrufer ruft coroutine auf
  → Coroutine läuft bis yield
  → yield gibt Wert zurück, Stack bleibt eingefroren
  → Aufrufer macht weiter
  → Aufrufer ruft coroutine erneut auf
  → Coroutine läuft weiter vom yield-Punkt, Stack ist noch da
  → ...
```

Das Entscheidende: Der Stack *bleibt erhalten*. Lokale Variablen, Schleifen,
rekursive Aufrufe — alles steht genau so da wie beim Pausieren.

---

## Grundsyntax

```tcl
coroutine name cmd ?arg ...?
```

Erzeugt eine Coroutine namens `name` und ruft `cmd` darin auf. Der erste Aufruf
läuft bis zum ersten `yield` und gibt dessen Argument zurück.

```tcl
yield ?wert?
```

Pausiert die Coroutine und gibt `wert` an den Aufrufer zurück. Beim nächsten
Aufruf der Coroutine kehrt `yield` mit dem übergebenen Argument zurück.

---

## Schritt 1: Einfache Coroutine

```tcl
proc zaehler {} {
    yield 1     ;# pausiert, gibt 1 zurück
    yield 2     ;# beim zweiten Aufruf: pausiert, gibt 2 zurück
    yield 3     ;# beim dritten Aufruf: pausiert, gibt 3 zurück
    return      ;# Coroutine ist erschöpft, Kommando wird gelöscht
}

coroutine c zaehler

puts [c]    ;# -> 1
puts [c]    ;# -> 2
puts [c]    ;# -> 3
# Weiterer Aufruf wäre ein Fehler: Kommando existiert nicht mehr
```

Was passiert nach `return`? Die Coroutine löscht sich selbst. `info commands c`
gibt danach eine leere Menge zurück. Vor dem Aufruf prüfen:

```tcl
if {[llength [info commands c]]} {
    puts [c]
}
```

---

## Schritt 2: yield in einer Schleife — der Generator

Das eigentliche Muster: `yield` mitten in einer Endlosschleife.

```tcl
proc fibonacci {} {
    set a 0
    set b 1
    while 1 {
        yield $a                ;# Wert nach außen geben, Stack einfrieren
        lassign [list $b [expr {$a + $b}]] a b   ;# Zustand weiterschreiben
    }
}

coroutine fib fibonacci

for {set i 0} {$i < 10} {incr i} {
    puts [fib]   ;# -> 0 1 1 2 3 5 8 13 21 34
}
```

`a` und `b` sind ganz normale lokale Variablen — sie leben einfach im
eingefrorenen Stack weiter. Kein global, kein Workaround.

---

## Schritt 3: Werte in die Coroutine hineinschicken

`yield` ist kein reines "Rausgeben" — es kann auch einen Wert *empfangen*.
Der Aufrufer übergibt beim nächsten Aufruf ein Argument, das `yield` als
Rückgabewert erhält.

```tcl
proc akkumulator {} {
    set summe 0
    while 1 {
        set wert [yield $summe]   ;# summe rausgeben, nächsten Wert empfangen
        incr summe $wert
    }
}

coroutine acc akkumulator

puts [acc]     ;# -> 0   (Startaufruf, initialisiert bis zum ersten yield)
puts [acc 10]  ;# -> 10  (10 hineinschicken, neue Summe zurück)
puts [acc 25]  ;# -> 35
puts [acc 5]   ;# -> 40
```

Das Muster `set x [yield $y]`: gleichzeitig `$y` rausgeben und auf den nächsten
Eingabewert warten. Producer und Consumer in einem.

---

## Schritt 4: Event-Loop-Integration

Das klassische GUI-Problem: ein langer Algorithmus blockiert die Oberfläche.

Ohne Coroutine muss man den Algorithmus in viele kleine `after`-Callbacks
zerhacken und den Zustand manuell in globalen Variablen halten. Mit Coroutine
bleibt der Algorithmus unverändert — `yield` übergibt die Kontrolle an die
Event-Loop.

```tcl
proc verzeichnis_scan {dir} {
    foreach fn [glob -nocomplain [file join $dir *]] {
        puts "Verarbeite: $fn"
        if {[file isdirectory $fn]} {
            verzeichnis_scan $fn   ;# Rekursion funktioniert ganz normal!
        }
        # Kontrolle an Event-Loop zurückgeben, dann weitermachen
        after idle [list after 0 [info coroutine]]
        yield
    }
}

# Startet den Scan ohne die GUI zu blockieren
coroutine scanner verzeichnis_scan /usr/share

# Event-Loop läuft — GUI bleibt responsiv, Scanner läuft nebenher
vwait forever
```

Das Idiom `after idle [list after 0 [info coroutine]]` plant einen einmaligen
Event-Loop-Durchlauf ein, der die Coroutine wieder aufruft. Die Coroutine macht
nach `yield` genau da weiter, wo sie war — auch mitten in der Rekursion.

---

## Schritt 5: yieldto — Peer-to-Peer zwischen Coroutinen

`yieldto` ist die Erweiterung von `yield`: statt an den Aufrufer zurückzukehren,
wird direkt ein anderes Kommando aufgerufen. Der Rückgabewert von `yieldto` ist
die *Liste* aller Argumente, mit denen die Coroutine später wieder aufgerufen wird.

```tcl
yieldto cmd ?arg ...?
```

```tcl
proc produzent {consumer} {
    yield                            ;# Initialisierung abwarten
    foreach wert {10 20 30 done} {
        yieldto $consumer $wert      ;# direkt an consumer übergeben
    }
}

proc konsument {} {
    while 1 {
        set wert [yield]
        if {$wert eq "done"} break
        puts "Empfangen: $wert"
    }
}

coroutine cons konsument
coroutine prod produzent cons

cons     ;# Konsument bis zum ersten yield fahren
prod     ;# Produzent starten — beide laufen jetzt kooperativ
```

### yieldMultiple — mehrere Argumente beim Fortsetzen empfangen

`yield` akzeptiert beim Fortsetzen nur *ein* Argument. Wer mehrere empfangen
will, verwendet `yieldto` mit `string cat` als Ziel — das empfiehlt auch die
offizielle Manpage:

```tcl
proc yieldMultiple {value} {
    tailcall yieldto string cat $value
}
```

`string cat` gibt alle Argumente unverändert zurück — `yieldto` erhält sie als
Liste. So kann der Aufrufer mehrere Werte auf einmal in die Coroutine schicken.

`tailcall` ist hier nötig damit `yieldMultiple` keinen eigenen Frame im
Coroutine-Stack hinterlässt. Siehe [tailcall.md](tailcall.md).

---

## Coroutinen inspizieren und modifizieren: coroprobe / coroinject

Tcl 9.0 macht `coroprobe` und `coroinject` zu offiziellen Builtins
(vorher: `tcl::unsupported::inject`).

Beide Befehle funktionieren nur auf *suspendierten* Coroutinen (nach `yield`
oder `yieldto`). Auf laufende Coroutinen können sie nicht angewendet werden.

### coroprobe — Zustand lesen ohne Seiteneffekte

```tcl
coroprobe coroName cmd ?arg...?
```

Führt `cmd` *sofort* im Kontext der suspendierten Coroutine aus. Die Coroutine
bleibt danach im selben Zustand — sie wartet weiterhin auf Fortsetzung.

```tcl
proc sammler {} {
    set liste {}
    for {set val [yield [info coroutine]]} {$val ne ""} {set val [yield]} {
        lappend liste $val
    }
    return $liste
}

coroutine col sammler
col "eins"
col "zwei"
col "drei"

# Akkumulator lesen ohne die Coroutine fortzusetzen:
puts [coroprobe col set liste]   ;# -> eins zwei drei

col "vier"
puts [col]   ;# -> eins zwei drei vier
```

### coroinject — Einmaliger Eingriff beim nächsten Fortsetzen

```tcl
coroinject coroName cmd ?arg...?
```

Plant einen Befehl ein, der beim *nächsten* Fortsetzen der Coroutine ausgeführt
wird — bevor die Coroutine selbst weiterläuft. Mehrere Injektionen werden als
Stack verwaltet (LIFO: letzte zuerst ausgeführt).

Der injizierte Befehl erhält zwei zusätzliche Argumente angehängt:
1. Den Namen des Befehls, der die Coroutine suspendiert hat (`yield` oder `yieldto`)
2. Den aktuellen Fortsetzungswert

Das Ergebnis des injizierten Befehls wird als Ergebnis des `yield`/`yieldto`
in der Coroutine verwendet.

```tcl
# Fortsetzung des Sammler-Beispiels von oben:

coroinject col apply {{type value} {
    puts "Abgefangen: '$value' bei einem $type in [info coroutine]"
    return [string toupper $value]
}}

col "fünf"
# -> Abgefangen: 'fünf' bei einem yield in ::col

puts [col]   ;# -> eins zwei drei vier FÜNF
```

Die Injektion ist einmalig — nach Ausführung wird sie entfernt.

### coroprobe vs. coroinject

| | `coroprobe` | `coroinject` |
|---|---|---|
| Ausführungszeitpunkt | sofort | beim nächsten Fortsetzen |
| Coroutine läuft weiter? | nein | ja (nach Injektion) |
| Ergebnis beeinflusst yield? | nein | ja |
| Mehrfach stapelbar? | nein | ja (LIFO) |
| Typischer Einsatz | Debugging, Inspektion | Eingabe transformieren |

---

## Wichtige Randbedingungen

**Coroutine erschöpft:** Nach `return` (oder Fehler) löscht sich die Coroutine
selbst. Weiterer Aufruf: Fehler "invalid command name".

**Gleicher Interpreter:** Coroutinen laufen im selben Interpreter. `yield` über
Interpreter-Grenzen hinweg ist nicht möglich.

**Nicht reentrant:** Eine Coroutine kann sich nicht selbst aufrufen, solange sie
aktiv ist.

**Coroutine-Name ermitteln:** Innerhalb der Coroutine:
```tcl
info coroutine   ;# -> ::name der aktuellen Coroutine
```

**Coroutine vorzeitig beenden:**
```tcl
rename [info coroutine] {}; yield   ;# von innen
```

---

## coroutine::util — blockierende Aufrufe simulieren

```tcl
package require coroutine 1.4
```

Tcllib liefert coroutinen-freundliche Versionen der blockierenden Standardbefehle.
Alle Wrapper sind *synchron aus Sicht der Coroutine* — sie blockieren die
aufrufende Coroutine bis das Ergebnis da ist — aber die Event-Loop läuft weiter.

### API-Übersicht

| Befehl | Entspricht | Besonderheit |
|---|---|---|
| `coroutine::util after delay` | `after delay` | Coroutine wartet, Event-Loop läuft |
| `coroutine::util gets chan ?var?` | `gets chan ?var?` | Wartet auf lesbare Zeile |
| `coroutine::util gets_safety chan limit var` | — | wie gets, bricht bei Limit ab |
| `coroutine::util read -nonewline chan ?n?` | `read chan ?n?` | Wartet bis EOF oder n Zeichen |
| `coroutine::util puts ?-nonewline? chan str` | `puts` | Wartet bis Chan schreibbar |
| `coroutine::util socket ?opts? host port` | `socket` | Non-blocking connect im Hintergrund |
| `coroutine::util vwait varname` | `vwait varname` | Wartet auf Schreibzugriff auf Variable |
| `coroutine::util await var...` | — | wie vwait, aber mehrere Variablen |
| `coroutine::util update ?idletasks?` | `update` | Pending Events/Idle-Handler abarbeiten |
| `coroutine::util global var...` | `global` | Coroutine-lokale Globals (Level #1) |
| `coroutine::util create arg...` | `coroutine` | Erzeugt Coroutine mit Auto-Name |
| `coroutine::util exit ?status?` | `exit` | Beendet nur die aktuelle Coroutine |

### Beispiel: Socket-Server

```tcl
package require coroutine

proc handler {sock} {
    while 1 {
        # gets blockiert die Coroutine — nicht die Event-Loop
        set zeile [coroutine::util gets $sock]
        if {[eof $sock]} break
        puts "Empfangen: $zeile"
    }
    close $sock
}

proc accept {sock addr port} {
    # Jeder Client bekommt seine eigene Coroutine
    coroutine::util create handler $sock
}

socket -server accept 8080
vwait forever
```

### Beispiel: Periodischer Hintergrundtask

```tcl
package require coroutine

coroutine::util create apply {{} {
    while 1 {
        coroutine::util after 1000
        puts "Noch aktiv: [clock format [clock seconds]]"
    }
}}
vwait forever
```

### Hinweis: coroutine::util global

`coroutine::util global` ist nicht identisch mit dem eingebauten `global`.
Die so importierten Variablen leben auf Stack-Level `#1` der Coroutine —
jede Coroutine hat ihren eigenen unabhängigen Satz dieser Variablen.
Das ist nützlich für Coroutine-lokalen Zustand ohne Namenskonflikte.

```tcl
proc worker {} {
    coroutine::util global state   ;# nur in dieser Coroutine sichtbar
    set state "laufend"
    coroutine::util after 500
    set state "fertig"
}
coroutine w1 worker
coroutine w2 worker   ;# w1 und w2 haben unabhängige state-Variablen
```

---

## coroutine::auto — transparente Coroutine-Unterstützung

```tcl
package require coroutine::auto 1.3
```

`coroutine::auto` baut auf `coroutine` auf und überschreibt die eingebauten
Tcl-Befehle so, dass sie *automatisch* coroutinen-bewusst werden — ohne dass
der aufrufende Code geändert werden muss.

Betroffen sind: `after`, `exit`, `gets`, `global`, `puts`, `read`, `socket`,
`update`, `vwait`.

Das bedeutet: Bestehenden Code, der diese Befehle verwendet, kann man einfach
in eine Coroutine stecken — er funktioniert dann nebenläufig, ohne Anpassung.

```tcl
package require coroutine::auto

# Dieser Code wurde nicht für Coroutinen geschrieben —
# er blockiert trotzdem nur die Coroutine, nicht die Event-Loop
proc legacy_reader {datei} {
    set fh [open $datei]
    while {[gets $fh zeile] >= 0} {   ;# gets ist jetzt coroutine-aware
        verarbeite $zeile
    }
    close $fh
}

coroutine reader1 legacy_reader /pfad/zur/datei1
coroutine reader2 legacy_reader /pfad/zur/datei2
vwait forever
```

### coroutine::util vs. coroutine::auto

| | `coroutine::util` | `coroutine::auto` |
|---|---|---|
| Verwendung | explizit (`coroutine::util gets ...`) | transparent (eingebautes `gets` wird ersetzt) |
| Codeänderung nötig? | ja | nein |
| Kontrolle | hoch | niedrig |
| Geeignet für | neuen Code | Legacy-Code einbetten |

---

## Coroutinen vs. Promises

Tcllib enthält auch ein `promise`-Paket (modelliert nach ECMAScript 6). Die
Frage wann Coroutinen und wann Promises ist eine echte Designentscheidung.

**Coroutinen** sind stärker wenn:
- der Ablauf *sequenziell* beschrieben werden soll ("erst A, dann B, dann C")
- Zustand natürlich im Call-Stack steckt (Schleifen, Rekursion, lokale Variablen)
- Standard-Fehlerbehandlung mit `try/catch` ausreicht

```tcl
# Coroutine-Stil: sequenziell, natürlicher Kontrollfluss
coroutine worker apply {{} {
    set a [coroutine::util gets $sock]
    set b [coroutine::util gets $sock]
    puts "Summe: [expr {$a + $b}]"
}}
```

**Promises** sind stärker wenn:
- *mehrere unabhängige* asynchrone Operationen kombiniert werden sollen
- Produzenten und Konsumenten vollständig *entkoppelt* sein sollen
- Ergebnisse aus parallelen Quellen zusammengeführt werden (`promise::all`)
- eine Kette von Abhängigkeiten aufgebaut wird, die beliebig erweitert werden kann

```tcl
# Promise-Stil: parallele Ausführung, kombinierbar
set p1 [promise::pexec du -sk /pfad1]
set p2 [promise::pexec du -sk /pfad2]
set gesamt [promise::all [list $p1 $p2]]
$gesamt done [promise::lambda {ergebnisse} {
    puts "Gesamt: [tcl::mathop::+ {*}$ergebnisse]"
}]
```

| | Coroutine | Promise |
|---|---|---|
| Kontrollfluss | sequenziell, explizit | deklarativ, verkettbar |
| Fehlerbehandlung | `try/catch` wie normal | `then`/`done` mit reject-Handler |
| Mehrere parallele Quellen | aufwendiger | `promise::all` eingebaut |
| Produzent/Konsument entkoppelt | nein | ja |
| Zustand im Code sichtbar | ja (lokale Vars) | nein (in Callbacks) |
| Paket nötig | nein (Builtin) | `promise` (Tcllib/SourceForge) |

Kurzregel: **Coroutine wenn der Ablauf eine Geschichte erzählt, Promise wenn
mehrere unabhängige Ergebnisse zusammengeführt werden.**

---

## Wann Coroutinen — wann nicht

| Situation | Lösung |
|---|---|
| Folge von Werten liefern (Generator) | Coroutine mit yield-Schleife |
| Langen Algorithmus nebenläufig ausführen | Coroutine + Event-Loop-Idiom |
| Blockierende I/O ohne Callback-Hölle | coroutine::util |
| Mehrere parallele Quellen kombinieren | Promise (`promise::all`) |
| Einfaches periodisches Polling | `after` reicht |
| Echter Parallelismus (CPU-intensiv) | Thread |

---

## Entscheidungsregel aus dem Regelbuch

> Coroutinen, wenn ein zustandsbehafteter Algorithmus die UI nicht blockieren soll.
> `after` für einfaches Scheduling. Thread für echte Parallelarbeit.

---

## Siehe auch

- [variable-scope.md](variable-scope.md) — Scope-Regeln gelten auch in Coroutinen
- [channels-io.md](channels-io.md) — `fileevent` als Alternative bei I/O
- Regelbuch Kap. 23.4 — Entscheidungsmatrix Nebenläufigkeit

## Quellen

- Nadkarni, Ashok P.: *The Tcl Programming Language*, 2nd ed., 2025 — Kap. 24
- Tcler's Wiki: https://wiki.tcl-lang.org/page/coroutine
- Tcl 9.0 Manpage: `coroutine`, `yield`, `yieldto`, `coroinject`, `coroprobe`
- Tcllib Manpages: `coroutine` 1.4, `coroutine::auto` 1.3
