# TclOO

*Stand: 2026-04-29*

TclOO ist das native Objektsystem von Tcl seit Version 8.6. Es bietet
Klassen, Vererbung, Mixins, Filter und Introspektion. TclOO ist im
Tcl-Kern eingebaut und braucht kein `package require`.

## Grundkonzept

Jede Klasse ist ein Objekt, jedes Objekt hat einen eigenen Namespace.
Methoden werden mit `method` definiert, Instanzvariablen mit `variable`.

```tcl
oo::class create Dog {
    variable name breed

    constructor {n b} {
        set name $n
        set breed $b
    }

    method speak {} {
        return "Wuff! Ich bin $name ($breed)"
    }

    method getName {} {
        return $name
    }
}

set d [Dog new "Rex" "Schaeferhund"]
puts [$d speak]   ;# -> Wuff! Ich bin Rex (Schaeferhund)
$d destroy
```

## Klassen erstellen

### oo::class create

```tcl
oo::class create ClassName {
    # Konstruktor, Methoden, Variablen
}
```

Der Rückgabewert ist der Name der Klasse. Die Klasse selbst ist
ein Objekt (Instanz von `oo::class`).

### Klasse ohne Body erweitern

```tcl
oo::class create Animal {}

oo::define Animal {
    variable species

    constructor {s} {
        set species $s
    }

    method getSpecies {} {
        return $species
    }
}
```

`oo::define` erweitert eine bestehende Klasse nachträglich.

## Konstruktor und Destruktor

### constructor

Wird bei der Erzeugung eines Objekts aufgerufen:

```tcl
oo::class create Connection {
    variable host port socket

    constructor {h p} {
        set host $h
        set port $p
        set socket ""
    }
}

set conn [Connection new "localhost" 8080]
```

Ohne expliziten Konstruktor wird ein leerer Konstruktor verwendet
der keine Argumente akzeptiert.

### destructor

Wird aufgerufen wenn das Objekt zerstört wird:

```tcl
oo::class create Connection {
    variable socket

    constructor {h p} {
        set socket [socket $h $p]
    }

    destructor {
        if {$socket ne ""} {
            close $socket
        }
    }
}
```

Der Destruktor hat keine Parameter. Er wird automatisch bei
`$obj destroy` oder `rename $obj ""` aufgerufen.

## Methoden

### method

Definiert eine oeffentliche Methode:

```tcl
oo::class create Calculator {
    variable result

    constructor {} {
        set result 0
    }

    method add {x} {
        set result [expr {$result + $x}]
        return [self]   ;# Method Chaining
    }

    method getResult {} {
        return $result
    }
}

set c [Calculator new]
$c add 5
$c add 3
puts [$c getResult]   ;# -> 8
```

### Zugriff auf Instanzvariablen

`variable` deklariert Instanzvariablen die in allen Methoden der
Klasse sichtbar sind. Innerhalb der Methodenkoerper sind sie direkt
als lokale Variablen verfügbar:

```tcl
oo::class create Counter {
    variable count

    constructor {} { set count 0 }
    method increment {} { incr count }
    method get {} { return $count }
}
```

Die `variable`-Deklaration auf Klassenebene macht die Variablen in
allen Methoden automatisch sichtbar, ohne sie in jeder Methode
einzeln deklarieren zu müssen.

## self

Der Befehl `self` liefert Informationen über das aktuelle Objekt:

| Befehl | Rückgabe |
|:-------|:----------|
| `self` | Name des aktuellen Objekts |
| `self class` | Klasse des aktuellen Objekts |
| `self namespace` | Namespace des aktuellen Objekts |
| `self caller` | Aufrufer-Info (Objekt, Klasse, Methode) |
| `self target` | Ziel bei Forwarding |
| `self next` | Nächste Methode in der Aufrufkette |

```tcl
oo::class create Base {
    method info {} {
        puts "Objekt: [self]"
        puts "Klasse: [self class]"
        puts "Namespace: [self namespace]"
    }
}

set b [Base new]
$b info
# -> Objekt: ::oo::Obj42
# -> Klasse: ::Base
# -> Namespace: ::oo::Obj42
```

## my

`my` ruft eine Methode auf dem eigenen Objekt auf, ohne den
Objektnamen zu kennen. Funktional identisch mit `[self] methodName`,
aber schneller:

```tcl
oo::class create App {
    method start {} {
        my initialize
        my run
    }

    method initialize {} {
        puts "Init"
    }

    method run {} {
        puts "Running"
    }
}
```

`my` ist besonders wichtig für den Aufruf privater Methoden und
in Konstruktoren wo das Objekt noch keinem externen Namen zugewiesen ist.

## Sichtbarkeit

### Oeffentliche Methoden (method)

Standardmäßig sind alle Methoden oeffentlich:

```tcl
oo::class create Foo {
    method publicMethod {} { return "sichtbar" }
}

set f [Foo new]
$f publicMethod   ;# OK
```

### Unexport (verbergen)

`unexport` macht eine Methode für externe Aufrufer unsichtbar.
Sie ist nur noch über `my` von innerhalb des Objekts aufrufbar:

```tcl
oo::class create Foo {
    method publicApi {} {
        return [my internalHelper]
    }

    method internalHelper {} {
        return "intern"
    }

    unexport internalHelper
}

set f [Foo new]
$f publicApi          ;# -> "intern"
$f internalHelper     ;# Fehler: unknown method
```

### Export

`export` macht eine zuvor verborgene Methode wieder sichtbar:

```tcl
oo::define Foo export internalHelper
```

### Private Methoden (Tcl 8.7+)

Ab Tcl 8.7 gibt es echte private Methoden, die auch von Unterklassen
nicht sichtbar sind:

```tcl
oo::class create Secure {
    method public {} {
        my Secret
    }

    private method Secret {} {
        return "geheim"
    }
}
```

In Tcl 8.6 ist `unexport` die beste Annaeherung an private Methoden.

## Vererbung

### Einfache Vererbung (superclass)

```tcl
oo::class create Animal {
    variable name

    constructor {n} {
        set name $n
    }

    method getName {} {
        return $name
    }

    method speak {} {
        return "..."
    }
}

oo::class create Dog {
    superclass Animal

    method speak {} {
        return "Wuff!"
    }
}

oo::class create Cat {
    superclass Animal

    method speak {} {
        return "Miau!"
    }
}

set d [Dog new "Rex"]
puts [$d getName]   ;# -> Rex (geerbt von Animal)
puts [$d speak]     ;# -> Wuff! (überschrieben)
```

### next (Methode der Elternklasse aufrufen)

`next` ruft die gleichnamige Methode der nächsten Klasse in der
Vererbungskette auf:

```tcl
oo::class create LoggedAnimal {
    superclass Animal

    constructor {name} {
        puts "Erzeuge: $name"
        next $name   ;# Animal::constructor aufrufen
    }

    method speak {} {
        set result [next]   ;# Animal::speak aufrufen
        puts "LOG: $result"
        return $result
    }
}
```

### Mehrfachvererbung

TclOO unterstützt Mehrfachvererbung:

```tcl
oo::class create Swimmer {
    method swim {} { return "schwimmt" }
}

oo::class create Runner {
    method run {} { return "rennt" }
}

oo::class create Triathlete {
    superclass Swimmer Runner

    method compete {} {
        return "[my swim] und [my run]"
    }
}
```

Die Reihenfolge in `superclass` bestimmt die Methodenaufloesung
(Method Resolution Order, MRO). Bei Konflikten gewinnt die zuerst
genannte Klasse.

## Mixins

Mixins fuegen einer Klasse oder einem einzelnen Objekt zusätzliche
Methoden hinzu, ohne die Vererbungshierarchie zu ändern:

### Klassen-Mixin

```tcl
oo::class create Serializable {
    method toDict {} {
        set result [dict create]
        foreach var [info object vars [self]] {
            my variable $var
            dict set result $var [set $var]
        }
        return $result
    }
}

oo::class create User {
    variable name email
    mixin Serializable

    constructor {n e} {
        set name $n
        set email $e
    }
}

set u [User new "Alice" "alice@example.com"]
puts [$u toDict]   ;# -> name Alice email alice@example.com
```

### Objekt-Mixin

Mixins können auch einzelnen Objekten hinzugefügt werden:

```tcl
oo::class create Debuggable {
    method debug {} {
        puts "Debug: [self class] [self]"
    }
}

set u [User new "Bob" "bob@example.com"]
oo::objdefine $u mixin Debuggable
$u debug   ;# -> Debug: ::User ::oo::Obj43
```

### Mixin vs. Vererbung

| Aspekt | Vererbung | Mixin |
|:-------|:----------|:------|
| Beziehung | "ist ein" | "kann auch" |
| Hierarchie | Fest | Nachtraeglich änderbar |
| Pro Objekt | Nein | Ja |
| Typischer Einsatz | Kernfunktionalitaet | Querschnittsfunktionen |

## Filter

Filter sind Methoden die vor jedem Methodenaufruf ausgeführt werden.
Sie können den Aufruf weiterleiten, modifizieren oder blockieren:

```tcl
oo::class create Logged {
    filter logFilter

    method logFilter {args} {
        set method [self target]
        puts "-> [lindex $method 1]"
        set result [next {*}$args]
        puts "<- [lindex $method 1]: $result"
        return $result
    }
}

oo::class create Service {
    mixin Logged

    method process {data} {
        return "verarbeitet: $data"
    }
}

set s [Service new]
$s process "test"
# -> -> process
# -> <- process: verarbeitet: test
```

## Forward

`forward` leitet einen Methodenaufruf an einen anderen Befehl weiter:

```tcl
oo::class create Logger {
    variable chan

    constructor {{file ""}} {
        if {$file ne ""} {
            set chan [open $file a]
        } else {
            set chan stdout
        }
    }

    forward write puts
    forward flush ::flush

    method log {msg} {
        my write $chan "[clock format [clock seconds]]: $msg"
        my flush $chan
    }
}
```

`forward` ist nützlich um Delegation zu implementieren oder
bestehende Befehle als Methoden bereitzustellen.

## Objekte ohne Klasse

Einzelne Objekte können direkt erzeugt und konfiguriert werden:

```tcl
set obj [oo::object new]

oo::objdefine $obj {
    variable count

    method increment {} {
        variable count
        if {![info exists count]} { set count 0 }
        incr count
    }

    method get {} {
        variable count
        if {![info exists count]} { return 0 }
        return $count
    }
}

$obj increment
$obj increment
puts [$obj get]   ;# -> 2
$obj destroy
```

## Objekterzeugung: new vs. create

### new

Erzeugt ein Objekt mit automatisch generiertem Namen:

```tcl
set d [Dog new "Rex"]
# d enthält z.B. "::oo::Obj42"
```

### create

Erzeugt ein Objekt mit vorgegebenem Namen:

```tcl
Dog create myDog "Rex"
myDog speak   ;# -> Wuff!
```

Benannte Objekte sind nützlich für Singletons oder wenn das Objekt
als Befehl unter einem festen Namen erreichbar sein soll.

## Variable-Sichtbarkeit in TclOO

### variable auf Klassenebene

Deklariert welche Variablen im Objekt-Namespace in allen Methoden
automatisch als lokale Variablen sichtbar sind:

```tcl
oo::class create Foo {
    variable x y z   ;# in allen Methoden als $x, $y, $z verfügbar

    constructor {} {
        set x 1
        set y 2
        set z 3
    }
}
```

### my variable in einzelnen Methoden

Wenn nicht alle Methoden alle Variablen brauchen:

```tcl
oo::class create Bar {
    constructor {} {
        my variable x
        set x 42
    }

    method getX {} {
        my variable x
        return $x
    }
}
```

### Variablen sind im Objekt-Namespace

Instanzvariablen leben im Namespace des Objekts:

```tcl
set d [Dog new "Rex" "Husky"]
set ns [info object namespace $d]
puts [set ${ns}::name]   ;# -> Rex (direkter Zugriff, nur für Debug)
```

## Introspektion

### info object

```tcl
set d [Dog new "Rex"]

info object class $d          ;# -> ::Dog
info object isa object $d     ;# -> 1
info object isa class Dog     ;# -> 1
info object methods $d        ;# -> speak getName
info object namespace $d      ;# -> ::oo::Obj42
info object vars $d           ;# -> name breed
```

### info class

```tcl
info class methods Dog            ;# -> speak getName
info class superclasses Dog       ;# -> ::Animal
info class subclasses Animal      ;# -> ::Dog ::Cat
info class instances Dog          ;# -> ::oo::Obj42
info class constructor Dog        ;# -> {n b} {set name $n ...}
info class definition Dog speak   ;# -> {} {return "Wuff!"}
info class variables Dog          ;# -> name breed
info class mixins Dog             ;# -> (Mixin-Liste)
info class filters Dog            ;# -> (Filter-Liste)
```

## Patterns

### Singleton

```tcl
oo::class create Singleton {
    variable instance

    self method getInstance {args} {
        variable instance
        if {![info exists instance] || [catch {$instance info}]} {
            set instance [my new {*}$args]
        }
        return $instance
    }
}

oo::class create AppConfig {
    superclass Singleton
    variable settings

    constructor {} {
        set settings [dict create]
    }

    method set {key value} {
        dict set settings $key $value
    }

    method get {key} {
        dict get $settings $key
    }
}

set cfg [AppConfig getInstance]
$cfg set debug 1
```

### Observer

```tcl
oo::class create Observable {
    variable observers

    constructor {} {
        set observers [dict create]
    }

    method on {event callback} {
        dict lappend observers $event $callback
    }

    method emit {event args} {
        if {[dict exists $observers $event]} {
            foreach cb [dict get $observers $event] {
                {*}$cb {*}$args
            }
        }
    }
}
```

### Hull-Pattern (Bert-Pattern für Widgets)

Für TclOO-basierte Megawidgets:

```tcl
oo::class create SearchEntry {
    variable hull entry btn

    constructor {parent args} {
        set hull [ttk::frame $parent.searchEntry]
        set entry [ttk::entry $hull.entry]
        set btn [ttk::button $hull.btn -text "Suchen" \
            -takefocus 0 \
            -command [list [self] onSearch]]

        pack $entry -side left -fill x -expand 1
        pack $btn -side right

        # -takefocus 0 für den Container
        $hull configure -takefocus 0
    }

    method onSearch {} {
        set term [$entry get]
        puts "Suche: $term"
    }

    method widget {} {
        return $hull
    }
}
```

## Tcl 9 Erweiterungen

Tcl 9 bringt drei neue Klassen-Typen, die häufige OO-Patterns
direkt in der Sprache unterstützen.

### oo::abstract -- Abstrakte Klassen

Abstrakte Klassen können nicht direkt instanziiert werden.
Sie erzwingen, dass Unterklassen bestimmte Methoden implementieren:

```tcl
oo::abstract create Shape {
    variable x y

    constructor {xPos yPos} {
        set x $xPos
        set y $yPos
    }

    # Muss von Unterklassen implementiert werden
    method area {} {
        error "Muss implementiert werden"
    }

    method move {dx dy} {
        incr x $dx
        incr y $dy
    }
}

oo::class create Rectangle {
    superclass Shape
    variable width height

    constructor {x y w h} {
        next $x $y
        set width $w
        set height $h
    }

    method area {} {
        return [expr {$width * $height}]
    }
}

# Shape create s 0 0       ;# FEHLER: Abstrakt!
Rectangle create r 0 0 10 5
puts [r area]               ;# -> 50
```

### oo::singleton -- Singleton-Pattern

Garantiert, dass eine Klasse nur eine einzige Instanz hat.
Jeder Aufruf von `new` oder `create` liefert dasselbe Objekt:

```tcl
oo::singleton create Database {
    variable connection

    method connect {host} {
        set connection $host
        puts "Verbunden mit $host"
    }

    method query {sql} {
        puts "Query auf $connection: $sql"
    }
}

set db1 [Database new]
set db2 [Database new]
# db1 und db2 sind IDENTISCH -- dasselbe Objekt

$db1 connect "localhost"
$db2 query "SELECT * FROM users"
# -> Query auf localhost: SELECT * FROM users
```

Vor Tcl 9 musste man Singletons manuell implementieren
(siehe Patterns-Abschnitt oben). `oo::singleton` macht
das überfluessig.

### oo::configurable -- Konfigurierbare Eigenschaften

Erzeugt automatisch `configure`/`cget`-Methoden im Tk-Stil:

```tcl
oo::configurable create Window {
    property width 800
    property height 600
    property title "Untitled"
    property resizable true

    method show {} {
        puts "Fenster: [my cget -title] ([my cget -width] x [my cget -height])"
    }
}

Window create w
w configure -title "Mein Fenster" -width 1024
w show
# -> Fenster: Mein Fenster (1024 x 600)

# Einzelne Eigenschaft abfragen:
puts [w cget -width]      ;# -> 1024

# Alle Eigenschaften:
puts [w configure]
```

`property` deklariert Eigenschaft, Standardwert und optional
einen Validierungs-Body:

```tcl
oo::configurable create Server {
    property port 8080 {
        if {$port < 1 || $port > 65535} {
            error "Ungueltiger Port: $port"
        }
    }
    property host "localhost"
}
```

### Vergleich: Tcl 8.6 vs. Tcl 9

| Pattern | Tcl 8.6 (manuell) | Tcl 9 (eingebaut) |
|:--------|:-------------------|:-------------------|
| Abstrakte Klasse | `error` in Basismethoden | `oo::abstract create` |
| Singleton | `variable instance` + Guard | `oo::singleton create` |
| Konfiguration | Eigene configure-Methode | `oo::configurable` + `property` |

## Häufige Fehler

### variable vergessen

```tcl
# FALSCH: name ist nicht deklariert
oo::class create Broken {
    constructor {n} {
        set name $n   ;# lokale Variable, nach constructor weg
    }
    method getName {} {
        return $name  ;# Fehler: can't read "name"
    }
}

# RICHTIG:
oo::class create Fixed {
    variable name

    constructor {n} {
        set name $n   ;# Instanzvariable
    }
    method getName {} {
        return $name  ;# OK
    }
}
```

### next vergessen im Konstruktor

```tcl
# FALSCH: Elternklasse wird nicht initialisiert
oo::class create Child {
    superclass Parent
    constructor {name extra} {
        set myExtra $extra
        # Parent::constructor wird nicht aufgerufen!
    }
}

# RICHTIG:
oo::class create Child {
    superclass Parent
    variable myExtra
    constructor {name extra} {
        next $name       ;# Parent::constructor aufrufen
        set myExtra $extra
    }
}
```

### self ausserhalb von Methoden

```tcl
# FALSCH: self nur innerhalb von Methoden gueltig
oo::class create Foo {
    puts [self]   ;# Fehler
}
```

### Objekt als Widget-Callback

```tcl
# FALSCH: Callback verliert Objektkontext
oo::class create MyWidget {
    method setup {parent} {
        ttk::button $parent.btn -command "my onClick"   ;# FALSCH
    }
}

# RICHTIG: [list] mit [self] oder [namespace code]
oo::class create MyWidget {
    method setup {parent} {
        ttk::button $parent.btn -command [list [self] onClick]
    }
}
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `oo::class create Name body` | Klasse definieren |
| `oo::define Class body` | Klasse erweitern |
| `oo::objdefine obj body` | Einzelnes Objekt erweitern |
| `ClassName new ?args?` | Objekt mit Auto-Name erzeugen |
| `ClassName create name ?args?` | Objekt mit festem Namen erzeugen |
| `$obj destroy` | Objekt zerstören |
| `method name args body` | Methode definieren |
| `constructor args body` | Konstruktor definieren |
| `destructor body` | Destruktor definieren |
| `variable name ...` | Instanzvariablen deklarieren |
| `superclass classes` | Elternklassen setzen |
| `mixin classes` | Mixins hinzufügen |
| `filter methods` | Filter aktivieren |
| `forward name cmd` | Methodenaufruf weiterleiten |
| `export/unexport method` | Sichtbarkeit steuern |
| `self` | Aktuelles Objekt abfragen |
| `my method args` | Eigene Methode aufrufen |
| `next ?args?` | Methode der Elternklasse aufrufen |

## Siehe auch

- [Namespace](namespace.md) -- Jedes Objekt hat einen eigenen Namespace
- [Prozeduren](proc.md) -- Methoden sind intern Prozeduren
- [Variable Scope](variable-scope.md) -- Instanzvariablen, `variable` in Methoden
- [Info](info.md) -- `info object`, `info class` für Introspektion
- [Namespace Ensemble](namespace-ensemble.md) -- Alternative: Ensemble statt OO
- [Fehlerbehandlung](error-handling.md) -- `try`/`throw` in Methoden
