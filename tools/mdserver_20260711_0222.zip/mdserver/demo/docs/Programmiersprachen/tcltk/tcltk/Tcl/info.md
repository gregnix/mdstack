# Der info-Befehl

*Stand: 2026-04-29*

`info` ist Tcls zentraler Befehl für Introspektion. Er liefert
Informationen über den Zustand des Interpreters: Welche Befehle,
Variablen, Namespaces und Prozeduren existieren, wie sie definiert sind,
und wo sich das laufende Script befindet.

## Übersicht nach Kategorie

| Kategorie | Unterbefehle |
|:----------|:-------------|
| Befehle | `commands`, `procs`, `cmdcount`, `cmdtype` |
| Prozedur-Details | `body`, `args`, `default` |
| Variablen | `vars`, `globals`, `locals`, `exists` |
| Aufrufstack | `level`, `frame` |
| Script und System | `script`, `nameofexecutable`, `hostname`, `library` |
| Version | `patchlevel`, `tclversion` |
| Pakete und Libraries | `loaded`, `sharedlibextension` |
| Sonstiges | `complete`, `coroutine`, `object`, `errorstack` |

## Befehle abfragen

### info commands

Listet alle Befehle die im aktuellen Scope sichtbar sind.
Dazu gehören eingebaute Befehle, Prozeduren und importierte Befehle.

```tcl
info commands           ;# alle Befehle
info commands str*      ;# alle die mit "str" beginnen
info commands ::app::*  ;# alle in Namespace app
```

Ein Glob-Pattern filtert die Ergebnisse:

```tcl
info commands *sort*    ;# -> lsort
```

### info procs

Listet nur Prozeduren (definiert mit `proc`), keine eingebauten Befehle:

```tcl
proc hello {} { return "hello" }
proc world {} { return "world" }

info procs          ;# -> hello world (und andere definierte Procs)
info procs h*       ;# -> hello
```

In einem Namespace:

```tcl
namespace eval app {
    proc start {} {}
    proc stop {} {}
}

info procs ::app::*   ;# -> ::app::start ::app::stop
```

### Unterschied commands vs. procs

```tcl
info commands puts     ;# -> puts (eingebaut)
info procs puts        ;# -> "" (kein Proc)

proc myProc {} {}
info commands myProc   ;# -> myProc
info procs myProc      ;# -> myProc
```

`info commands` liefert alles, `info procs` nur mit `proc` definierte
Prozeduren.

### info cmdcount

Gibt die Anzahl der bisher ausgeführten Befehle zurück:

```tcl
info cmdcount   ;# -> z.B. 4217
```

Nützlich für einfaches Performance-Profiling:

```tcl
set before [info cmdcount]
# ... Code ausführen ...
set after [info cmdcount]
puts "Befehle ausgeführt: [expr {$after - $before}]"
```

### info cmdtype

Seit Tcl 8.7. Gibt den Typ eines Befehls zurück:

```tcl
info cmdtype puts          ;# -> native
info cmdtype myProc        ;# -> proc
info cmdtype string        ;# -> ensemble
info cmdtype ::oo::class   ;# -> object
```

Mögliche Typen: `native`, `proc`, `ensemble`, `object`, `interp`,
`import`, `slave`, `coroutine`.

## Prozedur-Details

### info body

Gibt den Koerper einer Prozedur zurück:

```tcl
proc greet {name} {
    return "Hallo $name"
}

info body greet   ;# -> "\n    return \"Hallo $name\"\n"
```

### info args

Gibt die Parameterliste einer Prozedur zurück:

```tcl
proc calculate {a b {op +}} {
    expr "$a $op $b"
}

info args calculate   ;# -> a b op
```

### info default

Prüft ob ein Parameter einen Standardwert hat und speichert ihn:

```tcl
proc calculate {a b {op +}} { ... }

info default calculate a defVal    ;# -> 0 (kein Default)
info default calculate op defVal   ;# -> 1, defVal ist "+"

puts $defVal   ;# -> "+"
```

Syntax: `info default procName argName varName`

Gibt 1 zurück wenn ein Default existiert und speichert ihn in `varName`.
Gibt 0 zurück wenn kein Default existiert.

### Prozedur-Signatur rekonstruieren

Mit `info args` und `info default` lässt sich die vollständige
Signatur einer Prozedur rekonstruieren:

```tcl
proc showSignature {procName} {
    set params {}
    foreach arg [info args $procName] {
        if {[info default $procName $arg defVal]} {
            lappend params [list $arg $defVal]
        } else {
            lappend params $arg
        }
    }
    return "proc $procName {$params}"
}

proc example {a {b 10} args} { ... }
puts [showSignature example]
# -> proc example {a {b 10} args}
```

## Variablen abfragen

### info exists

Prüft ob eine Variable existiert:

```tcl
set x 42
info exists x       ;# -> 1
info exists y       ;# -> 0
```

Das ist der sicherste Weg um eine Variable zu prüfen, bevor sie
gelesen wird. Ohne `info exists` würde `$y` einen Fehler erzeugen.

### Array-Elemente prüfen

```tcl
array set data {name Alice age 22}

info exists data          ;# -> 1 (Array existiert)
info exists data(name)    ;# -> 1 (Element existiert)
info exists data(email)   ;# -> 0 (Element fehlt)
```

### info vars

Listet alle Variablen im aktuellen Scope:

```tcl
proc test {} {
    set a 1
    set b 2
    return [info vars]   ;# -> a b
}
```

Mit Pattern:

```tcl
info vars tcl_*   ;# -> tcl_library tcl_version tcl_platform ...
```

In einem Namespace:

```tcl
namespace eval app {
    variable config "test"
    variable debug 0
}

info vars ::app::*   ;# -> ::app::config ::app::debug
```

### info globals

Listet alle globalen Variablen:

```tcl
info globals           ;# alle globalen Variablen
info globals tcl_*     ;# -> tcl_library tcl_version ...
info globals auto_*    ;# -> auto_path auto_index ...
```

### info locals

Listet nur die lokalen Variablen der aktuellen Prozedur:

```tcl
set globalVar 42

proc test {} {
    global globalVar
    set localVar 1
    set anotherLocal 2
    puts [info locals]    ;# -> localVar anotherLocal
    # globalVar taucht nicht auf, obwohl via global zugreifbar
}
```

`info locals` zeigt keine via `global` oder `upvar` verknuepften
Variablen.

### Unterschied vars, globals, locals

| Befehl | Scope | Zeigt |
|:-------|:------|:------|
| `info vars` | Aktueller Scope | Alles sichtbare (lokal + verknüpft) |
| `info globals` | Global | Nur globale Variablen |
| `info locals` | Lokal | Nur echt lokale Variablen |

## Aufrufstack

### info level

Gibt Informationen über den Aufrufstack zurück.

Ohne Argument: Die aktuelle Stack-Tiefe:

```tcl
proc a {} { return [info level] }
proc b {} { return [a] }

a    ;# -> 1
b    ;# -> 2 (b ruft a, a ist auf Level 2)
```

Mit Argument: Der Befehl und seine Argumente auf dem angegebenen Level:

```tcl
proc inner {} {
    puts [info level 0]    ;# -> inner (eigener Aufruf)
    puts [info level 1]    ;# -> outer (Aufrufer)
}

proc outer {} {
    inner
}

outer
```

Negative Werte zählen relativ zum aktuellen Level:

```tcl
proc deep {} {
    puts [info level -1]   ;# -> ein Level höher (Aufrufer)
}
```

### info frame

Erweiterte Stack-Information seit Tcl 8.5. Liefert ein Dict mit
Details zum aktuellen Ausfuehrungskontext:

```tcl
proc test {} {
    set frame [info frame 0]
    puts [dict get $frame type]   ;# -> source oder proc
    puts [dict get $frame proc]   ;# -> ::test
    if {[dict exists $frame file]} {
        puts [dict get $frame file]   ;# Dateiname
        puts [dict get $frame line]   ;# Zeilennummer
    }
}
```

Ohne Argument gibt `info frame` die Gesamtzahl der Frames zurück.

### info errorstack

Seit Tcl 8.6. Liefert nach einem Fehler detaillierte Informationen
über den Aufrufstack zum Zeitpunkt des Fehlers:

```tcl
proc buggy {} {
    error "something went wrong"
}

if {[catch {buggy} err]} {
    puts [info errorstack]
    # -> INNER {invokeStk1 buggy} CALL {buggy}
}
```

Liefert abwechselnd Typ-Token und Beschreibung. Typen sind unter
anderem `INNER`, `CALL`, `UP`.

## Script und System

### info script

Gibt den Pfad des aktuell ausgeführten Scripts zurück:

```tcl
# In /home/user/app/main.tcl:
puts [info script]   ;# -> /home/user/app/main.tcl
```

Aenderbar mit optionalem Argument:

```tcl
info script /neuer/pfad.tcl   ;# setzt den Wert
```

### Typischer Einsatz: Pfade relativ zum Script

```tcl
set appDir [file dirname [file normalize [info script]]]
set libDir [file join $appDir lib]
set dataDir [file join $appDir data]
```

Das ist der korrekte Weg, Pfade in Anwendungen und Demos aufzuloesen,
statt relativ zum Arbeitsverzeichnis zu arbeiten.

### info nameofexecutable

Gibt den vollständigen Pfad zum laufenden Tcl-Interpreter zurück:

```tcl
info nameofexecutable   ;# -> /usr/bin/tclsh8.6
```

### info hostname

Gibt den Hostnamen des Rechners zurück:

```tcl
info hostname   ;# -> mycomputer.local
```

### info library

Gibt das Verzeichnis der Tcl-Systembibliothek zurück:

```tcl
info library   ;# -> /usr/lib/tcl8.6
```

Ist identisch mit dem Wert von `$tcl_library`.

### info sharedlibextension

Gibt die Dateiendung für Shared Libraries auf der aktuellen Plattform:

```tcl
info sharedlibextension   ;# -> .so (Linux), .dll (Windows), .dylib (macOS)
```

## Version

### info patchlevel

Die vollständige Versionsnummer des Tcl-Interpreters:

```tcl
info patchlevel   ;# -> 8.6.14 oder 9.0.0
```

### info tclversion

Nur Major und Minor Version:

```tcl
info tclversion   ;# -> 8.6 oder 9.0
```

### Tcl-Version prüfen

```tcl
# Tcl 9 oder neuer?
if {[package vcompare [info patchlevel] 9.0] >= 0} {
    puts "Tcl 9+"
}

# Mindestens 8.6?
if {[package vcompare [info patchlevel] 8.6] >= 0} {
    puts "Tcl 8.6+"
}
```

## Geladene Libraries

### info loaded

Listet alle geladenen Shared Libraries:

```tcl
info loaded      ;# alle im aktuellen Interpreter geladenen
info loaded ""   ;# dasselbe
```

Jeder Eintrag ist eine Liste aus Dateipfad und Paketname:

```tcl
# Beispiel-Ausgabe:
# {/usr/lib/libtk8.6.so Tk} {/usr/lib/sqlite3.so Sqlite3}
```

## Sonstige info-Befehle

### info complete

Prüft ob ein String ein vollständiger Tcl-Befehl ist (alle Klammern
und Anführungszeichen geschlossen):

```tcl
info complete {puts "hello"}        ;# -> 1
info complete {puts "hello}         ;# -> 0 (Anführungszeichen offen)
info complete {if {$x} \{}          ;# -> 0 (geschweifte Klammer offen)
```

Nützlich für interaktive Shells oder Editoren, um zu erkennen ob
der Benutzer noch weitere Eingabe erwartet wird:

```tcl
set buffer ""
while {1} {
    append buffer [gets stdin] "\n"
    if {[info complete $buffer]} {
        eval $buffer
        set buffer ""
    }
}
```

### info coroutine

Gibt den Namen der aktuellen Coroutine zurück, oder einen leeren
String wenn der Code nicht in einer Coroutine läuft:

```tcl
proc myCoroBody {} {
    puts [info coroutine]   ;# -> ::myCoro
    yield "hello"
    return "done"
}

coroutine myCoro myCoroBody
```

### info object (TclOO)

Seit Tcl 8.6. Liefert Informationen über TclOO-Objekte:

```tcl
oo::class create Dog {
    variable name
    constructor {n} { set name $n }
    method speak {} { return "Wuff" }
    method getName {} { return $name }
}

set d [Dog new "Rex"]

info object class $d         ;# -> ::Dog
info object methods $d       ;# -> speak getName
info object namespace $d     ;# -> ::oo::Obj42 (interner Namespace)
info object isa object $d    ;# -> 1
info object isa class Dog    ;# -> 1
```

#### info object Unterbefehle

| Unterbefehl | Funktion |
|:------------|:---------|
| `info object class obj` | Klasse des Objekts |
| `info object methods obj` | Oeffentliche Methoden |
| `info object namespace obj` | Interner Namespace |
| `info object isa object obj` | Ist es ein Objekt? |
| `info object isa class cls` | Ist es eine Klasse? |
| `info object vars obj` | Instanzvariablen |
| `info object definition obj method` | Methoden-Signatur und Body |
| `info object filters obj` | Aktive Filter |
| `info object mixins obj` | Aktive Mixins |
| `info object forward obj` | Forwarded Methods |

#### info class (TclOO)

Für Klassen-Introspektion:

```tcl
info class methods Dog          ;# -> speak getName
info class superclasses Dog     ;# -> ::oo::object
info class subclasses Dog       ;# -> (leer, wenn keine)
info class instances Dog        ;# -> ::oo::Obj42
info class constructor Dog      ;# -> Konstruktor-Argumente und Body
info class definition Dog speak ;# -> {} {return "Wuff"}
```

| Unterbefehl | Funktion |
|:------------|:---------|
| `info class methods cls` | Methoden der Klasse |
| `info class superclasses cls` | Elternklassen |
| `info class subclasses cls` | Kindklassen |
| `info class instances cls` | Instanzen der Klasse |
| `info class constructor cls` | Konstruktor-Details |
| `info class destructor cls` | Destruktor-Body |
| `info class definition cls method` | Methoden-Signatur und Body |
| `info class variables cls` | Deklarierte Variablen |
| `info class filters cls` | Klassen-Filter |
| `info class mixins cls` | Klassen-Mixins |

## Praxisbeispiele

### Alle Prozeduren in einem Namespace auflisten

```tcl
proc listNsProcs {ns} {
    set result {}
    foreach cmd [info commands ${ns}::*] {
        if {[info procs $cmd] ne ""} {
            lappend result [namespace tail $cmd]
        }
    }
    return [lsort $result]
}

puts [listNsProcs ::tcl::mathfunc]
```

### Prozedur-Dokumentation generieren

```tcl
proc docProc {procName} {
    set sig [list]
    foreach arg [info args $procName] {
        if {[info default $procName $arg defVal]} {
            lappend sig "?${arg}=${defVal}?"
        } elseif {$arg eq "args"} {
            lappend sig "?args...?"
        } else {
            lappend sig $arg
        }
    }
    return "$procName [join $sig { }]"
}

proc example {filename {encoding utf-8} args} { ... }
puts [docProc example]
# -> example filename ?encoding=utf-8? ?args...?
```

### Variable sicher lesen mit Fallback

```tcl
proc getVar {name {default ""}} {
    upvar 1 $name var
    if {[info exists var]} {
        return $var
    }
    return $default
}

set x 42
puts [getVar x "nix"]   ;# -> 42
puts [getVar y "nix"]   ;# -> nix
```

### Tcl-Version für bedingten Code

```tcl
proc setupEncoding {chan} {
    if {[package vcompare [info patchlevel] 9.0] >= 0} {
        # Tcl 9: Encoding-Profile verfügbar
        fconfigure $chan -encoding utf-8 -profile replace
    } else {
        # Tcl 8.6: Klassisch
        fconfigure $chan -encoding utf-8
    }
}
```

### Namespace-Baum anzeigen

```tcl
proc showNsTree {{ns ::} {indent ""}} {
    set name [expr {$ns eq "::" ? "::" : [namespace tail $ns]}]
    puts "${indent}${name}/"
    foreach child [lsort [namespace children $ns]] {
        showNsTree $child "${indent}  "
    }
}

showNsTree
```

## Häufige Fehler

### info exists mit qualifiziertem Namen

```tcl
# FALSCH: info exists mit Namespace-Pfad
info exists ::app::config   ;# funktioniert NUR im globalen Scope

# RICHTIG: Im Kontext des Namespaces prüfen
namespace eval app {
    info exists config
}

# Oder mit namespace upvar
namespace upvar ::app config c
info exists c
```

### info body auf eingebaute Befehle

```tcl
# FALSCH: Eingebaute Befehle haben keinen Body
info body puts   ;# Fehler: "puts" isn't a procedure

# RICHTIG: Vorher prüfen
if {[info procs puts] ne ""} {
    puts [info body puts]
}
```

### info commands in Namespaces

```tcl
# ACHTUNG: Ohne Pattern listet info commands nur den aktuellen Scope
namespace eval app {
    info commands   ;# -> globale + app-lokale Befehle
}

# Nur Namespace-Befehle:
info commands ::app::*
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `info commands ?pattern?` | Alle sichtbaren Befehle |
| `info procs ?pattern?` | Nur Prozeduren |
| `info cmdcount` | Anzahl ausgefuehrter Befehle |
| `info cmdtype cmd` | Typ eines Befehls (Tcl 8.7+) |
| `info body proc` | Prozedur-Koerper |
| `info args proc` | Parameterliste |
| `info default proc arg var` | Standardwert eines Parameters |
| `info exists var` | Existiert die Variable? |
| `info vars ?pattern?` | Variablen im Scope |
| `info globals ?pattern?` | Globale Variablen |
| `info locals ?pattern?` | Lokale Variablen |
| `info level ?n?` | Stack-Tiefe oder Aufruf auf Level n |
| `info frame ?n?` | Detaillierte Frame-Information |
| `info errorstack` | Fehler-Aufrufstack |
| `info script ?name?` | Aktuelles Script (lesen/setzen) |
| `info nameofexecutable` | Pfad zum Interpreter |
| `info hostname` | Hostname des Rechners |
| `info library` | Tcl-Systembibliothek |
| `info sharedlibextension` | Shared-Library-Endung |
| `info patchlevel` | Vollständige Tcl-Version |
| `info tclversion` | Major.Minor Tcl-Version |
| `info loaded ?interp?` | Geladene Shared Libraries |
| `info complete string` | Ist der String ein vollständiger Befehl? |
| `info coroutine` | Name der aktuellen Coroutine |
| `info object subcommand obj` | TclOO-Objekt-Introspektion |
| `info class subcommand cls` | TclOO-Klassen-Introspektion |

## Siehe auch

- [Prozeduren](proc.md) -- `info body`, `info args`, `info default`
- [Namespace](namespace.md) -- `info commands`, Namespace-Introspektion
- [Interpreter](interp.md) -- `info loaded`, Interpreter-Details
- [TclOO](tcloo.md) -- `info object`, `info class`
- [Metaprogramming](metaprogramming.md) -- `info frame`, `info level` für Stack
- [Trace](trace.md) -- Introspektion zur Laufzeit kombiniert mit Traces
