# Text-Widget: Das Tag-System

*Stand: 2026-04-29*

Das Text-Widget (`text`) ist eines der maechtigsten Widgets in Tk.
Sein Tag-System ermöglicht komplexe Textformatierung, Hyperlinks,
interaktive Bereiche und eingebettete Widgets. Dieses Dokument
behandelt Tags als zentralen Mechanismus für formatierte
Textanzeige und -bearbeitung.

## Grundkonzept

Ein Tag ist ein benannter Marker, der auf einen Textbereich
angewendet wird. Tags steuern das Aussehen, reagieren auf
Events und verknüpfen Daten mit Textbereichen.

```tcl
text .t -wrap word
pack .t -fill both -expand 1

# Text einfügen
.t insert end "Hello World"

# Tag auf Bereich anwenden
.t tag add bold 1.0 1.5
# "Hello" ist jetzt mit Tag "bold" markiert

# Tag konfigurieren -- erst jetzt wird es sichtbar
.t tag configure bold -font {TkDefaultFont 12 bold}
# "Hello" wird fett dargestellt
```

Tags können auch direkt beim Einfügen zugewiesen werden:

```tcl
.t insert end "Fetter Text" bold
.t insert end " und " {}
.t insert end "normaler Text"
```

Mehrere Tags gleichzeitig:

```tcl
.t insert end "Fett und rot" {bold red}
```

## Indizes im Text-Widget

Tags arbeiten mit dem Index-System des Text-Widgets.
Format: `Zeile.Zeichen` (1-basierte Zeilen, 0-basierte Zeichen).

### Basis-Indizes

```tcl
# Zeile 1, Zeichen 0 bis 5
.t tag add mytag 1.0 1.5

# Bis zum Ende der Zeile
.t tag add mytag 1.0 "1.0 lineend"

# Bis zum Ende des gesamten Textes
.t tag add mytag 1.0 end

# Cursor-Position (Insert-Mark)
.t tag add mytag insert "insert + 5 chars"
```

### Spezielle Index-Ausdrücke

```tcl
"end - 1 char"       ;# Vorletztes Zeichen (vor dem finalen \n)
"1.0 linestart"      ;# Anfang der Zeile 1
"1.0 lineend"        ;# Ende der Zeile 1
"insert wordstart"   ;# Anfang des Wortes am Cursor
"insert wordend"     ;# Ende des Wortes am Cursor
"2.5 + 10 chars"     ;# 10 Zeichen nach Position 2.5
"3.0 - 1 lines"      ;# Eine Zeile vor Zeile 3
```

### Indizes verschieben sich

Wenn Text eingefügt wird, verschieben sich alle nachfolgenden
Indizes. Das ist eine häufige Fehlerquelle:

```tcl
set pos [.t index "1.0"]
# pos = "1.0"

.t insert 1.0 "Neuer Text\n"
# Der alte "1.0" ist jetzt "2.0"!
# pos enthält noch "1.0" -- zeigt auf den neuen Text
```

### Marks als stabile Positionen

Marks bewegen sich mit dem Text mit und liefern so
stabile Referenzpunkte:

```tcl
.t mark set myMark 1.0
.t mark gravity myMark left
# myMark bleibt "links" vom eingefügten Text

.t insert 1.0 "Neuer Text\n"
# myMark zeigt immer noch auf den ursprünglichen Text
puts [.t index myMark]
# -> 2.0 (automatisch angepasst)
```

Gravity bestimmt das Verhalten bei Einfuegungen an der
Mark-Position:

| Gravity | Verhalten |
|:--------|:----------|
| `left` | Mark bleibt links vom eingefügten Text |
| `right` | Mark wandert rechts vom eingefügten Text (Standard) |

## Tag-Eigenschaften

Tags können zahlreiche visuelle Eigenschaften steuern:

### Schrift und Farbe

```tcl
.t tag configure code \
    -foreground #d63384 \
    -background #f8f9fa \
    -font {Courier 10}

.t tag configure link \
    -foreground blue \
    -underline 1

.t tag configure error \
    -foreground white \
    -background #dc3545 \
    -font {TkDefaultFont 10 bold}
```

### Absatz-Formatierung

```tcl
.t tag configure h1 \
    -font {TkDefaultFont 20 bold} \
    -spacing1 10 \
    -spacing3 5

.t tag configure blockquote \
    -lmargin1 20 \
    -lmargin2 20 \
    -foreground #6c757d \
    -font {TkDefaultFont 10 italic}

.t tag configure listitem \
    -lmargin1 15 \
    -lmargin2 30
```

### Vollständige Eigenschaftsliste

| Eigenschaft | Beschreibung |
|:------------|:-------------|
| `-foreground` | Textfarbe |
| `-background` | Hintergrundfarbe |
| `-font` | Schriftart |
| `-underline` | Unterstrichen (0/1) |
| `-underlinefg` | Farbe der Unterstreichung (Tcl 8.7+) |
| `-overstrike` | Durchgestrichen (0/1) |
| `-overstrikefg` | Farbe der Durchstreichung (Tcl 8.7+) |
| `-relief` | 3D-Effekt (flat, raised, sunken, ridge, groove) |
| `-borderwidth` | Rahmenbreite (erfordert relief) |
| `-lmargin1` | Linker Rand erste Zeile eines Absatzes |
| `-lmargin2` | Linker Rand Folgezeilen eines Absatzes |
| `-rmargin` | Rechter Rand |
| `-spacing1` | Abstand vor dem Absatz (Pixel) |
| `-spacing2` | Zeilenabstand innerhalb des Absatzes |
| `-spacing3` | Abstand nach dem Absatz (Pixel) |
| `-justify` | Ausrichtung: left, center, right |
| `-tabs` | Tabulator-Positionen |
| `-wrap` | Zeilenumbruch: none, char, word |
| `-elide` | Text verstecken (0/1) |

## Named Fonts für Tags

Das Listen-Format für Fonts (`{family size style}`) ist bei
Fontfamilien mit Leerzeichen mehrdeutig. Named Fonts loesen
dieses Problem sauber und ermöglichen zentrale Größenänderungen.

### Das Ambiguitätsproblem

```tcl
# PROBLEMATISCH: Tk liest 4 Token statt 3
.t tag configure h1 -font {DejaVu Sans 16 bold}
# Tk interpretiert: family="DejaVu", size="Sans" -> Fehler!

# WORKAROUND 1: Option-Format (eindeutig, aber verbose)
set family [font actual TkDefaultFont -family]
.t tag configure h1 -font [list -family $family -size 16 -weight bold]

# WORKAROUND 2: Named Font (empfohlen)
font create h1Font -family "DejaVu Sans" -size 16 -weight bold
.t tag configure h1 -font h1Font
```

### Zentrale Font-Verwaltung

Named Fonts erlauben es, die Schriftgröße aller Tags
mit einem einzigen Aufruf zu ändern:

```tcl
namespace eval ::viewer {
    proc initFonts {baseSize} {
        set family [font actual TkDefaultFont -family]
        set mono   [font actual TkFixedFont -family]
        
        # Fonts erstellen (oder überschreiben)
        foreach {name opts} [list \
            vBody   [list -family $family -size $baseSize] \
            vBold   [list -family $family -size $baseSize -weight bold] \
            vItalic [list -family $family -size $baseSize -slant italic] \
            vBoldIt [list -family $family -size $baseSize -weight bold -slant italic] \
            vMono   [list -family $mono   -size $baseSize] \
            vH1     [list -family $family -size [expr {int($baseSize * 1.6)}] -weight bold] \
            vH2     [list -family $family -size [expr {int($baseSize * 1.4)}] -weight bold] \
        ] {
            catch {font delete $name}
            font create $name {*}$opts
        }
    }
    
    proc setFontSize {newSize} {
        # Alle Named Fonts anpassen -- Tags aktualisieren sich automatisch
        font configure vBody   -size $newSize
        font configure vBold   -size $newSize
        font configure vItalic -size $newSize
        font configure vBoldIt -size $newSize
        font configure vMono   -size $newSize
        font configure vH1     -size [expr {int($newSize * 1.6)}]
        font configure vH2     -size [expr {int($newSize * 1.4)}]
    }
}

::viewer::initFonts 11

# Tags verwenden die Named Fonts
.t configure -font vBody
.t tag configure strong -font vBold
.t tag configure em     -font vItalic
.t tag configure code   -font vMono
.t tag configure h1     -font vH1
.t tag configure h2     -font vH2

# Später: Größe ändern -- alle Tags passen sich an
::viewer::setFontSize 14
```

### Bold+Italic Kombination

Für Fälle wo **bold** und *italic* sich überlappen,
wird ein eigener Combined-Font benötigt:

```tcl
font create vBoldItalic -family "DejaVu Sans" -size 11 \
    -weight bold -slant italic

# In Blockquotes: Basis ist italic, Bold muss bold+italic sein
.t tag configure quote  -font vItalic
.t tag configure bold_q -font vBoldItalic
```

Ohne diese Trennung würde bold in einem italic-Kontext
nur bold sein (italic ginge verloren), weil der Font
des hoeherwertigen Tags komplett gewinnt.

### font measure für Spaltenbreiten

```tcl
# Textbreite in Pixeln messen
set headerWidth [font measure vBold "Spaltenheader"]
set dataWidth   [font measure vMono "Beispieldaten"]

# Nützlich für dynamische Tabellenspalten
set colWidth [expr {max($headerWidth, $dataWidth) + 10}]
```

## Spacing für Typographie

Die Spacing-Optionen (`-spacing1`, `-spacing2`, `-spacing3`) ermöglichen
professionelle Typographie mit Abstaenden zwischen Bloecken,
ohne kuenstliche Leerzeilen einzufügen.

### Die drei Spacing-Werte

```tcl
# -spacing1: Abstand UEBER der ersten Zeile eines Absatzes
# -spacing2: Abstand ZWISCHEN umgebrochenen Zeilen (Zeilenabstand)
# -spacing3: Abstand UNTER der letzten Zeile eines Absatzes

.t tag configure h1 \
    -font vH1 \
    -spacing1 20 \
    -spacing3 10
# 20px Abstand vor der Überschrift, 10px danach

.t tag configure paragraph \
    -spacing1 0 \
    -spacing3 8
# 8px Abstand nach jedem Absatz
```

### Headings mit Spacing statt Leerzeilen

```tcl
# VORHER: Leerzeilen für Abstand (ungenau, nicht skalierbar)
.t insert end "\n"
.t insert end "Überschrift" h1
.t insert end "\n\n"

# NACHHER: Spacing-Tags (praezise, skalierbar)
.t tag configure h1 -font vH1 -spacing1 18 -spacing3 8
.t tag configure h2 -font vH2 -spacing1 14 -spacing3 6

.t insert end "Überschrift" h1
.t insert end "\n"
.t insert end "Unter-Überschrift" h2
.t insert end "\n"
# Abstände werden automatisch gerendert
```

### Spacing und Tag-Bereiche

**Wichtig:** Spacing wirkt nur wenn der Tag das Newline-Zeichen
am Zeilenende einschliesst. Das steht im Widerspruch zur
Background-Regel (Newline ohne Tag):

```tcl
# Spacing funktioniert:
.t insert end "Text\n" myTag
# -> spacing1/spacing3 werden angewendet

# Spacing funktioniert NICHT:
.t insert end "Text" myTag
.t insert end "\n"
# -> Newline hat keinen Tag, spacing wird ignoriert

# Kompromiss bei Tags mit Background:
# Separaten Spacing-Tag verwenden
.t tag configure h1_space -spacing1 20 -spacing3 10
.t tag configure h1_style -font vH1 -background #e0e0ff

.t insert end "Überschrift" h1_style
.t insert end "\n" h1_space
```

## Das Margin-Background-Problem

Ein häufiger Stolperstein: Tk rendert den Tag-Hintergrund
**inklusive** der Margins.

### Das Problem

```tcl
# FALSCH: Hintergrund erstreckt sich in den Margin-Bereich
.t tag configure header \
    -background #d0e0f0 \
    -lmargin1 30 -lmargin2 30
# Der blaue Hintergrund beginnt am linken Fensterrand,
# nicht am Textanfang!
```

### Warum?

Tk zeichnet den Hintergrund für den gesamten Bereich, den
der Tag beansprucht -- und Margins gehören zum Tag-Bereich.
Das führt zu farbigen Raendern, die meist ungewollt sind.

### Lösungen

**Option 1:** Keine Margins in Tags mit Hintergrund verwenden

```tcl
.t tag configure header -background #d0e0f0
# Margin getrennt oder per Leerzeichen
```

**Option 2:** Einrueckung durch Leerzeichen simulieren

```tcl
set indent "    "
.t insert end "${indent}Header-Text" header
```

**Option 3:** Separaten Margin-Tag ohne Hintergrund verwenden

```tcl
.t tag configure header_bg -background #d0e0f0
.t tag configure header_indent -lmargin1 30 -lmargin2 30

.t insert end "Header-Text" {header_bg header_indent}
# Hintergrund nur im Textbereich, Margin ist transparent
```

## Newlines richtig behandeln

### Das Problem

```tcl
# FALSCH: Hintergrund geht bis zum rechten Fensterrand
.t insert end "Header-Text\n" header
```

Wenn ein Newline-Zeichen den Tag traegt, erstreckt sich
der Hintergrund über die gesamte Zeile bis zum rechten Rand.

### Die Lösung

Newlines **ohne** Tag einfügen:

```tcl
# RICHTIG: Hintergrund endet am Textende
.t insert end "Header-Text" header
.t insert end "\n"
```

Konsequent angewendet:

```tcl
proc insertTaggedLine {widget text tag} {
    $widget insert end $text $tag
    $widget insert end "\n"
}

insertTaggedLine .t "Überschrift" h1
insertTaggedLine .t "Normaler Text" {}
```

## Tag-Prioritäten

Wenn sich Tags überlappen, bestimmt die Priorität,
welche Eigenschaften gewinnen.

### Standard-Priorität

Die Priorität entspricht der Reihenfolge, in der Tags
konfiguriert wurden -- später konfigurierte Tags haben
hoehere Priorität:

```tcl
.t insert end "Test"
.t tag add tag1 1.0 1.4
.t tag add tag2 1.2 1.4

.t tag configure tag1 -foreground red
.t tag configure tag2 -foreground blue

# "Te" ist rot (nur tag1)
# "st" hat beide Tags -- blau gewinnt (tag2 ist neuer)
```

### Prioritäten explizit setzen

```tcl
.t tag raise tag1       ;# tag1 nach oben (hoechste Priorität)
.t tag lower tag2       ;# tag2 nach unten (niedrigste Priorität)

.t tag raise tag1 tag2  ;# tag1 direkt über tag2
```

### Empfohlene Prioritätsreihenfolge

Für komplexe Anwendungen (z.B. Markdown-Viewer, Code-Editor)
empfiehlt sich eine feste Prioritaetshierarchie:

```tcl
proc setupTagPriority {w} {
    # Niedrigste Priorität (Basis-Formatierung)
    $w tag lower blockquote
    $w tag lower list

    # Mittlere Priorität (Inline-Formatierung)
    $w tag raise bold
    $w tag raise italic
    $w tag raise code

    # Hoechste Priorität (immer sichtbar)
    $w tag raise link
    $w tag raise sel      ;# Selektion immer oben
}
```

### Erstellungsreihenfolge statt raise/lower

Bei Megawidgets mit vielen Tags (Tablelist hat 11+) ist es
zuverlässiger, die Tags in der gewünschten Prioritätsreihenfolge
zu *erstellen*, statt nachträglich mit raise/lower zu korrigieren:

```tcl
# Tablelist-Pattern: Tags in Prioritätsreihenfolge erstellen
# Später erstellt = hoehere Priorität

# Niedrig: Hintergrund-Tags
$t tag configure itembg   -background ""
$t tag configure stripe   -background ""

# Mittel: Interaktions-Tags
$t tag configure select   -relief raised
$t tag configure curRow   -borderwidth 1
$t tag configure active   -borderwidth ""
$t tag configure disabled -foreground ""

# Hoch: Struktur-Tags
$t tag configure hiddenRow -elide 1
$t tag configure elidedRow -elide 1
$t tag configure hiddenCol -elide 1
$t tag configure elidedCol -elide 1

# Kommentar aus Tablelist-Quellcode:
# "DO NOT CHANGE the order of creation of these tags!"
```

**Vorteil:** Keine nachträglichen raise/lower-Aufrufe nötig.
Weniger Fehlerquellen wenn neue Tags hinzukommen.

### sel-Tag vermeiden (Windows-Plattform-Problem)

Tablelist verwendet den eingebauten `sel`-Tag NICHT, weil er auf
Windows nur sichtbar ist wenn das Widget den Fokus hat:

```tcl
# PROBLEM auf Windows:
# $t tag add sel 1.0 1.10
# -> Selektion verschwindet wenn anderes Widget Fokus bekommt

# TABLELIST-LOESUNG: Eigener select-Tag
$t tag configure mySelect -background #0078d7 -foreground white

proc selectRange {t from to} {
    $t tag remove mySelect 1.0 end
    $t tag add mySelect $from $to
}
```

Der eigene Tag hat keine der Sonderregeln des `sel`-Tags:
- Sichtbar ohne Fokus
- Volle Kontrolle über `tag configure`
- Kein Einfluss auf System-Clipboard
- Identisches Verhalten auf allen Plattformen

## Interaktive Tags: Links

### Naiver Ansatz (fehlerhaft)

```tcl
# FALSCH: Index-basiert -- nur Klick auf erstes Zeichen funktioniert
set links(1.5) "https://example.com"
.t tag bind link <Button-1> {
    set idx [%W index @%x,%y]
    if {[info exists links($idx)]} { ... }
}
```

### Robuster Ansatz: Zwei-Tag-System

Die bewährte Technik trennt Styling-Tags (wiederverwendbar)
von Zuordnungs-Tags (eindeutig pro Link):

```tcl
namespace eval ::textlinks {
    variable counter 0
    variable urls
    array set urls {}
}

proc ::textlinks::add {widget start end url} {
    variable counter
    variable urls

    # Eindeutigen Zuordnungs-Tag erzeugen
    set linkTag "hv_link_[incr counter]"

    # Styling-Tag (gemeinsam für alle Links)
    $widget tag add link $start $end

    # Zuordnungs-Tag (eindeutig für diesen Link)
    $widget tag add $linkTag $start $end

    # URL speichern
    set urls($linkTag) $url

    # Klick-Binding auf den Zuordnungs-Tag
    $widget tag bind $linkTag <Button-1> \
        [list ::textlinks::click $linkTag]
}

proc ::textlinks::click {linkTag} {
    variable urls
    if {[info exists urls($linkTag)]} {
        puts "Oeffne: $urls($linkTag)"
        # exec xdg-open $urls($linkTag) &
    }
}
```

### Hover-Effekt

Hover wird auf den gemeinsamen Styling-Tag gebunden,
damit er für alle Links gilt:

```tcl
proc ::textlinks::setupStyle {widget} {
    $widget tag configure link \
        -foreground blue \
        -underline 1

    $widget tag bind link <Enter> {
        %W configure -cursor hand2
    }

    $widget tag bind link <Leave> {
        %W configure -cursor {}
    }
}
```

### Tags an einer Position finden

Um bei einem Klick den richtigen Link zu identifizieren:

```tcl
proc ::textlinks::handleClick {widget x y} {
    set index [$widget index @$x,$y]
    set tags [$widget tag names $index]

    foreach tag $tags {
        if {[string match "hv_link_*" $tag]} {
            variable urls
            if {[info exists urls($tag)]} {
                puts "URL: $urls($tag)"
                break
            }
        }
    }
}
```

## Elide: Text verstecken

Mit `-elide 1` kann Text unsichtbar gemacht werden,
ohne ihn zu löschen. Das ist nützlich für
Code-Folding, Spoiler-Texte oder Filter:

```tcl
# Tag für versteckten Text
.t tag configure hidden -elide 1

# Text verstecken
.t tag add hidden 3.0 5.0

# Text wieder anzeigen
.t tag remove hidden 3.0 5.0
```

### Code-Folding Beispiel

```tcl
proc toggleFold {widget tag} {
    set config [$widget tag cget $tag -elide]
    if {$config} {
        $widget tag configure $tag -elide 0
    } else {
        $widget tag configure $tag -elide 1
    }
}

# Faltbarer Bereich
.t insert end "▼ Details\n" {fold_header}
.t insert end "Hier stehen Details...\n" {fold_body_1}
.t insert end "Noch mehr Details...\n" {fold_body_1}

.t tag bind fold_header <Button-1> \
    [list toggleFold .t fold_body_1]
```

### Mehrere Elide-Tags für verschiedene Zwecke

Ein einzelner Elide-Tag reicht selten. Wenn Text aus verschiedenen
Gruenden versteckt werden kann (Filter, Folding, Sichtbarkeit),
braucht jeder Grund einen eigenen Tag. Sonst ist unabhängige
Steuerung unmöglich.

Tablelist nutzt 5 separate Elide-Tags:

```tcl
$t tag configure hiddenRow -elide 1   ;# User versteckt Zeile explizit
$t tag configure elidedRow -elide 1   ;# Baum-Knoten eingeklappt
$t tag configure hiddenCol -elide 1   ;# User versteckt Spalte
$t tag configure elidedCol -elide 1   ;# Horizontales Scrolling
$t tag configure elidedWin -elide 1   ;# Widget temporär versteckt
```

**Warum das wichtig ist:**

```tcl
# FALSCH: Ein Tag für alles
$t tag configure hidden -elide 1
$t tag add hidden 3.0 3.end    ;# User versteckt Zeile
$t tag add hidden 5.0 5.end    ;# Baum eingeklappt

# Baum aufklappen -> ALLE versteckten Zeilen werden sichtbar!
$t tag remove hidden 5.0 5.end  ;# Zeile 3 bleibt versteckt...
# ...aber was wenn Zeile 3 auch im Baum war? Kein Unterschied möglich!

# RICHTIG: Eigener Tag pro Grund
$t tag add userHidden 3.0 3.end  ;# User-Aktion
$t tag add treeElided 5.0 5.end  ;# Baum-Aktion

# Baum aufklappen -> nur treeElided entfernen
$t tag remove treeElided 5.0 5.end
# userHidden bleibt unberuehrt!
```

**Elide-Kombination:** Wenn ein Textbereich mehrere Elide-Tags
hat, reicht es wenn *einer* davon `-elide 1` hat -- der Text
bleibt versteckt. Erst wenn ALLE Elide-Tags entfernt sind,
wird der Text sichtbar.

### search -elide: In verstecktem Text suchen

```tcl
# Standard: search ignoriert elidierte Bereiche
set pos [$t search "Suchtext" 1.0]

# Mit -elide: auch in verstecktem Text suchen
set pos [$t search -elide "Suchtext" 1.0]

# Tablelist nutzt das um Tab-Trennzeichen in
# versteckten Spalten zu finden:
set tabPos [$t search -elide "\t" $lineStart $lineEnd]
```

## Eingebettete Widgets und Bilder

Das Text-Widget kann nicht nur Text, sondern auch
Widgets und Bilder enthalten:

### Widgets einbetten

```tcl
ttk::button .t.btn -text "Klick mich" \
    -command {puts "Geklickt!"}
.t window create end -window .t.btn

ttk::entry .t.entry -width 20
.t window create end -window .t.entry -padx 5
```

### Bilder einbetten

```tcl
image create photo myimg -file "logo.png"
.t image create end -image myimg -padx 5 -pady 2
```

## Performance

### Sequential Insertion (empfohlen)

Tags direkt beim Einfügen zuweisen statt nachträglich:

```tcl
# LANGSAM: Einfügen, dann Tags zuweisen
foreach line $lines {
    set start [.t index end]
    .t insert end "$line\n"
    set end [.t index end]
    .t tag add highlight $start $end
}

# SCHNELL: Tag direkt beim Einfügen
foreach line $lines {
    .t insert end "$line\n" highlight
}
```

### Bulk-Operationen mit deaktiviertem Rendering

Bei grossen Textmengen das Widget während der
Änderungen deaktivieren:

```tcl
proc bulkInsert {widget lines} {
    $widget configure -state disabled
    # Änderungen vorbereiten...
    $widget configure -state normal

    foreach line $lines {
        $widget insert end "$line\n" body
    }
}
```

### Tag-Abfrage optimieren

```tcl
# LANGSAM: Alle Tags für jeden Index prüfen
for {set i 1} {$i <= $lineCount} {incr i} {
    set tags [.t tag names $i.0]
    # ...
}

# SCHNELL: Tag-Bereiche direkt abfragen
set ranges [.t tag ranges highlight]
# -> {1.0 3.0 5.0 7.0} (Start/End-Paare)
foreach {start end} $ranges {
    # Alle highlight-Bereiche
}
```

## Tag-Debugging mit dump

Der `dump`-Befehl ist das wichtigste Debugging-Werkzeug für Tags.
Er zeigt exakt welche Tags wo beginnen und enden.

### Alle Tag-Informationen anzeigen

```tcl
$t dump -tag 1.0 end
```

Gibt eine Liste von Tripeln zurück:
`tagon tagName index ... tagoff tagName index`

```tcl
# Beispiel-Output:
# tagon bold 1.0
# tagon h1 1.0
# tagoff bold 1.5
# tagon link 1.8
# tagoff h1 1.12
# tagoff link 1.15
```

### dump mit Callback für Analyse

```tcl
proc analyzeTag {key value index} {
    switch $key {
        tagon  { puts "  +$value bei $index" }
        tagoff { puts "  -$value bei $index" }
        text   { puts "  TEXT: [string range $value 0 30]..." }
    }
}

# Alle Infos mit Callback
.t dump -all -command analyzeTag 1.0 end
```

### Praxis: Tag-Overlap finden

```tcl
proc findOverlaps {t tag1 tag2} {
    # Findet Stellen wo sich zwei Tags überlappen
    set ranges1 [$t tag ranges $tag1]
    set ranges2 [$t tag ranges $tag2]
    
    set overlaps {}
    foreach {s1 e1} $ranges1 {
        foreach {s2 e2} $ranges2 {
            if {[$t compare $s1 < $e2] && [$t compare $s2 < $e1]} {
                set oStart [expr {[$t compare $s1 > $s2] ? $s1 : $s2}]
                set oEnd   [expr {[$t compare $e1 < $e2] ? $e1 : $e2}]
                lappend overlaps $oStart $oEnd
            }
        }
    }
    return $overlaps
}

set overlaps [findOverlaps .t bold italic]
puts "Bold+Italic Überlappungen: $overlaps"
```

### Praxis: Tag-Statistik

```tcl
proc tagStats {t} {
    puts "=== Tag-Statistik ==="
    foreach tag [$t tag names] {
        set ranges [$t tag ranges $tag]
        set count [expr {[llength $ranges] / 2}]
        if {$count > 0} {
            puts [format "  %-20s %d Bereiche" $tag $count]
        }
    }
}

tagStats .t
# Output:
#   bold                 12 Bereiche
#   italic                5 Bereiche
#   link                  8 Bereiche
#   code                  3 Bereiche
```

## Tag-Lifecycle und Cleanup

Tags die einmal konfiguriert wurden, bleiben bestehen bis
sie explizit gelöscht werden. Bei dynamischen Anwendungen
(z.B. Markdown-Viewer der Inhalt neu rendert) ist
sorgfältiges Cleanup wichtig.

### Problem: Tag-Akkumulation

```tcl
# Bei jedem Render werden neue Link-Tags erzeugt
# link1, link2, link3, ... link1000, link1001, ...
# Diese werden nie gelöscht!

proc renderDocument {t content} {
    $t delete 1.0 end
    # Aber: alte link-Tags existieren noch mit Bindings!
    foreach link $links {
        set tag "link[incr counter]"
        $t tag add $tag ...
        $t tag bind $tag <Button-1> ...
    }
}
```

### Lösung: Dynamische Tags aufräumen

```tcl
namespace eval ::viewer {
    variable linkCounter 0
    
    proc clearLinks {t} {
        variable linkCounter
        for {set i 1} {$i <= $linkCounter} {incr i} {
            set tag "link$i"
            # Bindings entfernen
            catch {$t tag bind $tag <Button-1> {}}
            catch {$t tag bind $tag <Enter> {}}
            catch {$t tag bind $tag <Leave> {}}
            # Tag löschen (inkl. Konfiguration)
            catch {$t tag delete $tag}
        }
        set linkCounter 0
    }
    
    proc render {t content} {
        clearLinks $t
        $t delete 1.0 end
        # ... neuer Inhalt ...
    }
}
```

### Statische vs. dynamische Tags

Gutes Muster: Tags in zwei Kategorien teilen:

```tcl
# STATISCHE Tags (einmal konfiguriert, nie gelöscht)
# - Formatierung: bold, italic, code, h1, h2, ...
# - Layout: quote, listitem, ...
# - Styling: link (Aussehen), highlight

# DYNAMISCHE Tags (pro Render-Zyklus neu)
# - Zuordnung: link1, link2, ... (URL pro Link)
# - Temporaer: _searchMatch, _currentLine

# Beim Re-Render: nur dynamische Tags löschen,
# statische Tags bleiben konfiguriert
```

## Praxis: Tag-Architektur für Dokument-Viewer

Für komplexe Anwendungen wie Markdown-Viewer oder Code-Editoren
bewährt sich eine geschichtete Tag-Architektur.

### Schicht 1: Block-Tags (niedrigste Priorität)

```tcl
# Steuern Margins, Spacing und Block-Hintergrund
.t tag configure quote    -lmargin1 20 -lmargin2 20 -foreground #555
.t tag configure codeblock -font vMono -background #f0f0f0
.t tag configure listitem  -lmargin1 15 -lmargin2 30
.t tag configure defterm   -font vBold
.t tag configure defdef    -lmargin1 30 -lmargin2 30
```

### Schicht 2: Inline-Tags (mittlere Priorität)

```tcl
# Steuern Schrift und Farbe innerhalb von Bloecken
.t tag configure strong     -font vBold
.t tag configure em         -font vItalic
.t tag configure codeinline -font vMono -background #e8e8e8
.t tag configure strike     -overstrike 1
```

### Schicht 3: Kontext-Tags (erhoehte Priorität)

In manchen Block-Kontexten müssen Inline-Tags anders aussehen.
Beispiel: Bold in einem Blockquote (das italic ist) braucht bold+italic:

```tcl
# Blockquote-Kontext: Basis ist italic
.t tag configure quote    -font vItalic
.t tag configure strong_q -font vBoldItalic  ;# bold + italic

# Tabellen-Kontext: Basis ist Monospace
set monoFamily [font actual TkFixedFont -family]
.t tag configure tablecell  -font vMono
.t tag configure strong_t   -font [list -family $monoFamily \
    -size 10 -weight bold]

# Beim Rendern: Kontext-Tag statt normalen Tag verwenden
if {$insideBlockquote} {
    $t insert end $boldText strong_q   ;# statt strong
} else {
    $t insert end $boldText strong
}
```

### Schicht 4: Interaktions-Tags (hoechste Priorität)

```tcl
# Link-Styling (statisch)
.t tag configure link -foreground blue -underline 0

# Link-Zuordnung (dynamisch, pro Link eindeutig)
# link1, link2, ... mit individuellem Klick-Binding

# Selektion immer ganz oben
.t tag raise sel
```

### Prioritäten setzen

```tcl
proc setupPriority {t} {
    # Block-Tags unten
    $t tag lower quote
    $t tag lower codeblock
    $t tag lower listitem
    
    # Inline-Tags darüber
    $t tag raise strong
    $t tag raise em
    $t tag raise codeinline
    
    # Kontext-Tags über ihren Block-Tags
    $t tag raise strong_q quote
    $t tag raise strong_t tablecell
    
    # Interaktions-Tags oben
    $t tag raise link
    $t tag raise sel
}
```

### Marks als Rendering-Helfer

Marks sind nützlich um beim sequentiellen Rendering
den Anfang eines Bereichs zu merken, auf den später
ein Tag angewendet wird:

```tcl
# Mark setzen wo der Block beginnt
$t mark set _blockStart end

# Inhalt einfügen
$t insert end "Zeile 1\n"
$t insert end "Zeile 2\n"
$t insert end "Zeile 3\n"

# Tag auf den gesamten Block anwenden
$t tag add codeblock _blockStart end

# Mark aufgrund der default gravity (right):
# _blockStart bleibt am Anfang des eingefügten Texts
```

## Tag-Verwaltung

### Alle Tags auflisten

```tcl
.t tag names             ;# Alle definierten Tags
.t tag names 1.5         ;# Tags an Position 1.5
```

### Tag-Bereiche abfragen

```tcl
.t tag ranges bold       ;# -> {1.0 1.5 3.2 3.8}
.t tag prevrange bold 2.0 ;# Vorheriger bold-Bereich vor 2.0
.t tag nextrange bold 1.0 ;# Nächster bold-Bereich nach 1.0
```

### Tags entfernen

```tcl
.t tag remove bold 1.0 1.5  ;# Tag von Bereich entfernen
.t tag delete bold           ;# Tag komplett löschen (inkl. Config)
```

### Tag-Konfiguration abfragen

```tcl
.t tag cget bold -foreground    ;# Einzelne Eigenschaft
.t tag configure bold           ;# Alle Eigenschaften
```

## Häufige Fehler

### Tag konfiguriert, aber nicht zugewiesen

```tcl
# FALSCH: Tag hat Eigenschaften, ist aber nirgends angewandt
.t tag configure important -foreground red -font {Arial 14 bold}
.t insert end "Wichtiger Text"
# Text ist normal -- "important" wurde nie zugewiesen!

# RICHTIG:
.t insert end "Wichtiger Text" important
```

### Tag-Bindings auf falschem Tag

```tcl
# FALSCH: Binding auf Styling-Tag -- alle Links reagieren gleich
.t tag bind link <Button-1> {openUrl "https://example.com"}

# RICHTIG: Binding auf eindeutigen Zuordnungs-Tag
.t tag bind hv_link_1 <Button-1> {openUrl "https://example.com"}
.t tag bind hv_link_2 <Button-1> {openUrl "https://other.com"}
```

### Newline mit Tag

```tcl
# FALSCH: Hintergrund über gesamte Zeile
.t insert end "Header\n" {header bg_blue}

# RICHTIG: Newline ohne Tag
.t insert end "Header" {header bg_blue}
.t insert end "\n"
```

### Index nach Einfuegung veraltet

```tcl
# FALSCH: Index stimmt nach insert nicht mehr
set start [.t index end]
.t insert 1.0 "Neuer Text\n"
.t tag add bold $start end  ;# start zeigt auf falschen Bereich!

# RICHTIG: Mark verwenden oder Index nach insert neu berechnen
.t mark set myStart end
.t insert 1.0 "Neuer Text\n"
.t tag add bold myStart end
```


### Tag-Bereich leer nach Insert (end vs. end-1c)

```tcl
# FALSCH: start und end zeigen auf dieselbe Position
set start [$t index end]
$t insert end "Link-Text"
set end [$t index end]
$t tag add link $start $end   ;# start >= end -- nichts hinzugefügt!
```

Das implizite Newline am Ende des Text-Widgets liegt NACH `end`.
Nach dem Insert verschiebt sich das Newline -- `start` und `end`
können gleich sein oder `start > end`.
`tag add` fügt dann stillschweigend keinen Bereich hinzu.
Das Binding existiert, ist aber unerreichbar (leere Ranges).

**Symptom:** Links sind blau und unterstrichen, Klicks haben keine Wirkung.
`$t tag ranges link1` gibt leer zurück.

```tcl
# RICHTIG: "end -1 chars" zeigt auf letztes echtes Zeichen
set start [$t index "end -1 chars"]
$t insert end "Link-Text"
set end [$t index "end -1 chars"]
$t tag add link $start $end   ;# korrekte Ranges
$t tag bind link <Button-1> {handleClick}
```

Diese Regel gilt für alle Tags die auf frisch eingefügten Inhalt
gesetzt werden: `link`, `pdflink`, `strong`, `em`, `code` etc.
Beim sequentiellen Rendering immer `"end -1 chars"` verwenden.

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `tag add name start end` | Tag auf Bereich anwenden |
| `tag remove name start end` | Tag von Bereich entfernen |
| `tag delete name` | Tag komplett löschen |
| `tag configure name -opt val` | Tag-Eigenschaften setzen |
| `tag cget name -opt` | Eigenschaft abfragen |
| `tag names ?index?` | Tags auflisten (an Position) |
| `tag ranges name` | Alle Bereiche eines Tags |
| `tag nextrange name start` | Nächster Bereich ab Position |
| `tag prevrange name start` | Vorheriger Bereich vor Position |
| `tag raise name` | Priorität erhoehen |
| `tag lower name` | Priorität verringern |
| `tag bind name event script` | Event-Binding an Tag |
| `insert end text tagList` | Text mit Tags einfügen |
| `mark set name index` | Stabile Position setzen |
| `mark gravity name dir` | Mark-Verhalten bei Insert |
| `window create index -window w` | Widget einbetten |
| `image create index -image img` | Bild einbetten |
| `dump -tag start end` | Tag-Bereiche debuggen |
| `dump -all -command proc start end` | Vollständiger Inhalt mit Callback |
| `font create name -family f -size s` | Named Font erstellen |
| `font configure name -size s` | Named Font ändern (Tags folgen) |
| `font actual name -family` | Tatsächliche Font-Eigenschaft |
| `font measure name string` | Textbreite in Pixeln |
| `bbox index` | Pixel-Position eines Zeichens |
| `dlineinfo index` | Pixel-Info einer Display-Zeile |

### Kernregeln

| Regel | Grund |
|:------|:------|
| Newlines ohne Tag einfügen | Verhindert Hintergrund über gesamte Zeile |
| Margins nicht mit Background kombinieren | Margin-Bereich wird mitgefärbt |
| Zwei-Tag-System für Links | Styling getrennt von Zuordnung |
| Tags beim Einfügen zuweisen | Schneller als nachträgliches `tag add` |
| Marks statt gespeicherter Indizes | Indizes verschieben sich bei insert |
| `tag raise sel` | Selektion immer sichtbar halten |
| Named Fonts statt Listen-Format | Vermeidet Font-Ambiguität bei Familien mit Leerzeichen |
| Kontext-Tags für verschachtelte Stile | Bold+Italic braucht eigenen Combined-Font |
| Dynamische Tags beim Re-Render löschen | Verhindert Tag-Akkumulation und Memory-Leaks |
| Spacing statt Leerzeilen | Praezise, skalierbare Abstände zwischen Bloecken |
| dump für Debugging | Zeigt exakt welche Tags wo beginnen/enden |
| Tags in Prioritätsreihenfolge erstellen | Zuverlaessiger als nachträgliches raise/lower |
| Eigener Select-Tag statt sel | Vermeidet Windows-Fokus-Problem |
| Separater Elide-Tag pro Versteck-Grund | Ermoeglicht unabhängige Steuerung |
| font "Courier -1" für unsichtbaren Strukturtext | Alternative zu elide wenn Text findbar bleiben soll |

## Sub- und Superscript mit offset

Die `-offset`-Eigenschaft verschiebt Text vertikal.
Positiv = nach oben, negativ = nach unten:

```tcl
.t tag configure superscript -offset 6  -font {TkDefaultFont 8}
.t tag configure subscript   -offset -3 -font {TkDefaultFont 8}

.t insert end "H"
.t insert end "2" subscript
.t insert end "O"
.t insert end "  E=mc"
.t insert end "2" superscript
```

Mit Named Fonts:

```tcl
font create smallFont -family [font actual TkDefaultFont -family] -size 8
.t tag configure sup -offset 6 -font smallFont
.t tag configure sub -offset -3 -font smallFont
```

**Hinweis:** `-offset` wird in Pixeln angegeben und skaliert nicht
automatisch mit der Schriftgröße. Bei dynamischen Font-Größen
muss der Offset manuell angepasst werden:

```tcl
proc updateSubSuperOffset {baseSize} {
    set offset [expr {int($baseSize * 0.5)}]
    .t tag configure sup -offset $offset
    .t tag configure sub -offset [expr {-$offset / 2}]
    font configure smallFont -size [expr {int($baseSize * 0.75)}]
}
```

## Siehe auch

- [Geometry Manager](geometry-manager.md) -- pack, grid, place für Widget-Layout
- [Trace](trace.md) -- Variable-Traces für Widget-Synchronisation
- [TclOO](tcloo.md) -- Widgets als Objekte kapseln
- [Fehlerbehandlung](error-handling.md) -- bgerror für GUI-Fehler
- [Namespace](namespace.md) -- Tag-Verwaltung in Namespaces organisieren
