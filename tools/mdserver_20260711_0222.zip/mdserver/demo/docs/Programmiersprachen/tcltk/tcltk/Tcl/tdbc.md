# TDBC -- Tcl Database Connectivity

*Stand: 2026-04-29*

TDBC ist die standardisierte Datenbankschnittstelle für Tcl, vergleichbar
mit JDBC (Java) oder PDO (PHP). Eine einheitliche API für verschiedene
Datenbanken: SQLite, PostgreSQL, MySQL/MariaDB und ODBC.

## Geschichte

TDBC 1.0 wurde von Kevin B. Kenny entwickelt und mit Tcl 8.6
ausgeliefert. Vor TDBC gab es nur datenbank-spezifische Extensions
mit unterschiedlichen APIs: tclodbc (ODBC), oratcl (Oracle), pgtcl
(PostgreSQL), DIO (Apache Rivet), nstcl/nsdbi (AOL Server). TDBC
schaffte erstmals eine einheitliche Schnittstelle.

TDBC besteht aus zwei Schichten:

- **Obere Schicht:** Die Anwendungs-API (dieses Dokument) -- drei
  TclOO-Klassen: `tdbc::connection`, `tdbc::statement` und
  `tdbc::resultset`.
- **Untere Schicht:** Treiber für spezifische Datenbanken. Die
  TDBC-Dokumentation definiert auch eine Schnittstelle zum Schreiben
  eigener Treiber.

## Unterstuetzte Treiber

| Paket              | Datenbank       | Enthalten in Tcl |
|--------------------|-----------------|-------------------|
| `tdbc::sqlite3`    | SQLite          | Ja (Core)         |
| `tdbc::postgres`   | PostgreSQL      | Ja (Core)         |
| `tdbc::odbc`       | ODBC-Treiber    | Ja (Core)         |
| `tdbc::mysql`      | MySQL/MariaDB   | Separat            |

**Hinweis:** Für Oracle wird oratcl direkt verwendet, nicht tdbc::oratcl
(siehe Abschnitt "Oracle mit oratcl" am Ende).

## Verbindung herstellen

### SQLite

```tcl
package require tdbc::sqlite3

# Datei-Datenbank
set db [tdbc::sqlite3::connection new "app.db"]

# In-Memory-Datenbank
set db [tdbc::sqlite3::connection new ":memory:"]

# Mit create (benanntes Objekt)
tdbc::sqlite3::connection create db "app.db"

# Mit Optionen
set db [tdbc::sqlite3::connection new "app.db" \
    -readonly 0 \
    -timeout 5000]
```

### MySQL

```tcl
package require tdbc::mysql

set db [tdbc::mysql::connection new \
    -host localhost \
    -port 3306 \
    -user appuser \
    -password secret \
    -database myapp]
```

Verfügbare MySQL-Optionen:

| Option          | Beschreibung                                    |
|-----------------|-------------------------------------------------|
| `-host`         | Hostname des DB-Servers (Standard: localhost)    |
| `-port`         | TCP/IP-Port                                     |
| `-socket`       | Unix-Socket oder Named Pipe                     |
| `-user`         | Benutzername (Standard: aktueller User)         |
| `-password`     | Passwort                                        |
| `-database`     | Standard-Datenbank (auch `-db`)                 |
| `-interactive`  | true: Timeout für interaktive Nutzer           |
| `-ssl_ca`       | Datei mit vertrauenswuerdigen CAs               |
| `-ssl_capath`   | Verzeichnis mit CA-Zertifikaten                 |
| `-ssl_cert`     | Client-Zertifikat                               |
| `-ssl_key`      | Client Private Key                              |
| `-ssl_cipher`   | Erlaubte Ciphers (Doppelpunkt-getrennt)         |

### PostgreSQL

```tcl
package require tdbc::postgres

set db [tdbc::postgres::connection new \
    -host localhost \
    -port 5432 \
    -database myapp \
    -user appuser \
    -password secret]
```

Verfügbare PostgreSQL-Optionen:

| Option      | Beschreibung                                        |
|-------------|-----------------------------------------------------|
| `-host`     | Hostname des DB-Servers                             |
| `-hostaddr` | IP-Adresse (hat Vorrang vor `-host`)                |
| `-port`     | TCP/IP-Port                                         |
| `-user`     | Benutzername                                        |
| `-password` | Passwort (auch `-pw`)                               |
| `-database` | Datenbankname (auch `-db`)                          |
| `-options`  | Zusätzliche CLI-Optionen an Server                 |
| `-sslmode`  | `disable`, `allow`, `prefer` (Standard), `require`  |
| `-service`  | Service-Name aus pg_service.conf                    |

### ODBC

```tcl
package require tdbc::odbc

# Mit DSN
set db [tdbc::odbc::connection new "DSN=MyDatabase;UID=user;PWD=pass"]

# Direkte Verbindung
set db [tdbc::odbc::connection new \
    "DRIVER={SQL Server};SERVER=localhost;DATABASE=mydb;UID=user;PWD=pass"]
```

### Gemeinsame Verbindungsoptionen

Alle TDBC-Treiber verstehen diese Optionen:

| Option       | Beschreibung                                        |
|--------------|-----------------------------------------------------|
| `-encoding`  | Zeichenkodierung (einer der `encoding names` Werte) |
| `-isolation` | Transaktions-Isolationslevel (siehe unten)          |
| `-timeout`   | Timeout in Millisekunden (0 = kein Timeout)         |
| `-readonly`  | `1` = Datenbank nicht ändern                       |

Transaktions-Isolationslevel (von niedrig nach hoch):

| Level               | Dirty Reads | Non-Repeatable Reads | Phantom Reads |
|---------------------|:-----------:|:--------------------:|:-------------:|
| `readuncommitted`   | Ja          | Ja                   | Ja            |
| `readcommitted`     | Nein        | Ja                   | Ja            |
| `repeatableread`    | Nein        | Nein                 | Ja            |
| `serializable`      | Nein        | Nein                 | Nein          |

### Verbindung konfigurieren: configure

```tcl
# Aktuelle Konfiguration abfragen
$db configure
# -> -encoding utf-8 -isolation serializable -readonly 0 -timeout 0

# Option ändern
$db configure -timeout 5000
$db configure -isolation readcommitted
```

### new vs. create

```tcl
# new: Automatischer Name, Rückgabe ist Objekt-Handle
set db [tdbc::sqlite3::connection new "app.db"]
# db ist z.B. "::oo::Obj42"

# create: Expliziter Name, wird zum Befehl
tdbc::sqlite3::connection create mydb "app.db"
# Aufruf: mydb allrows {...}
```

Beide Varianten sind gleichwertig. `new` ist flexibler (Objekt in
Variable), `create` ist lesbarer bei festen Verbindungen.

### Verbindung schließen

```tcl
$db close
# oder bei create:
mydb close
```

## Abfragen ausführen

TDBC bietet drei Wege: Kurzform über Connection, Prepared Statements,
und ResultSet-Iteration.

### Kurzform: allrows

```tcl
# Alle Zeilen als Liste von Dicts (Standard)
set rows [$db allrows {SELECT * FROM users}]

# Explizit als Dicts
set rows [$db allrows -as dicts {SELECT * FROM users}]

# Als Liste von Listen (nur Werte, ohne Spaltennamen)
set rows [$db allrows -as lists {SELECT * FROM users}]

# Mit Parametern
set rows [$db allrows -as dicts {
    SELECT * FROM users WHERE active = :active
} [dict create active 1]]

# Ergebnis verarbeiten
foreach row $rows {
    puts "Name: [dict get $row name]"
}
```

### Kurzform: foreach

```tcl
# Direkt über Connection iterieren
$db foreach row {SELECT * FROM users ORDER BY name} {
    puts "[dict get $row id]: [dict get $row name]"
}

# Mit -as dicts (explizit)
$db foreach -as dicts row {SELECT * FROM users} {
    puts [dict get $row name]
}

# Mit Parametern
$db foreach -as dicts row {
    SELECT * FROM users WHERE city = :city
} [dict create city "Berlin"] {
    puts [dict get $row name]
}
```

### Kurzform: Einzelne Abfragen ohne Ergebnis

```tcl
# Schema-Setup, DDL-Befehle
$db allrows {
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
}

$db allrows {CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)}
```

## Prepared Statements

Prepared Statements sind der empfohlene Weg für alle Abfragen mit
Parametern -- sicher gegen SQL-Injection und effizienter bei
Wiederverwendung.

### Grundprinzip

```tcl
# 1. Statement vorbereiten (einmal)
set stmt [$db prepare {
    SELECT * FROM users WHERE id = :id
}]

# 2. Ausführen (beliebig oft)
set rs [$stmt execute [dict create id 42]]
set rows [$rs allrows -as dicts]
$rs close

# 3. Statement schließen (am Ende)
$stmt close
```

### Sicher: try/finally

```tcl
set stmt [$db prepare {
    INSERT INTO users (name, email) VALUES (:name, :email)
}]
try {
    $stmt execute [dict create name "Alice" email "alice@example.com"]
} finally {
    $stmt close
}
```

### Statement-Methoden

```tcl
set stmt [$db prepare {SELECT * FROM users WHERE active = :active}]

# execute: Gibt ResultSet zurück
set rs [$stmt execute [dict create active 1]]
$rs close

# allrows: Direkt alle Zeilen
set rows [$stmt allrows -as dicts [dict create active 1]]

# foreach: Direkt iterieren
$stmt foreach -as dicts row [dict create active 1] {
    puts [dict get $row name]
}

# params: Gebundene Variablen inspizieren
puts [$stmt params]
# -> active {type Tcl_Obj precision 0 scale 0 nullable 1 direction in}

$stmt close
```

### allrows und foreach auf drei Ebenen

Beide Convenience-Methoden existieren auf allen drei TDBC-Klassen.
Je höher die Ebene, desto weniger Boilerplate:

**ResultSet-Ebene** (feinste Kontrolle):

```tcl
set stmt [$db prepare {SELECT Name FROM Accounts WHERE Balance >= :amount}]
try {
    set rs [$stmt execute [dict create amount 200]]
    try {
        set rows [$rs allrows -as dicts]
    } finally {
        $rs close
    }
} finally {
    $stmt close
}
```

**Statement-Ebene** (kein ResultSet-Handling nötig):

```tcl
set stmt [$db prepare {SELECT Name FROM Accounts WHERE Balance >= :amount}]
try {
    set rows [$stmt allrows -as dicts [dict create amount 200]]
} finally {
    $stmt close
}
```

**Connection-Ebene** (kuerzeste Form, kein Statement/ResultSet nötig):

```tcl
set rows [$db allrows -as dicts {
    SELECT Name FROM Accounts WHERE Balance >= :amount
} [dict create amount 200]]
```

**Wann welche Ebene?**

| Ebene       | Vorteile                       | Nachteile                    |
|-------------|--------------------------------|------------------------------|
| Connection  | Kuerzester Code, auto Cleanup  | Kein Statement-Caching       |
| Statement   | Wiederverwendbar, effizient    | Statement manuell schließen |
| ResultSet   | Feinste Kontrolle, grosse Daten| Meister Boilerplate          |

### Bound-Variable-Konfiguration: paramtype

Die meisten Treiber erkennen den Typ automatisch. Falls nötig,
kann er explizit gesetzt werden:

```tcl
set stmt [$db prepare {
    SELECT * FROM accounts WHERE balance >= :amount
}]

# Typ konfigurieren: NAME ?DIRECTION? TYPE ?PRECISION? ?SCALE?
$stmt paramtype amount in double

# Konfiguration abfragen
puts [$stmt params]
# -> amount {type double precision 0 scale 0 nullable 1 direction in}

$stmt close
```

Directions: `in` (Standard), `out`, `inout` (für Stored Procedures).

### Statement wiederverwenden

```tcl
# Einmal vorbereiten, oft ausführen
set insertStmt [$db prepare {
    INSERT INTO logs (timestamp, level, message)
    VALUES (:ts, :level, :msg)
}]

try {
    foreach entry $logEntries {
        $insertStmt execute [dict create \
            ts    [clock format [clock seconds] -format "%Y-%m-%dT%H:%M:%S"] \
            level [dict get $entry level] \
            msg   [dict get $entry message]]
    }
} finally {
    $insertStmt close
}
```

## Parameter-Bindung

TDBC unterstützt drei Bindungs-Syntaxen:

| Syntax    | Quelle              | Empfohlen |
|-----------|----------------------|:---------:|
| `:name`   | Dict-Schlüssel      | Ja        |
| `$name`   | Tcl-Variable im Scope | Nein     |
| `@name`   | Array-Element        | Nein      |

### Empfohlen: Dict mit :name

```tcl
set stmt [$db prepare {
    SELECT * FROM users WHERE name = :name AND city = :city
}]

# Dict-Schlüssel OHNE Doppelpunkt!
$stmt allrows -as dicts [dict create name "Alice" city "Berlin"]

$stmt close
```

### Häufiger Fehler: Doppelpunkt im Dict

```tcl
# FALSCH: Key mit Doppelpunkt
$stmt execute [dict create :name "Alice"]
# -> Fehler oder leeres Ergebnis

# RICHTIG: Key ohne Doppelpunkt
$stmt execute [dict create name "Alice"]
```

### Typkonvertierung

TDBC ist strenger als die direkte sqlite3-API. Strings aus GUI-Widgets
(z.B. Tablelist) müssen ggf. konvertiert werden:

```tcl
# String aus Widget
set idStr [$tbl cellcget $row,0 -text]    ;# "42" (String)

# Explizit als Integer
set id [expr {int($idStr)}]

$stmt execute [dict create id $id]
```

## ResultSet

Der `execute`-Aufruf liefert ein ResultSet-Objekt mit mehreren
Abruf-Methoden:

### nextlist, nextdict, nextrow

```tcl
set rs [$stmt execute $params]

# Als Liste (Werte in Spaltenreihenfolge)
while {[$rs nextlist val]} {
    puts $val    ;# z.B. "Tom 100.0"
}

# Als Dict (Spaltenname -> Wert)
while {[$rs nextdict val]} {
    puts [dict get $val name]
}

# nextrow: Kombination mit -as Option
while {[$rs nextrow -as dicts row]} {
    puts [dict get $row name]
}
# oder:
while {[$rs nextrow -as lists row]} {
    puts [lindex $row 0]
}
```

Alle drei Methoden geben `1` zurück wenn eine Zeile gelesen wurde,
`0` wenn keine weiteren Zeilen vorhanden sind.

### Spalteninformationen

```tcl
set rs [$stmt execute $params]

# Spaltennamen
set cols [$rs columns]
# -> {id name email active created_at}

# Zeilenanzahl (nicht bei allen Treibern zuverlässig)
set count [$rs rowcount]

# IMMER schließen!
$rs close
```

### Alle Zeilen auf einmal

```tcl
# allrows auf ResultSet-Ebene
set rs [$stmt execute $params]
set rows [$rs allrows -as dicts]
$rs close

# -columnsvariable: Spaltennamen separat erhalten
set rs [$stmt execute $params]
set rows [$rs allrows -as lists -columnsvariable cols]
$rs close
puts "Spalten: $cols"
# -> Spalten: Name Balance
```

### Multiple Result Sets

Manche Datenbanken liefern mehrere Result Sets pro Statement.
Nach dem letzten `nextdict`/`nextlist` (Rückgabe 0) prüfen:

```tcl
set rs [$stmt execute]
# Erstes Result Set verarbeiten
while {[$rs nextdict row]} {
    # ...
}

# Weitere Result Sets?
if {[$rs nextresults]} {
    # Neues Result Set mit evtl. anderen Spalten
    while {[$rs nextdict row]} {
        # ...
    }
}
$rs close
```

### nextrow vs. allrows

| Methode   | Speicher         | Anwendung              |
|-----------|------------------|------------------------|
| `allrows` | Alle im Speicher | Kleine Ergebnismengen  |
| `nextrow` | Zeile für Zeile | Grosse Ergebnismengen  |

## NULL-Werte

TDBC hat ein spezielles NULL-Handling: Ist eine Spalte NULL, **fehlt
der Schlüssel im Dict**. Das ist der wichtigste Unterschied zu anderen
Datenbank-APIs:

```tcl
set rows [$db allrows {SELECT name, email FROM users WHERE id = 1}]
set row [lindex $rows 0]

# FALSCH: Crash wenn email NULL ist!
set email [dict get $row email]
# -> key "email" not known in dictionary

# RICHTIG: Existenz prüfen
if {[dict exists $row email]} {
    set email [dict get $row email]
} else {
    set email ""
}
```

### Hilfsfunktion: dictGet

```tcl
proc dictGet {d key {default ""}} {
    if {[dict exists $d $key]} {
        return [dict get $d $key]
    }
    return $default
}

# Verwendung
set email [dictGet $row email "keine@email.de"]
set phone [dictGet $row phone ""]
```

### NULL explizit setzen

```tcl
# In TDBC: Key weglassen = NULL
set stmt [$db prepare {
    INSERT INTO users (name, email) VALUES (:name, :email)
}]

# email wird NULL:
$stmt execute [dict create name "Bob"]

# email wird gesetzt:
$stmt execute [dict create name "Alice" email "alice@test.de"]
```

## Transaktionen

### Automatisch mit transaction

Die `transaction`-Methode committed bei Return-Code `ok`, `return`,
`break` oder `continue`. Bei allen anderen Return-Codes (insbesondere
Fehlern) wird automatisch ein Rollback ausgeführt:

```tcl
$db transaction {
    set stmt [$db prepare {
        INSERT INTO orders (user_id, product, amount)
        VALUES (:uid, :product, :amount)
    }]
    try {
        foreach item $orderItems {
            $stmt execute $item
        }
    } finally {
        $stmt close
    }
    # Automatischer COMMIT am Ende
    # Bei Fehler: automatischer ROLLBACK
}
```

### Manuell

```tcl
$db begintransaction
try {
    $db allrows {INSERT INTO accounts ...}
    $db allrows {UPDATE balances ...}
    $db commit
} on error {err} {
    $db rollback
    error "Transaktion fehlgeschlagen: $err"
}
```

### Performance: Bulk-Insert

```tcl
# LANGSAM: Jeder Insert ist eine eigene Transaktion
foreach user $users {
    $db allrows {INSERT INTO users (name) VALUES (:name)} \
        [dict create name $user]
}

# SCHNELL: Alles in einer Transaktion (100x schneller!)
$db transaction {
    set stmt [$db prepare {INSERT INTO users (name) VALUES (:name)}]
    try {
        foreach user $users {
            $stmt execute [dict create name $user]
        }
    } finally {
        $stmt close
    }
}
```

## CRUD-Pattern

Vollständiges Beispiel für Create, Read, Update, Delete:

```tcl
namespace eval ::userdb {
    variable db

    proc connect {filename} {
        variable db
        package require tdbc::sqlite3
        set db [tdbc::sqlite3::connection new $filename]

        # Schema erstellen
        $db allrows {
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        }

        # Foreign Keys aktivieren (SQLite)
        $db allrows {PRAGMA foreign_keys = ON}
    }

    proc create {name email} {
        variable db
        set stmt [$db prepare {
            INSERT INTO users (name, email)
            VALUES (:name, :email)
        }]
        try {
            $stmt execute [dict create name $name email $email]
        } finally {
            $stmt close
        }
    }

    proc get {id} {
        variable db
        set stmt [$db prepare {
            SELECT * FROM users WHERE id = :id
        }]
        try {
            set rows [$stmt allrows -as dicts [dict create id $id]]
        } finally {
            $stmt close
        }
        if {[llength $rows] == 0} {
            return ""
        }
        return [lindex $rows 0]
    }

    proc list {{activeOnly 1}} {
        variable db
        if {$activeOnly} {
            return [$db allrows -as dicts {
                SELECT * FROM users WHERE active = 1 ORDER BY name
            }]
        }
        return [$db allrows -as dicts {
            SELECT * FROM users ORDER BY name
        }]
    }

    proc update {id data} {
        variable db
        # Nur übergebene Felder aktualisieren
        set setClauses {}
        set params [dict create id $id]
        dict for {key value} $data {
            lappend setClauses "$key = :$key"
            dict set params $key $value
        }
        set sql "UPDATE users SET [join $setClauses {, }] WHERE id = :id"
        set stmt [$db prepare $sql]
        try {
            $stmt execute $params
        } finally {
            $stmt close
        }
    }

    proc delete {id} {
        variable db
        set stmt [$db prepare {DELETE FROM users WHERE id = :id}]
        try {
            $stmt execute [dict create id $id]
        } finally {
            $stmt close
        }
    }

    proc disconnect {} {
        variable db
        if {$db ne ""} {
            $db close
            set db ""
        }
    }
}

# Verwendung:
userdb::connect "app.db"
userdb::create "Alice" "alice@example.com"
userdb::create "Bob" "bob@example.com"

set alice [userdb::get 1]
puts "Name: [dict get $alice name]"

set all [userdb::list]
foreach u $all {
    puts "[dict get $u id]: [dict get $u name]"
}

userdb::update 1 {email newalice@example.com}
userdb::delete 2
userdb::disconnect
```

## Schema-Migration

### Versions-Tabelle

```tcl
proc initMigrations {db} {
    $db allrows {
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            applied_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    }
}

proc currentVersion {db} {
    set rows [$db allrows {
        SELECT COALESCE(MAX(version), 0) AS v FROM schema_migrations
    }]
    return [dict get [lindex $rows 0] v]
}

proc migrate {db targetVersion migrations} {
    set current [currentVersion $db]

    for {set v [expr {$current + 1}]} {$v <= $targetVersion} {incr v} {
        if {[dict exists $migrations $v]} {
            puts "Migration $v anwenden..."
            $db transaction {
                $db allrows [dict get $migrations $v]
                $db allrows {
                    INSERT INTO schema_migrations (version) VALUES (:v)
                } [dict create v $v]
            }
        }
    }
}
```

### Migrationen definieren

```tcl
set migrations {
    1 {
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        )
    }
    2 {
        ALTER TABLE users ADD COLUMN email TEXT
    }
    3 {
        CREATE INDEX idx_users_email ON users(email)
    }
    4 {
        ALTER TABLE users ADD COLUMN active INTEGER DEFAULT 1
    }
}

initMigrations $db
migrate $db 4 $migrations
```

## SQLite-spezifisch

### PRAGMA-Einstellungen

```tcl
# Foreign Keys aktivieren (per Default aus!)
$db allrows {PRAGMA foreign_keys = ON}

# Performance für Bulk-Imports
$db allrows {PRAGMA synchronous = OFF}
$db allrows {PRAGMA journal_mode = MEMORY}
# ... Bulk-Operationen ...
$db allrows {PRAGMA synchronous = FULL}
$db allrows {PRAGMA journal_mode = DELETE}

# WAL-Modus (besser für gleichzeitige Leser/Schreiber)
$db allrows {PRAGMA journal_mode = WAL}
```

### Letzte eingefuegte ID

```tcl
# Nach INSERT:
set id [$db allrows {SELECT last_insert_rowid() AS id}]
set newId [dict get [lindex $id 0] id]

# Oder kürzer (SQLite-spezifisch):
# set newId [db lastinsertid]  ;# Nur bei create, nicht bei new
```

### Schema via CLI importieren

TDBC hat Probleme mit komplexen DDL (Triggers, FTS5, Virtual Tables).
Lösung: Schema-Datei über die SQLite3-CLI importieren:

```tcl
# schema.sql enthält komplexes DDL
if {[catch {exec sqlite3 $dbFile < $schemaFile} err]} {
    error "Schema-Import fehlgeschlagen: $err"
}

# Danach normal mit TDBC arbeiten
set db [tdbc::sqlite3::connection new $dbFile]
```

### FTS5 Volltextsuche

Schema (als SQL-Datei, via CLI importieren):

```sql
CREATE TABLE articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT
);

CREATE VIRTUAL TABLE articles_fts USING fts5(
    title, content,
    content='articles', content_rowid='id'
);

CREATE TRIGGER articles_ai AFTER INSERT ON articles BEGIN
    INSERT INTO articles_fts (rowid, title, content)
    VALUES (new.id, new.title, new.content);
END;

CREATE TRIGGER articles_au AFTER UPDATE ON articles BEGIN
    UPDATE articles_fts SET title = new.title, content = new.content
    WHERE rowid = new.id;
END;

CREATE TRIGGER articles_ad AFTER DELETE ON articles BEGIN
    DELETE FROM articles_fts WHERE rowid = old.id;
END;
```

Suche mit TDBC:

```tcl
# Einfache Suche
set rows [$db allrows {
    SELECT a.* FROM articles a
    JOIN articles_fts fts ON a.id = fts.rowid
    WHERE articles_fts MATCH :query
} [dict create query "tcl database"]]

# FTS5-Syntax:
# AND       - Beide Begriffe
# OR        - Einer der Begriffe
# NOT       - Ausschliessen
# "..."     - Phrase
# *         - Prefix (data* -> database, datatype ...)
```

## Introspektion

TDBC bietet umfangreiche Möglichkeiten, Datenbank-Metadaten abzufragen.

### Offene Objekte

```tcl
# Alle offenen Statements einer Verbindung
$db statements
# -> ::oo::Obj601::Stmt::4

# Alle offenen Result Sets
$db resultsets

# Nützlich für Cleanup, z.B. in Web-Servern nach jedem Request
```

### Tabellen auflisten

```tcl
# Alle Tabellen
set tables [$db tables]
# -> Verschachteltes Dict: Tabellenname -> {type table name ... sql ...}

# Mit SQL-Pattern (% = Wildcard)
set tables [$db tables "user%"]
```

Das Ergebnis ist ein verschachteltes Dict. Die Schlüssel der zweiten
Ebene sind treiber-abhängig.

### Spalten inspizieren

```tcl
# Alle Spalten einer Tabelle
set cols [$db columns Accounts]

# Spalte für Spalte (verschachteltes Dict):
dict for {colName info} $cols {
    puts "$colName: Typ=[dict get $info type], Nullable=[dict get $info nullable]"
}
# -> name: Typ=text, Nullable=1
# -> acctno: Typ=text, Nullable=0
# -> balance: Typ=double, Nullable=1

# Mit Pattern
set cols [$db columns Accounts "Bal%"]
```

Spalten-Beschreibung (zweite Dict-Ebene):

| Schlüssel | Beschreibung                                  |
|------------|-----------------------------------------------|
| `type`     | Datentyp der Spalte                           |
| `precision`| Genauigkeit (Bits, Dezimalstellen oder Breite)|
| `scale`    | Nachkommastellen                              |
| `nullable` | 1 = kann NULL enthalten, 0 = NOT NULL         |

Zusätzliche Schlüssel je nach Treiber möglich (z.B. `cid`, `pk`,
`notnull` bei SQLite).

### Primär- und Fremdschluessel

```tcl
# Primaerschluessel
$db primarykeys Accounts
# -> {ordinalPosition 2 columnName AcctNo}

# Fremdschluessel
$db foreignkeys -foreign Orders
# -> Liste von Dicts mit: foreignTable, foreignColumn,
#    primaryTable, primaryColumn
```

## Stored Procedures

Stored Procedures werden über `preparecall` aufgerufen:

```tcl
# Syntax: ?RESULTVAR =? STOREDPROCNAME (?arg, ...?)
set stmt [$db preparecall {call myProcedure(:param1, :param2)}]
$stmt execute [dict create param1 "wert1" param2 42]
$stmt close

# Mit Rückgabewert
set stmt [$db preparecall {result = myFunction(:input)}]
set rs [$stmt execute [dict create input "test"]]
# result enthält den Rückgabewert
$rs close
$stmt close
```

**Hinweis:** Stored Procedures sind nicht bei allen Treibern verfügbar.
SQLite unterstützt keine Stored Procedures.

## ODBC-Utilities

Das `tdbc::odbc`-Paket bietet zusätzliche Verwaltungsbefehle:

```tcl
package require tdbc::odbc

# Installierte ODBC-Treiber auflisten
set drivers [tdbc::odbc::drivers]
# -> Verschachteltes Dict mit Treibernamen und Attributen

# Konfigurierte Datenquellen auflisten
set dsns [tdbc::odbc::datasources]
set dsns [tdbc::odbc::datasources -user]    ;# Nur Benutzer-DSNs
set dsns [tdbc::odbc::datasources -system]  ;# Nur System-DSNs

# Datenquelle verwalten (erfordert ODBC Installer API)
tdbc::odbc::datasource add "SQL Server" DSN=MyDSN SERVER=localhost ...
tdbc::odbc::datasource remove "SQL Server" DSN=MyDSN
tdbc::odbc::datasource configure "SQL Server" DSN=MyDSN ...
# Auch: add_system, remove_system, configure_system
```

## TDBC vs. sqlite3-API

Die direkte sqlite3-API (`package require sqlite3`) und TDBC sind
**zwei völlig verschiedene APIs**. Nie mischen!

| Aspekt              | sqlite3 (direkt)         | TDBC                        |
|---------------------|--------------------------|-----------------------------|
| Package             | `sqlite3`                | `tdbc::sqlite3`             |
| Verbindung          | `sqlite3 db "file.db"`   | `tdbc::sqlite3::connection` |
| Abfrage             | `db eval {SQL}`          | `$db allrows {SQL}`         |
| Iteration           | `db eval {SQL} row {...}` | `$db foreach row {SQL} {...}` |
| Parameter           | Aus Scope (`:name`)      | Dict (`dict create name ..`) |
| Datenbanken         | Nur SQLite               | SQLite, Postgres, MySQL, ODBC |
| Statement           | Implizit                 | Explizit (`prepare`/`close`)  |

### Keine eval-Methode in TDBC!

```tcl
# FALSCH: TDBC hat kein eval
set db [tdbc::sqlite3::connection new "app.db"]
$db eval {SELECT * FROM users}
# -> unknown method "eval"

# RICHTIG:
$db allrows {SELECT * FROM users}
```

### Parameter-Bindung unterschiedlich

```tcl
# sqlite3: Parameter aus lokalem Scope
package require sqlite3
sqlite3 db "app.db"
set name "Alice"
db eval {SELECT * FROM users WHERE name = :name}
# :name wird automatisch aus $name im Scope genommen

# TDBC: Parameter als explizites Dict
package require tdbc::sqlite3
set db [tdbc::sqlite3::connection new "app.db"]
$db allrows {SELECT * FROM users WHERE name = :name} \
    [dict create name "Alice"]
```

## Oracle mit oratcl

Für Oracle-Datenbanken wird oratcl direkt verwendet, nicht
tdbc::oratcl (das existiert nicht als stabiler Treiber):

```tcl
package require Oratcl

# Verbindung
set lda [oralogon user/pass@service]

# Cursor oeffnen
set cur [oraopen $lda]

# SQL ausführen
orasql $cur {SELECT id, name FROM users WHERE active = 1}

# Ergebnisse lesen
while {[orafetch $cur -datavariable row] == 0} {
    lassign $row id name
    puts "$id: $name"
}

# Aufräumen
oraclose $cur
oralogoff $lda
```

Die oratcl-API ist grundlegend anders als TDBC. Für Details siehe
die separate oratcl-Dokumentation.

## Direkte Ausführung (MySQL)

MySQL unterstützt manche DDL-Statements nicht über `prepare`.
Dafuer gibt es `evaldirect`:

```tcl
# Nur MySQL! Umgeht das prepare/execute-Pattern
$db evaldirect {
    CREATE DATABASE IF NOT EXISTS myapp
}
```

Nur verwenden wenn `prepare` nicht funktioniert. Kein Parameter-Binding,
daher kein Schutz gegen SQL-Injection.

## Der `--` Separator

Bei `allrows` und `foreach` auf Connection-Ebene kann der `--`
Separator nötig sein, wenn SQL-Parameter übergeben werden und
das SQL-Statement mit einem `-` beginnen könnte:

```tcl
# Ohne -- könnte das Dict als Option interpretiert werden
$db allrows -as lists -- {
    UPDATE Accounts SET Balance = Balance - :amount WHERE Name = :name
} [dict create amount 50 name "Tom"]
```

## Fehlerbehandlung

### SQL-Fehler abfangen

```tcl
try {
    $db allrows {INSERT INTO users (email) VALUES (:email)} \
        [dict create email "duplicate@example.com"]
} on error {err opts} {
    if {[string match "*UNIQUE constraint*" $err]} {
        puts "Email existiert bereits"
    } else {
        puts "Datenbankfehler: $err"
    }
}
```

### Existenz prüfen vor Insert

```tcl
proc userExists {db email} {
    set rows [$db allrows {
        SELECT COUNT(*) AS cnt FROM users WHERE email = :email
    } [dict create email $email]]
    return [expr {[dict get [lindex $rows 0] cnt] > 0}]
}

if {![userExists $db $email]} {
    # Insert...
}
```

### Statement-Leaks vermeiden

```tcl
# SCHLECHT: Statement bleibt offen bei Fehler
set stmt [$db prepare {INSERT INTO ...}]
$stmt execute $data    ;# Fehler hier -> Statement nie geschlossen!
$stmt close

# GUT: try/finally garantiert close
set stmt [$db prepare {INSERT INTO ...}]
try {
    $stmt execute $data
} finally {
    $stmt close
}
```

## Portabilitaet zwischen Datenbanken

Der Hauptvorteil von TDBC: Gleiche API für verschiedene Datenbanken.
Nur die Verbindung aendert sich:

```tcl
# Konfigurierbar:
proc connectDB {config} {
    set driver [dict get $config driver]
    switch $driver {
        sqlite {
            package require tdbc::sqlite3
            return [tdbc::sqlite3::connection new \
                [dict get $config file]]
        }
        postgres {
            package require tdbc::postgres
            return [tdbc::postgres::connection new \
                -host [dict get $config host] \
                -database [dict get $config database] \
                -user [dict get $config user] \
                -password [dict get $config password]]
        }
        odbc {
            package require tdbc::odbc
            return [tdbc::odbc::connection new \
                [dict get $config connstring]]
        }
    }
}

# Entwicklung:
set db [connectDB {driver sqlite file dev.db}]

# Produktion:
set db [connectDB {driver postgres host db.example.com \
    database myapp user appuser password secret}]

# Ab hier: Identischer Code für alle Datenbanken
```

**Achtung:** SQL-Dialekte unterscheiden sich. AUTOINCREMENT (SQLite)
vs. SERIAL (PostgreSQL) vs. IDENTITY (SQL Server). Schema-DDL ist
nicht portabel, aber DML (SELECT, INSERT, UPDATE, DELETE) meistens
schon.

## Performance-Tipps

| Tipp                          | Wirkung                    |
|-------------------------------|----------------------------|
| Transaktionen für Batches    | 100x schneller bei Inserts |
| Prepared Statements cachen    | Kein wiederholtes Parsen   |
| Indizes auf WHERE-Spalten     | O(log n) statt O(n)       |
| PRAGMA journal_mode = WAL     | Bessere Parallelitaet      |
| allrows statt nextrow         | Schneller bei kleinen Mengen |
| nextrow bei grossen Mengen    | Weniger Speicherverbrauch  |

## Zusammenfassung

| Was                    | Wie                                    |
|------------------------|----------------------------------------|
| Verbindung             | `tdbc::sqlite3::connection new "file"` |
| Alle Zeilen            | `$db allrows {SQL}`                    |
| Iteration              | `$db foreach row {SQL} {...}`          |
| Prepared Statement     | `$db prepare {SQL}` -> `$stmt execute` |
| Parameter              | `dict create key value` (ohne `:`)     |
| NULL prüfen           | `dict exists $row key`                 |
| Transaktion            | `$db transaction {...}`                |
| Schließen             | `$stmt close`, `$db close`             |
| Sicherheit             | Immer Bind-Variablen, nie String-Interpolation |

**Die drei goldenen Regeln:**
1. **IMMER** Prepared Statements mit Bind-Variablen (`:name`)
2. **IMMER** Statements in `try`/`finally` schließen
3. **IMMER** `dict exists` vor Zugriff auf NULL-faehige Spalten

## Siehe auch

- [Error-Handling](error-handling.md) -- `try`/`finally` für Statement-Cleanup
- [TclOO](tcloo.md) -- Datenbank-Wrapper als Klasse
- [Namespace](namespace.md) -- Datenbank-Module in Namespaces
- [String-Modell](string-modell.md) -- Warum Typkonvertierung bei TDBC nötig sein kann
- [Substitution](substitution-escaping.md) -- Quoting in SQL-Strings

## Quellen

- Ashok P. Nadkarni: *The Tcl Programming Language*, Kap. 23 (2017)
- Kevin B. Kenny: *Tcl Database Connectivity* (TIP 350)
- TDBC Referenz: https://www.tcl-lang.org/man/tcl8.6/TdbcCmd/contents.htm
- MagicSplat TDBC-Artikel: https://www.magicsplat.com/articles/tdbc.html
- Tcler's Wiki TDBC: https://wiki.tcl-lang.org/page/TDBC
