# Unicode und Tcl/Tk

*Stand: 2026-04-29*

## Das Grundprinzip

Tcl-Strings sind intern abstrakte Unicode-Codepoint-Sequenzen.
Beim Schreiben in Dateien oder Netzwerk müssen sie als Bytes kodiert werden.

```
Tcl-String (Unicode)  ←→  Bytes (Encoding)  ←→  Datei / Netzwerk
     "Olá"            ←→   4f 6c c3 a1      ←→  UTF-8
     "Olá"            ←→   4f 6c e1         ←→  ISO8859-1
```

---

## Tcl 8.6 vs. Tcl 9 — Unicode-Grenzen

### Tcl 8.6 (TCL_UTF_MAX=3)

Tcl 8.6 unterstützt nur Codepoints **U+0000–U+FFFF** (BMP — Basic
Multilingual Plane). Zeichen oberhalb U+FFFF (Supplementary Plane,
z.B. Emoji) werden intern als **Surrogate-Paare** gespeichert oder zu
**U+FFFD** (Replacement Character) degradiert.

```tcl
# Tcl 8.6: string length eines 4-Byte Emoji
set c [format "%c" 0x1F600]  ;# 😀
string length $c             ;# -> 2 (Surrogate-Paar!) nicht 1
```

Intern speichert Tcl 8.6 U+1F600 als UTF-8 `F0 9F 98 80` —
vier Bytes, aber als **ein** logisches Zeichen nur wenn
`TCL_UTF_MAX=4` gebaut wurde (selten).

### Tcl 9 (TCL_UTF_MAX=4)

Tcl 9 unterstützt den **vollständigen Unicode-Bereich** U+0000–U+10FFFF.
`string length` gibt die korrekte Anzahl Codepoints zurück.

```tcl
# Tcl 9:
set c [format "%c" 0x1F600]
string length $c   ;# -> 1
```

---

## Das BMP-Whitespace-Problem (Tcl 8.6)

**`string trim` ohne Argument trimmt alle Unicode-Whitespace-Zeichen**,
nicht nur ASCII-Leerzeichen. Das betrifft u.a.:

| Codepoint | Name | Vorkommen |
|-----------|------|-----------|
| U+0085 | NEL (Next Line) | letztes Byte vieler BMP-Symbole in UTF-8 |
| U+00A0 | Non-Breaking Space | typografische Texte |
| U+2028 | Line Separator | Unicode-Zeilenumbruch |
| U+2029 | Paragraph Separator | Unicode-Absatzumbruch |

### Das Tückische: BMP-Symbole mit 0x85 als letztem UTF-8-Byte

Viele häufige BMP-Symbole haben `\x85` (= U+0085, NEL) als letztes
Byte ihrer UTF-8-Darstellung:

| Symbol | Codepoint | UTF-8 Bytes | Letztes Byte |
|--------|-----------|-------------|--------------|
| ✅ | U+2705 | `E2 9C 85` | `85` = NEL |
| ❌ | U+274C | `E2 9D 8C` | `8C` (sicher) |
| ✓ | U+2713 | `E2 9C 93` | `93` (sicher) |
| ✗ | U+2717 | `E2 9C 97` | `97` (sicher) |

**Konsequenz:** `string trim " ✅ "` liefert in Tcl 8.6 **`"â"`** —
nicht `"✅"`. Der NEL-Byte am Ende wird als Whitespace abgetrimmt,
sodass nur `E2 9C` = `â\x9c` übrig bleibt.

```tcl
# BUG in Tcl 8.6:
set s " ✅ "
string trim $s          ;# -> "â" (FALSCH!)

# Fix: Charset explizit angeben
string trim $s " \t"    ;# -> "✅" (KORREKT)
```

**Regel:** In Tcl 8.6 immer `string trim $var " \t"` statt `string trim $var`,
wenn der String Nicht-ASCII enthalten kann.

---

## Encoding bei Channels

### Die goldene Regel

**Immer Encoding explizit setzen — nie auf System-Defaults verlassen.**

```tcl
# FALSCH — System-Default (plattformabhängig):
set f [open "datei.txt" r]
set content [read $f]
close $f

# RICHTIG — explizites UTF-8:
set f [open "datei.txt" r]
fconfigure $f -encoding utf-8
set content [read $f]
close $f
```

### Binärmodus

```tcl
# Binär lesen — keine Encoding-Konvertierung:
set f [open "bild.png" rb]
set bytes [read $f]
close $f

# Nachträglich auf binär:
chan configure $chan -translation binary
# Setzt automatisch: -encoding iso8859-1, -translation lf
```

### encoding convertfrom / convertto

```tcl
# Bytes → Tcl-String:
set str [encoding convertfrom utf-8 $bytes]

# Tcl-String → Bytes:
set bytes [encoding convertto utf-8 $str]
```

---

## Encoding Profiles (nur Tcl 9)

| Profil | Verhalten | Unicode-konform |
|--------|-----------|-----------------|
| `strict` | Fehler bei ungültigen Bytes (Default) | Ja |
| `replace` | Ersetzt ungültige Bytes mit U+FFFD | Ja |
| `tcl8` | Bytes als ISO8859-1 (stille Korruption) | Nein |

```tcl
# Tcl 9:
chan configure $chan -encoding utf-8 -profile replace
```

In **Tcl 8.6** gibt es keine Profile — ungültige Bytes werden
stillschweigend wie im `tcl8`-Profil behandelt.

---

## Emoji und Supplementary Plane in Tcl 8.6

Zeichen oberhalb U+FFFF (4-Byte UTF-8, z.B. `F0 9F ...`) werden von
Tcl 8.6 zu **U+FFFD** degradiert, wenn sie als String geladen werden.

### Lösung: Binary lesen + preprocessBytes

```tcl
# FALSCH — Emoji gehen verloren:
set f [open "doc.md" r]
fconfigure $f -encoding utf-8
set text [read $f]   ;# 😀 wird zu U+FFFD

# RICHTIG — binär lesen, dann manuell konvertieren:
set f [open "doc.md" rb]
set raw [read $f]
close $f
# Emoji-Bytes (F0 xx xx xx) VOR der Konvertierung ersetzen:
set clean [preprocessEmoji $raw]
set text [encoding convertfrom utf-8 $clean]
```

Die `preprocessBytes`-Funktion in `pdf4tcllib` implementiert genau
dieses Pattern: Sie iteriert über die Rohdaten und ersetzt 4-Byte
UTF-8-Sequenzen durch ASCII-Fallbacks, bevor `encoding convertfrom`
aufgerufen wird.

### Surrogate-Paare in Tcl 8.6

Tcl 8.6 mit `TCL_UTF_MAX=3` speichert manche Emoji intern als
Surrogate-Paare (U+D800–U+DFFF). `string length` gibt dann 2 zurück
statt 1. Bei `split "" ""` werden Surrogate-Hälfte für Hälfte geliefert.

```tcl
set emoji "😀"
string length $emoji   ;# -> 1 oder 2 je nach Build

# Sicheres Iterieren:
set chars [split $emoji ""]
foreach c $chars {
    set cp [scan $c %c]
    if {$cp >= 0xD800 && $cp <= 0xDBFF} {
        # High surrogate — nächstes Zeichen ist Low surrogate
    }
}
```

---

## Tk und Unicode

Tk-Widgets (Text, Entry, Label etc.) arbeiten intern mit
Unicode und zeigen alle BMP-Zeichen korrekt an, **wenn der
System-Font das Zeichen enthält.**

```tcl
# Tk zeigt BMP-Zeichen direkt:
label .l -text "Checkmark: ✓  Pfeil: →  Euro: €"
pack .l
```

### Schrift-Fallback

Tk wählt automatisch einen Font-Fallback wenn das Zeichen im
primären Font fehlt. Auf Linux (Fontconfig) funktioniert das
meist gut; auf Windows und macOS kann es zu Lücken kommen.

### Text-Widget und Unicode

Das Text-Widget speichert intern Unicode-Codepoints. `string trim`
auf Text aus dem Widget unterliegt denselben Regeln wie oben.

```tcl
# Zeichen-genaues Navigieren im Text-Widget:
set idx [$t index "1.0 + 5 chars"]   ;# "chars" = Codepoints

# Seit Tk 8.5: Unterschied chars vs. indices
# chars  = Unicode-Zeichen (ohne eingebettete Widgets)
# indices = Zeichen + eingebettete Widgets/Images
set next [$t index "$pos + 1 indices"]
```

---

## Häufige Encodings

| Encoding | Verwendung | Bytes/Zeichen |
|----------|------------|---------------|
| `utf-8` | Modern, Internet | 1–4 (variabel) |
| `iso8859-1` | Latin-1, Westeuropa | 1 |
| `cp1252` | Windows Westeuropa | 1 |
| `utf-16le` | Windows intern | 2–4 |
| `binary` | Rohdaten | 1 (U+0000–U+00FF) |

```tcl
# Alle verfügbaren Encodings:
encoding names

# System-Encoding abfragen (nicht ändern!):
encoding system   ;# -> utf-8 (Linux), cp1252 (Windows DE)
```

---

## Unicode-Escapes in Tcl-Quellcode

```tcl
# \uXXXX — BMP (U+0000–U+FFFF)
set ae "\u00e4"   ;# ä
set arrow "\u2192" ;# →

# \UXXXXXXXX — Vollständiger Unicode (Tcl 9 / TCL_UTF_MAX=4)
set emoji "\U0001F600"  ;# 😀

# format %c — aus Codepoint:
set c [format "%c" 0x2705]  ;# ✅
```

### Literale Sonderzeichen in gesourcten Dateien

`source` liest eine Datei mit dem plattformabhängigen Channel-Default-Encoding
(Linux meist UTF-8, Windows oft cp1252). Enthält eine `.tcl`/`.tm`-Datei
literale Nicht-ASCII-Zeichen (Umlaute, Symbole, griechische Buchstaben),
entsteht ohne explizites Encoding Mojibake — jedes UTF-8-Byte wird als
eigenes Zeichen gelesen:

```tcl
# Datei enthält das Wort "Größe" (UTF-8-Bytes C3 B6 C3 9F)
source -encoding utf-8 datei.tcl
string length $s        ;# -> 5  (korrekt)

source -encoding iso8859-1 datei.tcl
string length $s        ;# -> 7  (Mojibake: jedes Byte einzeln)
```

Zwei robuste Strategien:

- Beim `source` immer `-encoding utf-8` angeben — unabhängig vom System.
- Sonderzeichen aus Codepoints bauen statt sie literal zu schreiben
  (`\uXXXX` oder `format %c`), dann ist das Datei-Encoding irrelevant.

`package require` ist nicht betroffen: Der `.tm`-Loader öffnet die Datei
intern bereits als UTF-8.

---

## Praktische Regeln (Zusammenfassung)

| Situation | Regel |
|-----------|-------|
| Datei lesen | `fconfigure $f -encoding utf-8` |
| Emoji in Datei | Binär lesen + `preprocessBytes` vor `encoding convertfrom` |
| `string trim` mit Nicht-ASCII | `string trim $var " \t"` (expliziter Charset) |
| Codepoint-Iteration | `split $str ""` + `scan $c %c` |
| BMP-Zeichen in Tk | Funktioniert direkt wenn Font vorhanden |
| Supplementary Plane in Tk 8.6 | Nicht direkt möglich — Fallback nötig |
| Windows: System-Encoding | Nie `encoding system` ändern — nur per Channel |

---

## Bekannte Fallen

### string trim trimmt BMP-Symbole (Tcl 8.6)

Jedes BMP-Zeichen dessen letztes UTF-8-Byte Unicode-Whitespace ist
(U+0085, U+00A0 etc.) wird von `string trim` abgeschnitten.
**Fix:** `string trim $var " \t"`

### encoding system utf-8 (Windows)

`encoding system utf-8` bricht auf Windows alle Systemaufrufe.
**Fix:** Nur per Channel konfigurieren.

### Binärdaten als String

`-translation binary` setzt implizit `-encoding iso8859-1`.
Wer danach `encoding convertfrom utf-8` aufruft, muss
`-translation binary` explizit wieder deaktivieren.

### U+FFFD nach Datei-Lesen (Tcl 8.6)

Supplementary-Plane-Zeichen in UTF-8-Dateien werden beim Lesen mit
`-encoding utf-8` zu U+FFFD. Lösung: Rohdaten binär lesen und
4-Byte-Sequenzen vorher ersetzen.

### Combining Characters

`é` (U+00E9) und `e` + `◌́` (U+0065 + U+0301) sehen gleich aus,
sind aber unterschiedliche Strings:

```tcl
string equal "\u00e9" "\u0065\u0301"  ;# -> 0
string length "\u00e9"               ;# -> 1
string length "\u0065\u0301"         ;# -> 2
```

Für Normalisierung: `package require tcl::transform::normalize`
(Tcl 9) oder manuell via `encoding convertto/from`.
