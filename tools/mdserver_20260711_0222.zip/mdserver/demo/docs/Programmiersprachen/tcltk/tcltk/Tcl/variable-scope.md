# Variable Scope

*Stand: 2026-04-29*

Tcl hat drei Ebenen der Variablensichtbarkeit: den globalen Scope,
den Namespace-Scope und den lokalen Scope innerhalb von Prozeduren.
Mehrere Befehle erlauben es, Variablen zwischen diesen Ebenen
zu verknüpfen.

## Die drei Scopes

### Globaler Scope

Variablen die ausserhalb von Prozeduren und Namespaces definiert
werden, leben im globalen Scope (`::`) und sind persistent:

```tcl
set appName "MeinProgramm"
# appName lebt in :: und ist überall per ::appName erreichbar
```

### Namespace-Scope

Variablen die mit `variable` in einem Namespace deklariert werden,
leben in diesem Namespace und sind persistent:

```tcl
namespace eval config {
    variable host "localhost"
    variable port 8080
}
# config::host und config::port sind persistent
```

### Lokaler Scope

Variablen die innerhalb einer Prozedur gesetzt werden, sind lokal
und werden bei Rueckkehr der Prozedur zerstört:

```tcl
proc test {} {
    set x 42        ;# lokal, nur hier sichtbar
    return $x
}
# x existiert nach dem Aufruf nicht mehr
```

## global

Macht eine globale Variable im lokalen Scope sichtbar:

```tcl
set counter 0

proc increment {} {
    global counter
    incr counter
}

increment
increment
puts $counter   ;# -> 2
```

### Mehrere Variablen auf einmal

```tcl
proc showConfig {} {
    global host port debug
    puts "$host:$port (debug=$debug)"
}
```

### Wie global funktioniert

`global counter` erzeugt im lokalen Scope eine Verknüpfung (Link)
zur globalen Variable `::counter`. Änderungen an der lokalen
Variable ändern die globale und umgekehrt.

```tcl
set x 10

proc test {} {
    global x
    set x 99
}

test
puts $x   ;# -> 99 (globale Variable wurde geändert)
```

### Wann global vermeiden

`global` durchbricht die Kapselung und erzeugt unsichtbare
Abhängigkeiten. In Namespace-basiertem Code ist `variable`
fast immer besser:

```tcl
# SCHLECHT: Globale Variable
set ::currentUser ""

proc login {name} {
    global currentUser
    set currentUser $name
}

# BESSER: Namespace-Variable
namespace eval session {
    variable currentUser ""

    proc login {name} {
        variable currentUser
        set currentUser $name
    }
}
```

## variable

Deklariert eine persistente Variable in einem Namespace. Innerhalb
von Prozeduren im selben Namespace muss `variable` verwendet werden,
um auf die Namespace-Variable zuzugreifen.

### Im Namespace-Body

```tcl
namespace eval db {
    variable connection ""
    variable queryCount 0
}
```

### In Namespace-Prozeduren

```tcl
namespace eval db {
    variable connection ""

    proc connect {dsn} {
        variable connection
        set connection [openDb $dsn]
    }

    proc isConnected {} {
        variable connection
        expr {$connection ne ""}
    }
}
```

### variable vs. global

| Aspekt | `global varName` | `variable varName` |
|:-------|:-----------------|:-------------------|
| Verknuepft mit | `::varName` | `::currentNamespace::varName` |
| Einsatz | Prozeduren ohne Namespace | Namespace-Prozeduren |
| Empfehlung | Vermeiden | Bevorzugen |

```tcl
namespace eval app {
    variable data "ns-data"

    proc test {} {
        global data       ;# -> verknüpft mit ::data (FALSCH!)
        variable data     ;# -> verknüpft mit ::app::data (RICHTIG)
    }
}
```

### variable mit und ohne Initialwert

```tcl
namespace eval app {
    # Mit Initialwert: Erzeugt und setzt die Variable
    variable version "1.0"

    # Ohne Initialwert: Erzeugt die Variable nur wenn noch nicht vorhanden
    variable config
}
```

In einer Prozedur hat `variable` nie einen Initialwert -- es
verknüpft nur:

```tcl
namespace eval app {
    variable count 0

    proc increment {} {
        variable count      ;# nur Verknüpfung, kein Wert
        incr count
    }
}
```

## upvar

Erzeugt eine lokale Variable die auf eine Variable in einem anderen
Stack-Frame verweist. Damit kann eine Prozedur auf Variablen ihres
Aufrufers zugreifen.

### Syntax

```tcl
upvar ?level? otherVar localVar ?otherVar2 localVar2 ...?
```

### Einfaches Beispiel

```tcl
proc doubleVar {varName} {
    upvar 1 $varName var
    set var [expr {$var * 2}]
}

set x 5
doubleVar x
puts $x   ;# -> 10
```

`upvar 1 $varName var` bedeutet: Verknuepfe die lokale Variable `var`
mit der Variable deren Name in `$varName` steht, im Stack-Frame eine
Ebene höher (dem Aufrufer).

### Level-Angabe

| Level | Bedeutung |
|:------|:----------|
| `1` | Ein Frame höher (Aufrufer) -- Standard-Anwendungsfall |
| `2` | Zwei Frames höher (Aufrufer des Aufrufers) |
| `0` | Aktueller Frame (selten sinnvoll) |
| `#0` | Globaler Frame |
| `#1` | Erster Frame über global |

```tcl
proc setGlobal {name value} {
    upvar #0 $name var
    set var $value
}

setGlobal myGlobal 42
puts $::myGlobal   ;# -> 42
```

`upvar #0` ist funktional aequivalent zu `global`, aber flexibler weil
der Variablenname dynamisch sein kann.

### Typische Einsatzgebiete

**Call-by-Reference:**

```tcl
proc swap {aName bName} {
    upvar 1 $aName a $bName b
    set tmp $a
    set a $b
    set b $tmp
}

set x 10
set y 20
swap x y
puts "$x $y"   ;# -> 20 10
```

**Ergebnis in Variable schreiben (wie lassign, regexp):**

```tcl
proc parseLine {line varName varAge} {
    upvar 1 $varName name $varAge age
    lassign [split $line ","] name age
}

parseLine "Alice,30" n a
puts "$n ist $a"   ;# -> Alice ist 30
```

**Dict-Eintrag direkt ändern:**

```tcl
proc dictIncr {dictName key {amount 1}} {
    upvar 1 $dictName d
    dict incr d $key $amount
}

set stats [dict create hits 0 errors 0]
dictIncr stats hits
dictIncr stats hits
dictIncr stats errors
puts $stats   ;# -> hits 2 errors 1
```

### upvar auf Array-Elemente

```tcl
proc getElement {arrName key} {
    upvar 1 $arrName arr
    return $arr($key)
}

array set config {host localhost port 8080}
puts [getElement config host]   ;# -> localhost
```

### Mehrere Variablen verknüpfen

```tcl
upvar 1 $nameVar name $ageVar age $cityVar city
```

## uplevel

Führt ein Script im Stack-Frame des Aufrufers (oder eines anderen
Frames) aus. Während `upvar` einzelne Variablen verknüpft, führt
`uplevel` ganzen Code in einem anderen Kontext aus.

### Syntax

```tcl
uplevel ?level? script ?script ...?
```

### Einfaches Beispiel

```tcl
proc myIf {condition body} {
    if {[uplevel 1 [list expr $condition]]} {
        uplevel 1 $body
    }
}

set x 5
myIf {$x > 3} {
    puts "x ist größer als 3"
}
```

### Level-Angabe

Wie bei `upvar`: `1` für den Aufrufer, `#0` für global.

### Typische Einsatzgebiete

**Kontrollstrukturen nachbauen:**

```tcl
proc repeat {n body} {
    for {set i 0} {$i < $n} {incr i} {
        uplevel 1 $body
    }
}

repeat 3 { puts "Hallo" }
```

**Timing:**

```tcl
proc measure {body} {
    set start [clock microseconds]
    uplevel 1 $body
    set end [clock microseconds]
    return [expr {$end - $start}]
}

set us [measure {
    string repeat "x" 100000
}]
puts "Dauer: ${us}us"
```

**Debug-Wrapper:**

```tcl
proc debug {msg body} {
    puts ">>> $msg"
    set code [catch {uplevel 1 $body} result opts]
    puts "<<< $msg (code=$code)"
    return -options $opts $result
}
```

### uplevel vs. eval

| Aspekt | `uplevel 1 $body` | `eval $body` |
|:-------|:------------------|:-------------|
| Ausfuehrungskontext | Aufrufer-Scope | Aktueller Scope |
| Variablenzugriff | Auf Aufrufer-Variablen | Auf lokale Variablen |
| Typischer Einsatz | Kontrollstrukturen, Makros | Dynamischer Code |

## apply

Führt eine anonyme Prozedur (Lambda) aus. Eine Lambda ist eine Liste
aus Argumentliste und Body, optional mit Namespace:

### Syntax

```tcl
apply {arglist body ?namespace?} ?arg ...?
```

### Einfaches Beispiel

```tcl
set square [list {x} {expr {$x * $x}}]

apply $square 5   ;# -> 25
apply $square 9   ;# -> 81
```

### Mit mehreren Parametern

```tcl
set add [list {a b} {expr {$a + $b}}]
apply $add 3 4   ;# -> 7
```

### Mit Namespace

```tcl
namespace eval math {
    variable pi 3.14159
}

set circleArea [list {r} {
    variable pi
    expr {$pi * $r * $r}
} ::math]

apply $circleArea 5   ;# -> 78.53975
```

### Typische Einsatzgebiete

**Callbacks:**

```tcl
after 1000 [list apply {{} {
    puts "Eine Sekunde vergangen"
}}]
```

**Funktionale Programmierung mit lmap:**

```tcl
set numbers {1 2 3 4 5}
set squared [lmap n $numbers {apply {{x} {expr {$x * $x}}} $n}]
# -> 1 4 9 16 25
```

**Sortieren mit Vergleichsfunktion:**

```tcl
set data {{Alice 30} {Bob 25} {Carol 35}}

set sorted [lsort -command [list apply {{a b} {
    set ageA [lindex $a 1]
    set ageB [lindex $b 1]
    expr {$ageA - $ageB}
}}] $data]
# -> {Bob 25} {Alice 30} {Carol 35}
```

### apply vs. proc

| Aspekt | `proc` | `apply` |
|:-------|:-------|:--------|
| Benannt | Ja | Nein (anonym) |
| Registriert | Im Namespace | Nirgends |
| Aufruf | Per Name | Per Variable |
| Scope | Eigener lokaler Scope | Eigener lokaler Scope |
| Bytecode | Ja (beim 1. Aufruf) | Ja (bei jedem Aufruf) |
| Einsatz | Reguläre Prozeduren | Callbacks, Lambdas |

### Wichtig: Tcl hat keine echten Closures

Der Body eines `apply` hat keinen Zugriff auf Variablen aus dem
umgebenden Scope. Alles was die Lambda braucht, muss explizit
übergeben oder per `variable`/`global` geholt werden:

```tcl
set factor 3

# FALSCH: $factor ist im Lambda nicht sichtbar
set fn [list {x} {expr {$factor * $x}}]
apply $fn 5   ;# Fehler: can't read "factor"

# RICHTIG: factor als Parameter übergeben
set fn [list {factor x} {expr {$factor * $x}}]
apply $fn $factor 5   ;# -> 15

# RICHTIG: In list einbetten für sofortige Substitution
set fn [list {x} "expr {\$x * $factor}"]
apply $fn 5   ;# -> 15 (aber: ohne Bytecode-Vorteil)
```

Für Callbacks mit gebundenen Werten das Command-Prefix-Pattern
verwenden:

```tcl
proc multiplyBy {factor x} {
    expr {$factor * $x}
}

set triple [list multiplyBy 3]
{*}$triple 5   ;# -> 15
```

## namespace upvar

Verknuepft eine lokale Variable mit einer Namespace-Variable.
Funktional ähnlich wie `variable`, aber von ausserhalb des
Namespaces nutzbar:

```tcl
namespace eval config {
    variable host "localhost"
    variable port 8080
}

proc showConfig {} {
    namespace upvar ::config host h port p
    puts "$h:$p"
}

showConfig   ;# -> localhost:8080
```

### namespace upvar vs. variable

| Aspekt | `variable name` | `namespace upvar ns name local` |
|:-------|:----------------|:-------------------------------|
| Wo nutzbar | Nur im eigenen Namespace | Von überall |
| Lokaler Name | Gleich wie Namespace-Variable | Frei waehlbar |
| Mehrere Variablen | Einzeln deklarieren | In einem Aufruf |

```tcl
namespace eval app {
    variable longConfigurationName "test"

    proc internal {} {
        variable longConfigurationName   ;# gleicher Name
    }
}

proc external {} {
    namespace upvar ::app longConfigurationName cfg   ;# kurzer Alias
    puts $cfg
}
```

## Scope-Fallen und Best Practices

### Falle: Variable in after/trace/bind

Timer, Traces und Widget-Bindings erzeugen keinen neuen Scope.
Variablen die zum Ausfuehrungszeitpunkt existieren müssen,
sollten per `[list]` sofort eingebunden werden:

```tcl
# FALSCH: $i hat zum Ausfuehrungszeitpunkt seinen letzten Wert
for {set i 0} {$i < 5} {incr i} {
    after [expr {$i * 1000}] "puts $i"
}
# Gibt 5x "5" aus

# RICHTIG: [list] bindet den aktuellen Wert
for {set i 0} {$i < 5} {incr i} {
    after [expr {$i * 1000}] [list puts $i]
}
# Gibt 0, 1, 2, 3, 4 aus
```

### Falle: upvar auf nicht-existente Variable

```tcl
proc test {varName} {
    upvar 1 $varName v
    # v existiert hier noch nicht wenn die Quellvariable fehlt
    if {![info exists v]} {
        set v "default"   ;# erzeugt die Variable beim Aufrufer
    }
}

# y existiert nicht:
test y
puts $y   ;# -> default (wurde von test erzeugt!)
```

### Falle: Namespace-Variable ohne variable-Deklaration

```tcl
namespace eval app {
    variable count 0

    proc broken {} {
        incr count       ;# Fehler: count nicht definiert (lokaler Scope)
    }

    proc correct {} {
        variable count
        incr count       ;# OK: verknüpft mit ::app::count
    }
}
```

### Best Practice: Scope minimieren

```tcl
# SCHLECHT: Globale Variable für temporäre Daten
set ::tempResult ""
proc compute {} {
    global tempResult
    set tempResult [heavyWork]
}

# BESSER: Rückgabewert verwenden
proc compute {} {
    return [heavyWork]
}
set result [compute]

# ODER: Ergebnis in Variable schreiben (call-by-reference)
proc compute {resultVar} {
    upvar 1 $resultVar result
    set result [heavyWork]
}
compute myResult
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `global varName ...` | Globale Variable im lokalen Scope sichtbar machen |
| `variable varName ?value?` | Namespace-Variable deklarieren/verknüpfen |
| `upvar ?level? otherVar localVar` | Variable aus anderem Frame verknüpfen |
| `uplevel ?level? script` | Script in anderem Frame ausführen |
| `apply {args body ?ns?} ?arg ...?` | Anonyme Prozedur ausführen |
| `namespace upvar ns var local` | Namespace-Variable verknüpfen |

### Entscheidungshilfe

| Situation | Befehl |
|:----------|:-------|
| Globale Variable in Proc nutzen | `global` (oder besser: vermeiden) |
| Namespace-Variable in Proc nutzen | `variable` |
| Call-by-Reference | `upvar 1` |
| Kontrollstruktur nachbauen | `uplevel 1` |
| Callback/Lambda | `apply` oder Command-Prefix |
| Namespace-Variable von aussen lesen | `namespace upvar` |

## Siehe auch

- [Prozeduren](proc.md) -- Lokaler Scope, Parameter, Rückgabewerte
- [Namespace](namespace.md) -- Namespace-Variablen mit `variable`
- [Code laden](source-eval-apply.md) -- `uplevel`, `apply`, Closures
- [Trace](trace.md) -- `upvar` in Trace-Callbacks
- [TclOO](tcloo.md) -- Instanzvariablen als Scope-Mechanismus
