# Tcl Standalone-Binaries: Starkits und Starpacks

*Stand: 2026-04-29*

## Überblick

Tcl-Anwendungen lassen sich als einzelne, ausführbare Dateien verteilen,
die weder eine Tcl-Installation noch zusätzliche Dateien benötigen.
Die klassische Technologie dafür heisst Starpack und basiert auf drei Saeulen:
dem Virtual File System (VFS), dem Tclkit-Interpreter und dem SDX-Werkzeug.

Dieses Dokument erklärt die Grundlagen, den Aufbau und den praktischen
Einsatz dieser Technologien. Es bezieht sich primär auf Tcl 8.6 und die
Metakit-basierte VFS-Variante. Für Tcl 9 und ZipFS-basierte Zipkits
siehe das Dokument `zipkit-deployment.md`.


## Aufbau einer Standalone-Datei

Eine Tcl-Standalone-Binary besteht aus zwei Teilen, die in einer einzigen
Datei zusammengefügt werden:

```
+---------------------------+
| Tcl-Interpreter (Tclkit)  |   <-- ausfuehrbarer Code
+---------------------------+
| Virtuelles Dateisystem    |   <-- Scripte, Pakete, Ressourcen
| (Metakit / ZIP)           |
+---------------------------+
| Groessenangabe (Trailer)  |   <-- Offset zum VFS-Anfang
+---------------------------+
```

Am Ende der Datei steht die Größe des Datenteils. Daraus berechnet der
Interpreter beim Start den Offset, an dem das virtuelle Dateisystem beginnt.


## Virtual File System (VFS)

### Grundprinzip

Ab Tcl 8.4 trennt der Interpreter Dateioperationen von der echten
Dateisystem-Schicht. Ein VFS-Treiber kann beliebige Datenquellen als
normales Dateisystem einhaengen. Danach funktionieren alle Standard-Befehle
wie `open`, `file copy`, `glob` und `source` transparent darauf.

### VFS-Typen

| Typ | Paket | Beschreibung |
|-----|-------|--------------|
| Metakit | vfs::mk4 | Eingebettete Datenbank, lesen und schreiben |
| ZIP | vfs::zip | ZIP-Archive, nur lesen |
| FTP | vfs::ftp | Fernzugriff auf FTP-Server |
| HTTP | vfs::http | Fernzugriff auf HTTP-Ressourcen |

Für Starkits und Starpacks wird traditionell Metakit verwendet,
weil es sowohl Lesen als auch Schreiben unterstützt.

### Mounten und Arbeiten

```tcl
package require vfs::mk4

# Metakit-Datei als VFS mounten
vfs::mk4::Mount C:/myKit.mk myKit

# Normale Dateibefehle funktionieren
file copy C:/README.txt myKit/
puts [glob myKit/*]
# -> myKit/README.txt

# Unmount schreibt ausstehende Änderungen
vfs::unmount myKit
```

### Wichtige Eigenschaften

VFS-Mounts gelten prozessweit -- alle Interpreter im Prozess sehen sie.
C-Erweiterungen, die die Tcl-Dateisystem-API nutzen, profitieren ebenfalls.
Zum Beispiel kann Tk Bilder direkt aus einem VFS laden.

Einschränkungen: Das Betriebssystem und andere Prozesse sehen das VFS nicht.
Man kann daher keine ausführbaren Dateien aus einem VFS per `exec` starten.
Der `load`-Befehl ist eine Ausnahme -- er kopiert Shared Libraries automatisch
in ein temporäres Verzeichnis und lädt sie von dort.


## Metakit-Datenbank

Metakit ist eine eingebettete Datenbank von Jean-Claude Wippler
(dem Autor von Tclkit). Sie dient als Container für das virtuelle
Dateisystem innerhalb von Starkits und Starpacks.

### Merkmale

Metakit speichert die gesamte Datenbank in einer einzigen Datei,
ist plattformunabhaengig (keine Konvertierung nötig) und hat einen
Speicherbedarf von nur etwa 125 KB. Die praktische Groessengrenze
für Starpacks liegt bei ungefaehr 1 GB.

### Interne Struktur (mk4vfs)

Der VFS-Treiber mk4vfs bildet Dateien und Verzeichnisse auf eine
verschachtelte Metakit-Datenstruktur ab:

```
Layout: {dirs {name parent:I {files {name size:I date:I contents:B}}}}
```

Jeder Eintrag in der View `dirs` repräsentiert ein Verzeichnis mit Name
und Verweis auf das Elternverzeichnis. Die Subview `files` enthält die
Dateien des jeweiligen Verzeichnisses mit Name, Größe, Datum und
binaeren Inhalten.

### Tcl-Zugriff mit Mk4tcl

```tcl
package require Mk4tcl

# Datei oeffnen (erstellen falls nicht vorhanden)
mk::file open myTag myDatabase.mk

# View-Layout definieren
mk::view layout myTag.people {name birthYear:I}

# Daten einfügen
mk::row append myTag.people name "Max Muster" birthYear 1985

# Daten abfragen
set rows [mk::select myTag.people -min birthYear 1980]
foreach i $rows {
    puts [mk::get myTag.people!$i]
}

# Datei schließen (auto-commit)
mk::file close myTag
```

Datentyp-Suffixe: `:S` (String, Standard), `:I` (Integer),
`:L` (64-Bit Integer), `:F` (Float), `:D` (Double), `:B` (Binary).


## Tclkit

### Was ist ein Tclkit?

Ein Tclkit ist ein einzelner ausfuehrbarer Tcl-Interpreter, der folgende
Komponenten enthält:

- Tcl-Interpreter (Kern)
- Tk (für GUI-Anwendungen)
- TclVFS (Virtual-File-System-Treiber für ZIP und Metakit)
- Metakit / Mk4tcl (eingebettete Datenbank)
- Optional: IncrTcl (objektorientierte Erweiterung)

Tclkits benötigen keine Installation und sind für viele Plattformen
verfügbar: Windows, Linux (x86, ARM, PowerPC, RISC-V), macOS,
FreeBSD, Solaris und weitere.

### Bezugsquellen

| Quelle | URL | Bemerkung |
|--------|-----|-----------|
| rkeene.org | tclkits.rkeene.org/fossil/wiki/Downloads | Vorgefertigte Tclkits |
| KitCreator | kitcreator.rkeene.org/kitcreator | Eigene Tclkits zusammenstellen |
| BAWT | bawt.tcl3d.org | Baut Tclkits aus Quellen |

### Zwei Varianten

```
tclkit-win32.exe      Vollständiges Tclkit mit Tk (GUI-Anwendungen)
tclkitsh-win32.exe    Nur Tcl ohne Tk (Konsolen-Anwendungen)
```

Unter Unix genügt ein einziges Binary für beide Zwecke.
Unter Windows gibt es separate Varianten mit und ohne Konsolenfenster.

### Verwendung als Interpreter

Tclkit kann als Ersatz für `tclsh` und `wish` verwendet werden:

```bash
# Script ausführen
tclkit hello.tcl

# Interaktive Shell
tclkit
```


## Starkit

### Was ist ein Starkit?

Ein Starkit ist eine einzelne Datei mit der Endung `.kit`, die ein
komplettes virtuelles Dateisystem enthält. Ein Starkit wird mit einem
externen Tclkit ausgeführt:

```bash
tclkit hello.kit
```

### VFS-Struktur eines Starkits

```
hello.vfs/
|-- main.tcl              # Einstiegspunkt (Pflicht)
|-- lib/                  # Pakete und Erweiterungen
    |-- app-hello/        # Anwendung als Paket
        |-- hello.tcl
        |-- pkgIndex.tcl
```

Die Datei `main.tcl` ist der einzige Pflichtbestandteil.
Das `lib`-Verzeichnis ist nötig, wenn Pakete geladen werden sollen.

### Aufbau von main.tcl

```tcl
package require starkit
starkit::startup
package require app-hello
```

Der Befehl `starkit::startup` führt zwei Aktionen aus. Er erweitert die
Variable `auto_path` um das `lib`-Verzeichnis, sodass alle Pakete dort
verfügbar werden. Ausserdem setzt er `starkit::topdir` auf den
virtuellen Pfad des VFS-Wurzelverzeichnisses.

### Ausfuehrungsmodus erkennen

Der Rückgabewert von `starkit::startup` zeigt an, wie das Script
gestartet wurde:

| Modus | Bedeutung |
|-------|-----------|
| unwrapped | Normal per `tclkit hello.vfs/main.tcl` |
| starkit | Als Starkit per `tclkit hello.kit` |
| starpack | Als Starpack per `hello.exe` |
| sourced | Per `source hello.vfs/main.tcl` |

### Ressourcen im Starkit

Zusätzliche Dateien wie Bilder oder Icons legt man in Unterverzeichnisse
innerhalb der VFS-Struktur:

```
hello.vfs/
|-- main.tcl
|-- res/
    |-- icon.png
    |-- logo.jpg
```

Zugriff im Script:

```tcl
set icon_path [file join $starkit::topdir res icon.png]
image create photo logo -file $icon_path
```

### Starkit-Dateiformat

Eine `.kit`-Datei beginnt mit einem Tcl-Script-Header:

```tcl
#!/bin/sh
# \
exec tclkit "$0" ${1+"$@"}
package require starkit
starkit::header mk4 -readonly
```

Danach folgen die binaeren Metakit-Daten. Unter Unix kann man eine `.kit`-Datei
direkt ausführbar machen, wenn `tclkit` im Systempfad liegt. Unter Windows
muss die `.kit`-Endung mit dem Tclkit-Programm verknüpft werden.

### Starkits untereinander verwenden

Man kann Pakete aus einem anderen Starkit verfügbar machen, ohne dessen
`main.tcl` auszuführen:

```tcl
vfs::mk4::Mount /pfad/zu/extra.kit /pfad/zu/extra.kit -readonly
lappend ::auto_path /pfad/zu/extra.kit/lib
```


## Starpack

### Was ist ein Starpack?

Ein Starpack vereint Tclkit und Starkit in einer einzigen ausführbaren Datei.
Es ist eine vollständig eigenständige Anwendung ohne externe Abhängigkeiten.

### Vorteile

- Einfachste Verteilung: eine einzelne Datei
- Keine Installation nötig, kein Tcl auf dem Zielsystem erforderlich
- Kein Aufraumen bei Deinstallation -- Datei löschen genügt
- Keine Abhaengigkeitsprobleme -- alles ist enthalten
- Endanwender müssen nicht wissen, dass die Anwendung in Tcl geschrieben ist

### Einschränkungen

- Plattformspezifisch: für jede Zielplattform ein eigenes Binary
- Groesser als ein Starkit (weil der komplette Interpreter enthalten ist)
- VFS ist nur lesbar -- Konfigurationsdaten müssen extern gespeichert werden
- `exec` auf Dateien innerhalb des VFS funktioniert nicht
- Praktische Groessengrenze etwa 1 GB (Metakit-Limit)


## SDX: Das Werkzeug

SDX (Starkit Developer eXtensions) ist selbst ein Starkit (`sdx.kit`)
und das zentrale Werkzeug zum Erstellen und Verwalten von Starkits
und Starpacks.

### Bezugsquelle

SDX ist unter anderem verfügbar bei:
chiselapp.com/user/aspect/repository/sdx/

### Die wichtigsten Befehle

#### qwrap: Schnelles Einpacken eines Scripts

```bash
tclkitsh sdx.kit qwrap hello.tcl
# Erzeugt hello.kit
```

`qwrap` erstellt automatisch die korrekte VFS-Struktur mit `main.tcl`,
dem `lib`-Verzeichnis und der Paket-Konvertierung der Quelldatei.

#### unwrap: Starkit entpacken

```bash
tclkitsh sdx.kit unwrap hello.kit
# Erzeugt hello.vfs/
```

#### wrap: VFS-Verzeichnis einpacken

```bash
# Als Starkit
tclkitsh sdx.kit wrap hello.kit

# Beschreibbares Starkit
tclkitsh sdx.kit wrap hello.kit -writable
```

SDX sucht automatisch nach dem Verzeichnis `hello.vfs`, wenn das
erste Argument `hello.kit` heisst.

#### wrap mit --runtime: Starpack erstellen

```bash
# Kopie des Tclkits erstellen (laufende Instanz kann sich nicht selbst kopieren)
copy tclkit.exe runtime.exe

# Starpack erzeugen
tclkitsh sdx.kit wrap hello.exe -runtime runtime.exe
```

Das Tclkit für `--runtime` muss eine andere physische Datei sein als das
ausfuehrende Tclkit. Es kann aber ein Tclkit für eine andere Plattform sein --
so lassen sich Cross-Platform-Builds erstellen, ohne Zugang zum Zielsystem
zu benötigen.

#### lsk: Inhalt eines Starkits auflisten

```bash
tclkitsh sdx.kit lsk hello.kit
```

### Schritt-für-Schritt: Starpack erstellen

Der vollständige Ablauf in sechs Schritten:

Schritt 1 -- Voraussetzungen herunterladen:

```bash
# Tclkit herunterladen (z.B. von rkeene.org)
# SDX herunterladen
mv sdx-20110317.kit sdx.kit
mv tclkit-cli-8_6_10-x64.exe tclkit.exe
```

Schritt 2 -- Verzeichnisstruktur anlegen:

```bash
mkdir -p demo.vfs/lib
```

Schritt 3 -- Pakete kopieren:

```bash
mkdir demo.vfs/lib/meinpaket
```

```tcl
# Datei: demo.vfs/lib/meinpaket/meinpaket.tcl
proc gruss {name} {
    return "Hallo $name"
}
package provide meinpaket 1.0
```

```tcl
# Datei: demo.vfs/lib/meinpaket/pkgIndex.tcl
package ifneeded meinpaket 1.0 [list source [file join $dir meinpaket.tcl]]
```

Schritt 4 -- Anwendungsdateien erstellen:

```bash
mkdir demo.vfs/app
```

```tcl
# Datei: demo.vfs/app/demo.tcl
package require meinpaket
puts [gruss "Welt"]
```

Schritt 5 -- main.tcl erstellen:

```tcl
# Datei: demo.vfs/main.tcl
package require starkit
starkit::startup
source [file join [file dirname [info script]] app demo.tcl]
```

Schritt 6 -- Starpack bauen:

```bash
copy tclkit.exe runtime.exe
tclkit sdx.kit wrap demo -runtime runtime.exe
# Unter Windows: rename demo demo.exe
```

Die erzeugte Datei ist sofort lauffaehig:

```bash
demo.exe
# -> Hallo Welt
```


## Automatisierung mit Makefile

Für wiederholbare Builds empfiehlt sich ein Makefile:

```makefile
APP = meinapp
TCLKIT = tclkitsh
SDX = $(TCLKIT) sdx.kit
RUNTIME = runtime.exe

# Starkit bauen
$(APP).kit: $(APP).vfs
	$(SDX) wrap $(APP).kit

# Starpack bauen
$(APP).exe: $(APP).kit
	copy $(TCLKIT).exe $(RUNTIME)
	$(SDX) wrap $(APP).exe -runtime $(RUNTIME)

# Aufraumen
clean:
	del $(APP).kit $(APP).exe $(RUNTIME)
```

Für Cross-Platform-Builds (z.B. Linux-Binary unter Windows bauen)
genügt es, ein anderes Runtime-Binary anzugeben:

```bash
make APP=meinapp RUNTIME=tclkit-linux-x86_64
```


## Alternativen zu SDX

| Werkzeug | Beschreibung |
|----------|--------------|
| freeWrap | Ähnlich wie Starpack, Binaries für Windows und Linux |
| TclApp | Kommerzielles Werkzeug aus ActiveStates TclDevKit, mit GUI |
| Tcl2Exe | Script zum schnellen Wrappen unter Windows |
| starpacker | SDX-basiertes Utility für vereinfachte Starpack-Erstellung |


## Tipps und Fallstricke

### Externes Speichern von Konfiguration

Da das VFS in Starpacks nur lesbar ist, müssen Konfigurationsdateien
extern gespeichert werden:

```tcl
# Konfigurationsverzeichnis neben dem Binary
set appdir [file dirname [info nameofexecutable]]
set conffile [file join $appdir meinapp.conf]
```

### Binäre Erweiterungen einbinden

Kompilierte C-Erweiterungen (.dll/.so) können ins `lib`-Verzeichnis
gelegt werden. Tcls `load`-Befehl kopiert sie zur Laufzeit in ein
temporäres Verzeichnis, weil das Betriebssystem keine Shared Libraries
direkt aus einem VFS laden kann.

### Starpack-Modus erkennen

```tcl
package require starkit
set modus [starkit::startup]

switch $modus {
    starpack {
        # Konfiguration extern speichern
        set confdir [file dirname [info nameofexecutable]]
    }
    starkit - unwrapped {
        # Konfiguration im VFS-Verzeichnis
        set confdir $starkit::topdir
    }
}
```

### Auto-Update für Starpacks

Da ein laufendes Starpack sich selbst nicht überschreiben kann,
verwendet man ein zweistufiges Verfahren:

1. Neue Version als `autoupdate-meinapp.exe` herunterladen und starten
2. Das Autoupdate-Binary wartet kurz (5 Sekunden), kopiert sich dann
   über die Originaldatei und startet diese neu

```tcl
# Im Autoupdate-Binary: Eigenen Namen prüfen
set exe [file tail [info nameofexecutable]]
if {[string match "autoupdate-*" $exe]} {
    after 5000
    set target [string range $exe 11 end]  ;# "autoupdate-" entfernen
    set dir [file dirname [info nameofexecutable]]

    # VFS unmounten, damit die Datei kopiert werden kann
    catch {vfs::mk4::Unmount exe [info nameofexecutable]}

    file copy -force [info nameofexecutable] [file join $dir $target]
    catch {file attributes [file join $dir $target] -permissions 0755}
    exec [file join $dir $target] {*}$argv &
    exit 0
}
```


## Zusammenfassung

Die Starpack-Technologie basiert auf drei Komponenten: Metakit als
eingebettete Datenbank, VFS für den transparenten Dateizugriff auf
diese Datenbank, und Tclkit als eigenstaendiger Interpreter.
Das SDX-Werkzeug fügt alles zu einer einzelnen ausführbaren Datei
zusammen.

Für Tcl 8.6 ist Starpack/Metakit der etablierte Standard.
Ab Tcl 9 steht mit ZipFS und Zipkits eine modernere Alternative
zur Verfügung, die ohne Metakit auskommt und direkt in den
Tcl-Kern integriert ist (siehe `zipkit-deployment.md`).
