# Code laden und ausführen: source, eval, apply

*Stand: 2026-04-29*

Tcl bietet mehrere Mechanismen um Code zur Laufzeit zu laden und
auszuführen. Diese Befehle unterscheiden sich darin, woher der Code
kommt (Datei vs. String vs. Lambda) und in welchem Kontext er
ausgeführt wird.

## source

Liest eine Datei ein und führt ihren Inhalt als Tcl-Script aus.

### Syntax

```tcl
source fileName
source -encoding encodingName fileName
```

### Grundverwendung

```tcl
source /pfad/zu/helpers.tcl
source [file join $appDir lib utils.tcl]
```

Der Code wird im aktuellen Scope ausgeführt. Variablen und
Prozeduren die in der Datei definiert werden, sind danach im
aufrufenden Scope sichtbar.

### Encoding

Standardmäßig wird die System-Codierung verwendet. Für UTF-8-
Dateien explizit angeben:

```tcl
source -encoding utf-8 /pfad/zu/datei.tcl
```

### info script

Während der Ausführung von `source` gibt `info script` den Pfad
der aktuell geladenen Datei zurück:

```tcl
# In helpers.tcl:
set myDir [file dirname [info script]]
```

Das ist der korrekte Weg, um Pfade relativ zur eigenen Datei
aufzuloesen.

### source vs. package require

| Aspekt | `source` | `package require` |
|:-------|:---------|:-------------------|
| Pfadangabe | Explizit, vollständig | Automatisch gefunden |
| Versionierung | Keine | Eingebaut |
| Doppelt laden | Kein Schutz | `package provide` verhindert es |
| Abhängigkeiten | Manuell verwalten | Automatisch aufgelöst |
| Einsatz | Eigene Projektdateien | Bibliotheken |

Für Bibliotheken immer `package require` verwenden. `source` ist
für das Laden eigener Projektdateien und in Bootstrapping-Szenarien
nützlich.

### source in Namespaces

`source` führt den Code im aktuellen Scope aus. Innerhalb von
`namespace eval` wird der Code im Namespace ausgeführt:

```tcl
namespace eval app {
    source helpers.tcl   ;# Procs landen in ::app
}
```

Vorsicht: Das ist fehleranfällig. Besser ist es, wenn die Datei
selbst ihren Namespace deklariert:

```tcl
# In helpers.tcl:
namespace eval app {
    proc helper {} { ... }
}
```

## eval

Führt einen oder mehrere Strings als Tcl-Script aus.

### Syntax

```tcl
eval script ?script ...?
```

Mehrere Argumente werden vor der Ausführung zu einem String
zusammengefügt (mit Leerzeichen getrennt):

```tcl
eval set x 42          ;# -> set x 42
eval {set x 42}        ;# -> set x 42
eval "set x" "42"      ;# -> set x 42
```

### Dynamischen Code ausführen

```tcl
set cmd "puts"
set msg "Hallo Welt"
eval $cmd [list $msg]   ;# -> Hallo Welt
```

### eval vs. {*} (Expand-Operator)

Seit Tcl 8.5 ist der Expand-Operator `{*}` in den meisten Faellen
die bessere Alternative zu `eval`:

```tcl
# Alt (eval):
set cmd [list string toupper "hello"]
eval $cmd

# Neu ({*}):
set cmd [list string toupper "hello"]
{*}$cmd
```

| Aspekt | `eval $cmd` | `{*}$cmd` |
|:-------|:------------|:----------|
| Parsing | Erneut geparst (langsamer) | Liste expandiert (schneller) |
| Sicherheit | Doppel-Substitution möglich | Keine Doppel-Substitution |
| Bytecode | Nein | Ja |
| Empfehlung | Vermeiden | Bevorzugen |

### Wann eval noch nötig ist

Für echten dynamischen Code, der als String zusammengebaut wird:

```tcl
# Script dynamisch zusammenbauen
set script ""
foreach item $items {
    append script [list processItem $item] "\n"
}
eval $script
```

Oder für Rueckwaertskompatibilitaet mit altem Code.

### Sicherheitsrisiko: Doppel-Substitution

```tcl
set userInput {[exec rm -rf /]}

# GEFAEHRLICH: eval führt die Substitution aus
eval puts $userInput   ;# würde exec ausführen!

# SICHER: list verhindert die Substitution
eval puts [list $userInput]   ;# -> [exec rm -rf /]

# BESSER: Kein eval nötig
puts $userInput   ;# -> [exec rm -rf /]
```

Faustregel: Wenn `eval` mit Benutzereingaben verwendet wird,
müssen alle variablen Teile mit `[list]` geschuetzt werden.

## apply

Führt eine anonyme Prozedur (Lambda) aus.

### Syntax

```tcl
apply {arglist body ?namespace?} ?arg ...?
```

Eine Lambda ist eine reguläre Tcl-Liste mit zwei oder drei Elementen.

### Grundverwendung

```tcl
apply {{x y} {expr {$x + $y}}} 3 4   ;# -> 7
```

### In Variablen speichern

```tcl
set double [list {x} {expr {$x * 2}}]
set square [list {x} {expr {$x * $x}}]

apply $double 5   ;# -> 10
apply $square 5   ;# -> 25
```

### Mit Namespace-Kontext

Das optionale dritte Element bestimmt, in welchem Namespace die
Lambda ausgeführt wird:

```tcl
namespace eval math {
    variable pi 3.14159265
}

set area [list {r} {
    variable pi
    expr {$pi * $r * $r}
} ::math]

apply $area 10   ;# -> 314.159265
```

### Scope-Verhalten

`apply` erzeugt einen eigenen lokalen Scope, genau wie `proc`.
Es gibt keinen Zugriff auf Variablen des umgebenden Scopes:

```tcl
set multiplier 3

# FALSCH: $multiplier ist im Lambda nicht sichtbar
apply {{x} {expr {$multiplier * $x}}} 5
# Fehler: can't read "multiplier"
```

Lösungen:

**Wert in die Lambda einbetten:**

```tcl
set multiplier 3
set fn [list {x} "expr {\$x * $multiplier}"]
apply $fn 5   ;# -> 15
```

Nachteil: Der Body ist ein String, kein Braced-Block, also
keine Bytecode-Optimierung.

**Als zusätzlichen Parameter übergeben:**

```tcl
set fn [list {multiplier x} {expr {$multiplier * $x}}]
apply $fn 3 5   ;# -> 15
```

**Command-Prefix statt Lambda verwenden:**

```tcl
proc multiplyBy {factor x} {
    expr {$factor * $x}
}

set triple [list multiplyBy 3]
{*}$triple 5   ;# -> 15
```

Das Command-Prefix-Pattern ist in Tcl oft besser geeignet als
Lambdas mit gebundenen Werten.

### apply als Callback

```tcl
# nach 1 Sekunde ausführen
after 1000 [list apply {{} {
    puts "Timer abgelaufen"
}}]

# Button-Command
ttk::button .btn -command [list apply {{} {
    puts "Geklickt"
}}]
```

### apply mit lmap und lsort

```tcl
# Liste transformieren
set numbers {1 2 3 4 5}
set doubled [lmap n $numbers {
    apply {{x} {expr {$x * 2}}} $n
}]
# -> 2 4 6 8 10

# Sortieren mit eigener Vergleichsfunktion
set people {{Alice 30} {Bob 25} {Carol 35}}
set sorted [lsort -command [list apply {{a b} {
    expr {[lindex $a 1] - [lindex $b 1]}
}}] $people]
# -> {Bob 25} {Alice 30} {Carol 35}
```

## uplevel

Führt ein Script im Stack-Frame des Aufrufers aus.

### Syntax

```tcl
uplevel ?level? script ?script ...?
```

### Grundverwendung

```tcl
proc myForeach {varName list body} {
    upvar 1 $varName var
    foreach var $list {
        uplevel 1 $body
    }
}

myForeach item {a b c} {
    puts "Item: $item"
}
```

### Level-Angabe

| Level | Bedeutung |
|:------|:----------|
| `1` | Aufrufer (Standard-Anwendungsfall) |
| `2` | Aufrufer des Aufrufers |
| `#0` | Globaler Scope |
| `#1` | Erster Scope über global |

### Typische Einsatzgebiete

**Kontrollstrukturen:**

```tcl
proc withFile {varName filename mode body} {
    upvar 1 $varName fd
    set fd [open $filename $mode]
    set code [catch {uplevel 1 $body} result opts]
    close $fd
    return -options $opts $result
}

withFile f "test.txt" r {
    puts [read $f]
}
```

**Timing-Wrapper:**

```tcl
proc time_ms {body} {
    set start [clock milliseconds]
    uplevel 1 $body
    set elapsed [expr {[clock milliseconds] - $start}]
    return $elapsed
}

set ms [time_ms {
    string repeat "x" 1000000
}]
puts "Dauer: ${ms}ms"
```

**Bedingte Ausführung:**

```tcl
proc when {condition body} {
    if {[uplevel 1 [list expr $condition]]} {
        uplevel 1 $body
    }
}

set x 5
when {$x > 3} {
    puts "x ist gross"
}
```

### uplevel vs. eval

| Aspekt | `uplevel 1 $body` | `eval $body` |
|:-------|:------------------|:-------------|
| Scope | Aufrufer | Aktuell (lokal) |
| Variablenzugriff | Aufrufer-Variablen | Lokale Variablen |
| Einsatz | Kontrollstrukturen | Dynamischer Code |
| break/continue | Wirkt im Aufrufer | Wirkt lokal |

## Zusammenspiel der Befehle

### Wann welchen Befehl verwenden

| Situation | Befehl |
|:----------|:-------|
| Datei laden | `source` |
| Bibliothek laden | `package require` (nicht source) |
| Dynamischen Code ausführen | `eval` oder `{*}` |
| Liste als Befehl ausführen | `{*}$cmd` (nicht eval) |
| Anonyme Funktion | `apply` |
| Callback definieren | `[list cmd arg]` oder `[list apply ...]` |
| Kontrollstruktur bauen | `uplevel 1` |
| Variable im Aufrufer setzen | `upvar 1` |
| Code im Aufrufer-Scope ausführen | `uplevel 1` |

### Sicherheitshierarchie

Von sicher zu unsicher:

1. `{*}$cmd` -- Liste wird expandiert, keine Doppel-Substitution
2. `apply $lambda arg` -- eigener Scope, keine Seiteneffekte
3. `uplevel 1 $body` -- Aufrufer-Scope, kontrolliert
4. `eval $script` -- Doppel-Substitution möglich, riskant
5. `interp eval child $code` -- Ausführung in Sandbox, kontrollierbar

### Command-Prefix als universelles Pattern

Das Command-Prefix-Pattern ist die sicherste und flexibelste Art,
aufrufbaren Code weiterzugeben:

```tcl
# Command-Prefix erzeugen
set cmd [list string toupper]

# Ausführen mit zusätzlichen Argumenten
{*}$cmd "hello"   ;# -> HELLO

# Mit gebundenen Argumenten
proc greet {greeting name} {
    return "$greeting, $name!"
}

set helloCmd [list greet "Hallo"]
{*}$helloCmd "Welt"   ;# -> Hallo, Welt!

# Als Callback in Widget
ttk::button .btn -command [list greet "Hi" "User"]
```

Vorteile gegenüber eval und apply:

- Keine Doppel-Substitution
- Bytecode-fähig
- Werte sind zum Definitionszeitpunkt gebunden
- Funktioniert überall wo ein Befehl erwartet wird

## Häufige Fehler

### source mit relativem Pfad

```tcl
# FALSCH: Relativ zum Arbeitsverzeichnis
source "lib/helpers.tcl"

# RICHTIG: Relativ zum eigenen Script
source [file join [file dirname [info script]] lib helpers.tcl]
```

### eval mit ungeschuetzten Variablen

```tcl
set name "Alice; exec rm -rf /"

# GEFAEHRLICH:
eval "puts $name"

# SICHER:
eval puts [list $name]

# BESSER: Kein eval nötig
puts $name
```

### apply und fehlender Scope

```tcl
set x 42

# FALSCH: x ist im Lambda nicht sichtbar
apply {{} {puts $x}}

# RICHTIG: x als Parameter
apply {{x} {puts $x}} $x

# RICHTIG: Command-Prefix
{*}[list puts $x]
```

### uplevel mit falscher Ebene

```tcl
# FALSCH: uplevel 0 ist der eigene Scope (sinnlos)
proc wrapper {body} {
    uplevel 0 $body   ;# führt im eigenen Scope aus
}

# RICHTIG: uplevel 1 für den Aufrufer
proc wrapper {body} {
    uplevel 1 $body
}
```

### Expand statt eval vergessen

```tcl
set args [list -encoding utf-8 -translation lf]

# FALSCH: Alles als ein Argument
fconfigure $chan $args

# FALSCH: eval mit Sicherheitsrisiko
eval fconfigure $chan $args

# RICHTIG: Expand
fconfigure $chan {*}$args
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `source file` | Datei einlesen und ausführen |
| `source -encoding enc file` | Datei mit Encoding laden |
| `eval script` | String als Script ausführen |
| `{*}$list` | Liste als Befehl + Argumente expandieren |
| `apply {args body ?ns?} ?args?` | Anonyme Prozedur ausführen |
| `uplevel ?level? script` | Script im Aufrufer-Scope ausführen |
| `info script` | Pfad des aktuell geladenen Scripts |

## Siehe auch

- [Prozeduren](proc.md) -- `apply` als anonyme Prozedur, `tailcall`
- [Variable Scope](variable-scope.md) -- `uplevel`, Closures, Lambda-Binding
- [Metaprogramming](metaprogramming.md) -- `eval`, `subst`, Code-Konstruktion
- [Package](package.md) -- `source` vs. `package require` zum Laden
- [Interpreter](interp.md) -- `eval` in Kind-Interpretern
- [Fehlerbehandlung](error-handling.md) -- Fehler bei `source` und `eval`
