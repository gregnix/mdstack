# Interpreter (interp)

*Stand: 2026-04-29*

Tcl erlaubt es, innerhalb eines laufenden Programms zusätzliche
Interpreter zu erzeugen. Diese Kind-Interpreter (Slave-Interpreter)
sind eigenständige Ausfuehrungsumgebungen mit eigenen Variablen,
Prozeduren und Namespaces. Safe-Interpreter schraenken den
Funktionsumfang ein, um nicht-vertrauenswuerdigen Code sicher
auszuführen.

## Grundkonzept

Jedes Tcl-Programm läuft in einem Interpreter. Der initiale
Interpreter heisst der Master (oder Parent). Mit `interp create`
können Kind-Interpreter erzeugt werden, die:

- eigene Variablen und Prozeduren haben
- eigene Namespaces besitzen
- eigene Packages laden können
- vom Master kontrolliert werden

```tcl
# Kind-Interpreter erzeugen
interp create child

# Befehl im Kind ausführen
child eval { set x 42 }
child eval { puts $x }   ;# -> 42

# Variable existiert nur im Kind
info exists x             ;# -> 0 (im Master nicht vorhanden)

# Kind löschen
interp delete child
```

## Interpreter erzeugen und verwalten

### interp create

```tcl
interp create name             ;# normaler Kind-Interpreter
interp create -safe name       ;# sicherer Kind-Interpreter
interp create                  ;# automatisch generierter Name
```

Der Rückgabewert ist der Name des neuen Interpreters.

### interp delete

```tcl
interp delete child
```

Loescht den Interpreter und alle darin enthaltenen Ressourcen.

### interp exists

```tcl
interp exists child   ;# -> 1 oder 0
```

### interp slaves (interp children)

```tcl
interp create a
interp create b

interp slaves           ;# -> a b
# Ab Tcl 8.7: interp children
```

### Verschachtelte Interpreter

Kind-Interpreter können eigene Kinder erzeugen:

```tcl
interp create parent
parent eval { interp create child }

# Vom Master aus auf den Enkel zugreifen:
interp eval {parent child} { set x 99 }
```

Der Pfad `{parent child}` identifiziert den Interpreter `child`
innerhalb von `parent`.

## Code ausführen

### interp eval

Führt ein Script im Kind-Interpreter aus und gibt das Ergebnis
zurück:

```tcl
interp create worker

set result [interp eval worker {
    proc calculate {a b} { expr {$a + $b} }
    calculate 3 4
}]

puts $result   ;# -> 7
```

### Kurzform

Wenn der Interpreter einen einfachen Namen hat, kann er direkt
als Befehl verwendet werden:

```tcl
interp create worker

worker eval { set greeting "Hallo" }
puts [worker eval { set greeting }]   ;# -> Hallo
```

### Variablen zwischen Interpretern

Interpreter teilen keine Variablen. Der Austausch erfolgt über
Rückgabewerte oder Aliase:

```tcl
interp create child

# Wert übergeben
set data "wichtig"
child eval [list set data $data]

# Ergebnis zurueckholen
set result [child eval { string toupper $data }]
puts $result   ;# -> WICHTIG
```

## Aliase

Aliase verbinden einen Befehl im Kind-Interpreter mit einem Befehl
im Master (oder einem anderen Interpreter). Damit kann der Master
dem Kind kontrolliert Zugriff auf Funktionen geben.

### interp alias

```tcl
interp create child

# Alias erstellen: "log" im Kind ruft "masterLog" im Master auf
proc masterLog {msg} {
    puts "LOG: $msg"
}

interp alias child log {} masterLog

child eval { log "Nachricht vom Kind" }
# -> LOG: Nachricht vom Kind
```

### Syntax

```tcl
interp alias targetInterp aliasName sourceInterp command ?arg ...?
```

- `targetInterp` -- der Interpreter in dem der Alias sichtbar ist
- `aliasName` -- der Name des Befehls im Ziel-Interpreter
- `sourceInterp` -- der Interpreter der den echten Befehl enthält
  (`{}` für den Master)
- `command` -- der echte Befehl
- `arg ...` -- optionale feste Argumente

### Alias mit festen Argumenten

```tcl
proc writeFile {filename data} {
    set fd [open $filename w]
    puts $fd $data
    close $fd
}

# Kind darf nur in ein bestimmtes Verzeichnis schreiben
interp alias child saveData {} writeFile "/tmp/sandbox/output.txt"

child eval { saveData "Testdaten" }
# Schreibt nach /tmp/sandbox/output.txt
```

### Aliase auflisten

```tcl
interp alias child    ;# ohne Argumente: Liste aller Aliase im Kind
```

### Alias löschen

```tcl
interp alias child log {}   ;# Alias "log" entfernen
```

## Safe-Interpreter

Ein Safe-Interpreter ist ein eingeschraenkter Interpreter, in dem
gefaehrliche Befehle nicht verfügbar sind. Damit kann nicht-
vertrauenswuerdiger Code ausgeführt werden.

### Erzeugen

```tcl
interp create -safe sandbox
```

### Entfernte Befehle

In einem Safe-Interpreter fehlen unter anderem:

| Befehl | Grund |
|:-------|:------|
| `open` | Dateisystem-Zugriff |
| `exec` | Externe Programme |
| `socket` | Netzwerk-Zugriff |
| `file` | Dateisystem-Information |
| `load` | Shared Libraries laden |
| `source` | Dateien einlesen |
| `cd` | Verzeichnis wechseln |
| `glob` | Dateien suchen |
| `pwd` | Arbeitsverzeichnis |
| `fconfigure` | Kanal-Konfiguration |
| `encoding` | (eingeschraenkt) |

### Sicheren Zugriff gewaehren

Über Aliase kann der Master dem Safe-Interpreter kontrolliert
Zugriff auf bestimmte Funktionen geben:

```tcl
interp create -safe sandbox

# Kontrolliertes Lesen aus einem bestimmten Verzeichnis
proc safeRead {filename} {
    set allowed "/data/public"
    set fullpath [file normalize [file join $allowed $filename]]
    if {![string match "${allowed}/*" $fullpath]} {
        return -code error "Zugriff verweigert: $filename"
    }
    set fd [open $fullpath r]
    set content [read $fd]
    close $fd
    return $content
}

interp alias sandbox readFile {} safeRead

sandbox eval { set data [readFile "config.txt"] }
sandbox eval { readFile "../etc/passwd" }   ;# Fehler: Zugriff verweigert
```

### interp issafe

```tcl
interp issafe sandbox   ;# -> 1
interp issafe {}        ;# -> 0 (Master ist nicht safe)
```

### Safe-Interpreter und Packages

Safe-Interpreter können standardmäßig keine Packages laden, weil
`source` und `load` fehlen. Der Master kann das kontrolliert
ermöglichen:

```tcl
interp create -safe sandbox

# Tcl-eigenes Hilfsmittel
::safe::interpCreate sandbox   ;# Alternative: erzeugt + konfiguriert
```

Das `safe`-Package (Teil von Tcl) bietet Hilfsprozeduren um
Safe-Interpreter mit kontrollierten Package-Lade-Möglichkeiten
auszustatten.

## Limits

Seit Tcl 8.5 können Ressourcen-Limits für Kind-Interpreter
gesetzt werden:

### Befehlslimit

Begrenzt die Anzahl der Befehle die ausgeführt werden duerfen:

```tcl
interp create worker

# Maximal 10000 Befehle
interp limit worker commands -value 10000

catch {
    worker eval {
        while {1} { incr i }   ;# wird nach 10000 Befehlen abgebrochen
    }
} err

puts $err   ;# -> command count limit exceeded
```

### Zeitlimit

Begrenzt die Ausfuehrungszeit:

```tcl
interp create worker

# 5 Sekunden Zeitlimit
set deadline [expr {[clock seconds] + 5}]
interp limit worker time -seconds $deadline

catch {
    worker eval {
        after 10000   ;# würde 10 Sekunden warten
    }
} err
```

### Limit-Callback

```tcl
proc onLimitReached {interp} {
    puts "Limit erreicht für $interp"
    interp delete $interp
}

interp limit worker commands -value 50000 \
    -command [list onLimitReached worker]
```

## Versteckte Befehle (Hidden Commands)

Befehle können in einem Interpreter verborgen werden, so dass sie
nicht direkt aufrufbar aber für Aliase noch verfügbar sind:

### interp hide

```tcl
interp create child

interp hide child exec
# exec ist jetzt nicht mehr direkt aufrufbar im Kind:
child eval { exec ls }   ;# Fehler

# Aber der Master kann den versteckten Befehl aufrufen:
interp invokehidden child exec ls   ;# OK
```

### interp expose

Macht einen versteckten Befehl wieder sichtbar:

```tcl
interp expose child exec
```

### interp hidden

Listet alle versteckten Befehle:

```tcl
interp hidden child
```

## Kanäle teilen (Transfer)

Datei-Kanäle können zwischen Interpretern übertragen werden:

### interp transfer

```tcl
interp create child

set fd [open "/tmp/test.txt" w]

# Kanal an Kind übertragen (nicht mehr im Master verfügbar)
interp transfer {} $fd child

child eval [list puts $fd "Geschrieben vom Kind"]
child eval [list close $fd]
```

### interp share

Wie transfer, aber der Kanal bleibt in beiden Interpretern verfügbar:

```tcl
set fd [open "/tmp/log.txt" a]
interp share {} $fd child

# Beide können schreiben:
puts $fd "Master schreibt"
child eval [list puts $fd "Kind schreibt"]

close $fd
child eval [list close $fd]
```

## Einsatzgebiete

### Plugin-System

```tcl
proc loadPlugin {name file} {
    interp create -safe plugin_$name

    # Kontrollierte API bereitstellen
    interp alias plugin_$name registerAction {} pluginRegister $name
    interp alias plugin_$name getConfig {} pluginGetConfig $name

    # Plugin-Code laden (kontrolliert)
    set fd [open $file r]
    set code [read $fd]
    close $fd]

    plugin_$name eval $code
}
```

### Sandbox für Benutzereingaben

```tcl
proc safeEval {userCode} {
    interp create -safe temp

    # Nur bestimmte Befehle erlauben
    interp alias temp print {} puts

    set code [catch {temp eval $userCode} result]
    interp delete temp

    return $result
}
```

### Parallele Ausführung (mit Thread-Package)

Kind-Interpreter sind die Grundlage für Tcl-Threads. Jeder Thread
hat seinen eigenen Interpreter:

```tcl
package require Thread

set tid [thread::create {
    # Läuft in eigenem Interpreter/Thread
    proc worker {data} {
        return [string toupper $data]
    }
    thread::wait
}]

set result [thread::send $tid {worker "hello"}]
puts $result   ;# -> HELLO
```

## Häufige Fehler

### Variablen direkt teilen

```tcl
# FALSCH: Interpreter teilen keine Variablen
set x 42
interp create child
child eval { puts $x }   ;# Fehler: can't read "x"

# RICHTIG: Wert übergeben
child eval [list set x $x]
child eval { puts $x }   ;# -> 42
```

### Safe-Interpreter unterschaetzen

```tcl
# FALSCH: Annehmen dass safe alles blockiert
interp create -safe sandbox
sandbox eval { while {1} {} }   ;# Endlosschleife! Blockiert den Master

# RICHTIG: Limits setzen
interp limit sandbox commands -value 100000
```

### Alias-Argumente falsch übergeben

```tcl
# FALSCH: Argumente werden nicht richtig durchgereicht
interp alias child myCmd {} masterCmd extraArg
# child: myCmd a b -> masterCmd extraArg a b (nicht masterCmd a b extraArg)

# Die festen Argumente stehen VOR den dynamischen
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `interp create ?-safe? ?name?` | Interpreter erzeugen |
| `interp delete name` | Interpreter löschen |
| `interp eval path script` | Script ausführen |
| `interp exists name` | Existiert der Interpreter? |
| `interp slaves` | Kind-Interpreter auflisten |
| `interp issafe name` | Ist es ein Safe-Interpreter? |
| `interp alias target alias source cmd ?args?` | Alias erstellen |
| `interp alias target alias` | Alias-Ziel abfragen |
| `interp alias target` | Alle Aliase auflisten |
| `interp hide name cmd` | Befehl verbergen |
| `interp expose name cmd` | Verborgenen Befehl aufdecken |
| `interp hidden name` | Verborgene Befehle auflisten |
| `interp invokehidden name cmd args` | Verborgenen Befehl aufrufen |
| `interp transfer src chan target` | Kanal übertragen |
| `interp share src chan target` | Kanal teilen |
| `interp limit name type options` | Ressourcen-Limit setzen |
| `interp limit name type` | Limit abfragen |

## Siehe auch

- [Namespace](namespace.md) -- Jeder Interpreter hat eigene Namespaces
- [Code laden](source-eval-apply.md) -- `source`, `eval` in Kind-Interpretern
- [Info](info.md) -- `info loaded`, Interpreter-Details
- [Fehlerbehandlung](error-handling.md) -- Error-Propagation zwischen Interpretern
- [Package](package.md) -- Pakete in Kind-Interpretern laden
