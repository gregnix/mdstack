# Tk Listbox-Widget Referenzhandbuch

*Stand: 2026-04-29*

Umfassende deutsche Referenz für das Tk Listbox-Widget (Tcl/Tk 8.6 und 9.x).

## Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Widget erstellen](#widget-erstellen)
3. [Konfigurationsoptionen](#konfigurationsoptionen)
4. [Elemente verwalten](#elemente-verwalten)
5. [Indizes](#indizes)
6. [Selektion](#selektion)
7. [Scrolling](#scrolling)
8. [Bindings und Events](#bindings-und-events)
9. [Styling und Aussehen](#styling-und-aussehen)
10. [Bekannte Probleme und Lösungen](#bekannte-probleme-und-loesungen)
11. [Praxisbeispiele](#praxisbeispiele)

---

## Überblick

Das Listbox-Widget zeigt eine scrollbare Liste von Textzeilen an. Benutzer können einzelne oder mehrere Einträge auswählen.

### Typische Anwendungsfälle

- Dateilisten
- Auswahllisten
- Log-Anzeigen
- Einfache Datenansichten

### Einschränkungen

- Nur Text (keine Bilder, keine Spalten)
- Keine hierarchische Darstellung
- Keine eingebetteten Widgets

Für erweiterte Anforderungen: [ttk::treeview](treeview.md) oder [tablelist](../tablelist/README.md)

---

## Widget erstellen

### Syntax

```tcl
listbox pathName ?options?
```

### Minimales Beispiel

```tcl
listbox .lb
pack .lb

# Einträge hinzufügen
.lb insert end "Eintrag 1"
.lb insert end "Eintrag 2"
.lb insert end "Eintrag 3"
```

### Mit Scrollbar

```tcl
listbox .lb -yscrollcommand {.sb set}
ttk::scrollbar .sb -orient vertical -command {.lb yview}

pack .sb -side right -fill y
pack .lb -side left -fill both -expand 1
```

### Mit beiden Scrollbars (Grid-Layout)

```tcl
listbox .lb -width 40 -height 15 \
    -xscrollcommand {.xsb set} \
    -yscrollcommand {.ysb set}

ttk::scrollbar .xsb -orient horizontal -command {.lb xview}
ttk::scrollbar .ysb -orient vertical -command {.lb yview}

grid .lb -row 0 -column 0 -sticky nsew
grid .ysb -row 0 -column 1 -sticky ns
grid .xsb -row 1 -column 0 -sticky ew

grid rowconfigure . 0 -weight 1
grid columnconfigure . 0 -weight 1
```

---

## Konfigurationsoptionen

### Geometrie

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -width | Integer | Breite in Zeichen (default: 20) |
| -height | Integer | Höhe in Zeilen (default: 10) |
| -setgrid | Boolean | Grid-Geometrie aktivieren |

### Aussehen

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -background / -bg | Farbe | Hintergrundfarbe |
| -foreground / -fg | Farbe | Textfarbe |
| -font | Font | Schriftart |
| -borderwidth / -bd | Pixel | Rahmenbreite |
| -relief | Relief | flat, raised, sunken, groove, ridge |
| -highlightthickness | Pixel | Fokus-Rahmenbreite |
| -highlightcolor | Farbe | Fokus-Rahmenfarbe |
| -highlightbackground | Farbe | Fokus-Rahmenfarbe ohne Fokus |

### Selektion

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -selectmode | Mode | single, browse, multiple, extended |
| -selectbackground | Farbe | Selektions-Hintergrund |
| -selectforeground | Farbe | Selektions-Vordergrund |
| -selectborderwidth | Pixel | Selektions-Rahmen |
| -exportselection | Boolean | Selektion in X-Selection exportieren |

### Selektionsmodi erklärt

| Modus | Beschreibung |
|-------|--------------|
| single | Genau ein Eintrag, Klick wählt aus |
| browse | Wie single, aber Drag ändert Auswahl (default) |
| multiple | Mehrere Einträge, Klick toggelt |
| extended | Mehrere mit Shift/Ctrl |

### Scrolling

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -xscrollcommand | Callback | Callback für horizontale Scrollbar |
| -yscrollcommand | Callback | Callback für vertikale Scrollbar |

### Sonstiges

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -listvariable | Variable | Variable mit der Liste verknüpfen |
| -state | State | normal oder disabled |
| -activestyle | Style | dotbox, underline, none |
| -cursor | Cursor | Mauszeiger |
| -disabledforeground | Farbe | Textfarbe bei disabled |
| -justify | Justify | left, center, right |

---

## Elemente verwalten

### Einfügen

```tcl
# Am Ende einfügen
.lb insert end "Neuer Eintrag"

# Am Anfang einfügen
.lb insert 0 "Erster Eintrag"

# An Position einfügen
.lb insert 5 "An Position 5"

# Mehrere auf einmal
.lb insert end "Eins" "Zwei" "Drei"
```

### Löschen

```tcl
# Einen Eintrag löschen
.lb delete 3

# Bereich löschen (inklusive)
.lb delete 2 5

# Alle löschen
.lb delete 0 end

# Ausgewählte löschen
foreach idx [lsort -integer -decreasing [.lb curselection]] {
    .lb delete $idx
}
```

**Wichtig:** Beim Löschen mehrerer Einträge von hinten nach vorne arbeiten!

### Abfragen

```tcl
# Eintrag an Index abfragen
set item [.lb get 3]

# Bereich abfragen
set items [.lb get 2 5]

# Alle Einträge
set allItems [.lb get 0 end]

# Anzahl Einträge
set count [.lb size]

# Index eines Eintrags suchen (ab Tk 8.5)
# Nicht direkt verfügbar - manuell:
proc findIndex {lb value} {
    set items [$lb get 0 end]
    return [lsearch -exact $items $value]
}
```

### Mit listvariable

```tcl
# Variable verknüpfen
set ::myList {Apfel Birne Kirsche}
listbox .lb -listvariable ::myList
pack .lb

# Liste ändern -> Listbox aktualisiert sich automatisch
lappend ::myList "Orange"
set ::myList [lsort $::myList]
```

---

## Indizes

Die Listbox verwendet verschiedene Index-Formate:

| Index | Beschreibung |
|-------|--------------|
| N | Numerischer Index (0-basiert) |
| active | Aktuell aktives Element |
| anchor | Anker für Bereichsselektion |
| end | Nach dem letzten Element |
| @x,y | Element an Fenster-Koordinate |

### Beispiele

```tcl
# Numerisch
.lb get 0
.lb get 5

# Aktives Element
.lb get active

# Element unter Mausposition
bind .lb <Motion> {
    set idx [%W index @%x,%y]
    if {$idx ne ""} {
        puts "Über Element $idx: [%W get $idx]"
    }
}

# Ende
.lb insert end "Am Ende"

# Index normalisieren
set idx [.lb index end]  ;# Gibt tatsächliche Anzahl
```

### Index aus Koordinaten

```tcl
# Element an Position
set idx [.lb index @$x,$y]

# Bounding Box eines Elements
set bbox [.lb bbox $idx]
# Gibt {x y width height} oder "" wenn nicht sichtbar
```

---

## Selektion

### Auswählen

```tcl
# Einzelnes Element
.lb selection set 3

# Bereich
.lb selection set 2 5

# Zur Selektion hinzufügen
.lb selection set 7

# Auswahl aufheben
.lb selection clear 3
.lb selection clear 0 end  ;# Alles

# Element einschließen/ausschließen
.lb selection includes 3  ;# Gibt 0 oder 1
```

### Aktive Selektion abfragen

```tcl
# Indizes der ausgewählten Elemente
set selectedIndices [.lb curselection]

# Ausgewählte Werte
set selectedValues {}
foreach idx [.lb curselection] {
    lappend selectedValues [.lb get $idx]
}

# Oder kürzer:
set selectedValues [lmap idx [.lb curselection] {.lb get $idx}]
```

### Anker setzen

```tcl
# Anker für Bereichsselektion
.lb selection anchor 5

# Bereich vom Anker bis Index auswählen
.lb selection set anchor 10
```

### Aktives Element

```tcl
# Aktives Element setzen
.lb activate 5

# Aktiven Index abfragen
set activeIdx [.lb index active]
```

### Sichtbar machen

```tcl
# Element sichtbar machen
.lb see 15
```

---

## Scrolling

### Scroll-Befehle

```tcl
# Horizontal
.lb xview            ;# Aktuelle Position {first last}
.lb xview moveto 0.5 ;# Zu Fraktion scrollen
.lb xview scroll 1 units
.lb xview scroll 1 pages

# Vertikal
.lb yview
.lb yview moveto 0.0
.lb yview scroll -1 units
.lb yview scroll 1 pages

# Zu Index scrollen
.lb yview $index
```

### Nächste/vorherige Seite

```tcl
proc pageDown {lb} {
    set height [$lb cget -height]
    $lb yview scroll 1 pages
}

proc pageUp {lb} {
    $lb yview scroll -1 pages
}
```

### Sichtbarer Bereich

```tcl
# Welche Elemente sind sichtbar?
proc getVisibleRange {lb} {
    set first [$lb index @0,0]
    set height [winfo height $lb]
    set last [$lb index @0,$height]
    return [list $first $last]
}
```

---

## Bindings und Events

### Standard-Bindings

| Event | Aktion (browse mode) |
|-------|---------------------|
| Button-1 | Auswählen |
| B1-Motion | Auswahl erweitern |
| Shift-Button-1 | Bereich auswählen |
| Control-Button-1 | Zur Auswahl hinzufügen/entfernen |
| Up/Down | Vorheriges/nächstes Element |
| Home/End | Erstes/letztes Element |
| Page Up/Down | Seite hoch/runter |

### Eigene Bindings

```tcl
# Doppelklick
bind .lb <Double-Button-1> {
    set idx [%W curselection]
    if {$idx ne ""} {
        set value [%W get $idx]
        puts "Doppelklick auf: $value"
    }
}

# Return-Taste
bind .lb <Return> {
    set idx [%W curselection]
    if {$idx ne ""} {
        processSelection %W $idx
    }
}

# Delete-Taste
bind .lb <Delete> {
    foreach idx [lsort -integer -decreasing [%W curselection]] {
        %W delete $idx
    }
}
```

### Virtual Events

```tcl
# <<ListboxSelect>> wird bei Selektionsänderung ausgelöst
bind .lb <<ListboxSelect>> {
    set selection [%W curselection]
    puts "Neue Auswahl: $selection"
}
```

### Kontextmenü

```tcl
menu .popup -tearoff 0
.popup add command -label "Bearbeiten" -command {editSelected .lb}
.popup add command -label "Löschen" -command {deleteSelected .lb}
.popup add separator
.popup add command -label "Alle auswählen" -command {.lb selection set 0 end}

bind .lb <Button-3> {
    # Erst das angeklickte Element auswählen
    set idx [%W index @%x,%y]
    if {$idx ne ""} {
        %W selection clear 0 end
        %W selection set $idx
    }
    tk_popup .popup %X %Y
}
```

---

## Styling und Aussehen

### Farben

```tcl
listbox .lb \
    -background white \
    -foreground black \
    -selectbackground #0078d4 \
    -selectforeground white \
    -highlightthickness 1 \
    -highlightcolor #0078d4
```

### Schriftart

```tcl
listbox .lb -font {Consolas 11}
# oder
listbox .lb -font TkFixedFont
```

### Aktiv-Stil

```tcl
# Kein Indikator für aktives Element
listbox .lb -activestyle none

# Gepunkteter Rahmen (default)
listbox .lb -activestyle dotbox

# Unterstreichung
listbox .lb -activestyle underline
```

### Zebra-Streifen (workaround)

Da Listbox keine itemconfigure unterstützt, sind echte Zebra-Streifen nicht möglich. Alternative: Leerzeichen-Padding oder ttk::treeview verwenden.

---

## Bekannte Probleme und Lösungen

### 1. Löschen mehrerer Elemente

**Problem:** Indizes verschieben sich beim Löschen.

```tcl
# FALSCH - Indizes verschieben sich
foreach idx [.lb curselection] {
    .lb delete $idx
}

# RICHTIG - Von hinten nach vorne
foreach idx [lsort -integer -decreasing [.lb curselection]] {
    .lb delete $idx
}
```

### 2. Selektion geht verloren

**Problem:** Bei -exportselection true geht Selektion verloren, wenn anderes Widget fokussiert wird.

```tcl
# Selektion behalten
listbox .lb -exportselection false
```

### 3. Horizontales Scrollen nicht nötig

**Problem:** Horizontale Scrollbar erscheint auch wenn nicht nötig.

```tcl
# Lösung: Breite dynamisch anpassen oder feste Breite
proc updateWidth {lb} {
    set maxLen 0
    foreach item [$lb get 0 end] {
        set len [string length $item]
        if {$len > $maxLen} {set maxLen $len}
    }
    $lb configure -width [expr {$maxLen + 2}]
}
```

### 4. Element nicht sichtbar nach Insert

**Problem:** Neues Element am Ende ist nicht sichtbar.

```tcl
# Nach Einfügen sichtbar machen
.lb insert end "Neuer Eintrag"
.lb see end
```

### 5. Langsam bei vielen Einträgen

**Problem:** Performance bei >10000 Einträgen.

```tcl
# Lösung: Updates bündeln
proc loadManyItems {lb items} {
    # Listbox temporär verstecken
    set parent [winfo parent $lb]
    pack forget $lb
    
    # Alle auf einmal einfügen
    $lb delete 0 end
    $lb insert end {*}$items
    
    # Wieder anzeigen
    pack $lb -fill both -expand 1
}

# Oder mit listvariable
set ::myList $items  ;# Schneller als einzelne inserts
```

### 6. Fokus-Probleme

**Problem:** Tastatur-Navigation funktioniert nicht.

```tcl
# Fokus explizit setzen
focus .lb

# Nach Klick Fokus behalten
bind .lb <Button-1> {+ focus %W}
```

---

## Praxisbeispiele

### Einfache Dateiliste

```tcl
package require Tk

proc loadDirectory {lb dir} {
    $lb delete 0 end
    
    foreach item [lsort [glob -nocomplain -directory $dir -tails *]] {
        if {[file isdirectory [file join $dir $item]]} {
            $lb insert end "📁 $item"
        } else {
            $lb insert end "📄 $item"
        }
    }
}

# GUI
ttk::frame .f
listbox .f.lb -width 40 -height 20 \
    -yscrollcommand {.f.sb set} \
    -selectmode browse
ttk::scrollbar .f.sb -orient vertical -command {.f.lb yview}

grid .f.lb -row 0 -column 0 -sticky nsew
grid .f.sb -row 0 -column 1 -sticky ns
grid rowconfigure .f 0 -weight 1
grid columnconfigure .f 0 -weight 1

pack .f -fill both -expand 1

# Doppelklick
bind .f.lb <Double-Button-1> {
    set idx [%W curselection]
    if {$idx ne ""} {
        set item [%W get $idx]
        # Ordner-Symbol entfernen
        set name [string range $item 3 end]
        puts "Ausgewählt: $name"
    }
}

# Laden
loadDirectory .f.lb [pwd]
```

### Such-Listbox mit Filter

```tcl
package require Tk

# Daten
set ::allItems {
    "Apple" "Apricot" "Avocado"
    "Banana" "Blackberry" "Blueberry"
    "Cherry" "Coconut" "Cranberry"
    "Date" "Dragonfruit"
}
set ::filteredItems $::allItems

# GUI
ttk::frame .f
ttk::entry .f.search -textvariable ::searchText
listbox .f.lb -listvariable ::filteredItems \
    -yscrollcommand {.f.sb set} -height 10
ttk::scrollbar .f.sb -orient vertical -command {.f.lb yview}

grid .f.search -row 0 -column 0 -columnspan 2 -sticky ew -pady 5
grid .f.lb -row 1 -column 0 -sticky nsew
grid .f.sb -row 1 -column 1 -sticky ns

grid rowconfigure .f 1 -weight 1
grid columnconfigure .f 0 -weight 1

pack .f -fill both -expand 1 -padx 10 -pady 10

# Filter-Funktion
proc filterList {args} {
    set pattern [string tolower $::searchText]
    
    if {$pattern eq ""} {
        set ::filteredItems $::allItems
    } else {
        set ::filteredItems {}
        foreach item $::allItems {
            if {[string match "*$pattern*" [string tolower $item]]} {
                lappend ::filteredItems $item
            }
        }
    }
}

# Trace auf Suchfeld
trace add variable ::searchText write filterList

# Enter für Auswahl
bind .f.lb <Return> {
    set idx [%W curselection]
    if {$idx ne ""} {
        tk_messageBox -message "Ausgewählt: [%W get $idx]"
    }
}

focus .f.search
```

### Dual-Listbox (Auswahl-Dialog)

```tcl
package require Tk

# Daten
set ::available {Montag Dienstag Mittwoch Donnerstag Freitag Samstag Sonntag}
set ::selected {}

# GUI
ttk::frame .f
ttk::label .f.lavail -text "Verfügbar:"
ttk::label .f.lsel -text "Ausgewählt:"

listbox .f.avail -listvariable ::available -selectmode extended \
    -width 20 -height 10 -yscrollcommand {.f.sb1 set}
ttk::scrollbar .f.sb1 -orient vertical -command {.f.avail yview}

listbox .f.sel -listvariable ::selected -selectmode extended \
    -width 20 -height 10 -yscrollcommand {.f.sb2 set}
ttk::scrollbar .f.sb2 -orient vertical -command {.f.sel yview}

ttk::frame .f.btns
ttk::button .f.btns.add -text ">" -width 3 -command addSelected
ttk::button .f.btns.addall -text ">>" -width 3 -command addAll
ttk::button .f.btns.rem -text "<" -width 3 -command removeSelected
ttk::button .f.btns.remall -text "<<" -width 3 -command removeAll
ttk::button .f.btns.up -text "↑" -width 3 -command moveUp
ttk::button .f.btns.down -text "↓" -width 3 -command moveDown

pack .f.btns.add .f.btns.addall .f.btns.rem .f.btns.remall \
    -pady 2
pack .f.btns.up .f.btns.down -pady 10

# Layout
grid .f.lavail -row 0 -column 0 -sticky w
grid .f.lsel -row 0 -column 3 -sticky w
grid .f.avail -row 1 -column 0 -sticky nsew
grid .f.sb1 -row 1 -column 1 -sticky ns
grid .f.btns -row 1 -column 2 -padx 10
grid .f.sel -row 1 -column 3 -sticky nsew
grid .f.sb2 -row 1 -column 4 -sticky ns

grid rowconfigure .f 1 -weight 1
grid columnconfigure .f {0 3} -weight 1

pack .f -fill both -expand 1 -padx 10 -pady 10

# Funktionen
proc addSelected {} {
    foreach idx [lsort -integer -decreasing [.f.avail curselection]] {
        set item [.f.avail get $idx]
        lappend ::selected $item
        set pos [lsearch -exact $::available $item]
        set ::available [lreplace $::available $pos $pos]
    }
}

proc addAll {} {
    set ::selected [concat $::selected $::available]
    set ::available {}
}

proc removeSelected {} {
    foreach idx [lsort -integer -decreasing [.f.sel curselection]] {
        set item [.f.sel get $idx]
        lappend ::available $item
        set pos [lsearch -exact $::selected $item]
        set ::selected [lreplace $::selected $pos $pos]
    }
    set ::available [lsort $::available]
}

proc removeAll {} {
    set ::available [lsort [concat $::available $::selected]]
    set ::selected {}
}

proc moveUp {} {
    set idxs [.f.sel curselection]
    if {[llength $idxs] != 1} return
    set idx [lindex $idxs 0]
    if {$idx == 0} return
    
    set item [lindex $::selected $idx]
    set ::selected [lreplace $::selected $idx $idx]
    set ::selected [linsert $::selected [expr {$idx - 1}] $item]
    .f.sel selection clear 0 end
    .f.sel selection set [expr {$idx - 1}]
}

proc moveDown {} {
    set idxs [.f.sel curselection]
    if {[llength $idxs] != 1} return
    set idx [lindex $idxs 0]
    if {$idx >= [llength $::selected] - 1} return
    
    set item [lindex $::selected $idx]
    set ::selected [lreplace $::selected $idx $idx]
    set ::selected [linsert $::selected [expr {$idx + 1}] $item]
    .f.sel selection clear 0 end
    .f.sel selection set [expr {$idx + 1}]
}

# Doppelklick-Bindings
bind .f.avail <Double-Button-1> addSelected
bind .f.sel <Double-Button-1> removeSelected
```

### Log-Viewer mit Auto-Scroll

```tcl
package require Tk

# GUI
ttk::frame .f
listbox .f.log -width 80 -height 25 \
    -font TkFixedFont \
    -yscrollcommand {.f.sb set} \
    -selectmode extended
ttk::scrollbar .f.sb -orient vertical -command {.f.log yview}

ttk::checkbutton .f.auto -text "Auto-Scroll" -variable ::autoScroll
set ::autoScroll 1

ttk::button .f.clear -text "Löschen" -command {.f.log delete 0 end}

grid .f.log -row 0 -column 0 -sticky nsew
grid .f.sb -row 0 -column 1 -sticky ns
grid .f.auto -row 1 -column 0 -sticky w -pady 5
grid .f.clear -row 1 -column 0 -sticky e -pady 5

grid rowconfigure .f 0 -weight 1
grid columnconfigure .f 0 -weight 1

pack .f -fill both -expand 1 -padx 5 -pady 5

# Log-Funktion
proc log {level message} {
    set timestamp [clock format [clock seconds] -format "%H:%M:%S"]
    set entry "\[$timestamp\] \[$level\] $message"
    
    .f.log insert end $entry
    
    # Limit auf 1000 Einträge
    if {[.f.log size] > 1000} {
        .f.log delete 0
    }
    
    # Auto-Scroll
    if {$::autoScroll} {
        .f.log see end
    }
}

# Demo: Periodische Log-Einträge
set ::logMessages {
    {INFO "Application started"}
    {DEBUG "Loading configuration..."}
    {INFO "Configuration loaded"}
    {WARN "Deprecated API used"}
    {ERROR "Connection timeout"}
    {INFO "Retrying connection..."}
    {INFO "Connected successfully"}
    {DEBUG "Processing request #1234"}
}

proc demoLog {} {
    set msg [lindex $::logMessages [expr {int(rand() * [llength $::logMessages])}]]
    log {*}$msg
    after 1000 demoLog
}

demoLog
```

---

## Siehe auch

- [text.md](text.md) - Text-Widget für formatierte Texte
- [treeview.md](treeview.md) - ttk::treeview für hierarchische Listen
- [canvas.md](canvas.md) - Canvas für grafische Darstellungen
- **Tcl/Tk Manual:** https://www.tcl-lang.org/man/tcl8.6/TkCmd/listbox.html
