# try -- Strukturierte Fehlerbehandlung in Tcl

*Stand: 2026-04-29*

**Seit:** Tcl 8.6 (TIP #329)

**Quelle:** https://www.tcl-lang.org/man/tcl/TclCmd/try.htm

## Übersicht

Der `try`-Befehl wertet ein Script aus und führt je nach
Rueckgabecode weitere Handler-Scripts aus. Optional wird
ein abschliessendes `finally`-Script ausgeführt, das immer
läuft -- auch bei Fehlern oder wenn ein Handler die Prozedur
mit `return` verlässt.

`try` ist die empfohlene Alternative zu `catch` wenn verschiedene
Fehlerarten differenziert behandelt werden sollen oder wenn
Ressourcen zuverlässig freigegeben werden müssen.

## Syntax

```tcl
try body ?handler ...? ?finally script?
```

Ein Handler hat eine von zwei Formen:

```tcl
on code varList handlerBody
trap errorPattern varList handlerBody
```

Die `varList` enthält null, ein oder zwei Variablennamen:
der erste empfaengt das Ergebnis des Body-Scripts, der zweite
das Return-Options-Dictionary.

## Grundlagen

### Einfachste Form

Ohne Handler und ohne `finally` verhält sich `try` wie `eval`,
ist aber bytecode-kompiliert und damit schneller:

```tcl
try { set x 1 }
# -> 1

try { set x $nosuchvar }
# -> Fehler wird propagiert (kein Handler definiert)
```

### Einfache Fehlerbehandlung

```tcl
try {
    set fd [open "config.ini" r]
    set data [read $fd]
    close $fd
} on error {result ropts} {
    puts "Fehler: $result"
}
```

Der `on error`-Handler fängt jeden Fehler (Return-Code 1) ab.
Die Variable `result` enthält die Fehlermeldung, `ropts` das
Return-Options-Dictionary mit `-errorcode`, `-errorinfo` usw.

## Die Handler-Typen

### on -- Handler nach Return-Code

`on` fängt einen bestimmten Return-Code ab. Der Code kann als
Zahl oder als Mnemonic angegeben werden:

| Mnemonic | Code | Bedeutung |
|:---------|:-----|:----------|
| `ok` | 0 | Normales Ergebnis |
| `error` | 1 | Fehler |
| `return` | 2 | return aus Script |
| `break` | 3 | break aus Schleife |
| `continue` | 4 | continue aus Schleife |
| 5-0x3FFFFFFF | 5+ | Benutzerdefinierte Codes |

```tcl
try {
    someCommand
} on ok {result} {
    puts "Erfolg: $result"
} on error {result} {
    puts "Fehler: $result"
} on return {result} {
    puts "Return: $result"
} on break {} {
    puts "Break empfangen"
} on continue {} {
    puts "Continue empfangen"
}
```

### trap -- Handler nach Error-Code

`trap` fängt ausschliesslich Fehler ab (Return-Code 1), bei
denen der `-errorcode` mit dem angegebenen Pattern beginnt.
Das Pattern wird als Präfix-Liste geprüft -- zusätzliche
Elemente im Error-Code werden ignoriert.

```tcl
try {
    set fd [open "/tmp/config.ini" r]
    set data [read $fd]
    close $fd
} trap {POSIX ENOENT} {result} {
    # Datei nicht gefunden
    puts "Datei existiert nicht: $result"
} trap {POSIX EACCES} {result} {
    # Keine Berechtigung
    puts "Zugriff verweigert: $result"
} on error {result} {
    # Alle anderen Fehler
    puts "Unbekannter Fehler: $result"
}
```

Das Pattern `{POSIX ENOENT}` passt auf jeden Error-Code, der
mit den Elementen `POSIX` und `ENOENT` beginnt, z.B.
`{POSIX ENOENT {no such file or directory}}`.

Ein leeres Pattern `trap {} ...` ist aequivalent zu `on error ...`
und fängt alle Fehler unabhängig vom Error-Code ab.

### Arithmetik-Fehler differenzieren

```tcl
proc safe_div {a b} {
    try {
        return [expr {$a / $b}]
    } trap {ARITH DIVZERO} {result} {
        # Division durch Null: Infinity zurückgeben
        return [expr {$a / 0.0}]
    } trap {ARITH} {result} {
        # Andere Arithmetik-Fehler (Domain, Overflow, ...)
        puts "Rechenfehler: $result"
        return NaN
    }
}

safe_div 4 2     ;# -> 2
safe_div 4 0     ;# -> Inf  (statt Fehler)
safe_div 4 0.0   ;# -> Inf  (kein Fehler, kein Handler nötig)
```

## Reihenfolge der Handler

Handler werden in der angegebenen Reihenfolge geprüft. Der
erste passende Handler wird ausgeführt, alle weiteren ignoriert.

Daraus folgt eine kritische Regel: `trap`-Handler müssen immer
**vor** `on error` stehen. Ein `on error`-Handler fängt alle
Fehler ab und macht nachfolgende `trap`-Handler unerreichbar.

```tcl
# FALSCH: on error steht vor trap
try {
    riskyOp
} on error {result} {
    puts "Fehler"              ;# fängt ALLES ab
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"         ;# wird NIE ausgeführt!
}

# RICHTIG: trap vor on error
try {
    riskyOp
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"         ;# spezifisch zuerst
} on error {result} {
    puts "Anderer Fehler"      ;# Auffang-Handler zuletzt
}
```

Ebenso sollten spezifischere `trap`-Pattern vor allgemeineren
stehen -- vom Speziellen zum Allgemeinen:

```tcl
try {
    riskyOp
} trap {POSIX ENOENT} {result} {
    # Sehr spezifisch: Datei nicht gefunden
} trap {POSIX} {result} {
    # Allgemeiner: Jeder POSIX-Fehler
} on error {result} {
    # Am allgemeinsten: Jeder Fehler
}
```

## Handler-Weiterleitung mit Bindestrich

Wenn der Handler-Body ein einzelner Bindestrich `-` ist, wird
stattdessen der Body des nächsten Handlers verwendet. Damit
lassen sich mehrere Bedingungen auf denselben Code abbilden:

```tcl
try {
    connectToServer $host
} trap {NETWORK TIMEOUT} {result} - \
  trap {NETWORK REFUSED} {result} - \
  trap {NETWORK UNREACHABLE} {result} {
    # Gleiche Behandlung für alle drei Netzwerk-Fehler
    puts "Verbindungsproblem: $result"
    retryWithFallback $host
}
```

## Die varList im Detail

Die `varList` enthält null, ein oder zwei Variablennamen.
Fehlende oder leere Variablennamen überspringen die Zuweisung.

```tcl
# Zwei Variablen: Ergebnis und Options-Dictionary
try {
    error "Testfehler"
} on error {result ropts} {
    puts "Ergebnis: $result"
    puts "Error-Code: [dict get $ropts -errorcode]"
    puts "Stack-Trace: [dict get $ropts -errorinfo]"
}

# Eine Variable: Nur das Ergebnis
try {
    error "Testfehler"
} on error {result} {
    puts "Ergebnis: $result"
}

# Keine Variablen: Nichts zugewiesen
try {
    error "Testfehler"
} on error {} {
    puts "Ein Fehler ist aufgetreten"
}

# Zweite Variable überspringen (leerer Name)
try {
    error "Testfehler"
} on error {result {}} {
    puts "Ergebnis: $result"
}
```

Das Return-Options-Dictionary (`ropts`) enthält bei Fehlern
folgende Schlüssel:

| Schlüssel | Inhalt |
|:-----------|:-------|
| `-code` | Return-Code (1 bei Fehler) |
| `-errorcode` | Maschinenlesbarer Error-Code (Liste) |
| `-errorinfo` | Stack-Trace (Zeichenkette) |
| `-errorline` | Zeilennummer des Fehlers |
| `-errorstack` | Strukturierter Stack (Token-Wert-Paare) |
| `-level` | Stack-Level |

## finally -- Ressourcen zuverlässig freigeben

Der `finally`-Block wird **immer** ausgeführt, egal ob:

- das Body-Script erfolgreich war
- ein Fehler aufgetreten ist
- ein Handler ausgeführt wurde
- ein Handler die Prozedur mit `return` verlassen hat

Die einzige Ausnahme: Der Interpreter wird im Body oder
Handler gelöscht.

### Typisches Muster: Datei sicher schließen

```tcl
set fd [open "daten.txt" r]
try {
    set data [read $fd]
    return [parseData $data]
} finally {
    close $fd
}
```

Hier wird `close $fd` auch dann ausgeführt, wenn `read` oder
`parseData` einen Fehler auslöst oder das `return` die Prozedur
verlässt.

### finally mit Handlern kombiniert

```tcl
set fd [open "daten.csv" r]
try {
    set data [read $fd]
    return [parseCsv $data]
} trap {PARSE CSV} {result} {
    puts "CSV-Fehler: $result"
    return [list]
} on error {result} {
    puts "Unerwarteter Fehler: $result"
    return [list]
} finally {
    close $fd
    puts "Datei geschlossen"
}
```

### Rückgabewert und finally

Wenn `finally` normal abschliesst (ohne Exception), wird sein
Ergebnis verworfen. Das Ergebnis des Body- oder Handler-Scripts
wird als Ergebnis von `try` propagiert.

Wenn `finally` eine Exception auslöst (z.B. durch `return` oder
`error`), überschreibt diese das vorherige Ergebnis. Das
Return-Options-Dictionary des Body/Handlers wird dann unter dem
Schlüssel `-during` im neuen Options-Dictionary gespeichert.

```tcl
proc demo {finallyReturn} {
    set result_list [list]
    try {
        error "BAM"
    } trap {} {} {
        lappend result_list "Trap"
        return "return from trap"
    } finally {
        lappend result_list "Finally"
        if {$finallyReturn} {
            return "return from finally"
        }
    }
    return "return from proc end"
}

demo 0   ;# -> "return from trap"    (finally aendert nichts)
demo 1   ;# -> "return from finally" (finally überschreibt)
```

## Propagation: Was passiert ohne Handler?

Wenn kein passender Handler für den Return-Code existiert,
wird der Code samt Ergebnis und Options-Dictionary an den
Aufrufer weitergeleitet (propagiert). Das ist ein wichtiger
Unterschied zu `catch`, das alle Codes abfaengt.

```tcl
# break wird propagiert (kein on break Handler)
foreach item {1 2 3} {
    try {
        if {$item == 2} break
        puts $item
    } on error {result} {
        puts "Fehler: $result"
    }
}
# Ausgabe: 1  (break bei item=2 beendet foreach)
```

Dies ist ein grosser Vorteil gegenüber `catch`: `try` mit
`on error` fängt nur Fehler, lässt aber `break`, `continue`
und `return` durch. `catch` verschluckt dagegen alles.

## try vs. catch

| Aspekt | `catch` | `try` |
|:-------|:--------|:------|
| Verfügbar seit | Tcl 8.0 | Tcl 8.6 |
| Handler | Einer für alles | Mehrere, nach Code/Error-Code |
| Error-Code prüfen | Manuell mit `lindex` | `trap` mit Pattern |
| Ressourcen-Cleanup | Manuell kodieren | `finally`-Klausel |
| break/continue | Wird verschluckt | Wird propagiert (bei `on error`) |
| Empfehlung | Einfache Fälle, Legacy | Differenzierte Behandlung |

### Aequivalenz-Beispiel

Dieselbe Logik einmal mit `catch`, einmal mit `try`:

```tcl
# Mit catch: Manuell und fehleranfällig
set fd [open "daten.txt" r]
set code [catch {
    set data [read $fd]
    processData $data
} result ropts]
close $fd
if {$code != 0} {
    set ec [dict get $ropts -errorcode]
    if {[lindex $ec 0] eq "POSIX" && [lindex $ec 1] eq "ENOENT"} {
        puts "Datei nicht gefunden"
    } else {
        return -options $ropts $result
    }
}
```

```tcl
# Mit try: Klar strukturiert
set fd [open "daten.txt" r]
try {
    set data [read $fd]
    processData $data
} trap {POSIX ENOENT} {result} {
    puts "Datei nicht gefunden"
} finally {
    close $fd
}
```

## Praxis-Beispiele

### Datenbank-Zugriff absichern

```tcl
proc queryDatabase {dsn sql} {
    set db [openDatabase $dsn]
    try {
        set stmt [$db prepare $sql]
        try {
            set rows [$stmt allrows]
            return $rows
        } finally {
            $stmt close
        }
    } finally {
        $db close
    }
}
```

### Netzwerk-Operation mit Retry

```tcl
proc fetchWithRetry {url {maxRetries 3}} {
    for {set i 0} {$i < $maxRetries} {incr i} {
        try {
            set token [http::geturl $url -timeout 5000]
            try {
                set data [http::data $token]
                return $data
            } finally {
                http::cleanup $token
            }
        } trap {POSIX ECONNREFUSED} {result} - \
          trap {POSIX ETIMEDOUT} {result} {
            if {$i < $maxRetries - 1} {
                after [expr {1000 * ($i + 1)}]
            }
        }
    }
    throw {NETWORK EXHAUSTED} \
        "Alle $maxRetries Versuche für $url fehlgeschlagen"
}
```

### Temporaere Datei sicher verwenden

```tcl
proc processWithTempFile {data} {
    set tmpfile [file tempfile tmpfd ".tmp"]
    try {
        puts $tmpfd $data
        close $tmpfd
        set tmpfd ""
        # Externe Verarbeitung
        exec tool --input $tmpfile --output result.txt
        set fd [open "result.txt" r]
        try {
            return [read $fd]
        } finally {
            close $fd
        }
    } finally {
        if {$tmpfd ne ""} {
            catch {close $tmpfd}
        }
        file delete -force $tmpfile
    }
}
```

### exec-Fehler differenzieren

Beim Aufruf externer Programme erzeugt `exec` verschiedene
Error-Codes die sich mit `trap` sauber unterscheiden lassen:

```tcl
try {
    set result [exec someprogram arg1 arg2]
} trap NONE {output} {
    # Programm beendete mit Exit-Code 0, hat aber
    # auf stderr geschrieben
    puts "Warnung: $output"
} trap CHILDSTATUS {output} {
    # Programm beendete mit Exit-Code != 0
    puts "Fehler: $output"
} trap CHILDKILLED {output} {
    # Programm wurde durch Signal beendet
    puts "Abgebrochen: $output"
}
```

### Eigene Kontrollstruktur mit try

`try` kann als Shim verwendet werden, um ein ganzes Script
dort zu übergeben, wo ein einzelner Befehl erwartet wird.
Im Gegensatz zu `eval` ist `try` bytecode-kompiliert:

```tcl
# Coroutine mit Script statt Befehl
coroutine gen try {
    yield 3
    yield 7
    yield 23
}

gen  ;# -> 3
gen  ;# -> 7
gen  ;# -> 23
```

### tailcall mit try

Die Kombination `tailcall` und `try` kann `uplevel 1` ersetzen,
wenn der `uplevel`-Aufruf der letzte Befehl einer Prozedur ist.
Der Vorteil: `tailcall` macht den Aufrufer zum Ausfuehrenden,
während `uplevel` nur auf dessen Variablen zugreift.

```tcl
proc myCommand {script} {
    # Statt: uplevel 1 $script
    tailcall try $script
}
```

### bgerror und try

Fehler in Event-Callbacks (z.B. `after`-Callbacks) erreichen
keinen umgebenden `catch` oder `try`. Seit Tcl 8.6 lassen sie
sich mit `interp bgerror` behandeln:

```tcl
proc myBgError {msg opts} {
    set code [dict get $opts -errorcode]
    puts stderr "Background-Fehler \[$code\]: $msg"
    puts stderr [dict get $opts -errorinfo]
}
interp bgerror {} myBgError
```

## Zusammenspiel mit throw

`throw` (seit Tcl 8.6) ist der bevorzugte Partner für `try`,
weil er einen Error-Code erzwingt. Das ermöglicht praezise
`trap`-Handler:

```tcl
# Fehler definieren
proc getItem {db id} {
    set rows [$db allrows "SELECT * FROM items WHERE id = :id"]
    if {[llength $rows] == 0} {
        throw {APP ITEM NOTFOUND} "Item $id nicht gefunden"
    }
    return [lindex $rows 0]
}

# Fehler differenziert abfangen
try {
    set item [getItem $db $id]
    displayItem $item
} trap {APP ITEM NOTFOUND} {msg} {
    createNewItem $db $id
} trap {APP} {msg} {
    puts "Anwendungsfehler: $msg"
}
```

### Error-Code-Konventionen

Error-Codes sind Listen. Die Konvention ist hierarchisch
vom Modul zum Detail:

```tcl
# {MODUL KATEGORIE ?DETAIL?}
throw {MYAPP NOTFOUND}      "Eintrag nicht gefunden"
throw {MYAPP AUTH EXPIRED}   "Token abgelaufen"
throw {MYAPP INPUT RANGE}    "Wert ausserhalb des Bereichs"
```

Tcl-eigene Error-Codes:

| Präfix | Bedeutung | Beispiele |
|:--------|:----------|:----------|
| `TCL` | Tcl-interne Fehler | `TCL READ VARNAME`, `TCL LOOKUP VARNAME x` |
| `POSIX` | Betriebssystem-Fehler | `POSIX ENOENT`, `POSIX EACCES`, `POSIX EISDIR` |
| `ARITH` | Arithmetik-Fehler | `ARITH DIVZERO`, `ARITH DOMAIN`, `ARITH OVERFLOW` |
| `NONE` | Kein spezifischer Code | exec-Warnung (stderr-Ausgabe) |
| `CHILDSTATUS` | Kindprozess-Exit | `CHILDSTATUS pid exitcode` |
| `CHILDKILLED` | Kindprozess-Signal | `CHILDKILLED pid signal msg` |

## Häufige Fehler und Fallen

### Falle 1: Handler in falscher Reihenfolge

```tcl
# FALSCH: on error vor trap
try {
    riskyOp
} on error {result} {
    puts "Fehler"
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"   ;# wird NIE ausgeführt!
}

# RICHTIG: trap vor on error
try {
    riskyOp
} trap {POSIX ENOENT} {result} {
    puts "Datei fehlt"
} on error {result} {
    puts "Anderer Fehler"
}
```

### Falle 2: Fehler verschlucken

```tcl
# SCHLECHT: Alle Fehler ignoriert
try {
    riskyOp
} on error {} {}

# BESSER: Nur erwartete Fehler abfangen
try {
    riskyOp
} trap {EXPECTED ERROR} {result} {
    handleExpectedError $result
}
# Unerwartete Fehler werden automatisch weitergeleitet!
```

### Falle 3: Ressource vor try oeffnen

Die Ressource muss **vor** dem `try`-Block geoeffnet werden,
damit `finally` sie schließen kann. Wenn `open` selbst
fehlschlaegt, gibt es nichts zu schließen.

```tcl
# RICHTIG: open vor try
set fd [open "daten.txt" r]
try {
    set data [read $fd]
} finally {
    close $fd
}
```

```tcl
# FALSCH: open innerhalb von try, aber fd in finally verwendet
try {
    set fd [open "daten.txt" r]
    set data [read $fd]
} finally {
    close $fd   ;# Fehler wenn open fehlschlug: fd existiert nicht!
}
```

### Falle 4: catch vs. try bei break/continue

```tcl
# PROBLEM: catch verschluckt break
foreach item $list {
    catch {
        process $item
        if {$done} break   ;# break wird von catch verschluckt!
    }
}

# LOESUNG: try mit on error lässt break durch
foreach item $list {
    try {
        process $item
        if {$done} break   ;# break geht an foreach
    } on error {result} {
        puts "Fehler bei $item: $result"
    }
}
```

### Falle 5: finally verändert Rückgabewert

```tcl
# UEBERRASCHUNG: finally kann den Rückgabewert überschreiben
proc überraschung {} {
    try {
        return "gewollt"
    } finally {
        return "ungewollt"
    }
}
überraschung   ;# -> "ungewollt" (nicht "gewollt"!)
```

In `finally` sollte normalerweise kein `return` stehen. Der
Block dient dem Aufräumen, nicht dem Festlegen von Ergebnissen.

## Vollständige Referenz der Propagation

Das Ergebnis und der Return-Code von `try` werden wie folgt
bestimmt:

1. `body` wird ausgewertet.
2. Handler werden der Reihe nach gegen den Return-Code (und
   bei `trap` gegen den Error-Code) geprüft.
3. Wird ein passender Handler gefunden, wird dessen Body
   ausgeführt. Das Ergebnis des Handlers wird zum Ergebnis
   von `try`.
4. Wird kein passender Handler gefunden, werden Return-Code
   und Ergebnis des Body-Scripts propagiert.
5. `finally` wird ausgeführt (falls vorhanden).
6. Schliesst `finally` normal ab, wird sein Ergebnis verworfen.
7. Loest `finally` eine Exception aus, überschreibt diese
   das bisherige Ergebnis. Die vorherigen Return-Options
   werden unter `-during` im neuen Options-Dictionary gespeichert.

## Entscheidungshilfe

| Situation | Empfehlung |
|:----------|:-----------|
| Neuen Fehler auslösen | `throw {CODE} "Nachricht"` |
| Einfach abfangen | `catch { ... } result` |
| Differenziert abfangen | `try { ... } trap {CODE} { ... }` |
| Ressource sicher schließen | `try { ... } finally { close $fd }` |
| Gefangene Exception weiterleiten | `return -options $ropts $result` |
| break/continue nicht verschlucken | `try` statt `catch` verwenden |

## Siehe auch

- `catch` -- Einfache Fehlerbehandlung (seit Tcl 8.0)
- `throw` -- Fehler mit Error-Code auslösen (seit Tcl 8.6)
- `error` -- Klassischer Fehlerbefehl
- `return` -- Return-Code und Options-Dictionary steuern
- `info errorstack` -- Strukturierter Fehler-Stack

---

*Quellen: Tcl/Tk 8.6 Referenz, Tcl Programming with the Tcl/Tk 8.5+,
Tcler's Wiki (try), error-handling.md*
