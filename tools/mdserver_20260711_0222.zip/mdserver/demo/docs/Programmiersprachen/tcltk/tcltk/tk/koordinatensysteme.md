# Koordinatensysteme in Tcl/Tk

*Stand: 2026-04-29*

Übersicht aller Koordinatensysteme die in Tcl/Tk und pdf4tcl vorkommen --
woher der Ursprung (0,0) kommt, in welche Richtung y wächst, und wie man
zwischen den Systemen wechselt.

## Inhaltsverzeichnis

1. [Überblick: alle Systeme auf einen Blick](#überblick)
2. [Tk-Fenster und Widgets](#tk-fenster-und-widgets)
3. [tk::canvas](#tkcanvas)
4. [tko::path](#tkopath)
5. [pack und grid](#pack-und-grid)
6. [place](#place)
7. [pdf4tcl orient false](#pdf4tcl-orient-false)
8. [pdf4tcl orient true](#pdf4tcl-orient-true)
9. [Konvertierungen](#konvertierungen)
10. [Häufige Fehler](#häufige-fehler)

---

## Überblick

| System | Ursprung (0,0) | Y-Richtung | Einheit |
|--------|---------------|------------|---------|
| Tk-Fenster | oben links | nach unten | Pixel |
| tk::canvas | oben links | nach unten | Pixel |
| tko::path | oben links | nach unten | Pixel |
| pack / grid | oben links | nach unten | Pixel |
| place | oben links (default) | nach unten | Pixel oder relativ 0.0..1.0 |
| pdf4tcl `-orient false` | **unten links** | **nach oben** | Points (1/72 inch) |
| pdf4tcl `-orient true` | oben links | nach unten | Points (1/72 inch) |

**Faustregel:** Alles in Tk hat den Ursprung oben links mit y nach unten.
pdf4tcl mit `-orient false` (Standard-PDF) ist das einzige System das
davon abweicht -- daher immer `-orient true` verwenden.

---

## Tk-Fenster und Widgets

```
(0,0) ─────────────→ X
  │
  │   Fenster
  ↓
  Y
```

```tcl
# Position und Größe eines Widgets
set x [winfo x .btn]       ;# Pixel von links des Eltern-Containers
set y [winfo y .btn]       ;# Pixel von oben des Eltern-Containers
set w [winfo width .btn]
set h [winfo height .btn]

# Absolute Bildschirmkoordinaten
set rx [winfo rootx .btn]
set ry [winfo rooty .btn]

# Mausposition im Fenster (Event-Binding)
bind . <Motion> {
    set mx %x    ;# Pixel von links
    set my %y    ;# Pixel von oben
}
```

---

## tkcanvas

Identisch zu Tk-Fensterkoordinaten -- Ursprung oben links, Y nach unten:

```
(0,0) ─────────────→ X
  │
  │   Canvas
  ↓
  Y
```

```tcl
canvas .c -width 400 -height 300

# x=50, y=100: 50px von links, 100px von oben
.c create oval 50 100 150 200 -fill blue
.c create text 100 50 -text "Titel" -anchor n

# Mauskoordinaten -- canvasx/canvasy bei Scrolling wichtig!
bind .c <Button-1> {
    set cx [%W canvasx %x]   ;# Canvas-X (inkl. Scroll-Offset)
    set cy [%W canvasy %y]   ;# Canvas-Y
}

# Bounding Box
set bb [.c bbox $item]     ;# {x1 y1 x2 y2}
set bb [.c bbox all]       ;# alle Items
```

**Bei gescrolltem Canvas:** `%x`/`%y` sind Fenster-Pixel, nicht
Canvas-Koordinaten. Immer `canvasx`/`canvasy` verwenden:

```tcl
# scrollregion definiert den virtuellen Canvas-Bereich
.c configure -scrollregion {0 0 2000 1500}

# Nach Scrolling stimmen %x/%y nicht mehr mit Canvas-Coords überein
bind .c <Button-1> {
    set x [%W canvasx %x]   ;# RICHTIG
    # set x %x              ;# FALSCH bei gescrolltem Canvas
}
```

---

## tkopath

Identisch zu `tk::canvas` -- oben links, Y nach unten, Einheit Pixel.

```tcl
package require tko
catch { set ::path::antialias 1 }

tko::path .p -width 400 -height 300

# rect: x1 y1 x2 y2 (Bounding Box, wie canvas rectangle)
.p create rect 50 20 200 100 -rx 8 -fill "#b3d1f0"

# circle: Mittelpunkt cx cy, Radius als Option
.p create circle 150 150 -r 50 -fill "#ffcccc"

# text: x y ist Baseline des Textes
.p create text 200 50 -text "Titel" -fontsize 16 -textanchor middle
```

**Einziger Unterschied zu canvas:** `-fontsize` ist in **Pixel** (nicht Points).

**PDF-Export:** `-bbox all` ist Pflicht:
```tcl
$pdf canvas .p -bbox [.p bbox all] -x 50 -y 50 -width 400 -height 300
```

---

## pack und grid

`pack` und `grid` berechnen Positionen automatisch -- kein explizites
Koordinatensystem. Intern: oben links, Y nach unten, Einheit Pixel.

```tcl
# pack: Widgets stapeln
pack .lbl -side top -padx 10 -pady 5    ;# padx/pady in Pixel

# grid: tabellarisches Layout
grid .lbl   -row 0 -column 0 -padx 5 -pady 5
grid .entry -row 0 -column 1 -sticky ew

# Elastisches Layout: Gewichtung
grid columnconfigure . 1 -weight 1   ;# Spalte 1 wächst
grid rowconfigure . 2 -weight 1      ;# Zeile 2 wächst
```

---

## place

`place` erlaubt absolute Pixel-Koordinaten **oder** relative Positionen
(0.0..1.0 = Anteil des Eltern-Containers):

```tcl
# Absolut
place .w -x 50 -y 100 -width 200 -height 80

# Relativ -- zentriert
place .w -relx 0.5 -rely 0.5 -anchor center -width 200 -height 80

# Gemischt: horizontal zentriert, 20px von oben
place .w -relx 0.5 -y 20 -anchor n -width 200 -height 80

# Ecken
place .w -relx 0.0 -rely 1.0 -anchor sw   ;# unten links
place .w -relx 1.0 -rely 0.0 -anchor ne   ;# oben rechts
place .w -relx 1.0 -rely 1.0 -anchor se   ;# unten rechts
```

**Anker-Werte:** `n ne e se s sw w nw center`

---

## pdf4tcl orient false

Standard-PDF-Koordinatensystem (kartesisch):

```
  Y
  ↑
  │   PDF-Seite A4
  │   Höhe: 841.89pt
(0,0)────────────→ X
     Breite: 595.28pt
```

```tcl
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient false]
$pdf startPage

# y=50: nahe UNTEN (50pt vom Seitenboden)
$pdf text "Fußzeile" -x 50 -y 50

# y=800: nahe OBEN (800pt vom Seitenboden = 41pt vom Seitenrand oben)
$pdf text "Kopfzeile" -x 50 -y 800

# Nächste Zeile: y nimmt AB (nach unten = kleinerer Wert)
set y 750
$pdf text "Zeile 1" -x 50 -y $y
set y [expr {$y - 16}]
$pdf text "Zeile 2" -x 50 -y $y
```

---

## pdf4tcl orient true

Empfohlener Modus -- entspricht Tk-Canvas und HTML:

```
(0,0)────────────→ X
  │   Breite: 595.28pt
  │   PDF-Seite A4
  ↓
  Y
  Höhe: 841.89pt
```

```tcl
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

# y=50: nahe OBEN (50pt vom Seitenrand oben)
$pdf text "Kopfzeile" -x 50 -y 50

# y=800: nahe UNTEN
$pdf text "Fußzeile" -x 50 -y 800

# Nächste Zeile: y nimmt ZU (nach unten = größerer Wert)
set y 80
$pdf text "Zeile 1" -x 50 -y $y
set y [expr {$y + 16}]
$pdf text "Zeile 2" -x 50 -y $y
```

**Mit pdf4tcllib page::context:**

```tcl
set ctx [pdf4tcllib::page::context a4 -margin 25 -orient true]

# top:    kleiner Wert ~71pt -- Textbeginn oben
# bottom: großer Wert ~771pt -- Textende unten

set y [dict get $ctx top]
$pdf text "Erste Zeile" -x [dict get $ctx left] -y $y
pdf4tcllib::page::_advance $ctx y 16   ;# y += 16
$pdf text "Zweite Zeile" -x [dict get $ctx left] -y $y
```

---

## Konvertierungen

### Pixel ↔ Points

```tcl
proc px2pt {px {dpi 96}} { expr {$px * 72.0 / $dpi} }
proc pt2px {pt {dpi 96}} { expr {$pt * $dpi / 72.0} }

proc mm2pt {mm} { expr {$mm / 25.4 * 72.0} }
proc pt2mm {pt} { expr {$pt * 25.4 / 72.0} }
proc cm2pt {cm} { expr {$cm / 2.54 * 72.0} }
```

**Tabelle bei 96 dpi:**

| Pixel | Points |
|-------|--------|
| 8 px | 6 pt |
| 12 px | 9 pt |
| 16 px | 12 pt |
| 20 px | 15 pt |
| 24 px | 18 pt |
| 32 px | 24 pt |

### orient false ↔ orient true

```tcl
set pageH 841.89   ;# A4-Höhe in Points

# orient false -> orient true (und umgekehrt)
proc flipY {y pageH} { expr {$pageH - $y} }

# Beispiel: y=750 (orient false) = y=91.89 (orient true)
set y_true [flipY 750 841.89]   ;# 91.89pt
```

---

## Häufige Fehler

### pdf4tcl: y-Richtung verwechselt

```tcl
# orient true -- y wächst nach UNTEN
set pdf [::pdf4tcl::new %AUTO% -paper a4 -orient true]
$pdf startPage

# FALSCH: y=750 ist fast unten (wie orient false gedacht)
$pdf text "Kopfzeile?" -x 50 -y 750   ;# landet fast am Seitenrand unten!

# RICHTIG: y=50 ist oben bei orient true
$pdf text "Kopfzeile" -x 50 -y 50
```

### pdf4tcl: Text-Baseline vergessen

```tcl
# y bei $pdf text ist die BASELINE, nicht die Oberkante des Textes
# Ascender ≈ 0.75 × fontSize oberhalb der Baseline

$pdf setFont 14 Helvetica
set y 80
# Tatsächliche Oberkante: ca. y - 14*0.75 = y - 10.5pt
$pdf text "Hallo" -x 50 -y $y   ;# Baseline bei y=80
```

### canvas: bbox ohne Argument

```tcl
# FALSCH bei tko::path
set bb [.p bbox]        ;# Fehler: braucht tagOrId

# RICHTIG
set bb [.p bbox all]    ;# alle Items
set bb [.c bbox all]    ;# canvas: ebenfalls funktioniert
```

### canvas: Mauskoordinaten ohne Konversion

```tcl
# FALSCH bei gescrolltem Canvas
bind .c <Button-1> {
    .c create oval %x %y [expr {%x+10}] [expr {%y+10}] -fill red
    # Kreis erscheint am falschen Ort wenn Canvas gescrollt ist!
}

# RICHTIG
bind .c <Button-1> {
    set cx [%W canvasx %x]
    set cy [%W canvasy %y]
    .c create oval $cx $cy [expr {$cx+10}] [expr {$cy+10}] -fill red
}
```

### place: relx/rely Wertebereich

```tcl
# FALSCH: relx erwartet 0.0..1.0, nicht Pixel
place .w -relx 50 -rely 30    ;# 50-fache Containerbreite!

# RICHTIG: relativ
place .w -relx 0.5 -rely 0.3 -anchor center

# RICHTIG: absolut
place .w -x 50 -y 30 -width 200 -height 80
```

---

## Siehe auch

- [canvas.md](canvas.md) - tk::canvas Referenz inkl. PDF-Export
- [tkopath.md](tkopath.md) - tko::path SVG-Canvas
- [geometry-manager.md](geometry-manager.md) - pack und grid
- [place.md](place.md) - place Geometry Manager
