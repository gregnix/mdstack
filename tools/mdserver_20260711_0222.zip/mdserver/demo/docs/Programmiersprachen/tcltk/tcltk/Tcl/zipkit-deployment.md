# Tcl 9 Deployment: Zipkits, ZipFS und BAWT

*Stand: 2026-04-29*

## Überblick

Ab Tcl 9 gibt es eine neue Methode für Single-File-Deployment, die
ohne Metakit und das klassische VFS-System auskommt. Stattdessen wird
ZipFS verwendet -- ein ZIP-basiertes virtuelles Dateisystem, das direkt
in den Tcl-Kern integriert ist. Die damit erzeugten Standalone-Binaries
heissen Zipkits.

Dieses Dokument beschreibt ZipFS, den Bau von Zipkits, das BAWT-Framework
und alternative Deployment-Methoden. Für die klassische Starpack-Technologie
(Tcl 8.6, Metakit, SDX) siehe `starpack-grundlagen.md`.


## ZipFS: ZIP als Dateisystem

### Was ist ZipFS?

ZipFS ist ein virtuelles Dateisystem auf Basis von ZIP-Archiven.
Es ist ab Tcl 9 direkt im Kern enthalten und benötigt keine
zusätzlichen Erweiterungen. Alle Befehle sind im `zipfs`-Ensemble
zusammengefasst.

ZipFS ist in Tcl 8.6 nicht verfügbar.

### ZIP-Archive erstellen

```tcl
# Aus Verzeichnis
zipfs mkzip archiv.zip /pfad/zum/verzeichnis

# Mit Pfad-Bereinigung (entfernt Präfix aus gespeicherten Pfaden)
zipfs mkzip archiv.zip /pfad/zum/verzeichnis /pfad/zum/

# Aus Dateiliste (Paare: Quelldatei -> Name im Archiv)
zipfs lmkzip archiv.zip [list \
    /pfad/dateiA.txt ersteA.txt \
    /pfad/dateiB.txt zweiteB.txt]
```

### Archive mounten

```tcl
# Mounten unter dem ZipFS-Wurzelpfad
zipfs mount archiv.zip mnt
# -> //zipfs:/mnt

# Danach normale Dateibefehle verwenden
set inhalt [glob //zipfs:/mnt/*]
set text [readFile //zipfs:/mnt/readme.txt]
```

Alle ZipFS-Mounts erscheinen unterhalb der ZipFS-Wurzel, die
`zipfs root` zurueckgibt (normalerweise `//zipfs:/`).

### Binäre Daten mounten

```tcl
# ZIP-Archiv direkt aus einem Binär-String mounten
set zip_daten [readFile archiv.zip binary]
zipfs mountdata $zip_daten //zipfs:/daten
```

### Introspection

```tcl
# Alle Mounts auflisten
zipfs mount
# -> Dictionary: Mountpoint -> Archivpfad

# Prüfen ob Pfad in ZipFS existiert
zipfs exists //zipfs:/mnt/datei.txt

# Alle Dateien unter einem Verzeichnis finden
zipfs find //zipfs:/mnt

# Informationen zu einer Datei (Archiv, Originalgroesse, komprimiert, Offset)
zipfs info //zipfs:/mnt/datei.txt

# Dateien filtern
zipfs list -glob *.tcl
zipfs list -regexp {/lib/}
```

### Unmounten

```tcl
zipfs unmount //zipfs:/mnt

# Alternativ ohne ZipFS-Präfix
zipfs unmount mnt
```

### Einschränkungen

ZipFS unterstützt nur die Speichermethoden STORE und DEFLATE.
Multi-Part-Archive und das 64-Bit-Format werden nicht unterstützt.
Änderungen an Dateien finden nur im Speicher statt und werden beim
Unmounten verworfen -- sie werden nicht ins ZIP-Archiv zurueckgeschrieben.
Verzeichnisoperationen wie Erstellen und Löschen von Dateien werden
in Tcl 9.0 noch nicht unterstützt.


## Eingebettete ZIP-Archive

### Grundprinzip

Auf Windows, Linux und macOS kann ein ZIP-Archiv an eine ausführbare
Datei angehängt werden, ohne dass das Betriebssystem sie nicht mehr
als ausführbar erkennt. Tcl 9 nutzt diesen Mechanismus für die
Bereitstellung der Tcl-Kernbibliotheken und für Anwendungs-Deployment.

### Automatisches Mounting beim Start

Wenn Tcl 9 startet, prüft es zwei Stellen auf eingebettete ZIP-Archive:

| Quelle | Mountpoint | Inhalt |
|--------|------------|--------|
| Shared Library (tcl90.dll) | //zipfs:/lib/tcl | Tcl-Support-Scripte |
| Hauptprogramm (tclsh/wish) | //zipfs:/app | Anwendungscode |

Enthaelt das Archiv am Hauptprogramm eine Datei `main.tcl` auf der
obersten Ebene, wird diese automatisch als Anwendungsscript ausgeführt.

### Unterschied zu Tcl 8.6 Tclkits

In Tcl 8.6 setzt ein Tclkit die `auto_path`-Variable und andere
Suchpfade vollständig selbst. Tcl 9 Zipkits werten dagegen weiterhin
Umgebungsvariablen wie `TCLLIBPATH` aus. Falls das nicht gewünscht ist,
muss `auto_path` in der `main.tcl` explizit angepasst werden.


## Zipkits erstellen

### Was ist ein Zipkit?

Ein Zipkit ist das Tcl-9-Aequivalent eines Starpacks: ein statisch
gelinkter Tcl-Interpreter mit einem angehaengten ZIP-Archiv, das alle
Anwendungsdateien enthält. Der Begriff Zipkit grenzt sich vom
klassischen Tclkit ab, das auf Metakit basiert.

### Bezugsquellen für statische Interpreter

| Quelle | Bemerkung |
|--------|-----------|
| Magicsplat | Statische tclsh/wish für Windows (x86, x64) |
| BAWT Apps-Seite | Zipkits für mehrere Plattformen mit Tcl/Tk 9.0.3 |

### Ablauf: Zipkit mit zipfs mkimg

```tcl
# 1. Verzeichnisstruktur anlegen
file mkdir meinapp.vfs
file copy $tcl_library [file join meinapp.vfs tcl_library]
# Für GUI-Apps zusätzlich:
file copy $tk_library [file join meinapp.vfs tk_library]

# 2. Eigene Pakete kopieren
file mkdir [file join meinapp.vfs lib]
file copy /pfad/zu/meinpaket [file join meinapp.vfs lib meinpaket]

# 3. main.tcl erstellen
writeFile [file join meinapp.vfs main.tcl] {
    lappend auto_path //zipfs:/app/lib
    package require meinpaket
    # ... Anwendungscode ...
}

# 4. Zipkit erzeugen
zipfs mkimg meinapp.exe meinapp.vfs meinapp.vfs "" \
    /pfad/zu/tclsh90s.exe
```

Der letzte Parameter ist der Pfad zum statischen Interpreter.
Wenn das Script selbst in einem statischen Interpreter läuft,
kann dieser Parameter weggelassen werden -- dann wird der
aktuell laufende Interpreter als Vorlage verwendet.

### Varianten von zipfs mkimg und zipfs lmkimg

```tcl
# Aus Verzeichnis
zipfs mkimg OUTFILE INDIR ?STRIPPATH? ?PASSWORD? ?IMAGEPATH?

# Aus Dateiliste
zipfs lmkimg OUTFILE FILELIST ?PASSWORD? ?IMAGEPATH?
```

`STRIPPATH` sollte auf den Namen des Quellverzeichnisses gesetzt werden,
damit die Dateien im Archiv relativ und nicht mit absolutem Pfad
gespeichert werden.

### Vollständiges Beispiel: GUI-Anwendung

Dieses Script läuft in einem statischen `wish90s` und erzeugt ein
Zipkit mit Twapi-Unterstützung:

```tcl
# Prüfen ob wir in einem statischen wish laufen
set exe_path [zipfs mount //zipfs:/app]
if {$exe_path eq ""} {
    puts "Bitte statisches wish verwenden!"
    exit 1
}

# VFS-Struktur aufbauen
file delete -force meinapp.vfs
file mkdir meinapp.vfs
file copy $tcl_library [file join meinapp.vfs tcl_library]
file copy $tk_library  [file join meinapp.vfs tk_library]
file mkdir [file join meinapp.vfs lib]
file copy /pfad/zu/twapi5.0.2 [file join meinapp.vfs lib twapi5.0.2]

# Anwendungs-Einstiegspunkt
writeFile [file join meinapp.vfs main.tcl] {
    lappend auto_path //zipfs:/app/lib
    package require twapi
    console show
    puts "Twapi [twapi::get_version]"
}

# Zipkit erzeugen
zipfs mkimg meinapp.exe meinapp.vfs meinapp.vfs "" $exe_path
```


## Tclkit vs Zipkit: Transparente Erkennung

Wenn Code sowohl in klassischen Tclkits (Tcl 8.6) als auch in
Zipkits (Tcl 9) laufen soll, braucht man eine Abstraktionsschicht.
Das folgende Modul erkennt den Kit-Typ automatisch:

```tcl
namespace eval poKit {
    namespace ensemble create
    namespace export GetKitTopDir GetKitType HaveKit

    proc HaveTclkit {} {
        return [info exists ::starkit::topdir]
    }

    proc HaveZipkit {} {
        if {[package vcompare "9.0" [info tclversion]] <= 0 &&
            [lsearch -exact [zipfs mount] "//zipfs:/app"] >= 0} {
            return 1
        }
        return 0
    }

    proc HaveKit {} {
        return [expr {[HaveTclkit] || [HaveZipkit]}]
    }

    proc GetKitType {} {
        if {[HaveTclkit]} { return "Tclkit" }
        if {[HaveZipkit]} { return "Zipkit" }
        return "Unwrapped"
    }

    proc GetKitTopDir {} {
        if {[HaveTclkit]} { return $::starkit::topdir }
        if {[HaveZipkit]} { return "//zipfs:/app" }
        return ""
    }
}
```

Verwendung:

```tcl
set topdir [poKit GetKitTopDir]
set icon [file join $topdir res icon.png]
```


## BAWT: Build Automation With Tcl

### Was ist BAWT?

BAWT ist ein konfigurierbares Framework von Paul Obermeier zum
automatischen Bauen von C/C++-Bibliotheken aus Quellcode. Es wird
primär für die Tcl- und OpenSceneGraph-Welt verwendet und unterstützt
Windows, Linux, macOS und SunOS.

BAWT erzeugt unter anderem Tclkits, Zipkits und fertige Starpacks.
Ausserdem stellt es eine umfangreiche Sammlung vorkompilierter
Tcl-Pakete bereit.

### Distribution-Struktur

Aus der BAWT-Distribution wird für reine Tcl/Tk-Anwendungen nur ein
kleiner Teil benötigt:

```
Distribution/
|-- opt/
    |-- Tcl/
        |-- lib/          <-- Hier liegen alle Tcl-Pakete (~80-100)
            |-- scrollutil2.7/
            |-- tablelist7.8/
            |-- rl_json0.16.0/
            |-- twapi5.2.0/
            |-- ...
```

Der Rest der Distribution (31.000+ Verzeichnisse für C++-Entwicklung,
Shared Libraries, Header-Dateien) wird für Tcl-Anwendungen nicht benötigt.

### Setup-Dateien

BAWT organisiert Builds in Setup-Dateien, die definieren welche
Bibliotheken gebaut werden sollen:

| Setup-Datei | Inhalt |
|-------------|--------|
| Tcl_Tclkit.bawt | Nur Tcl, Tk und Tclkits |
| Tcl_Basic.bawt | Tclkits plus alle Tcl/Tk-Pakete ohne 3rd-Party-Abhängigkeiten |
| Tcl_Starpack.bawt | Fertige Starpacks (Gorilla, TkSQLite, poApps etc.) |

### Tclkits und Zipkits mit BAWT

Standardmäßig baut BAWT Tclkits (Metakit-basiert). Für Tcl 9 können
stattdessen Zipkits erzeugt werden:

```bash
# Standard: Tclkits
./Build-Linux.sh --tcl-version 9.0.3

# Mit Zipkits statt Tclkits
./Build-Linux.sh --tcl-version 9.0.3 --zipkit
```

Unter Windows analog:

```bat
Build-Windows.bat --tcl-version 9.0.3 --zipkit
```

Auf SunOS funktionieren Tclkit-basierte Starpacks nicht.
Dort müssen Zipkits mit Tcl 9 verwendet werden.

### Starpacks mit BAWT

Die Datei `Tcl_Starpack.bawt` definiert vorgefertigte Starpacks:

| Anwendung | Beschreibung |
|-----------|--------------|
| gorilla | Password-Manager |
| tksqlite | SQLite-GUI |
| tkchat | Tcl-Chat-Client |
| poApps | Paul Obermeiers Anwendungssammlung |
| BawtLogViewer | Log-Viewer für BAWT-Builds |
| jigsaw | Puzzle-Spiel |

BAWT wrpt diese automatisch je nach `--zipkit`-Option entweder
mit Tclkits oder Zipkits.


## Alternative Deployment-Methoden

### freeWrap

FreeWrap erzeugt ausführbare Dateien ähnlich wie Starpacks.
Verfügbar für Windows und Linux, quelloffen. Die Funktionalität
ist ähnlich wie Starpack-Technologie mit denselben Einschränkungen
(kein Schreibzugriff auf VFS). Die Bedienung ist weniger flexibel
als SDX.

### Tcl2Exe

Ein Script zum schnellen Wrappen unter Windows. Es nutzt intern
Tclkit und SDX, vereinfacht aber den Ablauf:

```bash
# Einzelnes Script wrappen
tcl2exe gui1 meinapp.tcl meinapp.exe

# Mit zusätzlichen Bibliotheken
tcl2exe gui1 meinapp.tcl meinapp.exe pfad/zu/lib lib

# Über Konfigurationsdatei (.tpkg)
tcl2exe pkgfile meinapp
```

Eine `.tpkg`-Datei definiert Script, Ziel, GUI-Modus und Extras:

```tcl
{
    meinapp {
        script scripts/meinapp.tcl
        target bin/meinapp.exe
        gui 1
        extras {
            lib/meinpaket lib/meinpaket
            res/icons     res/icons
        }
    }
}
```

### Tcl/Tk-Binaries über Go

Ein ungewoehnlicher aber funktionsfaehiger Ansatz nutzt die Go-Sprache:
Das Paket `modernc.org/tk9.0` ist eine automatische Übersetzung von
Tcl/Tk 9.0 von C nach reinem Go. Es enthält einen vollständigen
Tcl-9-Interpreter.

```go
package main

import (
    _ "embed"
    . "modernc.org/tk9.0"
    . "modernc.org/tk9.0/extensions/eval"
)

//go:embed main.tcl
var tclMain string

func main() {
    Eval(tclMain)
    App.Wait()
}
```

Build und Cross-Compilation:

```bash
# Für lokale Plattform
go build -trimpath

# Cross-Compile für Windows
GOOS=windows go build -trimpath
```

Vorteile: einfache Cross-Compilation, keine C-Abhängigkeiten,
ca. 8-9 MB Dategroesse. Nachteil: erfordert Go-Kenntnisse,
die Go-Übersetzung liegt möglicherweise etwas hinter der
offiziellen Tcl-Version zurück.


## Vergleich: Tclkit vs Zipkit vs Go

| Eigenschaft | Tclkit (Tcl 8.6) | Zipkit (Tcl 9) | Go-Wrapper |
|-------------|-----------------|----------------|------------|
| VFS-Backend | Metakit | ZipFS | Go embed |
| Tcl-Version | 8.6.x | 9.0.x | 9.0.x (übersetzt) |
| Werkzeug | sdx.kit | zipfs mkimg | go build |
| Schreibzugriff | Ja (Starkit) | Nur im Speicher | Nein |
| Cross-Compile | Anderes Runtime angeben | Anderes Runtime angeben | GOOS/GOARCH setzen |
| Größe (minimal) | ca. 1-2 MB | ca. 2-3 MB | ca. 8-9 MB |
| Extern nötig | sdx.kit + tclkit | Statischer tclsh/wish | Go Compiler |
| Plattformen | Sehr viele | Windows, Linux, macOS | Alle Go-Plattformen |


## Tcl 9 Kompatibilität: Bekannte Probleme

### Package-Require mit Dash-Suffix

Tcl 9 erfordert ein Dash-Suffix bei Versionsangaben, die auch mit
Tcl 9 funktionieren sollen:

```tcl
# FALSCH -- Tcl 9 lehnt ab (Version 8.6 ist nicht 9.x):
package require Tk 8.6

# RICHTIG -- "8.6 oder neuer" funktioniert mit 8.6, 8.7 und 9.x:
package require Tk 8.6-
```

Beim Bau von Starpacks und Zipkits sollten alle `package require`-Aufrufe
in den eingebetteten Paketen automatisch gepatcht werden:

```bash
# In Build-Scripts: automatisches Patchen
sed -i 's/package require Tk 8\.6$/package require Tk 8.6-/' datei.tcl
```

### VFS-Pfadkollisionen

Tcl 9 fügt `lib/` automatisch zu `auto_path` hinzu und erwartet dort
Kern-Pakete. Eigene Pakete sollten daher nicht in `lib/` innerhalb des
VFS liegen:

```
# FALSCH -- kollidiert mit Tcl 9 Core-Paketen:
meinapp.vfs/lib/meinpaket/

# RICHTIG -- eigener Verzeichnisname:
meinapp.vfs/applib/meinpaket/
```

In `main.tcl` dann entsprechend:

```tcl
lappend auto_path //zipfs:/app/applib
```


## Praxis: Build-System für eigene Anwendungen

### Verzeichnisstruktur

```
projekt/
|-- src/
    |-- main.tcl
    |-- app/
        |-- meinapp.tcl
|-- deps.txt                 # Abhängigkeiten
|-- build.conf               # Build-Konfiguration
```

### deps.txt: Abhängigkeiten definieren

Format: Paketname, Version, Typ (tcl oder c)

```
scrollutil  2.7    tcl
tablelist   7.8    tcl
rl_json     0.16.0 c
twapi       5.2.0  c
```

### build.conf: Build-Konfiguration

```bash
APP_NAME="meinapp"
APP_VERSION="1.0"
VFS_DIR="meinapp.vfs"
USE_TK=1
# BUILDSYS zeigt auf zentrales Build-Verzeichnis mit Tclkits und Paketen
BUILDSYS="/home/user/buildsys"
```

### Build-Ablauf

```bash
# 1. VFS-Struktur aufbauen
mkdir -p $VFS_DIR/applib $VFS_DIR/apptm

# 2. Tcl-Kernbibliotheken kopieren (für Zipkit)
cp -r $BUILDSYS/tcl_library $VFS_DIR/

# 3. Abhängigkeiten aus BAWT-Paketen kopieren
while read name version typ; do
    src="$BUILDSYS/bawt/Linux/x64/lib/${name}${version}"
    cp -r "$src" "$VFS_DIR/applib/"
done < deps.txt

# 4. Anwendungscode kopieren
cp -r src/* $VFS_DIR/

# 5. Zipkit/Starpack erzeugen
tclsh90s <<EOF
zipfs mkimg meinapp $VFS_DIR $VFS_DIR "" [info nameofexecutable]
EOF
```


## Zusammenfassung

| Thema | Tcl 8.6 | Tcl 9 |
|-------|---------|-------|
| VFS-Technologie | Metakit + tclvfs | ZipFS (im Kern) |
| Interpreter | Tclkit | Zipkit (statischer tclsh/wish) |
| Werkzeug | sdx.kit (wrap/unwrap) | zipfs mkimg/lmkimg |
| App-Mountpoint | $starkit::topdir | //zipfs:/app |
| Lib-Mountpoint | $starkit::topdir/lib | //zipfs:/app/lib oder /applib |
| Erkennung | info exists ::starkit::topdir | zipfs mount //zipfs:/app |

Der Wechsel von Tclkits zu Zipkits erfordert Anpassungen an `main.tcl`
und der Verzeichnisstruktur, aber die grundsaetzliche Idee -- alles in
eine einzelne Datei packen -- bleibt gleich.
