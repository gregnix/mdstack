# Traces

*Stand: 2026-04-29*

Tcl kann Code automatisch ausführen wenn Variablen gelesen, geschrieben
oder gelöscht werden, wenn Befehle umbenannt oder gelöscht werden,
und wenn Befehle ausgeführt werden. Diese Fähigkeit heisst Tracing
und wird mit dem `trace`-Befehl gesteuert.

## Variable-Traces

### trace add variable

```tcl
trace add variable varName ops callback
```

Registriert einen Callback der ausgeführt wird wenn die Variable
`varName` bestimmte Operationen durchläuft.

### Operationen

| Operation | Auslöser |
|:----------|:----------|
| `read` | Kurz bevor die Variable gelesen wird |
| `write` | Direkt nachdem die Variable geschrieben wurde |
| `unset` | Nachdem die Variable gelöscht wurde |
| `array` | Bei Zugriff über den `array`-Befehl |

Mehrere Operationen können als Liste angegeben werden:

```tcl
trace add variable myvar {read write unset} myCallback
```

### Callback-Signatur

Der Callback bekommt drei zusätzliche Argumente:

```tcl
proc myCallback {varName elemName op} {
    # varName  - Name der Variable (im Aufrufer-Kontext)
    # elemName - Array-Element (leer bei einfachen Variablen)
    # op       - Ausgeloeste Operation: read, write, unset, array
}
```

### Grundbeispiel

```tcl
proc tracer {varName elemName op} {
    puts "Trace: $op auf $varName"
}

trace add variable x {read write unset} tracer

set x 42       ;# -> Trace: write auf x
puts $x        ;# -> Trace: read auf x
unset x        ;# -> Trace: unset auf x
```

### Variable im Callback ändern

Da der Callback im selben Kontext wie die Operation ausgeführt
wird, braucht eine Prozedur als Callback `upvar` um auf die
Variable zuzugreifen:

```tcl
proc upperTrace {varName elemName op} {
    upvar 1 $varName var
    set var [string toupper $var]
}

trace add variable name write upperTrace

set name "hallo"   ;# name ist jetzt "HALLO"
```

Read-Traces können die Variable ebenfalls ändern -- der neue
Wert wird zurückgegeben:

```tcl
proc reverseOnRead {varName elemName op} {
    upvar 1 $varName var
    set var [string reverse $var]
}

trace add variable text read reverseOnRead
set text "ABC"
puts $text   ;# -> CBA
puts $text   ;# -> ABC  (wieder umgedreht)
```

### Rekursionsschutz

Tcl deaktiviert read- und write-Traces während ein read- oder
write-Callback läuft. Dadurch werden endlose Rekursionen verhindert.
Ausnahme: unset-Traces werden auch während anderer Callbacks
ausgelöst.

### Fehler in Callbacks

Bei read- und write-Callbacks: Wenn der Callback einen Fehler wirft,
schlaegt die urspruengliche Operation mit demselben Fehler fehl.

Bei unset-Callbacks: Fehler werden ignoriert.

### Trace auf nicht existierende Variable

Traces können auf Variablen gesetzt werden die noch nicht existieren:

```tcl
trace add variable x write myCallback
# x existiert noch nicht -- Trace feuert wenn x erzeugt wird
set x 1   ;# -> Callback wird aufgerufen
```

### Trace und unset

Wenn eine Variable gelöscht wird (explizit oder beim Verlassen
des Scopes), wird der unset-Trace ausgelöst und danach der
Trace selbst entfernt:

```tcl
trace add variable x {write unset} myCallback
set x 1      ;# -> write Callback
unset x      ;# -> unset Callback
set x 2      ;# kein Callback mehr (Trace wurde mit x gelöscht)
```

### Scope-Erkennung mit unset-Trace

Ein unset-Trace auf eine lokale Variable feuert wenn die Prozedur
endet. Das kann zur Ressourcen-Freigabe genutzt werden:

```tcl
proc closeCallback {chan args} { close $chan }

proc demo {} {
    set fd [open "daten.txt" r]
    trace add variable fd unset [list closeCallback $fd]
    # ... Arbeit mit $fd ...
    # Wenn demo endet: fd wird unset -> Trace schliesst den Kanal
}
```

### Variablenname im Callback

Der übergebene Variablenname ist der Name im Aufrufer-Kontext,
nicht zwingend der Name auf dem der Trace registriert wurde:

```tcl
trace add variable x write tracer
upvar 0 x alias
set alias 1   ;# -> Callback bekommt "alias" als varName, nicht "x"
```

Falls der Original-Name benötigt wird, kann er als zusätzliches
Argument beim Erstellen des Trace mitgegeben werden:

```tcl
trace add variable x write [list myCallback x]
```

## Array-Traces

### Einzelnes Element tracen

```tcl
trace add variable arr(key) {read write unset} tracer

set arr(key) 1       ;# -> Callback mit varName="arr", elemName="key"
array set arr {key 2} ;# -> Callback feuert ebenfalls
unset arr             ;# -> Callback für arr(key)
```

### Gesamtes Array tracen

Mit der `array`-Operation werden Zugriffe über den `array`-Befehl
erfasst:

```tcl
array set myarr {a 1 b 2}
trace add variable myarr array tracer

array get myarr    ;# -> Callback mit op="array", elemName=""
array set myarr {} ;# -> Callback
```

Die `array`-Operation allein erfasst keine Zugriffe auf einzelne
Elemente:

```tcl
set myarr(a)       ;# -> KEIN Callback (nur array-Op registriert)
```

### Array-Elemente und Array-Befehl kombiniert tracen

```tcl
trace add variable myarr {read write unset array} tracer

array get myarr    ;# -> array-Callback, dann read für jedes Element
set myarr(a) 5     ;# -> write-Callback für Element "a"
```

### unset bei Arrays

`unset arr` loescht das gesamte Array mit einem einzigen
unset-Callback (elemName leer). Einzelne Element-Traces werden
nicht separat ausgelöst.

`array unset arr pattern` hingegen löst den array-Callback
und dann individuelle unset-Callbacks für jedes passende Element aus.

## Anwendungen von Variable-Traces

### Lazy Initialization (Cache)

```tcl
proc calcOnDemand {varName elemName op} {
    upvar 1 $varName var
    if {![info exists var($elemName)]} {
        # Teuer berechnen und cachen
        set var($elemName) [expensiveCalc $elemName]
    }
}

array set cache {}
trace add variable cache read calcOnDemand

puts $cache(42)   ;# Berechnet beim ersten Zugriff, danach gecacht
puts $cache(42)   ;# Aus dem Cache
```

### Konstanten (Read-Only-Variablen, Tcl 8)

Tcl 9 hat `const`, für Tcl 8 kann man Konstanten mit Traces
simulieren:

```tcl
proc makeConstant {varName value} {
    upvar 1 $varName var
    set var $value
    trace add variable var write [list _constGuard $value]
}

proc _constGuard {constVal varName elemName op} {
    upvar 1 $varName var
    set var $constVal   ;# Originalwert wiederherstellen
    throw {CONST MODIFY} "Konstante darf nicht geändert werden"
}

makeConstant PI 3.14159
set PI 0   ;# -> Fehler, PI bleibt 3.14159
```

### Datenfluss (Spreadsheet-Muster)

Änderungen an Quell-Variablen propagieren automatisch zu
abhaengigen Variablen:

```tcl
proc updateSum {args} {
    set ::summe [expr {$::a + $::b}]
}

trace add variable a write updateSum
trace add variable b write updateSum

set a 3    ;# summe wird automatisch berechnet
set b 4    ;# summe = 7
```

### Ressourcen-Management

Alternative zu `try...finally` -- besonders nützlich bei
Namespace-Löschung oder Coroutine-Abbruch wo `finally` nicht
ausgeführt wird:

```tcl
proc autoClose {chan args} { close $chan }

proc demo {} {
    set fd [open "daten.txt" r]
    trace add variable fd unset [list autoClose $fd]
    # fd wird automatisch geschlossen wenn die Prozedur endet
    set data [read $fd]
}
```

## Command-Traces

### trace add command

```tcl
trace add command cmdName ops callback
```

Registriert einen Callback für Umbenennung oder Löschung eines
Befehls. Der Befehl muss bereits existieren.

### Operationen

| Operation | Auslöser |
|:----------|:----------|
| `rename` | Befehl wird umbenannt (nicht bei Löschung via `rename cmd ""`) |
| `delete` | Befehl wird gelöscht (auch bei Namespace-Löschung) |

### Callback-Signatur

```tcl
proc cmdTracer {oldName newName op} {
    # oldName - Vollqualifizierter alter Name
    # newName - Vollqualifizierter neuer Name (leer bei delete)
    # op      - "rename" oder "delete"
}
```

### Beispiel

```tcl
proc cmdTracer {old new op} {
    puts "$op: $old -> $new"
}

namespace eval ns { proc demo {} {} }
trace add command ns::demo {rename delete} cmdTracer

rename ns::demo myDemo   ;# -> rename: ::ns::demo -> ::myDemo
rename myDemo ""          ;# -> delete: ::myDemo ->
```

### Anwendung: Proxy-Cleanup

Nützlich für Befehle die externe Ressourcen repräsentieren.
Bei Löschung des Befehls wird die Ressource freigegeben:

```tcl
proc createHandle {name resource} {
    proc $name {args} [list handleCmd $resource {*}$args]
    trace add command $name delete [list releaseResource $resource]
}
```

### Hinweise

Traces bleiben nach Umbenennung erhalten. Bei Neudefinition einer
Prozedur (erneutes `proc`) wird der alte Befehl gelöscht und ein
neuer erzeugt -- der delete-Trace feuert, ist aber auf der neuen
Definition nicht mehr aktiv.

## Execution-Traces

### trace add execution

```tcl
trace add execution cmdName ops callback
```

Zeichnet die Ausführung eines Befehls auf. Sehr mächtig für
Debugging, aber mit erheblichem Performance-Overhead.

### Operationen

| Operation | Auslöser |
|:----------|:----------|
| `enter` | Vor Ausführung des Befehls |
| `leave` | Nach Ausführung des Befehls |
| `enterstep` | Vor jedem Befehl während der Ausführung (rekursiv) |
| `leavestep` | Nach jedem Befehl während der Ausführung (rekursiv) |

### Callback-Signatur

Bei enter/enterstep:

```tcl
proc enterTracer {commandString op} {
    # commandString - Vollständiger Befehl mit Argumenten
    # op            - "enter" oder "enterstep"
}
```

Bei leave/leavestep:

```tcl
proc leaveTracer {commandString returnCode result op} {
    # commandString - Vollständiger Befehl
    # returnCode    - 0 (ok), 1 (error), 2 (return), ...
    # result        - Ergebnis des Befehls
    # op            - "leave" oder "leavestep"
}
```

### Beispiel: Befehlsausfuehrung verfolgen

```tcl
proc tracer {args} { puts "Trace: [join $args {, }]" }

proc a {} { b }
proc b {} { return "Ergebnis" }

trace add execution a {enter leave} tracer
a
# -> Trace: a, enter
#    Trace: a, 0, Ergebnis, leave
```

### enterstep/leavestep: Alle Unterbefehle verfolgen

```tcl
trace add execution a {enterstep leavestep} tracer
a
# -> Trace: b, enterstep
#    Trace: return Ergebnis, enterstep
#    Trace: return Ergebnis, 2, Ergebnis, leavestep
#    Trace: b, 0, Ergebnis, leavestep
```

`enterstep`/`leavestep` erfassen jeden Befehl der während der
Ausführung des getrackten Befehls ausgeführt wird -- auch
verschachtelte Aufrufe in beliebiger Tiefe.

### Einsatzgebiete

Execution-Traces sind primär für Debugging und Fehlerdiagnose
gedacht. Sie ermöglichen:

- Profiling (welche Befehle werden wie oft aufgerufen)
- Debugging (Ausfuehrungsreihenfolge verfolgen)
- Logging (Fehler und Exceptions im Feld protokollieren)

Wegen des Performance-Overheads nicht im normalen Programmfluss
verwenden.

## Traces verwalten

### trace remove

```tcl
trace remove variable varName ops callback
trace remove command  cmdName ops callback
trace remove execution cmdName ops callback
```

Entfernt einen spezifischen Trace. Die Argumente `ops` und
`callback` müssen exakt mit den Werten übereinstimmen die bei
`trace add` verwendet wurden:

```tcl
# Trace hinzufügen:
trace add variable x {read write} myCallback

# RICHTIG entfernen (ops und callback müssen matchen):
trace remove variable x {read write} myCallback

# FALSCH (ops stimmen nicht überein, wird ignoriert):
trace remove variable x read myCallback
```

Um nur eine Operation zu entfernen: alten Trace komplett entfernen
und neuen mit den verbleibenden Operationen hinzufügen.

Trace auf nicht existierende Variable entfernen wird ignoriert.
Trace auf nicht existierenden Befehl entfernen erzeugt einen Fehler.

### trace info

```tcl
trace info variable varName
trace info command  cmdName
trace info execution cmdName
```

Gibt eine Liste von `{ops callback}`-Paaren zurück:

```tcl
trace add variable x {read write} tracer1
trace add variable x unset tracer2

trace info variable x
# -> {{read write} tracer1} {unset tracer2}
```

### Alle Traces einer Variable entfernen

```tcl
foreach t [trace info variable x] {
    trace remove variable x {*}$t
}
```

## Mehrere Traces

Auf eine Variable oder einen Befehl können beliebig viele Traces
registriert werden. Sie werden in umgekehrter Reihenfolge ihrer
Erstellung aufgerufen (zuletzt hinzugefügt = zuerst aufgerufen).

Wenn ein Trace einen Fehler wirft, werden die verbleibenden Traces
nicht aufgerufen.

## Häufige Fehler

### upvar vergessen im Callback

```tcl
# FALSCH: varName ist nur der Name, nicht die Variable
proc badTrace {varName elemName op} {
    set varName "neuer Wert"   ;# Aendert nur den lokalen Parameter!
}

# RICHTIG: upvar verwenden
proc goodTrace {varName elemName op} {
    upvar 1 $varName var
    set var "neuer Wert"
}
```

### Trace mit upvar-Alias registrieren

Traces die über eine per `upvar` verknuepfte Variable ausgelöst
werden, bekommen den Alias-Namen statt des Original-Namens:

```tcl
trace add variable x write tracer
upvar 0 x alias
set alias 1   ;# tracer bekommt "alias", nicht "x"
```

### trace add variable mit trace/vwait/textvariable

Variablen-Aliase (via `upvar`) können nicht mit `trace`, `vwait`
oder Tk's `-textvariable` verwendet werden. Immer den originalen
Variablennamen verwenden.

### Trace-Entfernung mit falschen Parametern

```tcl
trace add variable x {read write} tracer
trace remove variable x read tracer    ;# Wird IGNORIERT (ops matchen nicht)
trace remove variable x {read write} tracer   ;# Korrekt
```

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `trace add variable name ops callback` | Variable beobachten |
| `trace add command name ops callback` | Befehl-Lebenszyklus beobachten |
| `trace add execution name ops callback` | Befehl-Ausführung verfolgen |
| `trace remove ... name ops callback` | Trace entfernen |
| `trace info ... name` | Aktive Traces auflisten |

### Variable-Operationen

| Op | Timing | Aenderbar | Fehler |
|:---|:-------|:----------|:-------|
| `read` | Vor dem Lesen | Ja | Bricht Lesen ab |
| `write` | Nach dem Schreiben | Ja | Bricht Schreiben ab |
| `unset` | Nach dem Löschen | Nein | Wird ignoriert |
| `array` | Bei array-Befehl | Ja | Bricht Operation ab |

### Command-Operationen

| Op | Auslöser |
|:---|:----------|
| `rename` | Umbenennung (nicht bei Löschung) |
| `delete` | Löschung oder Namespace-Löschung |

### Execution-Operationen

| Op | Timing | Tiefe |
|:---|:-------|:------|
| `enter` | Vor dem Befehl | Nur der Befehl selbst |
| `leave` | Nach dem Befehl | Nur der Befehl selbst |
| `enterstep` | Vor jedem Unterbefehl | Alle Ebenen |
| `leavestep` | Nach jedem Unterbefehl | Alle Ebenen |

## Siehe auch

- [Variable Scope](variable-scope.md) -- `upvar` in Trace-Callbacks
- [Prozeduren](proc.md) -- Execution-Traces auf Procs
- [Fehlerbehandlung](error-handling.md) -- Traces und Fehler-Propagation
- [Info](info.md) -- `info commands` zur Introspektion vor Tracing
- [Metaprogramming](metaprogramming.md) -- Traces für dynamische Code-Erzeugung
