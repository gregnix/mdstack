# Tk ttk::treeview Referenzhandbuch

*Stand: 2026-04-29*

Umfassende deutsche Referenz für das ttk::treeview Widget (Tcl/Tk 8.6 und 9.x).

## Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Widget erstellen](#widget-erstellen)
3. [Konfigurationsoptionen](#konfigurationsoptionen)
4. [Spalten definieren](#spalten-definieren)
5. [Items verwalten](#items-verwalten)
6. [Hierarchie und Baumstruktur](#hierarchie-und-baumstruktur)
7. [Selektion](#selektion)
8. [Tags und Styling](#tags-und-styling)
9. [Scrolling](#scrolling)
10. [Bindings und Events](#bindings-und-events)
11. [Bekannte Probleme und Lösungen](#bekannte-probleme-und-loesungen)
12. [Praxisbeispiele](#praxisbeispiele)

---

## Überblick

Das ttk::treeview Widget ist ein vielseitiges Widget für:

- Hierarchische Baumansichten (Dateiexplorer, Kategorien)
- Tabellarische Daten mit Spalten
- Listen mit Icons
- Kombinationen aus Baum und Tabelle

### Kernkonzepte

| Konzept | Beschreibung |
|---------|--------------|
| Item | Ein Eintrag im Treeview, identifiziert durch Item-ID |
| Column | Eine Datenspalte (#0 = Baumstruktur-Spalte, #1+ = Datenspalten) |
| Heading | Spaltenüberschrift |
| Parent | Übergeordnetes Item ("" für Root-Ebene) |
| Tag | Benannter Bezeichner für Styling und Bindings |

### Spalte #0 vs. Datenspalten

- **#0**: Die "tree column", zeigt Hierarchie und Icon
- **#1, #2, ...**: Zusätzliche Datenspalten (definiert mit -columns)

---

## Widget erstellen

### Syntax

```tcl
ttk::treeview pathName ?options?
```

`ttk::treeview` kennt **kein** `-width` beim Erzeugen — der Versuch wirft
`unknown option "-width"`. Die Höhe steuert `-height` (in Zeilen), die Breite
wird pro Spalte über `column ... -width` (in Pixel) gesetzt:

```tcl
ttk::treeview .tv -show tree -height 12   ;# Höhe = Zeilen
.tv column #0 -width 200 -minwidth 140    ;# Breite = Pixel, pro Spalte
```

### Einfache Liste

```tcl
ttk::treeview .tv -show tree
pack .tv -fill both -expand 1

.tv insert {} end -text "Eintrag 1"
.tv insert {} end -text "Eintrag 2"
.tv insert {} end -text "Eintrag 3"
```

### Mit Spalten (Tabelle)

```tcl
ttk::treeview .tv -columns {name size date} -show headings
pack .tv -fill both -expand 1

.tv heading name -text "Name"
.tv heading size -text "Größe"
.tv heading date -text "Datum"

.tv insert {} end -values {"Dokument.txt" "12 KB" "2024-01-15"}
.tv insert {} end -values {"Bild.png" "245 KB" "2024-01-14"}
```

### Baum mit Spalten

```tcl
ttk::treeview .tv -columns {size date} -show {tree headings}
pack .tv -fill both -expand 1

.tv heading #0 -text "Name"
.tv heading size -text "Größe"
.tv heading date -text "Datum"

set folder [.tv insert {} end -text "Ordner" -open true]
.tv insert $folder end -text "Datei1.txt" -values {"10 KB" "2024-01-15"}
.tv insert $folder end -text "Datei2.txt" -values {"5 KB" "2024-01-14"}
```

### Mit Scrollbars

```tcl
ttk::frame .f
ttk::treeview .f.tv -columns {a b c} -show headings \
    -yscrollcommand {.f.vsb set} \
    -xscrollcommand {.f.hsb set}
ttk::scrollbar .f.vsb -orient vertical -command {.f.tv yview}
ttk::scrollbar .f.hsb -orient horizontal -command {.f.tv xview}

grid .f.tv -row 0 -column 0 -sticky nsew
grid .f.vsb -row 0 -column 1 -sticky ns
grid .f.hsb -row 1 -column 0 -sticky ew

grid rowconfigure .f 0 -weight 1
grid columnconfigure .f 0 -weight 1
pack .f -fill both -expand 1
```

---

## Konfigurationsoptionen

### Widget-Optionen

| Option | Typ | Beschreibung |
|--------|-----|--------------|
| -columns | Liste | Spalten-IDs (außer #0) |
| -displaycolumns | Liste | Sichtbare Spalten und Reihenfolge |
| -show | Liste | tree, headings oder beides |
| -selectmode | Mode | browse, extended, none |
| -height | Integer | Sichtbare Zeilen |
| -padding | Pixel | Innerer Abstand |

### -show Optionen

| Wert | Beschreibung |
|------|--------------|
| tree | Zeigt Spalte #0 (Baumstruktur) |
| headings | Zeigt Spaltenüberschriften |
| {tree headings} | Zeigt beides (default) |
| {} | Zeigt weder Baum noch Überschriften |

### -selectmode Optionen

| Modus | Beschreibung |
|-------|--------------|
| browse | Ein Item auswählbar (default) |
| extended | Mehrere mit Shift/Ctrl |
| none | Keine Auswahl möglich |

---

## Spalten definieren

### Spalten konfigurieren

```tcl
# Breite
.tv column name -width 200
.tv column #0 -width 250

# Mindestbreite
.tv column name -minwidth 100

# Dehnung (bei Fenstergrößenänderung)
.tv column name -stretch true
.tv column size -stretch false

# Ausrichtung
.tv column size -anchor e      ;# Rechts
.tv column name -anchor w      ;# Links
.tv column type -anchor center ;# Zentriert
```

### Überschriften konfigurieren

```tcl
# Text
.tv heading name -text "Dateiname"

# Ausrichtung
.tv heading name -anchor w

# Sortier-Callback
.tv heading name -command [list sortColumn .tv name 0]

# Bild
.tv heading name -image $sortIcon
```

### Spaltenreihenfolge ändern

```tcl
# Nur bestimmte Spalten anzeigen
.tv configure -displaycolumns {name size}

# Reihenfolge ändern
.tv configure -displaycolumns {size name modified}

# Alle anzeigen (Standardreihenfolge)
.tv configure -displaycolumns #all
```

---

## Items verwalten

### Einfügen

```tcl
# Am Ende von Root
set id [.tv insert {} end -text "Name" -values {val1 val2}]

# Am Anfang
.tv insert {} 0 -text "Erster"

# Mit eigener ID
.tv insert {} end -id myitem -text "Mit ID"

# Mit Icon
.tv insert {} end -text "Ordner" -image $folderIcon

# Mit Tag
.tv insert {} end -text "Wichtig" -tags important

# Als Kind
set parent [.tv insert {} end -text "Eltern" -open true]
.tv insert $parent end -text "Kind 1"
.tv insert $parent end -text "Kind 2"
```

### Abfragen

```tcl
# Item-Eigenschaften
.tv item $id -text        ;# Text in #0
.tv item $id -values      ;# Werte in anderen Spalten
.tv item $id -tags        ;# Tags
.tv item $id -open        ;# Geöffnet (Baum)?

# Einzelne Spalte
.tv set $id name          ;# Wert der Spalte "name"

# Kinder
.tv children {}           ;# Kinder von Root
.tv children $parentId    ;# Kinder eines Items

# Eltern
.tv parent $id

# Index unter Geschwistern
.tv index $id
```

### Ändern

```tcl
# Text ändern
.tv item $id -text "Neuer Name"

# Werte ändern
.tv item $id -values {"Wert1" "Wert2" "Wert3"}

# Einzelne Spalte
.tv set $id name "Neuer Wert"

# Öffnen/Schließen
.tv item $id -open true
.tv item $id -open false

# Tags ändern
.tv item $id -tags {tag1 tag2}
```

### Löschen

```tcl
# Einzelnes Item (und alle Kinder)
.tv delete $id

# Mehrere Items
.tv delete [list $id1 $id2 $id3]

# Alle Items
.tv delete [.tv children {}]
```

### Verschieben

```tcl
# An neue Position unter gleichem Eltern
.tv move $id $parent $newIndex

# Zu anderem Eltern
.tv move $id $newParent end

# An Root verschieben
.tv move $id {} end
```

### Item aus Koordinaten

```tcl
# Item an Position
set id [.tv identify item $x $y]

# Spalte an Position
set col [.tv identify column $x $y]

# Region an Position (heading, separator, cell, tree, nothing)
set region [.tv identify region $x $y]
```

---

## Hierarchie und Baumstruktur

### Baum aufbauen

```tcl
# Root-Items
set docs [.tv insert {} end -text "Dokumente" -open true]
set pics [.tv insert {} end -text "Bilder" -open false]

# Unterordner
set work [.tv insert $docs end -text "Arbeit" -open true]
set priv [.tv insert $docs end -text "Privat"]

# Dateien
.tv insert $work end -text "Bericht.docx"
.tv insert $work end -text "Tabelle.xlsx"
```

### Öffnen/Schließen

```tcl
# Einzelnes Item
.tv item $id -open true
.tv item $id -open false

# Status abfragen
set isOpen [.tv item $id -open]

# Alle öffnen
proc openAll {tv {parent {}}} {
    foreach child [$tv children $parent] {
        $tv item $child -open true
        openAll $tv $child
    }
}

# Alle schließen
proc closeAll {tv {parent {}}} {
    foreach child [$tv children $parent] {
        closeAll $tv $child
        $tv item $child -open false
    }
}
```

### Pfad ermitteln

```tcl
proc getPath {tv id} {
    set path [list [$tv item $id -text]]
    set parent [$tv parent $id]
    while {$parent ne ""} {
        set path [linsert $path 0 [$tv item $parent -text]]
        set parent [$tv parent $parent]
    }
    return [join $path "/"]
}
```

---

## Selektion

### Auswählen

```tcl
# Auswählen
.tv selection set $id
.tv selection set [list $id1 $id2 $id3]

# Zur Auswahl hinzufügen
.tv selection add $id

# Aus Auswahl entfernen
.tv selection remove $id

# Auswahl umschalten
.tv selection toggle $id
```

### Abfragen

```tcl
# Ausgewählte Items
set selected [.tv selection]

# Erstes ausgewähltes
set first [lindex [.tv selection] 0]
```

### Fokus

```tcl
# Fokussiertes Item setzen
.tv focus $id

# Fokussiertes Item abfragen
set focused [.tv focus]
```

### Sichtbar machen

```tcl
# Item sichtbar machen (scrollt und öffnet Eltern)
.tv see $id
```

---

## Tags und Styling

### Tags zuweisen

```tcl
# Bei Erstellung
.tv insert {} end -text "Wichtig" -tags important

# Nachträglich
.tv item $id -tags {tag1 tag2}
```

### Tag konfigurieren

```tcl
# Vordergrund/Hintergrund
.tv tag configure important -foreground red
.tv tag configure selected -background yellow

# Schriftart
.tv tag configure bold -font {TkDefaultFont 10 bold}

# Bild
.tv tag configure folder -image $folderIcon
```

### Zebra-Streifen

```tcl
.tv tag configure oddrow -background #f0f0f0
.tv tag configure evenrow -background white

proc applyZebra {tv {parent {}}} {
    set row 0
    foreach child [$tv children $parent] {
        if {$row % 2 == 0} {
            $tv item $child -tags evenrow
        } else {
            $tv item $child -tags oddrow
        }
        incr row
        applyZebra $tv $child
    }
}
```

---

## Scrolling

### Scroll-Befehle

```tcl
# Vertikal
.tv yview            ;# Position {first last}
.tv yview moveto 0.5 ;# Zu Fraktion
.tv yview scroll 1 units
.tv yview scroll 1 pages

# Horizontal
.tv xview
.tv xview moveto 0.0
.tv xview scroll 1 units
```

### Item sichtbar machen

```tcl
# Scrollt automatisch und öffnet Eltern
.tv see $id
```

### Bounding Box

```tcl
# Sichtbarer Bereich eines Items
set bbox [.tv bbox $id]        ;# Ganze Zeile
set bbox [.tv bbox $id column] ;# Bestimmte Zelle
# bbox = {x y width height} oder "" wenn nicht sichtbar
```

---

## Bindings und Events

### Standard-Events

| Event | Beschreibung |
|-------|--------------|
| <<TreeviewSelect>> | Selektion geändert |
| <<TreeviewOpen>> | Item wird geöffnet |
| <<TreeviewClose>> | Item wird geschlossen |

### Event-Bindings

```tcl
# Selektion geändert
bind .tv <<TreeviewSelect>> {
    set sel [%W selection]
    puts "Ausgewählt: $sel"
}

# Item geöffnet
bind .tv <<TreeviewOpen>> {
    set id [%W focus]
    puts "Geöffnet: $id"
}

# Item geschlossen
bind .tv <<TreeviewClose>> {
    set id [%W focus]
    puts "Geschlossen: $id"
}
```

### Maus-Bindings

```tcl
# Doppelklick
bind .tv <Double-Button-1> {
    set id [%W identify item %x %y]
    if {$id ne ""} {
        puts "Doppelklick auf: $id"
    }
}

# Rechtsklick (Kontextmenü)
bind .tv <Button-3> {
    set id [%W identify item %x %y]
    if {$id ne ""} {
        %W selection set $id
        tk_popup .contextmenu %X %Y
    }
}
```

### Tag-Bindings

```tcl
# Binding auf Tag
.tv tag bind clickable <Button-1> {
    puts "Klick auf clickable Item"
}
```

---

## Bekannte Probleme und Lösungen

### 1. Spalte #0 nicht ausblendbar

```tcl
# Workaround: Sehr schmal machen
.tv column #0 -width 0 -stretch false
```

### 2. Keine Zeilenfarben bei leerem Tag

```tcl
# Lösung: Immer einen Default-Tag zuweisen
.tv insert {} end -text "Item" -tags default
.tv tag configure default -background white
```

### 3. Performance bei vielen Items

```tcl
# Lazy Loading beim Öffnen
bind .tv <<TreeviewOpen>> {
    set id [%W focus]
    loadChildren %W $id
}

proc loadChildren {tv parent} {
    set children [$tv children $parent]
    if {[llength $children] == 1 && [$tv item [lindex $children 0] -text] eq "..."} {
        $tv delete [lindex $children 0]
        # Echte Kinder laden
        foreach item [getDataForParent $parent] {
            $tv insert $parent end -text $item
        }
    }
}
```

### 4. Sortierung

```tcl
proc sortColumn {tv col numeric} {
    set data {}
    foreach id [$tv children {}] {
        if {$col eq "#0"} {
            set value [$tv item $id -text]
        } else {
            set value [$tv set $id $col]
        }
        lappend data [list $value $id]
    }
    
    if {$numeric} {
        set data [lsort -index 0 -integer $data]
    } else {
        set data [lsort -index 0 -dictionary $data]
    }
    
    set idx 0
    foreach item $data {
        $tv move [lindex $item 1] {} $idx
        incr idx
    }
}
```

---

## Praxisbeispiele

### Einfacher Dateiexplorer

```tcl
package require Tk

# Treeview erstellen
ttk::frame .f
ttk::treeview .f.tv -columns {size modified} -show {tree headings} \
    -yscrollcommand {.f.vsb set}
ttk::scrollbar .f.vsb -orient vertical -command {.f.tv yview}

.f.tv heading #0 -text "Name" -anchor w
.f.tv heading size -text "Größe" -anchor e
.f.tv heading modified -text "Geändert" -anchor w

.f.tv column #0 -width 250 -stretch true
.f.tv column size -width 80 -stretch false -anchor e
.f.tv column modified -width 150 -stretch false

grid .f.tv -row 0 -column 0 -sticky nsew
grid .f.vsb -row 0 -column 1 -sticky ns
grid rowconfigure .f 0 -weight 1
grid columnconfigure .f 0 -weight 1
pack .f -fill both -expand 1

# Verzeichnis laden
proc loadDirectory {tv parent dir} {
    foreach child [$tv children $parent] {
        $tv delete $child
    }
    
    # Verzeichnisse
    foreach item [lsort -dictionary [glob -nocomplain -directory $dir -types d -tails *]] {
        set path [file join $dir $item]
        set id [$tv insert $parent end -text "📁 $item" -open false]
        
        if {[llength [glob -nocomplain -directory $path *]] > 0} {
            $tv insert $id end -text "..." -tags placeholder
        }
        
        set mtime [clock format [file mtime $path] -format "%Y-%m-%d %H:%M"]
        $tv set $id modified $mtime
    }
    
    # Dateien
    foreach item [lsort -dictionary [glob -nocomplain -directory $dir -types f -tails *]] {
        set path [file join $dir $item]
        set id [$tv insert $parent end -text "📄 $item"]
        
        set size [file size $path]
        if {$size < 1024} {
            set sizeStr "$size B"
        } elseif {$size < 1048576} {
            set sizeStr "[expr {$size / 1024}] KB"
        } else {
            set sizeStr "[expr {$size / 1048576}] MB"
        }
        $tv set $id size $sizeStr
        
        set mtime [clock format [file mtime $path] -format "%Y-%m-%d %H:%M"]
        $tv set $id modified $mtime
    }
}

# Pfad eines Items ermitteln
proc getItemPath {tv id} {
    set parts {}
    while {$id ne ""} {
        set text [$tv item $id -text]
        # Emoji entfernen
        set name [string range $text 3 end]
        lappend parts $name
        set id [$tv parent $id]
    }
    return [file join {*}[lreverse $parts]]
}

# Lazy Loading beim Öffnen
bind .f.tv <<TreeviewOpen>> {
    set id [%W focus]
    set children [%W children $id]
    
    if {[llength $children] == 1} {
        set child [lindex $children 0]
        if {"placeholder" in [%W item $child -tags]} {
            set path [getItemPath %W $id]
            loadDirectory %W $id $path
        }
    }
}

# Startverzeichnis laden
loadDirectory .f.tv {} [pwd]
```

### Sortierbare Tabelle

```tcl
package require Tk

# Daten
set ::data {
    {1 "Müller" "Anna" 28 "Berlin"}
    {2 "Schmidt" "Thomas" 35 "Hamburg"}
    {3 "Weber" "Maria" 42 "München"}
    {4 "Fischer" "Peter" 31 "Köln"}
    {5 "Meyer" "Lisa" 25 "Frankfurt"}
}

# Sortier-Richtung pro Spalte
set ::sortDir [dict create id 1 nachname 1 vorname 1 alter 1 stadt 1]

# GUI
ttk::frame .f
ttk::treeview .f.tv -columns {id nachname vorname alter stadt} \
    -show headings -selectmode extended \
    -yscrollcommand {.f.vsb set}
ttk::scrollbar .f.vsb -orient vertical -command {.f.tv yview}

grid .f.tv -row 0 -column 0 -sticky nsew
grid .f.vsb -row 0 -column 1 -sticky ns
grid rowconfigure .f 0 -weight 1
grid columnconfigure .f 0 -weight 1
pack .f -fill both -expand 1 -padx 5 -pady 5

# Spalten konfigurieren
foreach {col text width anchor numeric} {
    id "ID" 50 center 1
    nachname "Nachname" 120 w 0
    vorname "Vorname" 100 w 0
    alter "Alter" 60 center 1
    stadt "Stadt" 100 w 0
} {
    .f.tv heading $col -text $text -command [list sortTable .f.tv $col $numeric]
    .f.tv column $col -width $width -anchor $anchor
}

# Sortier-Funktion
proc sortTable {tv col numeric} {
    set dir [dict get $::sortDir $col]
    dict set ::sortDir $col [expr {$dir * -1}]
    
    set data {}
    foreach id [$tv children {}] {
        set value [$tv set $id $col]
        lappend data [list $value $id]
    }
    
    if {$numeric} {
        if {$dir > 0} {
            set data [lsort -index 0 -integer $data]
        } else {
            set data [lsort -index 0 -integer -decreasing $data]
        }
    } else {
        if {$dir > 0} {
            set data [lsort -index 0 -dictionary $data]
        } else {
            set data [lsort -index 0 -dictionary -decreasing $data]
        }
    }
    
    set idx 0
    foreach item $data {
        $tv move [lindex $item 1] {} $idx
        incr idx
    }
    
    applyZebra $tv
}

# Zebra-Streifen
.f.tv tag configure oddrow -background #f5f5f5
.f.tv tag configure evenrow -background white

proc applyZebra {tv} {
    set row 0
    foreach id [$tv children {}] {
        if {$row % 2 == 0} {
            $tv item $id -tags evenrow
        } else {
            $tv item $id -tags oddrow
        }
        incr row
    }
}

# Daten laden
proc loadData {tv data} {
    $tv delete [$tv children {}]
    foreach row $data {
        $tv insert {} end -values $row
    }
    applyZebra $tv
}

loadData .f.tv $::data
```

### Dict zu Treeview Mapping

```tcl
package require Tk

# Dict-Daten
set ::data {
    users {
        user1 {name "Max" email "max@example.com"}
        user2 {name "Erika" email "erika@example.com"}
    }
    settings {
        display {theme "dark" language "de"}
        notifications {email 1 push 0}
    }
}

# Treeview erstellen
ttk::treeview .tv -columns {value} -show {tree headings} \
    -yscrollcommand {.vsb set}
ttk::scrollbar .vsb -orient vertical -command {.tv yview}

.tv heading #0 -text "Schlüssel"
.tv heading value -text "Wert"
.tv column #0 -width 200
.tv column value -width 250

pack .vsb -side right -fill y
pack .tv -side left -fill both -expand 1

# Dict rekursiv in Treeview einfügen
proc dictToTreeview {tv parent data} {
    if {![string is list $data] || [llength $data] % 2 != 0} {
        $tv set $parent value $data
        return
    }
    
    if {[catch {dict keys $data} keys]} {
        $tv set $parent value $data
        return
    }
    
    foreach key $keys {
        set value [dict get $data $key]
        set id [$tv insert $parent end -text $key -open true]
        dictToTreeview $tv $id $value
    }
}

dictToTreeview .tv {} $::data
```

---

## Siehe auch

- [listbox.md](listbox.md) - Einfache Listen ohne Hierarchie
- [canvas.md](canvas.md) - Freie grafische Darstellung
- [text.md](text.md) - Formatierter Text
- **tablelist** - Erweiterte Tabellenfunktionen (externes Paket)
- **Tcl/Tk Manual:** https://www.tcl-lang.org/man/tcl8.6/TkCmd/ttk_treeview.html
