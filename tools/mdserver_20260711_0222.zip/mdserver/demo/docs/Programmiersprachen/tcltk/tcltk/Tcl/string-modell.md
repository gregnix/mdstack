# Das String-Modell -- Tcl verstehen

*Stand: 2026-04-29*

Tcl unterscheidet sich fundamental von anderen Sprachen: Es gibt
nur einen Datentyp -- den String. Alles, was in Tcl existiert, ist
ein String: Zahlen, Listen, Code, Konfigurationsdaten. Das ist keine
Einschränkung, sondern ein Designprinzip mit weitreichenden Konsequenzen.

## Alles ist ein String

In Tcl gibt es keine nativen Integer, Floats oder Arrays. Jeder Wert
ist zunaechst ein String. Die Interpretation hängt vom Kontext ab:

```tcl
set x 42

# Als Zahl (expr interpretiert "42" als Integer):
expr {$x + 10}           ;# -> 52

# Als String (string sieht zwei Zeichen):
string length $x          ;# -> 2

# Als Liste (lindex sieht ein Listenelement):
lindex $x 0               ;# -> 42

# Als Boolescher Wert:
if {$x} { puts "wahr" }   ;# -> wahr (nicht-null = wahr)
```

Dasselbe gilt für komplexere Strukturen:

```tcl
set liste {a b c}
# liste enthält den String "a b c"
# Erst wenn ein Listenbefehl kommt, wird er als Liste interpretiert

set code {puts "Hello"}
# code enthält den String {puts "Hello"}
# Erst eval oder uplevel führt ihn als Code aus
```

### Warum Strings?

Tcl wurde 1988 von John Ousterhout als Einbettungssprache entworfen.
Ein universeller Typ (String) vereinfacht die Implementierung und
die Schnittstelle zu C-Programmen. Die Konsequenzen:

- **Keine Typkonvertierungen:** `set x 42` braucht kein `int()` oder Cast.
- **Natuerliche Serialisierung:** Jeder Wert ist bereits Text und kann
  direkt in Dateien geschrieben oder über Netzwerke gesendet werden.
- **Code als Daten:** Da Code auch nur ein String ist, kann Tcl sich
  selbst inspizieren und modifizieren -- Metaprogrammierung ist nativ.
- **Einfache Einbettung:** C-Programme können Tcl-Werte als `char*`
  austauschen, ohne komplexe Objektstrukturen.

## Dual-Ported Objects (Tcl_Obj)

Obwohl "alles String ist", waere es extrem langsam, jede Zahl vor dem
Rechnen aus einem String zu parsen. Tcl löst das mit Dual-Ported
Objects -- intern gespeicherten Werten mit zwei Repraesentationen:

```
Tcl_Obj
    |
    +-- stringRep: "42"         (String-Darstellung, für Ausgabe)
    |
    +-- internalRep: 42         (Native Darstellung, für Berechnung)
    |
    +-- typePtr: tclIntType     (Typ der internen Darstellung)
```

### Lazy Conversion

Nicht beide Repraesentationen müssen gleichzeitig existieren. Tcl
erzeugt sie erst bei Bedarf (lazy):

```tcl
set x [expr {2 + 2}]
# x hat: internalRep=4 (int), stringRep=NULL (noch nicht gebraucht)

puts $x
# Jetzt wird stringRep="4" erzeugt (für die Ausgabe)

expr {$x + 1}
# Nutzt internalRep=4 direkt (kein String-Parsing nötig)
```

### Bekannte interne Typen

Tcl kennt intern verschiedene Typen, die aber für den Programmierer
normalerweise unsichtbar sind:

| Interner Typ      | Erzeugt durch           | Zweck                          |
|--------------------|-------------------------|--------------------------------|
| `int` / `wideInt`  | `expr`, `incr`          | Ganzzahlen                     |
| `double`           | `expr` mit Dezimalpunkt | Gleitkommazahlen               |
| `boolean`          | `if`, `while`           | Wahrheitswerte                 |
| `list`             | `list`, `lindex` etc.   | Geparste Listenstruktur        |
| `dict`             | `dict create` etc.      | Schlüssel-Wert-Paare          |
| `bytearray`        | `binary format`         | Binärdaten                    |
| `cmdName`          | Befehlsaufruf           | Aufgeloeste Befehlsreferenz    |
| `procbody`         | `proc`                  | Kompilierter Prozedurkörper    |

### Typ abfragen (Tcl 8.7+)

Ab Tcl 8.7 kann der aktuelle interne Typ sichtbar gemacht werden:

```tcl
# Tcl 8.7+:
::tcl::unsupported::representation $x
# -> value is a int with a refcount of 2 ...
```

**Achtung:** Diese Information ist nur für Debugging gedacht. Code
sollte nie vom internen Typ abhaengen -- das widerspricht dem
String-Paradigma.

## Shimmering

Shimmering tritt auf, wenn Tcl die interne Repräsentation wechseln
muss, weil ein Wert in unterschiedlichen Kontexten verwendet wird:

```tcl
set x "42"
# x.type = NULL (reiner String)

expr {$x + 1}
# x.type = int (String -> Int konvertiert)

lindex $x 0
# x.type = list (Int -> List konvertiert, Int-Rep verloren!)

expr {$x + 1}
# x.type = int (List -> Int, erneutes Parsen nötig!)
```

Jede Konvertierung kostet Zeit. Bei einzelnen Werten ist das
vernachlaessigbar, aber in engen Schleifen kann Shimmering zum
Performance-Problem werden.

### Shimmering erkennen

```tcl
# Tcl 8.7+: Typ vor und nach Operationen prüfen
proc showType {varName} {
    upvar 1 $varName var
    puts "[::tcl::unsupported::representation $var]"
}

set x 42
showType x    ;# int
lindex $x 0
showType x    ;# list (shimmer!)
expr {$x+1}
showType x    ;# int (shimmer zurück!)
```

### Shimmering vermeiden

```tcl
# SCHLECHT: Derselbe Wert als Zahl und Liste verwendet
set x "1 2 3"
foreach item $x { ... }     ;# x wird Liste
set sum [expr {$x}]         ;# Fehler oder Shimmer

# BESSER: Separate Variablen für verschiedene Verwendungen
set numStr "42"
set numVal [expr {int($numStr)}]
# numStr bleibt String, numVal bleibt Int
```

## Listen sind Strings

Tcl-Listen haben kein eigenes Literal. Eine Liste ist ein String,
der nach bestimmten Regeln geparst wird:

```tcl
set a {a b c}
set b "a b c"
# Beide sind identisch: der String "a b c"
# Erst lindex/lrange etc. interpretieren ihn als 3-Element-Liste
```

### Gruppierung mit geschweiften Klammern

Elemente mit Leerzeichen müssen gruppiert werden:

```tcl
set liste {Hallo Welt {Guten Morgen} Ende}
lindex $liste 0    ;# -> Hallo
lindex $liste 2    ;# -> Guten Morgen (ein Element!)
llength $liste     ;# -> 4
```

### Der list-Befehl: Sicheres Erzeugen

Manuelles String-Basteln ist gefaehrlich:

```tcl
# GEFAEHRLICH:
set name "Hans {Peter"
set liste "a $name b"
llength $liste     ;# -> unvorhersehbar! (unbalancierte Klammern)

# SICHER:
set liste [list a $name b]
llength $liste     ;# -> 3 (immer korrekt)
```

`list` escaped automatisch Sonderzeichen:

```tcl
list "a b" "c {d" "e\nf"
# -> {a b} c\ \{d {e
# f}
# (korrekt escaped, auch wenn es haesslich aussieht)
```

**Regel:** Verwende immer `list` / `lappend` / `linsert` zum Erzeugen
von Listen. Nie manuell mit String-Operationen zusammenbauen.

### Verschachtelte Listen

```tcl
set matrix [list [list 1 2 3] [list 4 5 6] [list 7 8 9]]
# -> {1 2 3} {4 5 6} {7 8 9}

lindex $matrix 1 2      ;# -> 6 (Zeile 1, Spalte 2)
lindex $matrix {1 2}    ;# -> 6 (aequivalent)
```

## Dicts sind Strings

Seit Tcl 8.5 gibt es Dicts -- Schlüssel-Wert-Strukturen, die ebenfalls
als Strings dargestellt werden:

```tcl
set person {name Alice alter 30 stadt Berlin}

dict get $person name     ;# -> Alice
dict get $person alter    ;# -> 30
dict set person beruf Entwickler
# person ist jetzt: name Alice alter 30 stadt Berlin beruf Entwickler
```

Ein Dict ist ein String mit gerader Elementzahl -- jedes ungerade Element
ist ein Schlüssel, jedes gerade ein Wert. Intern speichert Tcl das
als Hash-Tabelle für schnellen Zugriff.

### Dict vs. Array

| Eigenschaft      | dict                    | array                   |
|------------------|-------------------------|-------------------------|
| Speicherung      | Ein Tcl_Obj (ein Wert)  | Viele Variablen         |
| Übergabe        | Als Wert (per Value)    | Per Name (`upvar`)      |
| Verschachtelung  | `dict get $d key sub`   | Nicht nativ             |
| Iteration        | `dict for {k v} $d`     | `array names`, `foreach`|
| Performance      | O(1) Zugriff            | O(1) Zugriff            |
| Serialisierung   | Direkt (ist ein String) | `array get` nötig      |

**Empfehlung:** Dicts sind fast immer die bessere Wahl, ausser wenn
Variablen-Traces auf einzelne Schlüssel benötigt werden (nur Arrays
unterstützen das).

## Code ist String (Homoikonizitaet)

Tcl ist homoikonisch: Code und Daten haben dieselbe Repräsentation.
Das ermöglicht maechtige Metaprogrammierung:

### Code inspizieren

```tcl
proc greet {name} {
    return "Hallo $name"
}

info body greet      ;# -> return "Hallo $name"
info args greet      ;# -> name
info default greet name defVal  ;# -> 0 (kein Default)
```

### Code dynamisch erzeugen

```tcl
# Fabrik-Pattern: Prozedur erzeugt Prozedur
proc makeCounter {name {start 0}} {
    set body [string map [list %START% $start] {
        variable count%START%
        if {![info exists count%START%]} {
            set count%START% %START%
        }
        incr count%START%
    }]
    # Besser: Closure-Pattern mit Lambda
    coroutine $name apply {{start} {
        set n $start
        while 1 {
            yield $n
            incr n
        }
    }} $start
}

makeCounter myCount 10
myCount    ;# -> 10
myCount    ;# -> 11
```

### eval und seine Alternativen

```tcl
# eval -- führt String als Code aus:
set cmd {puts "Hello"}
eval $cmd

# SICHERHEITSRISIKO bei Benutzereingaben:
set input [gets stdin]
eval $input               ;# NIEMALS! Beliebiger Code möglich

# Sichere Alternativen:
# 1. Befehlsliste (kein Parsing):
{*}$cmd                   ;# Expansion-Operator (Tcl 8.5+)

# 2. apply für Lambdas:
set fn {{x} { expr {$x * 2} }}
apply $fn 5               ;# -> 10

# 3. interp eval in Sandbox:
interp create -safe slave
slave eval {expr {2 + 2}}  ;# -> 4 (eingeschraenkter Interpreter)
```

## Performance-Implikationen

### String-Konkatenierung

```tcl
# LANGSAM (O(n^2) -- jedes append kopiert den gesamten String):
set result ""
for {set i 0} {$i < 10000} {incr i} {
    set result "$result x"
}

# SCHNELL (append ist optimiert, O(n) amortisiert):
set result ""
for {set i 0} {$i < 10000} {incr i} {
    append result " x"
}

# NOCH SCHNELLER (ein Aufruf):
set result [string repeat " x" 10000]
```

**Wichtig:** `append` ist speziell optimiert -- es erweitert den
internen Puffer, statt jedes Mal einen neuen String zu erzeugen.
Dagegen erzeugt `set x "$x ..."` jedes Mal eine neue Kopie.

### Listen-Zugriff

```tcl
# Liste: O(n) für Index-Zugriff (muss Elemente zählen)
set bigList [lrepeat 100000 item]
lindex $bigList 99999      ;# Muss 99999 Elemente überspringen

# Dict: O(1) für Key-Zugriff (Hash-Tabelle)
set bigDict [dict create]
for {set i 0} {$i < 100000} {incr i} {
    dict set bigDict key$i value$i
}
dict get $bigDict key99999  ;# Direkter Zugriff
```

### Shimmering in Schleifen

```tcl
# SCHLECHT: Shimmer bei jedem Durchlauf
set data "1 2 3 4 5"
for {set i 0} {$i < 1000} {incr i} {
    set len [llength $data]    ;# data wird Liste
    set sum [expr {$data}]     ;# FEHLER: "1 2 3 4 5" ist kein Ausdruck
}

# BESSER: Einmal konvertieren
set data "1 2 3 4 5"
set dataList [list {*}$data]   ;# Explizit als Liste
foreach item $dataList {
    # item bleibt in konsistentem Typ
}
```

### Performance-Vergleich: Zugriffsmuster

| Operation                  | Komplexitaet | Empfehlung               |
|----------------------------|--------------|--------------------------|
| `lindex $list $i`          | O(n)         | Für kleine Listen OK     |
| `dict get $dict $key`      | O(1)         | Bevorzugt für Lookups   |
| `array get arr($key)`      | O(1)         | Alternative zu Dicts     |
| `append var $text`         | O(1) amort.  | Immer statt "$var$text"  |
| `lappend var $item`        | O(1) amort.  | Immer statt manuellem concat |
| `string index $s $i`       | O(1)         | Schneller Zeichen-Zugriff |
| `lsearch -sorted $list $x` | O(log n)    | Bei sortierten Listen    |

## Vergleich mit anderen Sprachen

| Aspekt              | Tcl                  | Python               | Lisp                   |
|---------------------|----------------------|----------------------|------------------------|
| Grundtyp            | String               | Objekt               | S-Expression           |
| Homoikonisch        | Ja                   | Nein                 | Ja                     |
| Typkonvertierung    | Implizit, lazy       | Explizit             | Explizit               |
| Listen-Literal      | Whitespace-getrennt  | Komma in `[]`        | `(a b c)`              |
| Metaprogrammierung  | Nativ (`info`, `eval`)| Reflection, `exec`  | Makros                 |
| Serialisierung      | Trivial (ist String) | `json`, `pickle`     | `read`/`write`         |

## Zusammenfassung

Das String-Modell ist Tcl's praegendste Eigenschaft:

- **Alles ist String:** Zahlen, Listen, Dicts, Code -- alles hat eine
  String-Repräsentation.
- **Dual-Ported Objects:** Intern speichert Tcl effiziente native
  Typen (int, list, dict), konvertiert aber lazy bei Bedarf.
- **Shimmering:** Wiederholter Typwechsel kostet Performance --
  konsistente Nutzung vermeidet das.
- **list/dict statt String-Basteln:** Immer die typgerechten Befehle
  verwenden, nie manuell Strings zusammensetzen.
- **Code = Daten:** Tcl ist homoikonisch, was maechtige
  Metaprogrammierung ermöglicht, aber auch Sicherheitsrisiken birgt.

## Siehe auch

- [Substitution und Escaping](substitution-escaping.md) -- die Parsing-Regeln,
  die auf dem String-Modell aufbauen
- [Prozeduren](proc.md) -- `info body`/`info args` zur Code-Inspektion
- [Metaprogrammierung](metaprogramming.md) -- dynamische Codeerzeugung
  und -manipulation im Detail
- [Introspection (info)](info.md) -- alle info-Unterbefehle zu Variablen,
  Befehlen und Typen
- [Variablen und Scope](variable-scope.md) -- wie Variablen den
  String-Wert speichern und referenzieren
- [Trace](trace.md) -- Variablen-Traces, die auf Wertaenderungen reagieren
