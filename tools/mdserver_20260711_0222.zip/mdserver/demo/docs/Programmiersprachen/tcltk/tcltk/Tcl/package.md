# Package

*Stand: 2026-04-29*

Packages buendeln zusammengehoerige Prozeduren und Daten unter einem Namen
mit Versionsnummer. Der `package`-Befehl verwaltet das Auffinden, Laden und
die Versionierung von Bibliotheken.

## Grundkonzept

Ein Package ist eine logische Einheit aus einer oder mehreren Tcl-Dateien
(und optional Shared Libraries), die per `package require` geladen wird.
Tcl kuemmert sich um:

- das Auffinden der Dateien über `auto_path`
- Versionspruefung und -auswahl
- Laden nur bei Bedarf (Lazy Loading)
- Schutz vor doppeltem Laden

```tcl
# In der Bibliothek:
package provide mylib 1.0

# In der Anwendung:
package require mylib 1.0
```

## Die drei Saeulen

### package provide

Deklariert, dass ein Package mit bestimmter Version geladen ist:

```tcl
package provide mylib 1.0
```

Dieser Befehl muss in jeder Paket-Datei stehen. Er verhindert doppeltes
Laden: Wenn das Paket bereits geladen ist, passiert nichts. Wenn eine
andere Version bereits geladen ist, gibt es einen Fehler.

Ohne Versionsargument gibt er die aktuell geladene Version zurück:

```tcl
package provide Tcl   ;# -> 8.6.14 (oder ähnlich)
```

### package require

Lädt ein Package:

```tcl
package require mylib             ;# neueste verfügbare Version
package require mylib 1.0         ;# 1.0 oder kompatibel neuer
package require -exact mylib 1.0  ;# nur genau 1.0
```

Wenn das Paket noch nicht geladen ist, sucht Tcl es über die
registrierten Mechanismen (pkgIndex.tcl, .tm Module) und führt
das registrierte Ladescript aus.

### package ifneeded

Registriert ein Script, das ausgeführt wird wenn ein bestimmtes
Paket in einer bestimmten Version benötigt wird:

```tcl
package ifneeded mylib 1.0 [list source [file join $dir mylib.tcl]]
```

Dieser Befehl steht typischerweise in der `pkgIndex.tcl`.
Das Script wird erst bei `package require` ausgeführt (Lazy Loading).

## Versionierung

### Versionsnummern-Syntax

Versionsnummern bestehen aus Dezimalzahlen, getrennt durch Punkte:

| Beispiel | Gueltig |
|:---------|:--------|
| `1` | Ja |
| `1.0` | Ja |
| `1.0.3` | Ja |
| `2.1a5` | Ja (Alpha) |
| `2.1b3` | Ja (Beta) |
| `1.0.0.0` | Ja |

Die Buchstaben `a` (Alpha) und `b` (Beta) kennzeichnen instabile Releases
und duerfen genau einmal statt eines Punktes stehen.

### Versionsvergleich

```tcl
package vcompare 1.0 2.0    ;# -> -1 (1.0 < 2.0)
package vcompare 2.0 1.0    ;# -> 1  (2.0 > 1.0)
package vcompare 1.0 1.0    ;# -> 0  (gleich)
```

### Versionsanforderungen

| Syntax | Bedeutung |
|:-------|:----------|
| `1.0` | Mindestens 1.0, gleiche Major-Version |
| `1.0-2.0` | Mindestens 1.0, kleiner als 2.0 |
| `1.0-` | Mindestens 1.0, kein oberes Limit |
| `-exact 1.0` | Nur genau 1.0 |

Die Konvention lautet: Innerhalb einer Major-Version bleibt die
Rueckwaertskompatibilitaet erhalten. Ein Wechsel der Major-Version
(z.B. 1.x zu 2.x) kann inkompatible Änderungen bringen.

```tcl
package require http 2.0    ;# akzeptiert 2.0, 2.1, 2.9 aber nicht 3.0
```

## Die pkgIndex.tcl

### Funktion

Die Datei `pkgIndex.tcl` ist ein Tcl-Script, das beim Durchsuchen von
`auto_path` ausgewertet wird. Sie registriert Pakete über
`package ifneeded`, lädt sie aber noch nicht.

### Die Variable $dir

Tcl setzt `$dir` automatisch auf das Verzeichnis der pkgIndex.tcl.
Diese Variable darf nicht selbst definiert werden:

```tcl
# pkgIndex.tcl
# $dir ist automatisch gesetzt!
package ifneeded mylib 1.0 [list source [file join $dir mylib.tcl]]
```

### Typische Einträge

Einfaches Paket:

```tcl
package ifneeded mylib 1.0 [list source [file join $dir mylib.tcl]]
```

Paket aus mehreren Dateien:

```tcl
package ifneeded mylib 1.0 [subst {
    source [list [file join $dir core.tcl]]
    source [list [file join $dir util.tcl]]
    source [list [file join $dir ui.tcl]]
}]
```

Alias (alternative Schreibweise):

```tcl
package ifneeded MyLib 1.0 [list package require -exact mylib 1.0]
```

Shared Library:

```tcl
package ifneeded myext 1.0 [list load [file join $dir myext[info sharedlibextension]]]
```

### pkgIndex.tcl generieren

Der Befehl `pkg_mkIndex` erzeugt eine pkgIndex.tcl automatisch:

```tcl
pkg_mkIndex /pfad/zu/lib *.tcl
```

Er durchsucht alle passenden Dateien nach `package provide` und erzeugt
die entsprechenden `package ifneeded` Einträge.

Für komplexere Fälle ist manuelles Schreiben zuverlässiger.

## Der auto_path

`auto_path` ist eine globale Variable mit einer Liste von Verzeichnissen,
in denen Tcl nach `pkgIndex.tcl` Dateien sucht.

### Pfad hinzufügen

```tcl
lappend auto_path /pfad/zu/meinen/packages
```

### Standardpfade

Tcl initialisiert `auto_path` mit:

1. Dem Verzeichnis aus der `TCLLIBPATH`-Umgebungsvariable
2. Der Tcl-Systembibliothek (`$tcl_library`)
3. Verzeichnissen relativ zum Tcl-Executable

### Pfade prüfen

```tcl
puts $auto_path
```

### Automatisches Durchsuchen

Beim ersten `package require` durchsucht Tcl alle Verzeichnisse in
`auto_path` und deren direkte Unterverzeichnisse nach `pkgIndex.tcl`.
Die gefundenen Einträge werden gecacht.

## auto_load und tclIndex

Vor dem Package-System gab es `auto_load` mit `tclIndex`-Dateien.
Dieses System arbeitet auf Prozedur-Ebene statt auf Paket-Ebene.

### tclIndex erzeugen

```tcl
auto_mkindex /pfad/zu/lib *.tcl
```

### Funktionsweise

Wenn ein unbekannter Befehl aufgerufen wird:

1. Der `unknown`-Handler wird aufgerufen
2. Dieser ruft `auto_load` auf
3. `auto_load` sucht den Befehl im `auto_index`-Array
4. Falls nicht gefunden, werden alle `tclIndex`-Dateien in `auto_path` geladen
5. Der Befehl wird erneut im `auto_index` gesucht

Für neue Projekte ist das Package-System (oder besser: .tm Module)
vorzuziehen. Das tclIndex-System ist Legacy.

## Introspection

### Geladene Pakete

```tcl
package names              ;# alle bekannten Pakete (geladen + registriert)
package present mylib      ;# Version des geladenen Pakets (Fehler wenn nicht geladen)
```

### Verfügbare Versionen

```tcl
package versions mylib     ;# Liste verfuegbarer Versionen
```

### Dateien eines Pakets

```tcl
package files mylib        ;# Dateien die zum Paket gehören
```

### Ladescript abfragen

```tcl
package ifneeded mylib 1.0  ;# ohne Script: gibt registriertes Script zurück
```

## Weitere package-Befehle

### package prefer

Steuert ob bei `package require` ohne exakte Version stabile oder
die neueste Version bevorzugt wird:

```tcl
package prefer              ;# Aktuelle Einstellung abfragen
package prefer stable       ;# Nur stabile Versionen (ohne a/b Suffix)
package prefer latest       ;# Neueste Version, auch Alpha/Beta
```

Standardmäßig ist `stable` aktiv. Das bedeutet: Wenn sowohl `1.0`
als auch `1.1a3` verfügbar sind, wählt `package require mylib`
die Version `1.0`.

Mit `latest` würde `1.1a3` gewählt.

Die Einstellung kann nur von `stable` auf `latest` geändert werden,
nicht umgekehrt:

```tcl
package prefer latest       ;# OK
package prefer stable       ;# Fehler wenn vorher latest gesetzt
```

### package forget

Entfernt die Registrierung eines Pakets. Danach ist es weder als
geladen noch als verfügbar bekannt:

```tcl
package forget mylib
```

Nach `package forget` kann das Paket erneut registriert und geladen
werden. Die tatsächlich definierten Prozeduren und Variablen werden
dadurch nicht entfernt, nur die Package-Verwaltung vergisst das Paket.

Typischer Einsatz: Während der Entwicklung ein Paket neu laden:

```tcl
package forget mylib
source /pfad/zu/mylib.tcl   ;# lädt erneut, package provide darin
```

### package unknown

Registriert einen Handler, der aufgerufen wird wenn `package require`
ein unbekanntes Paket anfordert. Der Standard-Handler durchsucht
`auto_path` nach `pkgIndex.tcl` Dateien.

```tcl
# Standard-Handler abfragen
package unknown   ;# -> ::tcl::tm::UnknownHandler ::tclPkgUnknown

# Eigenen Handler setzen
package unknown myPackageHandler

proc myPackageHandler {name args} {
    # Eigene Suchlogik, z.B. aus Netzwerk laden
    puts "Suche Paket: $name $args"
}
```

In der Praxis wird der Standard-Handler selten ersetzt.

### Konfiguration

Das `pkgconfig`-Muster: Pakete können eine `pkgconfig`-Prozedur
im eigenen Namespace bereitstellen:

```tcl
namespace eval mylib {
    proc pkgconfig {subcmd args} {
        variable config
        switch $subcmd {
            list { return [dict keys $config] }
            get  { return [dict get $config [lindex $args 0]] }
        }
    }
    variable config [dict create \
        version "1.0" \
        debug   0 \
        author  "Team" \
    ]
}

mylib::pkgconfig list           ;# -> version debug author
mylib::pkgconfig get version    ;# -> 1.0
```

Tcl selbst nutzt dieses Muster:

```tcl
tcl::pkgconfig list             ;# -> debug threaded optimized ...
tcl::pkgconfig get optimized    ;# -> 1
```

## Plattformuebergreifende Pakete

Das `platform`-Paket hilft bei Paketen mit plattformspezifischen
Shared Libraries:

```tcl
package require platform

platform::identify    ;# -> linux-glibc2.19-x86_64
platform::generic     ;# -> linux-x86_64
```

Ein plattformuebergreifendes Paket kann Shared Libraries in
Unterverzeichnissen ablegen, benannt nach dem Platform-Identifier,
und in der `pkgIndex.tcl` die richtige laden:

```
myext/
|-- pkgIndex.tcl
|-- linux-x86_64/
|   +-- myext.so
+-- win32-x86_64/
    +-- myext.dll
```

```tcl
# pkgIndex.tcl
package require platform
set plat [platform::generic]
package ifneeded myext 1.0 \
    [list load [file join $dir $plat myext[info sharedlibextension]]]
```

### platform::shell

Identifiziert die Plattform eines anderen Tcl-Interpreters auf demselben
System. Nützlich für Installer:

```tcl
package require platform::shell
platform::shell::identify /usr/bin/tclsh8.6
```

## Projektstruktur

Empfohlene Struktur für ein Package-Projekt:

```
mylib/
|-- src/
|   +-- pkg/
|       |-- pkgIndex.tcl
|       |-- core.tcl
|       +-- util.tcl
|-- demo/
|   |-- demo-bootstrap.tcl
|   +-- demo-basic.tcl
|-- tests/
|   +-- test-basic.tcl
+-- README.md
```

### Demo-Bootstrap

Damit Demos ohne Installation funktionieren:

```tcl
# demo-bootstrap.tcl
set demoDir [file dirname [info script]]
set rootDir [file normalize [file join $demoDir ..]]

lappend auto_path [file join $rootDir src pkg]
```

```tcl
# demo-basic.tcl
source [file join [file dirname [info script]] demo-bootstrap.tcl]

package require mylib 1.0
puts [mylib::hello]
```

Der entscheidende Punkt: Pfade immer relativ zum Script, nie zum
aktuellen Arbeitsverzeichnis.

## Häufige Fehler

### package provide fehlt

```tcl
# FALSCH: Paket kann doppelt geladen werden
proc mylib::hello {} { return "hello" }

# RICHTIG:
package provide mylib 1.0
proc mylib::hello {} { return "hello" }
```

### Pfad relativ zum cwd

```tcl
# FALSCH: Funktioniert nur aus einem Verzeichnis
lappend auto_path "../lib"

# RICHTIG: Relativ zum Script
lappend auto_path [file join [file dirname [info script]] ../lib]
```

### list vergessen in pkgIndex.tcl

```tcl
# FALSCH: Bricht bei Leerzeichen im Pfad
package ifneeded mylib 1.0 "source $dir/mylib.tcl"

# RICHTIG: list schützt vor Sonderzeichen
package ifneeded mylib 1.0 [list source [file join $dir mylib.tcl]]
```

### Zirkulaere Abhängigkeiten

```tcl
# Paket A:
package require B   ;# lädt B, das A braucht -> Endlosschleife

# Lösung: Abhängigkeiten auflösen oder gemeinsamen Code
# in ein drittes Paket auslagern
```

## Package vs. Module (.tm)

| Aspekt | Package (pkgIndex) | Modul (.tm) |
|:-------|:-------------------|:------------|
| Dateien | Mehrere möglich | Eine Datei |
| Index | pkgIndex.tcl nötig | Kein Index nötig |
| Pfad-Variable | `auto_path` | `tcl::tm::path` |
| Distribution | Mehrere Dateien | Eine Datei kopieren |
| Shared Libraries | Gut unterstützt | Umstaendlich |
| Performance | Langsamer (Index lesen) | Schneller |
| Empfehlung | Legacy, Aliase, Binaries | Neue Projekte |

Für neue Projekte sind .tm Module fast immer die bessere Wahl.
Siehe die separate Dokumentation zu Tcl Modulen.

## Zusammenfassung

| Befehl | Funktion |
|:-------|:---------|
| `package provide name version` | Paket als geladen markieren |
| `package require name ?version?` | Paket laden |
| `package require -exact name version` | Genau diese Version laden |
| `package ifneeded name version script` | Ladescript registrieren |
| `package names` | Alle bekannten Pakete auflisten |
| `package versions name` | Verfügbare Versionen |
| `package present name` | Geladene Version (Fehler wenn nicht) |
| `package files name` | Dateien des Pakets |
| `package vcompare v1 v2` | Versionen vergleichen |
| `package prefer ?stable/latest?` | Versionspraeference steuern |
| `package forget name` | Paket-Registrierung entfernen |
| `package unknown ?handler?` | Handler für unbekannte Pakete |
| `pkg_mkIndex dir ?pattern?` | pkgIndex.tcl generieren |
| `auto_mkindex dir ?pattern?` | tclIndex generieren (Legacy) |

## Siehe auch

- [Tcl Module](tm-module.md) -- Alternative: Einzeldatei-Module (.tm)
- [Namespace](namespace.md) -- Pakete in Namespaces kapseln
- [Namespace Ensemble](namespace-ensemble.md) -- Paket-API als Ensemble
- [Code laden](source-eval-apply.md) -- `source` für einfaches Laden
