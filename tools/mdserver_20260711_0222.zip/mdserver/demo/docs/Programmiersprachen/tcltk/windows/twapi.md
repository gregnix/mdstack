# TWAPI Handbuch

*Stand: 2026-04-29*

Tcl Windows API - Nachschlagewerk für Windows-Programmierung mit Tcl.

Dieses Handbuch basiert auf der offiziellen TWAPI-Dokumentation von Ashok P. Nadkarni.

## Einfuehrung

TWAPI (Tcl Windows API) bietet direkten Zugriff auf Windows-Funktionen aus Tcl heraus. Es ist die umfangreichste Windows-Erweiterung für Tcl.

### Warum TWAPI

- Tiefe Windows-Integration ohne C-Code
- Umfangreiche Dokumentation
- Aktiv gepflegt
- Teil von Magicsplat Tcl/Tk

### Grundlegende Verwendung

```tcl
package require twapi

# Einfacher Test
puts [twapi::get_os_description]
```

## Installation

### Magicsplat (empfohlen)

Magicsplat enthält TWAPI bereits:

1. Download von https://www.magicsplat.com/tcl-installer/
2. Installer ausführen
3. TWAPI ist enthalten

### Manuell via Teapot

```bash
teacup install twapi
```

### Version prüfen

```tcl
package require twapi
puts [package version twapi]
```

## System

Systeminformationen und Hardware-Zugriff.

### Betriebssystem

```tcl
# OS-Beschreibung (z.B. "Windows 11 Pro")
twapi::get_os_description

# Version als Liste {major minor build}
twapi::get_os_version

# Architektur (z.B. "amd64")
twapi::get_processor_arch
```

### Speicher

```tcl
set mem [twapi::get_memory_info]

# Verfügbare Keys:
# -totalphys -availphys -totalpagefile -availpagefile
# -totalvirtual -availvirtual -memoryload

# Beispiel: RAM in MB
set totalMB [expr {[dict get $mem -totalphys] / 1024 / 1024}]
set availMB [expr {[dict get $mem -availphys] / 1024 / 1024}]
puts "RAM: $availMB / $totalMB MB"
```

### System-Uptime

```tcl
# Millisekunden seit Systemstart
set ms [twapi::get_system_uptime]

# In lesbare Form umrechnen
proc formatUptime {ms} {
    set secs [expr {$ms / 1000}]
    set days [expr {$secs / 86400}]
    set hours [expr {($secs % 86400) / 3600}]
    set mins [expr {($secs % 3600) / 60}]
    return "$days Tage, $hours Std, $mins Min"
}

puts [formatUptime [twapi::get_system_uptime]]
```

### Computername

```tcl
# NetBIOS-Name
twapi::get_computer_name

# Auch verfügbar
twapi::get_computer_netbios_name
```

## Prozesse

Prozessverwaltung und -überwachung.

### Prozesse auflisten

```tcl
# Alle PIDs
set pids [twapi::get_process_ids]

# Name zu PID
twapi::get_process_name $pid

# Pfad zu PID
twapi::get_process_path $pid

# Detaillierte Info
twapi::get_process_info $pid -name -path -commandline -parent
```

### Aktueller Prozess

```tcl
set myPid [pid]
puts "PID: $myPid"
puts "Name: [twapi::get_process_name $myPid]"
puts "Pfad: [twapi::get_process_path $myPid]"
```

### Prozess starten

```tcl
# Einfach starten
twapi::create_process "notepad.exe"

# Mit Argumenten
twapi::create_process "notepad.exe" -cmdline "notepad.exe test.txt"

# Mit Optionen
twapi::create_process "cmd.exe" \
    -cmdline "cmd.exe /c dir" \
    -showwindow hide
```

### Prozess beenden

```tcl
# Vorsicht - nur wenn nötig
twapi::end_process $pid -force
```

## Dateisystem

Laufwerke und Dateisystem-Überwachung.

### Laufwerke

```tcl
# Alle Laufwerke auflisten
twapi::get_logical_drives
# Ergebnis z.B.: {A: C: D: E:}

# Laufwerkstyp ermitteln
twapi::get_drive_type "C:"
# Mögliche Werte: fixed, removable, cdrom, remote, ramdisk
```

### Laufwerksinfo

```tcl
# Freier Speicherplatz
set info [twapi::get_volume_info C:]
dict get $info -freespace
dict get $info -totalspace
```

### Dateisystem-Watcher

Änderungen in Verzeichnissen überwachen:

```tcl
proc onFileChange {path action args} {
    puts "Änderung: $action - $path"
}

# Überwachung starten
set handle [twapi::begin_filesystem_monitor "C:/Temp" onFileChange \
    -subtree 1]

# Später beenden
twapi::cancel_filesystem_monitor $handle
```

## Registry

Windows-Registry lesen und schreiben.

### Werte lesen

```tcl
package require registry

# Wert lesen
set productName [registry get \
    {HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion} \
    ProductName]

# Schlüssel auflisten
registry keys {HKEY_CURRENT_USER\Software}

# Werte eines Schluessels auflisten
registry values {HKEY_CURRENT_USER\Environment}
```

### Werte schreiben

```tcl
# String-Wert setzen
registry set {HKEY_CURRENT_USER\Software\MeineApp} "Setting1" "Wert1"

# DWORD-Wert setzen
registry set {HKEY_CURRENT_USER\Software\MeineApp} "Number1" 42 dword
```

### Schlüssel löschen

```tcl
# Wert löschen
registry delete {HKEY_CURRENT_USER\Software\MeineApp} "Setting1"

# Schlüssel löschen (nur wenn leer)
registry delete {HKEY_CURRENT_USER\Software\MeineApp}
```

## Dienste

Windows-Dienste verwalten (erfordert oft Admin-Rechte).

### Dienste auflisten

```tcl
# Alle Dienstnamen
twapi::get_service_names

# Status eines Dienstes
twapi::get_service_status "wuauserv"
# Mögliche Werte: running, stopped, paused, start_pending, ...
```

### Dienst-Details

```tcl
set cfg [twapi::get_service_configuration "Spooler"]
dict get $cfg -displayname
dict get $cfg -start_type
dict get $cfg -binary_path
```

### Dienste steuern

```tcl
# Starten (erfordert Admin-Rechte)
twapi::start_service "Spooler"

# Stoppen
twapi::stop_service "Spooler"

# Pausieren (wenn unterstützt)
twapi::pause_service "Spooler"
```

## Netzwerk

Netzwerkadapter und Verbindungen.

### Adapter

```tcl
# Liste aller Adapter
set adapters [twapi::get_network_adapters]

# Adapter-Details
foreach adapter $adapters {
    set info [twapi::get_network_adapter_info $adapter]
    puts [dict get $info -description]
}
```

### IP-Adressen

```tcl
set info [twapi::get_network_adapter_info $adapter]
puts [dict get $info -ipaddresses]
```

### TCP-Verbindungen

```tcl
# Aktive TCP-Verbindungen
twapi::get_tcp_connections

# Listening Ports
twapi::get_tcp_listeners
```

### Hostname

```tcl
twapi::get_computer_name
twapi::get_computer_netbios_name
```

## Fenster

Fenster finden und manipulieren.

### Fenster finden

```tcl
# Nach Titel suchen (mit Wildcard)
set wins [twapi::find_windows -text "*Notepad*"]

# Sichtbare Top-Level-Fenster
set visible [twapi::find_windows -visible true -toplevel true]

# Fenster-Text lesen
twapi::get_window_text $hwnd
```

### Fenster-Eigenschaften

```tcl
# Position und Größe
twapi::get_window_coordinates $hwnd

# Klasse
twapi::get_window_class $hwnd

# Prozess-ID
twapi::get_window_process $hwnd
```

### Fenster manipulieren

```tcl
# Verschieben und Größe ändern
twapi::move_window $hwnd 100 100 800 600

# In den Vordergrund bringen
twapi::set_foreground_window $hwnd

# Minimieren
twapi::minimize_window $hwnd

# Maximieren
twapi::maximize_window $hwnd

# Wiederherstellen
twapi::restore_window $hwnd
```

## Zwischenablage

Clipboard-Operationen.

### Text lesen

```tcl
# Prüfen ob Text verfügbar (CF_TEXT = 1)
if {[twapi::clipboard_format_available 1]} {
    set text [twapi::read_clipboard_text]
    puts $text
}
```

### Text schreiben

```tcl
twapi::write_clipboard_text "Hallo Welt"
```

### Formate prüfen

```tcl
# Verfügbare Formate
twapi::get_clipboard_formats

# Wichtige Format-IDs:
# 1 = CF_TEXT
# 13 = CF_UNICODETEXT
# 2 = CF_BITMAP
```

## Shell-Integration

Explorer und Shell-Funktionen.

### Spezielle Ordner

```tcl
twapi::get_shell_folder CSIDL_DESKTOP
twapi::get_shell_folder CSIDL_DOCUMENTS
twapi::get_shell_folder CSIDL_APPDATA
twapi::get_shell_folder CSIDL_PROGRAMS
twapi::get_shell_folder CSIDL_STARTUP
```

### Datei mit Standard-App oeffnen

```tcl
# PDF mit Standard-Viewer oeffnen
twapi::shell_execute -path "C:/Dokumente/test.pdf"

# Mit bestimmtem Verb
twapi::shell_execute -path "test.txt" -verb "edit"

# URL im Browser oeffnen
twapi::shell_execute -path "https://www.tcl.tk"
```

### Verknüpfung erstellen

```tcl
twapi::write_shortcut "C:/Users/Public/Desktop/MeineApp.lnk" \
    -path "C:/Programme/MeineApp/app.exe" \
    -desc "Meine Anwendung" \
    -args "--config default" \
    -workdir "C:/Programme/MeineApp"
```

## COM und Automation

COM-Objekte für Office-Integration etc.

### COM mit tcom

```tcl
package require tcom

# Excel starten
set excel [::tcom::ref createobject "Excel.Application"]
$excel Visible 1

# Arbeitsmappe erstellen
set workbooks [$excel Workbooks]
set wb [$workbooks Add]
set sheet [[$wb Worksheets] Item 1]

# Zelle beschreiben
[$sheet Cells 1 1] Value "Hallo aus Tcl!"

# Speichern und schließen
$wb SaveAs "C:/Temp/test.xlsx"
$wb Close
$excel Quit
```

### COM mit twapi

```tcl
package require twapi_com

set excel [twapi::comobj "Excel.Application"]
$excel Visible 1

# ... analog zu tcom ...

$excel -destroy
```

## Sicherheit

Benutzer und Berechtigungen.

### Aktueller Benutzer

```tcl
twapi::get_current_user
twapi::get_user_name
twapi::get_current_user_sid
```

### Lokale Gruppen

```tcl
# Alle lokalen Gruppen
twapi::get_local_groups

# Mitglieder einer Gruppe
twapi::get_local_group_members "Administrators"
```

### Benutzer prüfen

```tcl
# Ist Benutzer Administrator?
proc isAdmin {} {
    set groups [twapi::get_current_user_groups]
    foreach group $groups {
        if {[string match "*Administrators*" $group]} {
            return 1
        }
    }
    return 0
}
```

## Tipps und Tricks

### Fehlerbehandlung

```tcl
if {[catch {twapi::get_process_name $pid} result]} {
    puts "Fehler: $result"
} else {
    puts "Name: $result"
}
```

### Performance

```tcl
# Mehrere Infos auf einmal holen ist effizienter
set info [twapi::get_process_info $pid -name -path -parent -threads]

# als einzelne Aufrufe
set name [twapi::get_process_name $pid]
set path [twapi::get_process_path $pid]
```

### Debug-Ausgaben

```tcl
# Alle verfügbaren Befehle auflisten
puts [info commands twapi::*]

# Hilfe zu einem Befehl (wenn dokumentiert)
# Siehe https://twapi.magicsplat.com/
```

## Ressourcen

- TWAPI Dokumentation: https://twapi.magicsplat.com/
- Tcl Wiki TWAPI: https://wiki.tcl-lang.org/page/TWAPI
- Magicsplat: https://www.magicsplat.com/

## Eingabe simulieren

Tastatur- und Mauseingaben simulieren.

### Tastatureingabe

```tcl
# Text senden (wie getippt)
twapi::send_keys "Hallo Welt"

# Sondertasten
twapi::send_keys "{ENTER}"
twapi::send_keys "{TAB}"
twapi::send_keys "{BACKSPACE}"
twapi::send_keys "{DELETE}"
twapi::send_keys "{ESCAPE}"
twapi::send_keys "{F1}"

# Modifier-Tasten
twapi::send_keys "^c"          ;# Ctrl+C
twapi::send_keys "^v"          ;# Ctrl+V
twapi::send_keys "%{F4}"       ;# Alt+F4
twapi::send_keys "+{INSERT}"   ;# Shift+Insert

# Mehrere Tasten
twapi::send_keys "^a^c"        ;# Ctrl+A, Ctrl+C
```

### Mauseingabe

```tcl
# Maus bewegen
twapi::move_mouse 100 200

# Mausposition abfragen
set pos [twapi::get_mouse_location]
puts "X: [lindex $pos 0], Y: [lindex $pos 1]"

# Klicken
twapi::click_mouse_button left
twapi::click_mouse_button right
twapi::click_mouse_button middle

# Doppelklick
twapi::click_mouse_button left -count 2
```

### Hotkeys

```tcl
# Hotkey registrieren
set hk_id [twapi::register_hotkey Ctrl-Alt-F11 {
    puts "Hotkey gedrueckt!"
}]

# Hotkey entfernen
twapi::unregister_hotkey $hk_id

# Event-Loop erforderlich (in tclsh)
vwait forever
```

## Verzeichnis überwachen

Änderungen in Ordnern erkennen.

### Einfacher Watcher

```tcl
proc onFileChange {path action args} {
    puts "Änderung: $action"
    puts "Pfad: $path"
    puts "Details: $args"
}

# Überwachung starten
set handle [twapi::begin_filesystem_monitor "C:/Temp" onFileChange \
    -subtree 1 \
    -filename 1 \
    -dirname 1 \
    -size 1 \
    -lastwrite 1]

# Event-Loop starten
vwait forever

# Später: Überwachung beenden
twapi::cancel_filesystem_monitor $handle
```

### Aktionen

Die Callback-Funktion erhält folgende Aktionen:

| Aktion | Beschreibung |
|:-------|:-------------|
| added | Datei/Ordner erstellt |
| removed | Datei/Ordner gelöscht |
| modified | Datei/Ordner geändert |
| renameold | Alter Name bei Umbenennung |
| renamenew | Neuer Name bei Umbenennung |

## WMI Abfragen

Windows Management Instrumentation für Systemabfragen.

### Grundlagen

```tcl
package require twapi_wmi

# WMI-Objekt erstellen
set wmi [twapi::wmi_root]
```

### Prozesse abfragen

```tcl
set wmi [twapi::wmi_root]
$wmi -with {{ExecQuery "SELECT * FROM Win32_Process"}} -iterate proc {
    puts "Name: [$proc Name]"
    puts "PID: [$proc ProcessId]"
    puts "---"
}
```

### Systeminfo abfragen

```tcl
set wmi [twapi::wmi_root]
$wmi -with {{ExecQuery "SELECT * FROM Win32_ComputerSystem"}} -iterate cs {
    puts "Hersteller: [$cs Manufacturer]"
    puts "Modell: [$cs Model]"
    puts "RAM: [expr {[$cs TotalPhysicalMemory] / 1024 / 1024}] MB"
}
```

### Installierte Software

```tcl
set wmi [twapi::wmi_root]
$wmi -with {{ExecQuery "SELECT * FROM Win32_Product"}} -iterate prod {
    puts "[$prod Name] - [$prod Version]"
}
```

## Event Log

Windows Ereignisprotokoll lesen.

### Log-Einträge lesen

```tcl
package require twapi_eventlog

# Eventlog oeffnen
set hlog [twapi::eventlog_open -source "Application"]

# Einträge lesen (neueste zuerst)
set events [twapi::eventlog_read $hlog -direction back]

foreach event $events {
    puts "Zeit: [dict get $event -timewritten]"
    puts "Quelle: [dict get $event -source]"
    puts "Typ: [dict get $event -type]"
    puts "Nachricht: [dict get $event -message]"
    puts "---"
}

# Log schließen
twapi::eventlog_close $hlog
```

### Event-Typen

| Typ | Beschreibung |
|:----|:-------------|
| error | Fehler |
| warning | Warnung |
| information | Information |
| auditsuccess | Audit erfolgreich |
| auditfailure | Audit fehlgeschlagen |

## Drucker

Drucker verwalten und drucken.

### Drucker auflisten

```tcl
package require twapi_printer

# Alle Drucker
set printers [twapi::enumerate_printers]
foreach p $printers {
    puts [dict get $p -name]
}

# Standard-Drucker
set default [twapi::get_default_printer]
puts "Standard: $default"
```

### Drucker-Info

```tcl
set info [twapi::get_printer_info $printerName]
puts "Status: [dict get $info -status]"
puts "Jobs: [dict get $info -jobs]"
```

## Task Scheduler

Geplante Aufgaben verwalten.

### Aufgaben auflisten

```tcl
package require twapi_task

set tasks [twapi::task_enumerate]
foreach task $tasks {
    puts $task
}
```

### Aufgabe erstellen

```tcl
# Aufgabe definieren
twapi::task_create "MeineAufgabe" \
    -path "C:/Scripts/backup.bat" \
    -account SYSTEM \
    -trigger {daily -starttime "02:00"}
```

## Performance Counter

Systemleistung messen.

### CPU-Auslastung

```tcl
package require twapi_pdh

# Counter oeffnen
set query [twapi::pdh_query_open]
set counter [twapi::pdh_add_counter $query "\\Processor(_Total)\\% Processor Time"]

# Wert lesen (zweimal mit Pause)
twapi::pdh_query_collect $query
after 1000
twapi::pdh_query_collect $query

set cpu [twapi::pdh_get_scalar_value $counter]
puts "CPU: [format %.1f $cpu]%"

# Aufräumen
twapi::pdh_counter_close $counter
twapi::pdh_query_close $query
```

## Named Pipes

Inter-Prozess-Kommunikation.

### Server

```tcl
package require twapi_namedpipe

# Pipe erstellen
set pipe [twapi::namedpipe_server "\\\\.\\pipe\\mypipe"]

# Auf Client warten
twapi::namedpipe_wait $pipe

# Daten lesen/schreiben
puts $pipe "Hallo Client"
flush $pipe
set data [gets $pipe]

close $pipe
```

### Client

```tcl
# Pipe oeffnen
set pipe [open "\\\\.\\pipe\\mypipe" r+]
fconfigure $pipe -blocking 1 -buffering line

# Daten lesen/schreiben
set data [gets $pipe]
puts $pipe "Hallo Server"
flush $pipe

close $pipe
```

## Kryptographie

Verschluesselung und Hashing.

### Hash berechnen

```tcl
package require twapi_crypto

# MD5
set hash [twapi::md5 "Hallo Welt"]
puts "MD5: $hash"

# SHA1
set hash [twapi::sha1 "Hallo Welt"]
puts "SHA1: $hash"

# SHA256
set hash [twapi::sha256 "Hallo Welt"]
puts "SHA256: $hash"
```

### Datei hashen

```tcl
set data [twapi::read_file "datei.txt"]
set hash [twapi::sha256 $data]
puts "SHA256: $hash"
```

## Tipps für die Praxis

### Fehler abfangen

```tcl
if {[catch {
    set name [twapi::get_process_name $pid]
} err]} {
    puts "Fehler: $err"
}
```

### Mit try/finally

```tcl
set handle [twapi::get_process_handle $pid]
try {
    # Mit Handle arbeiten
    set info [twapi::get_process_info $pid -name -path]
} finally {
    twapi::close_handle $handle
}
```

### Handles immer schließen

```tcl
# Clipboard
twapi::open_clipboard
try {
    set text [twapi::read_clipboard_text]
} finally {
    twapi::close_clipboard
}

# Prozess-Handle
set h [twapi::get_process_handle $pid]
try {
    # ...
} finally {
    twapi::close_handle $h
}
```

### Admin-Rechte prüfen

```tcl
proc isAdmin {} {
    if {[catch {twapi::process_in_administrators} result]} {
        return 0
    }
    return $result
}

if {![isAdmin]} {
    puts "Warnung: Einige Funktionen erfordern Admin-Rechte"
}
```

## Ressourcen

- TWAPI Dokumentation: https://twapi.magicsplat.com/
- Tcl on Windows Buch: https://www.magicsplat.com/book
- Tcl Wiki TWAPI: https://wiki.tcl-lang.org/page/TWAPI
- Magicsplat: https://www.magicsplat.com/
