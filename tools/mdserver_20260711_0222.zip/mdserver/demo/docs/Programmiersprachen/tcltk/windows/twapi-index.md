# TWAPI Index

*Stand: 2026-04-29*

Übersicht aller TWAPI-Module und wichtiger Befehle.

## Module

| Modul | Package | Beschreibung |
|:------|:--------|:-------------|
| apputil | twapi_apputil | Anwendungs-Hilfsfunktionen |
| base | twapi_base | Basis-Funktionen, Handles |
| certs | twapi_crypto | Zertifikate und PKI |
| clipboard | twapi_clipboard | Zwischenablage |
| com | twapi_com | COM Automation |
| comserver | twapi_com | COM Server erstellen |
| console | twapi_console | Konsolen-Steuerung |
| crypto | twapi_crypto | Kryptographie |
| device | twapi_device | Geräte-Management |
| etw | twapi_etw | Event Tracing for Windows |
| eventlog | twapi_eventlog | Windows Ereignisprotokoll |
| input | twapi_input | Tastatur/Maus-Eingabe |
| msi | twapi_msi | Windows Installer |
| multimedia | twapi_multimedia | Audio/Sound |
| namedpipe | twapi_namedpipe | Named Pipes |
| network | twapi_network | Netzwerk-Funktionen |
| nls | twapi_nls | Sprache und Locale |
| osinfo | twapi_os | Betriebssystem-Info |
| pdh | twapi_pdh | Performance Counter |
| power | twapi_power | Energieverwaltung |
| printer | twapi_printer | Drucker |
| process | twapi_process | Prozesse und Threads |
| registry | twapi_registry | Windows Registry |
| resource | twapi_resource | Ressourcen in EXE/DLL |
| schedule | twapi_task | Task Scheduler |
| security | twapi_security | Sicherheit und ACLs |
| services | twapi_service | Windows Dienste |
| share | twapi_share | Dateifreigaben |
| shell | twapi_shell | Windows Shell |
| sspi | twapi_security | Security Support Provider |
| storage | twapi_storage | Speicher und Laufwerke |
| synch | twapi_synch | Synchronisation |
| tls | twapi_crypto | TLS/SSL |
| ui | twapi_ui | Fenster und UI |
| users | twapi_account | Benutzer und Gruppen |
| winsta | twapi_winsta | Window Stations |
| wmi | twapi_wmi | WMI Abfragen |

## Befehle nach Kategorie

### System und OS

```tcl
twapi::get_os_description        ;# OS-Name (z.B. "Windows 11 Pro")
twapi::get_os_version            ;# Version als Liste {major minor build}
twapi::get_os_info               ;# Detaillierte OS-Info
twapi::get_processor_arch        ;# Architektur (amd64, x86)
twapi::get_computer_name         ;# Computername
twapi::get_system_uptime         ;# Laufzeit in Millisekunden
twapi::get_memory_info           ;# RAM-Statistik
twapi::get_system_parameters_info ;# Systemparameter
```

### Prozesse

```tcl
twapi::get_process_ids           ;# Alle PIDs
twapi::get_process_name PID      ;# Prozessname
twapi::get_process_path PID      ;# Pfad zur EXE
twapi::get_process_info PID ?opts? ;# Detaillierte Info
twapi::get_process_commandline PID ;# Kommandozeile
twapi::get_process_memory_info PID ;# Speichernutzung
twapi::get_process_modules PID   ;# Geladene DLLs
twapi::create_process PROG ?opts? ;# Prozess starten
twapi::end_process PID ?-force?  ;# Prozess beenden
twapi::process_exists PID        ;# Existiert Prozess?
twapi::get_current_process_id    ;# Eigene PID
```

### Threads

```tcl
twapi::get_current_thread_id     ;# Eigene TID
twapi::get_process_thread_ids PID ;# Alle Threads eines Prozesses
twapi::get_thread_info TID       ;# Thread-Info
twapi::suspend_thread TID        ;# Thread anhalten
twapi::resume_thread TID         ;# Thread fortsetzen
```

### Dienste

```tcl
twapi::get_service_names         ;# Alle Dienstnamen
twapi::get_service_status NAME   ;# Status (running, stopped, ...)
twapi::get_service_state NAME    ;# Zustand
twapi::get_service_configuration NAME ;# Konfiguration
twapi::start_service NAME        ;# Starten
twapi::stop_service NAME         ;# Stoppen
twapi::pause_service NAME        ;# Pausieren
twapi::continue_service NAME     ;# Fortsetzen
twapi::service_exists NAME       ;# Existiert Dienst?
twapi::create_service NAME CMD ?opts? ;# Dienst erstellen
twapi::delete_service NAME       ;# Dienst löschen
```

### Fenster und UI

```tcl
twapi::find_windows ?opts?       ;# Fenster suchen
twapi::get_window_text HWND      ;# Fenstertitel
twapi::set_window_text HWND TEXT ;# Titel setzen
twapi::get_window_coordinates HWND ;# Position/Größe
twapi::move_window HWND X Y W H  ;# Verschieben/Größe
twapi::show_window HWND          ;# Anzeigen
twapi::hide_window HWND          ;# Verstecken
twapi::minimize_window HWND      ;# Minimieren
twapi::maximize_window HWND      ;# Maximieren
twapi::restore_window HWND       ;# Wiederherstellen
twapi::set_foreground_window HWND ;# In Vordergrund
twapi::get_foreground_window     ;# Aktives Fenster
twapi::get_desktop_window        ;# Desktop-Handle
```

### Zwischenablage

```tcl
twapi::open_clipboard            ;# Clipboard oeffnen
twapi::close_clipboard           ;# Clipboard schließen
twapi::read_clipboard_text       ;# Text lesen
twapi::write_clipboard_text TEXT ;# Text schreiben
twapi::clipboard_format_available FMT ;# Format verfügbar?
twapi::get_clipboard_formats     ;# Verfügbare Formate
twapi::empty_clipboard           ;# Leeren
```

### Netzwerk

```tcl
twapi::get_network_adapters      ;# Adapter-Liste
twapi::get_network_adapter_info ID ;# Adapter-Details
twapi::get_tcp_connections       ;# TCP-Verbindungen
twapi::get_udp_connections       ;# UDP-Verbindungen
twapi::get_tcp_listeners         ;# Listening Ports
twapi::get_ip_addresses          ;# IP-Adressen
twapi::resolve_hostname NAME     ;# DNS-Auflösung
twapi::resolve_address IP        ;# Reverse DNS
```

### Dateisystem und Laufwerke

```tcl
twapi::get_logical_drives        ;# Laufwerksbuchstaben
twapi::get_drive_type DRV        ;# Laufwerkstyp
twapi::get_volume_info DRV       ;# Volume-Info
twapi::get_mounted_volume_paths VOL ;# Mount-Punkte
twapi::begin_filesystem_monitor PATH CB ?opts? ;# Watcher
twapi::cancel_filesystem_monitor HANDLE ;# Watcher stoppen
```

### Shell und Explorer

```tcl
twapi::get_shell_folder CSIDL    ;# Spezielle Ordner
twapi::shell_execute ?opts?      ;# Datei/URL oeffnen
twapi::write_shortcut PATH ?opts? ;# Verknüpfung erstellen
twapi::read_shortcut PATH        ;# Verknüpfung lesen
twapi::recycle_file PATH         ;# In Papierkorb
twapi::shell_object_properties_dialog PATH ;# Eigenschaften-Dialog
```

### Benutzer und Gruppen

```tcl
twapi::get_current_user          ;# Aktueller Benutzer
twapi::get_user_name             ;# Benutzername
twapi::get_current_user_sid      ;# Benutzer-SID
twapi::get_user_account_info USER ;# Benutzer-Info
twapi::get_local_groups          ;# Lokale Gruppen
twapi::get_local_group_members GRP ;# Gruppenmitglieder
twapi::get_user_local_groups USER ;# Gruppen eines Benutzers
twapi::new_user USER PASS ?opts? ;# Benutzer erstellen
twapi::delete_user USER          ;# Benutzer löschen
```

### Eingabe simulieren

```tcl
twapi::send_keys KEYS            ;# Tastatureingabe
twapi::send_input INPUT          ;# Low-Level Eingabe
twapi::click_mouse_button BTN    ;# Mausklick
twapi::move_mouse X Y            ;# Maus bewegen
twapi::get_mouse_location        ;# Mausposition
twapi::register_hotkey MODS KEY SCRIPT ;# Hotkey registrieren
twapi::unregister_hotkey ID      ;# Hotkey entfernen
```

### Audio/Multimedia

```tcl
twapi::beep ?FREQ? ?DUR?         ;# Beep-Ton
twapi::play_sound FILE ?opts?    ;# WAV abspielen
twapi::stop_sound                ;# Sound stoppen
twapi::get_volume_info           ;# Lautstaerke
twapi::set_volume LEVEL          ;# Lautstaerke setzen
```

### Registry (mit twapi)

```tcl
twapi::reg_key_open ROOT KEY ?opts? ;# Schlüssel oeffnen
twapi::reg_key_close HANDLE      ;# Schlüssel schließen
twapi::reg_key_create ROOT KEY   ;# Schlüssel erstellen
twapi::reg_key_delete ROOT KEY   ;# Schlüssel löschen
twapi::reg_value_get HANDLE NAME ;# Wert lesen
twapi::reg_value_set HANDLE NAME VAL TYPE ;# Wert schreiben
twapi::reg_value_delete HANDLE NAME ;# Wert löschen
twapi::reg_keys HANDLE           ;# Unterschluessel
twapi::reg_values HANDLE         ;# Werte auflisten
```

### Sicherheit

```tcl
twapi::get_current_user_sid      ;# Eigene SID
twapi::lookup_account_name NAME  ;# Name zu SID
twapi::lookup_account_sid SID    ;# SID zu Name
twapi::get_file_security_descriptor PATH ;# Datei-ACL
twapi::set_file_security_descriptor PATH SD ;# ACL setzen
twapi::get_process_integrity     ;# Integrity Level
twapi::get_process_elevation     ;# Elevation Status
```

### WMI

```tcl
twapi::wmi_root                  ;# WMI Root-Objekt
twapi::wmi_collect_classes ?NS?  ;# WMI Klassen
# Beispiel:
set wmi [twapi::wmi_root]
$wmi -with {{ExecQuery "SELECT * FROM Win32_Process"}} -iterate proc {
    puts [$proc Name]
}
```

## Beispiel-Skripte

| Datei | Beschreibung |
|:------|:-------------|
| beep | System-Beep |
| bringtoforeground | Fenster in Vordergrund |
| checkavailablespace | Speicherplatz prüfen |
| dumpeventlog | Ereignisprotokoll ausgeben |
| exitprograms | Programme beenden |
| getclipboard | Zwischenablage lesen |
| hidewindows | Fenster verstecken |
| hotkey | Hotkey registrieren |
| installservice | Dienst installieren |
| killprograms | Programme killen |
| listdrives | Laufwerke auflisten |
| listusers | Benutzer auflisten |
| mapdrive | Netzlaufwerk verbinden |
| monitordir | Verzeichnis überwachen |
| playwavfile | WAV abspielen |
| printcomputername | Computername ausgeben |
| printsysteminfo | Systeminfo ausgeben |
| putclipboard | In Zwischenablage schreiben |
| restartservice | Dienst neustarten |
| sendtext | Text senden (Tastatur) |
| showacls | ACLs anzeigen |
| showprocessowners | Prozess-Besitzer anzeigen |
| showrunningservices | Laufende Dienste |
| showwindows | Fenster anzeigen |
| unmapdrive | Netzlaufwerk trennen |

## CSIDL-Konstanten für Shell-Ordner

| Konstante | Beschreibung |
|:----------|:-------------|
| CSIDL_DESKTOP | Desktop |
| CSIDL_PROGRAMS | Startmenue Programme |
| CSIDL_PERSONAL | Eigene Dateien |
| CSIDL_DOCUMENTS | Dokumente |
| CSIDL_FAVORITES | Favoriten |
| CSIDL_STARTUP | Autostart |
| CSIDL_RECENT | Zuletzt verwendet |
| CSIDL_SENDTO | Senden an |
| CSIDL_STARTMENU | Startmenue |
| CSIDL_APPDATA | Anwendungsdaten (Roaming) |
| CSIDL_LOCAL_APPDATA | Anwendungsdaten (Lokal) |
| CSIDL_PROGRAM_FILES | Programme |
| CSIDL_WINDOWS | Windows-Verzeichnis |
| CSIDL_SYSTEM | System32 |
| CSIDL_FONTS | Schriftarten |

## Ressourcen

- TWAPI Dokumentation: https://twapi.magicsplat.com/
- Magicsplat: https://www.magicsplat.com/
- Tcl on Windows Buch: https://www.magicsplat.com/book
