# Tcl/Tk unter Windows

*Stand: 2026-04-29*

Tcl/Tk läuft hervorragend unter Windows. Dieses Dokument beschreibt die wichtigsten Windows-spezifischen Aspekte.

## Installation

### Magicsplat (empfohlen)

Magicsplat ist die umfangreichste Tcl/Tk-Distribution für Windows:

- Tcl/Tk 8.6+
- Alle wichtigen Pakete vorinstalliert
- TWAPI, tcom, tdbc enthalten
- Einfacher MSI-Installer

Download: https://www.magicsplat.com/tcl-installer/

### ActiveTcl

Alternative von ActiveState:

- Kommerzieller Support verfügbar
- Community Edition kostenlos
- Weniger Pakete als Magicsplat

### Installation prüfen

```tcl
puts "Tcl Version: [info patchlevel]"
puts "Tk Version: [package version Tk]"
puts "Plattform: $tcl_platform(platform)"
```

## Pfade und Dateisystem

### Pfad-Schreibweise

Tcl akzeptiert Forward-Slashes auf allen Plattformen:

```tcl
# Empfohlen - funktioniert überall
set path "C:/Users/Name/Documents"

# Auch möglich mit Backslash (muss escaped werden)
set path "C:\\Users\\Name\\Documents"

# file join für portable Pfade
set path [file join $env(USERPROFILE) Documents]
```

### Wichtige Umgebungsvariablen

```tcl
# Benutzerverzeichnis
puts $env(USERPROFILE)
# z.B. C:/Users/Name

# Anwendungsdaten
puts $env(APPDATA)
# z.B. C:/Users/Name/AppData/Roaming

# Lokale Anwendungsdaten
puts $env(LOCALAPPDATA)
# z.B. C:/Users/Name/AppData/Local

# Temporaeres Verzeichnis
puts $env(TEMP)
# z.B. C:/Users/Name/AppData/Local/Temp

# Programmverzeichnis
puts $env(PROGRAMFILES)
# z.B. C:/Program Files
```

### Konfigurationsdateien speichern

```tcl
proc getConfigDir {appName} {
    set base $::env(APPDATA)
    set dir [file join $base $appName]
    if {![file exists $dir]} {
        file mkdir $dir
    }
    return $dir
}

# Verwendung
set configDir [getConfigDir "MeineApp"]
set configFile [file join $configDir "settings.conf"]
```

## Registry

Windows-Registry direkt aus Tcl ansprechen.

### Package laden

```tcl
package require registry
```

### Werte lesen

```tcl
# String-Wert lesen
set value [registry get {HKEY_CURRENT_USER\Environment} "Path"]

# Mit Fehlerbehandlung
if {[catch {
    set value [registry get $key $name]
} err]} {
    puts "Registry-Fehler: $err"
}
```

### Werte schreiben

```tcl
# String
registry set {HKEY_CURRENT_USER\Software\MeineApp} "Setting1" "Wert"

# DWORD (Zahl)
registry set {HKEY_CURRENT_USER\Software\MeineApp} "Number1" 42 dword
```

### Schlüssel auflisten

```tcl
# Unterschluessel
set keys [registry keys {HKEY_CURRENT_USER\Software}]

# Werte eines Schluessels
set values [registry values {HKEY_CURRENT_USER\Environment}]
```

### Registry-Typen

| Typ | Beschreibung |
|:----|:-------------|
| sz | String |
| expand_sz | String mit Umgebungsvariablen |
| dword | 32-bit Zahl |
| binary | Binärdaten |
| multi_sz | Liste von Strings |

## COM Automation

Windows-Anwendungen per COM steuern.

### tcom (empfohlen)

```tcl
package require tcom

# Excel starten
set excel [::tcom::ref createobject "Excel.Application"]
$excel Visible 1

# Arbeitsmappe erstellen
set wb [[$excel Workbooks] Add]
set sheet [[$wb Worksheets] Item 1]

# Zellen beschreiben
[$sheet Cells 1 1] Value "Spalte A"
[$sheet Cells 1 2] Value "Spalte B"
[$sheet Cells 2 1] Value 100
[$sheet Cells 2 2] Value 200

# Speichern
$wb SaveAs "C:/Temp/test.xlsx"

# Schließen
$wb Close
$excel Quit
```

### Word-Beispiel

```tcl
package require tcom

set word [::tcom::ref createobject "Word.Application"]
$word Visible 1

set docs [$word Documents]
set doc [$docs Add]

set sel [$word Selection]
$sel TypeText "Hallo aus Tcl!"
$sel TypeParagraph
$sel TypeText "Zweite Zeile"

$doc SaveAs "C:/Temp/test.docx"
$doc Close
$word Quit
```

### Outlook-Beispiel

```tcl
package require tcom

# Outlook starten oder verbinden
if {[catch {::tcom::ref getactiveobject "Outlook.Application"} app]} {
    set app [::tcom::ref createobject "Outlook.Application"]
}

# Neue Mail erstellen (olMailItem = 0)
set mail [$app CreateItem 0]
$mail To "empfaenger@example.com"
$mail Subject "Test von Tcl"
$mail Body "Dies ist eine Test-Mail."

# Mail anzeigen (nicht senden)
$mail Display
```

## Dateityp-Verknuepfungen

Dateien mit Standard-Anwendung oeffnen.

### Mit TWAPI

```tcl
package require twapi

# Datei mit Standard-App oeffnen
twapi::shell_execute -path "C:/Dokument.pdf"

# URL im Browser oeffnen
twapi::shell_execute -path "https://www.tcl.tk"

# Ordner im Explorer oeffnen
twapi::shell_execute -path "C:/Users"
```

### Mit exec

```tcl
# start-Befehl verwenden
exec {*}[auto_execok start] "" "C:/Dokument.pdf" &

# Spezifische Anwendung
exec {*}[auto_execok start] "" notepad.exe "C:/test.txt" &
```

## ttk Theming

Native Windows-Optik mit ttk.

### Verfügbare Themes

```tcl
# Alle Themes auflisten
puts [ttk::style theme names]
# Typisch: clam alt default classic vista winnative xpnative

# Theme setzen
ttk::style theme use vista
```

### Theme-Empfehlung

| Theme | Beschreibung |
|:------|:-------------|
| vista | Moderner Windows-Look (empfohlen) |
| winnative | Klassischer Windows-Look |
| clam | Plattformübergreifend konsistent |

### Theme beim Start setzen

```tcl
package require Tk

# Am Anfang der Anwendung
if {$tcl_platform(platform) eq "windows"} {
    ttk::style theme use vista
}
```

## Native Dialoge

Windows-Dialoge verwenden.

### Datei oeffnen

```tcl
set filename [tk_getOpenFile \
    -title "Datei oeffnen" \
    -filetypes {
        {"Textdateien" {.txt}}
        {"Alle Dateien" *}
    } \
    -initialdir [pwd]]

if {$filename ne ""} {
    puts "Gewählt: $filename"
}
```

### Datei speichern

```tcl
set filename [tk_getSaveFile \
    -title "Speichern unter" \
    -defaultextension ".txt" \
    -filetypes {
        {"Textdateien" {.txt}}
        {"Alle Dateien" *}
    }]
```

### Verzeichnis wählen

```tcl
set dirname [tk_chooseDirectory \
    -title "Ordner wählen" \
    -initialdir $env(USERPROFILE)]
```

### Farbauswahl

```tcl
set color [tk_chooseColor \
    -title "Farbe wählen" \
    -initialcolor "#ff0000"]
```

## Konsole und Ausgaben

### Konsole ausblenden

```tcl
# Konsole beim Start ausblenden (nur Windows)
if {$tcl_platform(platform) eq "windows"} {
    console hide
}

# Konsole für Debug anzeigen
console show
```

### Ohne Konsole starten

Anwendung mit `wish` statt `tclsh` starten, oder:

```batch
@echo off
start /b wish app.tcl
```

## Encoding

Zeichensatz-Probleme vermeiden.

### UTF-8 verwenden

```tcl
# Datei mit UTF-8 lesen
set fh [open $filename r]
fconfigure $fh -encoding utf-8
set content [read $fh]
close $fh

# Datei mit UTF-8 schreiben
set fh [open $filename w]
fconfigure $fh -encoding utf-8
puts $fh $content
close $fh
```

### System-Encoding

```tcl
# Standard-Encoding des Systems
puts [encoding system]
# Auf Windows oft: cp1252

# Verfügbare Encodings
puts [encoding names]
```

## Prozesse starten

Externe Programme ausführen.

### exec Grundlagen

```tcl
# Einfacher Befehl
set result [exec cmd /c dir]

# Mit Argumenten
exec notepad.exe "test.txt"

# Im Hintergrund
exec notepad.exe &
```

### auto_execok verwenden

```tcl
# Findet ausführbare Datei
set notepad [auto_execok notepad]
exec {*}$notepad "test.txt" &

# start-Befehl für URLs/Dateien
exec {*}[auto_execok start] "" "https://www.tcl.tk" &
```

### Ausgabe erfassen

```tcl
# stdout erfassen
set output [exec cmd /c "dir /b"]

# stdout und stderr
set output [exec cmd /c "dir /b" 2>@1]
```

## Deployment

Anwendung verteilen.

### Starkit erstellen

```tcl
# Mit sdx (separat installieren)
# sdx wrap app.kit
# sdx wrap app.exe -runtime tclkit.exe
```

### Batch-Starter

```batch
@echo off
REM app-starter.bat
cd /d "%~dp0"
wish app\main.tcl %*
```

### Abhängigkeiten prüfen

```tcl
proc checkDependencies {} {
    set missing {}
    
    foreach pkg {Tk tdbc::sqlite3 tablelist_tile} {
        if {[catch {package require $pkg}]} {
            lappend missing $pkg
        }
    }
    
    if {[llength $missing] > 0} {
        tk_messageBox -icon error \
            -title "Fehlende Pakete" \
            -message "Folgende Pakete fehlen:\n[join $missing \n]"
        exit 1
    }
}
```

## Häufige Probleme

### DPI-Skalierung

Auf hochaufloesenden Displays kann die Darstellung unscharf sein:

```tcl
# DPI-Awareness setzen (Windows 10+)
if {$tcl_platform(platform) eq "windows"} {
    catch {
        package require twapi
        twapi::set_process_dpi_awareness 2
    }
}
```

### Fokus-Probleme

Fenster kommt nicht in den Vordergrund:

```tcl
# Fenster aktivieren
wm deiconify .
raise .
focus -force .
```

### Pfade mit Leerzeichen

```tcl
# Falsch
exec notepad C:/Program Files/app/file.txt

# Richtig (mit geschweiften Klammern)
exec notepad {C:/Program Files/app/file.txt}

# Oder mit file nativename
exec notepad [file nativename "C:/Program Files/app/file.txt"]
```

## Ressourcen

- Magicsplat Tcl/Tk: https://www.magicsplat.com/tcl-installer/
- TWAPI Dokumentation: https://twapi.magicsplat.com/
- Tcl Wiki Windows: https://wiki.tcl-lang.org/page/Windows
- tcom Dokumentation: https://wiki.tcl-lang.org/page/tcom
