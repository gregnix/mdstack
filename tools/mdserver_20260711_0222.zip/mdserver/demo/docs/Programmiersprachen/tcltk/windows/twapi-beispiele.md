# TWAPI Beispiele

*Stand: 2026-04-29*

Lauffaehige Code-Beispiele für den TWAPI-Explorer.

## System

### Betriebssystem-Info

```tcl
set os [twapi::get_os_description]
set ver [twapi::get_os_version]
set arch [twapi::get_processor_arch]
return "OS: $os\nVersion: [join $ver .]\nArchitektur: $arch"
```

### Speicher-Info

```tcl
set mem [twapi::get_memory_info]
set total [expr {[dict get $mem -totalphys] / 1024 / 1024}]
set avail [expr {[dict get $mem -availphys] / 1024 / 1024}]
set used [expr {$total - $avail}]
set pct [expr {100.0 * $used / $total}]
return "Gesamt: $total MB\nVerfuegbar: $avail MB\nBenutzt: $used MB ([format %.1f $pct]%)"
```

### System-Uptime

```tcl
set ms [twapi::get_system_uptime]
set secs [expr {$ms / 1000}]
set days [expr {$secs / 86400}]
set hours [expr {($secs % 86400) / 3600}]
set mins [expr {($secs % 3600) / 60}]
return "Laufzeit: $days Tage, $hours Stunden, $mins Minuten"
```

### Computername und Benutzer

```tcl
set computer [twapi::get_computer_name]
set user [twapi::get_current_user]
return "Computer: $computer\nBenutzer: $user"
```

## Prozesse

### Alle Prozesse auflisten

```tcl
set result ""
set pids [twapi::get_process_ids]
foreach pid [lrange $pids 0 19] {
    catch {
        set name [twapi::get_process_name $pid]
        append result [format "%6d  %s\n" $pid $name]
    }
}
return "PID     Name\n------  ----\n$result"
```

### Aktueller Prozess

```tcl
set pid [pid]
set name [twapi::get_process_name $pid]
set path [twapi::get_process_path $pid]
set mem [twapi::get_process_memory_info $pid]
set ws [expr {[dict get $mem -workingsetsize] / 1024}]
return "PID: $pid\nName: $name\nPfad: $path\nSpeicher: $ws KB"
```

### Prozess suchen

```tcl
set suchname "notepad*"
set pids [twapi::get_process_ids -glob -name $suchname]
if {[llength $pids] == 0} {
    return "Kein Prozess gefunden: $suchname"
}
set result "Gefunden:\n"
foreach pid $pids {
    catch {
        append result "$pid: [twapi::get_process_name $pid]\n"
    }
}
return $result
```

## Fenster

### Sichtbare Fenster

```tcl
set result ""
set wins [twapi::find_windows -visible true -toplevel true]
foreach hwnd [lrange $wins 0 14] {
    catch {
        set title [twapi::get_window_text $hwnd]
        if {$title ne ""} {
            append result [format "0x%08X  %s\n" $hwnd $title]
        }
    }
}
return "Handle      Titel\n----------  -----\n$result"
```

### Fenster nach Titel finden

```tcl
set suchtitel "*Notepad*"
set wins [twapi::find_windows -text $suchtitel]
if {[llength $wins] == 0} {
    return "Kein Fenster gefunden: $suchtitel"
}
set result ""
foreach hwnd $wins {
    set title [twapi::get_window_text $hwnd]
    set pos [twapi::get_window_coordinates $hwnd]
    append result "Handle: $hwnd\nTitel: $title\nPosition: $pos\n\n"
}
return $result
```

## Zwischenablage

### Text lesen

```tcl
twapi::open_clipboard
try {
    if {[twapi::clipboard_format_available 1]} {
        set text [twapi::read_clipboard_text]
        return "Inhalt:\n$text"
    } else {
        return "(Kein Text in Zwischenablage)"
    }
} finally {
    twapi::close_clipboard
}
```

### Text schreiben

```tcl
set text "Hallo von TWAPI-Explorer!\n[clock format [clock seconds]]"
twapi::open_clipboard
twapi::empty_clipboard
twapi::write_clipboard_text $text
twapi::close_clipboard
return "Geschrieben:\n$text"
```

## Shell

### Spezielle Ordner

```tcl
set result ""
set folders {
    CSIDL_DESKTOP "Desktop"
    CSIDL_DOCUMENTS "Dokumente"
    CSIDL_APPDATA "AppData"
    CSIDL_LOCAL_APPDATA "LocalAppData"
    CSIDL_PROGRAM_FILES "Programme"
    CSIDL_WINDOWS "Windows"
}
foreach {csidl name} $folders {
    catch {
        set path [twapi::get_shell_folder $csidl]
        append result "$name:\n  $path\n"
    }
}
return $result
```

### Datei mit Standard-App oeffnen

```tcl
# Notepad oeffnen
twapi::shell_execute -path "notepad.exe"
return "Notepad gestartet"
```

## Netzwerk

### Netzwerkadapter

```tcl
set result ""
foreach ifc [twapi::get_network_adapters] {
    catch {
        set info [twapi::get_network_adapter_info $ifc]
        set name [dict get $info -description]
        set ips [dict get $info -ipaddresses]
        append result "$name\n"
        foreach ip $ips {
            append result "  IP: $ip\n"
        }
    }
}
return $result
```

### TCP-Verbindungen

```tcl
set result "Lokale Adresse          Remote Adresse          Status\n"
append result [string repeat - 70]
append result "\n"
set conns [twapi::get_tcp_connections]
foreach conn [lrange $conns 0 9] {
    set local "[dict get $conn -localaddr]:[dict get $conn -localport]"
    set remote "[dict get $conn -remoteaddr]:[dict get $conn -remoteport]"
    set state [dict get $conn -state]
    append result [format "%-22s  %-22s  %s\n" $local $remote $state]
}
return $result
```

## Dienste

### Laufende Dienste

```tcl
set result ""
set services [twapi::get_service_names]
foreach svc [lrange $services 0 14] {
    catch {
        set status [twapi::get_service_status $svc]
        if {$status eq "running"} {
            append result "$svc\n"
        }
    }
}
return "Laufende Dienste:\n$result"
```

### Dienst-Status prüfen

```tcl
set svcname "Spooler"
if {[twapi::service_exists $svcname]} {
    set status [twapi::get_service_status $svcname]
    set cfg [twapi::get_service_configuration $svcname]
    set display [dict get $cfg -displayname]
    return "Dienst: $display\nInterner Name: $svcname\nStatus: $status"
} else {
    return "Dienst nicht gefunden: $svcname"
}
```

## Registry

### Werte lesen

```tcl
package require registry
set key {HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion}
set product [registry get $key ProductName]
set build [registry get $key CurrentBuildNumber]
set owner [registry get $key RegisteredOwner]
return "Produkt: $product\nBuild: $build\nRegistriert: $owner"
```

### Umgebungsvariablen

```tcl
package require registry
set key {HKEY_CURRENT_USER\Environment}
set values [registry values $key]
set result ""
foreach val [lrange $values 0 9] {
    catch {
        set data [registry get $key $val]
        append result "$val = $data\n"
    }
}
return $result
```

## Eingabe

### Tastatureingabe senden

```tcl
# Erst Notepad starten und Fokus setzen
# twapi::send_keys "Hallo Welt!{ENTER}"
return "Tastatureingabe: twapi::send_keys \"Text{ENTER}\"\n\nSondertasten:\n{ENTER} {TAB} {BACKSPACE} {DELETE}\n{F1}-{F12} {HOME} {END}\n^=Ctrl +=Shift %=Alt"
```

### Mausposition

```tcl
set pos [twapi::get_mouse_location]
return "Mausposition: X=[lindex $pos 0], Y=[lindex $pos 1]"
```

## Laufwerke

### Alle Laufwerke

```tcl
set result ""
foreach drv [twapi::get_logical_drives] {
    set type [twapi::get_drive_type $drv]
    append result "$drv  $type\n"
}
return "Laufwerk  Typ\n--------  ---\n$result"
```

### Speicherplatz

```tcl
set drv "C:"
set info [twapi::get_volume_info $drv]
set total [expr {[dict get $info -size] / 1024 / 1024 / 1024}]
set free [expr {[dict get $info -freespace] / 1024 / 1024 / 1024}]
set used [expr {$total - $free}]
return "Laufwerk $drv\nGesamt: $total GB\nBelegt: $used GB\nFrei: $free GB"
```

## Benutzer

### Aktueller Benutzer

```tcl
set user [twapi::get_current_user]
set sid [twapi::get_current_user_sid]
return "Benutzer: $user\nSID: $sid"
```

### Lokale Gruppen

```tcl
set result ""
foreach grp [twapi::get_local_groups] {
    append result "$grp\n"
}
return "Lokale Gruppen:\n$result"
```
