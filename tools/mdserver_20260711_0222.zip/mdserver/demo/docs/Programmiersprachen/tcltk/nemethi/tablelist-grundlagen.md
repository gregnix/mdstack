# Tablelist - Multi-Spalten-Tabellen für Tcl/Tk

*Stand: 2026-06-16*

Tablelist ist eine reine Tcl/Tk-Bibliothek von Csaba Nemethi für
Multi-Spalten-Tabellen mit optionaler Baumstruktur. Sie bietet
editierbare Zellen, eingebettete Widgets, Sortierung und einen
Tree-Modus in einer konsistenten, gut getesteten API.

Version: 7.10 -- Lizenz: BSD-ähnlich -- Abhängigkeiten: Tcl/Tk 8.4+

Website: https://www.nemethi.de

---

## Paketnamen

Tablelist liefert mehrere Paketnamen. Für ttk-Optik
`tablelist_tile` laden (oder die Variante `Tablelist_tile`):

```tcl
package require tablelist_tile   ;# ttk-Themed (empfohlen)
;# Alternativen: tablelist  Tablelist  Tablelist_tile
```

Der Widget-Befehl liegt im Namespace `tablelist`:

```tcl
tablelist::tablelist .t -columns {0 "Name" left}
```

---

## Widget erstellen

### Spalten-Definition

Die Option `-columns` erwartet eine flache Liste aus Dreiergruppen
`{breite titel ausrichtung}`. Breite `0` bedeutet automatische Breite,
Ausrichtung ist `left`, `right` oder `center`:

```tcl
tablelist::tablelist .t -columns {
    0  "Name"   left
    8  "Größe"  right
    0  "Datum"  center
} -stretch all -background white
pack .t -fill both -expand 1
```

### Spaltenzahl und Titel abfragen

```tcl
.t columncount                ;# -> 3
.t columncget 0 -title        ;# -> "Name"
```

---

## Spalten konfigurieren

```tcl
# Breite (in Zeichen; 0 = automatisch)
.t columnconfigure 0 -width 12

# Ausrichtung
.t columnconfigure 1 -align right

# Sortiermodus für diese Spalte
.t columnconfigure 1 -sortmode integer   ;# ascii, integer, real, dictionary
```

| Spalten-Option | Bedeutung |
|----------------|-----------|
| -width | Breite in Zeichen (0 = automatisch an Inhalt) |
| -title | Spaltenüberschrift |
| -align | left, right, center |
| -sortmode | ascii, integer, real, dictionary |
| -editable | Zelle dieser Spalte editierbar |

---

## Daten einfügen, lesen, ändern

### Einfügen

```tcl
.t insert end {Alpha 10 2026-01-01}
.t insert end {Beta  20 2026-01-02}
```

Werte mit Leerzeichen als verschachtelte Liste übergeben, sonst
zerfallen sie in mehrere Spalten:

```tcl
;# FALSCH: wird als vier Spaltenwerte gelesen
.t insert end {Max Mustermann 30 Berlin}

;# RICHTIG: ein Wert pro Spalte
.t insert end [list "Max Mustermann" 30 "Berlin"]
```

### Lesen und Größe

```tcl
.t size                       ;# Anzahl Zeilen
.t get 0                      ;# Werte der Zeile 0 als Liste
lindex [.t get 0] 0           ;# erster Spaltenwert
```

### Ändern

```tcl
.t rowconfigure 0 -background "#eef"     ;# ganze Zeile
.t cellconfigure 0,1 -text "21"          ;# einzelne Zelle (row,col)
```

---

## Löschen -- Reihenfolge beachten

Nach jedem `delete` verschieben sich die Indizes der folgenden Zeilen.
Mehrere Zeilen daher **von hinten nach vorne** löschen:

```tcl
;# FALSCH: nach delete 0 zeigt Index 1 auf die ehemalige Zeile 2
foreach i {0 1 2} { .t delete $i }

;# RICHTIG: absteigend
foreach i [lsort -integer -decreasing {0 1 2}] { .t delete $i }
```

---

## Selektion und das Select-Event

`curselection` liefert die Indizes der ausgewählten Zeilen:

```tcl
.t selection set 1
.t curselection               ;# -> 1
```

Das virtuelle Event `<<TablelistSelect>>` feuert auf dem
**Mega-Widget** selbst, nicht auf dem bodypath:

```tcl
;# RICHTIG: Binding am Widget $t
bind .t <<TablelistSelect>> {
    set sel [.t curselection]
    if {[llength $sel]} {
        puts "Ausgewählt: [.t get [lindex $sel 0]]"
    }
}

;# FALSCH: am bodypath wird das Event nie ausgelöst
bind [.t bodypath] <<TablelistSelect>> { ... }
```

---

## Maus-Bindings: Doppelklick auf eine Zeile

Tablelist kennt kein `nearest` mit Canvas-Koordinaten. Für die
getroffene Zeile `tablelist::convEventFields` verwenden und am
`bodytag` binden, damit das Binding nicht mit Tablelist-Internals
kollidiert:

```tcl
bind [.t bodytag] <Double-1> {
    lassign [tablelist::convEventFields %W %x %y] tbl x y
    set row [$tbl containing $y]
    if {$row >= 0} {
        puts "Doppelklick auf Zeile $row: [$tbl get $row]"
    }
}
```

`convEventFields` übersetzt die Event-Koordinaten und liefert
`{widget x y}` (den Mega-Widget-Pfad plus body-relative Koordinaten);
`containing` gibt den Zeilenindex zurück (`-1`, wenn keine Zeile
getroffen wurde).

---

## Baumstruktur (Tree-Modus)

`insertchild` hängt eine Zeile unter einen Elternknoten. Als
Elternknoten dient `root` oder ein zuvor erhaltener Schlüssel. Der
Rückgabewert ist ein **skalarer** fullKey (`k0`, `k1`, …) -- keine
Liste:

```tcl
tablelist::tablelist .t -columns {0 "Knoten" left}
set parent [.t insertchild root   end {Ordner}]
set child  [.t insertchild $parent end {Datei}]
```

`rowconfigure`, `cellconfigure`, `expand` und `collapse` akzeptieren
sowohl Index als auch Schlüssel:

```tcl
.t collapse $parent
.t expand   $parent
.t expandall
.t collapseall
```

---

## Mit scrollutil

Scrollbars am bequemsten über eine `scrollutil::scrollarea`. Das
Tablelist-Widget als Kind der Scrollarea erzeugen und zuweisen:

```tcl
package require scrollutil_tile
scrollutil::scrollarea .sa
tablelist::tablelist .sa.t -columns {0 "Name" left 0 "Wert" right}
.sa setwidget .sa.t
pack .sa -fill both -expand 1
```

Details siehe [scrollutil-grundlagen.md](scrollutil-grundlagen.md).

---

## Bekannte Fallen

### Select-Event am bodypath

`<<TablelistSelect>>` am bodypath bleibt wirkungslos -- das Event
feuert nur am Mega-Widget. Immer `bind $t <<TablelistSelect>>`.

### Doppelklick über Canvas-Koordinaten

`canvasy` existiert bei Tablelist nicht. Die Zeile über
`convEventFields` + `containing` bestimmen (siehe oben).

### event generate <Double-1> in Tests

Ein synthetisches `event generate $w <Double-1>` schlägt fehl
(`TK EVENT BAD_MODIFIER`). In Tests stattdessen den gebundenen
Handler direkt aufrufen und die Geometrie über `convEventFields` +
`containing` kalibrieren.

### Werte mit Leerzeichen

Eine flache Liste zerlegt mehrteilige Werte in mehrere Spalten -- pro
Zeile eine echte Liste übergeben (`[list ...]`), siehe oben.

---

## Siehe auch

- [TABLELIST-FIXE-SPALTEN.md](TABLELIST-FIXE-SPALTEN.md) -- erste Spalten beim Scrollen fixieren
- [scrollutil-grundlagen.md](scrollutil-grundlagen.md) -- Scrollbars und scrollbare Container
- [../tcltk/tk/treeview.md](../tcltk/tk/treeview.md) -- Tk-eigene Baum-/Tabellen-Alternative
