# Nemethi Bibliotheken - Übersicht

*Stand: 2026-04-29*

Diese Sammlung enthält Informationen über die wichtigsten Tcl/Tk-Bibliotheken von Csaba Nemethi.

## Verfügbare Bibliotheken

### 1. Tablelist
**Version:** 7.9  
**Verzeichnis:** `../tablelist7.9/`

**Beschreibung:**
Tablelist ist ein leistungsstarkes Tabellen-Widget für Tk, das eine Vielzahl von Funktionen bietet:
- Mehrspaltige Tabellen mit Sortierung
- Editierbare Zellen
- Eingebettete Widgets in Zellen
- Tree-Modus für hierarchische Daten
- Drag & Drop
- Druckfunktionen
- Export nach CSV/HTML

**Verwendung:**
```tcl
package require tablelist_tile
set tbl [tablelist::tablelist .tbl -columns {0 "Name" 0 "PLZ" 0 "Ort"}]
```

**Dokumentation:**
- [Grundlagen](../starter/knownhow/tablelist-grundlagen.md)
- [Editierung](../starter/knownhow/tablelist-editierung.md)
- [Embedded Widgets](../starter/knownhow/tablelist-embedded-widgets.md)
- [Tree-Modus](../starter/knownhow/tablelist-tree-modus.md)

---

### 2. Mentry
**Version:** 4.5  
**Verzeichnis:** `../mentry4.5/`

**Beschreibung:**
Mentry (Multi-Entry) ist ein Widget-Paket für strukturierte Eingabefelder:
- Datum/Zeit-Eingaben
- IP-Adressen (IPv4/IPv6)
- Telefonnummern
- Festkommazahlen
- Ethernet-Adressen
- Franking IDs

**Verwendung:**
```tcl
package require mentry
set mentry [mentry::dateMentry .date]
```

**Dokumentation:**
- [Grundlagen](../starter/knownhow/mentry-grundlagen.md)

---

### 3. WCB (Widget Callback Package)
**Version:** 4.2  
**Verzeichnis:** `../wcb4.2/`

**Beschreibung:**
WCB erweitert Tk-Widgets um Callback-Funktionen:
- Validierung von Eingaben
- Formatierung von Werten
- Automatische Konvertierung
- Erweiterte Event-Behandlung

**Verwendung:**
```tcl
package require wcb
wcb::callback .entry before insert validate {return [string is digit %S]}
```

**Dokumentation:**
- Siehe `../wcb4.2/doc/`

---

### 4. TSW (Toggle Switch Widget)
**Version:** 1.4  
**Verzeichnis:** `../tsw1.4/`

**Beschreibung:**
TSW ist ein Toggle-Switch-Widget für moderne UI-Designs:
- Ein/Aus-Schalter
- Verschiedene Themes
- Konfigurierbare Farben und Größen
- Serial-Line-Konfiguration

**Verwendung:**
```tcl
package require tsw
set toggle [tsw::toggleswitch .toggle -command {puts "Toggled"}]
```

**Dokumentation:**
- Siehe `../tsw1.4/doc/`

---

### 5. Scrollutil
**Version:** 2.8  
**Verzeichnis:** `../scrollutil2.8/`

**Beschreibung:**
Scrollutil vereinfacht die Verwendung von Scrollbars in Tk:
- Scrollarea für beliebige Widgets
- ScrollableFrame für scrollbare Bereiche
- ScrolledNotebook für Notebooks mit Scrollbars
- ScrollSync für synchronisierte Scrollbars
- PagesMan für Seitenverwaltung

**Verwendung:**
```tcl
package require scrollutil
set sa [scrollutil::scrollarea .sa]
$sa setwidget $widget
```

**Dokumentation:**
- [Grundlagen](../starter/knownhow/scrollutil-grundlagen.md)

---

## Gemeinsame Verwendung

Diese Bibliotheken arbeiten oft zusammen:

### Beispiel: Tablelist mit Scrollutil
```tcl
package require tablelist_tile
package require scrollutil

set sa [scrollutil::scrollarea .sa]
set tbl [tablelist::tablelist .tbl -columns {0 "Name" 0 "PLZ"}]
$sa setwidget $tbl
```

### Beispiel: Mentry mit WCB
```tcl
package require mentry
package require wcb

set mentry [mentry::dateMentry .date]
wcb::callback $mentry before insert validate {# Validierung}
```

---

## Installation

Alle Bibliotheken sind reine Tcl-Pakete und benötigen keine Kompilierung:

1. Bibliothek in den `auto_path` einbinden
2. `package require` verwenden

**Beispiel:**
```tcl
set auto_path [linsert $auto_path 0 /pfad/zu/nemethi/tablelist7.9]
package require tablelist_tile
```

---

## Links und Quellen

- **Autor:** Csaba Nemethi
- **Website:** https://www.nemethi.de/
- **Lizenz:** Siehe jeweilige COPYRIGHT.txt Dateien

---

## Weitere Informationen

Für detaillierte Informationen siehe:
- `../starter/knownhow/` - Praktische Anleitungen
- `../starter/doc/` - Vollständige Dokumentation
- `../starter/template/` - Code-Vorlagen
