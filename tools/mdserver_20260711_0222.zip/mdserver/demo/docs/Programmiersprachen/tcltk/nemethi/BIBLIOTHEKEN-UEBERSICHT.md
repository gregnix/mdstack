# Nemethi Bibliotheken - Detaillierte Übersicht

*Stand: 2026-04-29*

## Übersicht

Diese Dokumentation sammelt Informationen über die wichtigsten Tcl/Tk-Bibliotheken von Csaba Nemethi.

## Verfügbare Bibliotheken

| Bibliothek | Version | Verzeichnis | Hauptzweck |
|------------|---------|-------------|------------|
| **Tablelist** | 7.9 | `../tablelist7.9/` | Mehrspaltige Tabellen und Tree-Widgets |
| **Mentry** | 4.5 | `../mentry4.5/` | Strukturierte Eingabefelder (Datum, IP, etc.) |
| **WCB** | 4.2 | `../wcb4.2/` | Widget Callbacks für Validierung/Formatierung |
| **TSW** | 1.4 | `../tsw1.4/` | Toggle Switch Widget (Ein/Aus-Schalter) |
| **Scrollutil** | 2.8 | `../scrollutil2.8/` | Vereinfachte Scrollbar-Verwaltung |

---

## 1. Tablelist

### Beschreibung
Tablelist ist ein leistungsstarkes Tabellen-Widget für Tk mit umfangreichen Funktionen.

### Hauptfunktionen
- ✅ Mehrspaltige Tabellen mit Sortierung
- ✅ Editierbare Zellen (verschiedene Widget-Typen)
- ✅ Eingebettete Widgets in Zellen (Button, Combobox, etc.)
- ✅ Tree-Modus für hierarchische Daten
- ✅ Drag & Drop
- ✅ Druckfunktionen
- ✅ Export nach CSV/HTML
- ✅ Spalten-Sichtbarkeit
- ✅ Filterung

### Verwendung
```tcl
package require tablelist_tile

# Einfache Tabelle
set tbl [tablelist::tablelist .tbl \
    -columns {0 "Name" 0 "PLZ" 0 "Ort"} \
    -stretch all \
    -labelcommand tablelist::sortByColumn]

# Daten hinzufügen
$tbl insert end [list "Müller" "12345" "Berlin"]
$tbl insert end [list "Schmidt" "54321" "Hamburg"]
```

### Dokumentation
- **Grundlagen:** `../starter/knownhow/tablelist-grundlagen.md`
- **Editierung:** `../starter/knownhow/tablelist-editierung.md`
- **Embedded Widgets:** `../starter/knownhow/tablelist-embedded-widgets.md`
- **Tree-Modus:** `../starter/knownhow/tablelist-tree-modus.md`
- **Offizielle Docs:** `../tablelist7.9/doc/`

### Typische Anwendungsfälle
- Datenlisten mit mehreren Spalten
- Editierbare Datentabellen
- Hierarchische Datenstrukturen (Tree)
- Master-Detail-Ansichten

---

## 2. Mentry

### Beschreibung
Mentry (Multi-Entry) erstellt strukturierte Eingabefelder für spezielle Datentypen.

### Unterstützte Formate
- 📅 **Datum/Zeit** - Verschiedene Formate (DD.MM.YYYY, MM/DD/YYYY, etc.)
- 🌐 **IP-Adressen** - IPv4 und IPv6
- 📞 **Telefonnummern** - Verschiedene Formate
- 💰 **Festkommazahlen** - Dezimalzahlen mit fester Genauigkeit
- 🔌 **Ethernet-Adressen** - MAC-Adressen
- 📮 **Franking IDs** - Postfrankierung

### Verwendung
```tcl
package require mentry

# Datum-Eingabe
set mentry [mentry::dateMentry .date -format "DMY" -separator "."]

# IP-Adresse
set ipMentry [mentry::ipAddrMentry .ip]

# Telefonnummer
set phoneMentry [mentry::phoneNumberMentry .phone]
```

### Dokumentation
- **Grundlagen:** `../starter/knownhow/mentry-grundlagen.md`
- **Offizielle Docs:** `../mentry4.5/doc/`

### Typische Anwendungsfälle
- Formulare mit strukturierten Eingaben
- Datum/Zeit-Auswahl
- Netzwerk-Konfiguration
- Telefonnummern-Eingabe

---

## 3. WCB (Widget Callback Package)

### Beschreibung
WCB erweitert Tk-Widgets um Callback-Funktionen für Validierung, Formatierung und Konvertierung.

### Hauptfunktionen
- ✅ **Validierung** - Eingaben vor dem Einfügen prüfen
- ✅ **Formatierung** - Werte automatisch formatieren
- ✅ **Konvertierung** - Automatische Typ-Konvertierung
- ✅ **Schutz** - Bestimmte Bereiche vor Änderung schützen
- ✅ **Begrenzung** - Maximale Zeichenanzahl

### Verwendung
```tcl
package require wcb

# Nur Zahlen erlauben
wcb::callback .entry before insert validate {
    return [string is digit %S]
}

# Automatische Formatierung
wcb::callback .entry after insert format {
    # Formatierungscode
}

# Maximale Länge
wcb::callback .entry before insert validate {
    return [expr {[string length [%W get]] < 10}]
}
```

### Dokumentation
- **Offizielle Docs:** `../wcb4.2/doc/`

### Typische Anwendungsfälle
- Eingabevalidierung
- Automatische Formatierung (z.B. Telefonnummern)
- Geschützte Bereiche in Eingabefeldern
- Längenbegrenzung

---

## 4. TSW (Toggle Switch Widget)

### Beschreibung
TSW ist ein modernes Toggle-Switch-Widget für Ein/Aus-Schalter.

### Hauptfunktionen
- ✅ Ein/Aus-Schalter
- ✅ Verschiedene Themes (Aqua, Vista, Clam, etc.)
- ✅ Konfigurierbare Farben und Größen
- ✅ Serial-Line-Konfiguration
- ✅ Callback bei Änderung

### Verwendung
```tcl
package require tsw

# Einfacher Toggle
set toggle [tsw::toggleswitch .toggle \
    -command {puts "State: [%W cget -state]"}]

# Mit Theme
set toggle [tsw::toggleswitch .toggle \
    -theme aqua \
    -oncolor blue]
```

### Dokumentation
- **Offizielle Docs:** `../tsw1.4/doc/`

### Typische Anwendungsfälle
- Einstellungs-Dialoge
- Feature-Aktivierung/Deaktivierung
- Serial-Line-Konfiguration
- Moderne UI-Designs

---

## 5. Scrollutil

### Beschreibung
Scrollutil vereinfacht die Verwendung von Scrollbars in Tk-Anwendungen.

### Hauptkomponenten
- ✅ **Scrollarea** - Scrollbars für beliebige Widgets
- ✅ **ScrollableFrame** - Scrollbarer Frame-Bereich
- ✅ **ScrolledNotebook** - Notebook mit Scrollbars
- ✅ **ScrollSync** - Synchronisierte Scrollbars
- ✅ **PagesMan** - Seitenverwaltung
- ✅ **PlainNotebook** - Einfaches Notebook ohne Scrollbars

### Verwendung
```tcl
package require scrollutil

# Scrollarea für Tablelist
set sa [scrollutil::scrollarea .sa]
set tbl [tablelist::tablelist .tbl -columns {0 "Name"}]
$sa setwidget $tbl

# ScrollableFrame
set sf [scrollutil::scrollableframe .sf]
pack $sf -expand yes -fill both
```

### Dokumentation
- **Grundlagen:** `../starter/knownhow/scrollutil-grundlagen.md`
- **Offizielle Docs:** `../scrollutil2.8/doc/`

### Typische Anwendungsfälle
- Scrollbare Tabellen (mit Tablelist)
- Scrollbare Bereiche in Dialogen
- Synchronisierte Scrollbars
- Seitenverwaltung

---

## Kombinierte Verwendung

### Tablelist + Scrollutil
```tcl
package require tablelist_tile
package require scrollutil

set sa [scrollutil::scrollarea .sa]
set tbl [tablelist::tablelist .tbl \
    -columns {0 "Name" 0 "PLZ"} \
    -stretch all]
$sa setwidget $tbl
pack $sa -expand yes -fill both
```

### Mentry + WCB
```tcl
package require mentry
package require wcb

set mentry [mentry::dateMentry .date]
# Zusätzliche Validierung mit WCB
wcb::callback $mentry before insert validate {
    # Eigene Validierung
}
```

---

## Installation

Alle Bibliotheken sind reine Tcl-Pakete:

### Methode 1: auto_path erweitern
```tcl
set auto_path [linsert $auto_path 0 \
    /pfad/zu/nemethi/tablelist7.9 \
    /pfad/zu/nemethi/scrollutil2.8]
package require tablelist_tile
package require scrollutil
```

### Methode 2: Direktes Laden
```tcl
source /pfad/zu/nemethi/tablelist7.9/tablelist_tile.tcl
source /pfad/zu/nemethi/scrollutil2.8/scrollutil_tile.tcl
```

---

## Abhängigkeiten

| Bibliothek | Abhängigkeiten |
|------------|----------------|
| Tablelist | Tcl/Tk 8.4+ |
| Mentry | Tcl/Tk 8.4+ |
| WCB | Tcl/Tk 8.4+ |
| TSW | Tcl/Tk 8.6+, tksvg (für 8.6) |
| Scrollutil | Tcl/Tk 8.4+ |

---

## Links und Quellen

- **Autor:** Csaba Nemethi
- **E-Mail:** csaba.nemethi@t-online.de
- **Website:** https://www.nemethi.de/
- **Lizenz:** Siehe jeweilige `COPYRIGHT.txt` Dateien

---

## Weitere Ressourcen

- **Praktische Anleitungen:** `../starter/knownhow/`
- **Vollständige Dokumentation:** `../starter/doc/`
- **Code-Vorlagen:** `../starter/template/`
- **Beispiele:** `../starter/bind/`
