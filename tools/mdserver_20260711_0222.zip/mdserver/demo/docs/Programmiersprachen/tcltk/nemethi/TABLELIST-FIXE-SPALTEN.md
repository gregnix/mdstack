# Tablelist: Fixe Spalten beim Scrollen

*Stand: 2026-04-29*

## Problem

Sie haben eine Tabelle mit vielen Spalten (z.B. 20) und möchten, dass die ersten 2 Spalten beim vertikalen Scrollen **fest bleiben** (nicht mit scrollen).

## Lösung: `-titlecolumns` Option

Die Option `-titlecolumns` ermöglicht es, die ersten N Spalten fest zu halten beim horizontalen Scrollen.

### Syntax

```tcl
tablelist::tablelist $widget \
    -columns {...} \
    -titlecolumns 2  ;# Erste 2 Spalten bleiben fest
```

### Beispiel

```tcl
package require tablelist_tile
package require scrollutil

# Tabelle mit 20 Spalten erstellen
set cols {}
for {set i 0} {$i < 20} {incr i} {
    lappend cols 0 "Spalte $i"
}

set sa [scrollutil::scrollarea .sa]
set tbl [tablelist::tablelist .sa.tbl \
    -columns $cols \
    -titlecolumns 2 \  ;# Erste 2 Spalten bleiben fest!
    -stretch all \
    -height 10]

$sa setwidget $tbl
pack $sa -expand yes -fill both

# Testdaten einfügen
for {set row 0} {$row < 100} {incr row} {
    set rowData {}
    for {set col 0} {$col < 20} {incr col} {
        lappend rowData "R${row}C${col}"
    }
    $tbl insert end $rowData
}
```

### Verhalten

- **Erste 2 Spalten:** Bleiben immer sichtbar, auch beim horizontalen Scrollen
- **Spalten 3-20:** Können horizontal gescrollt werden
- **Vertikales Scrollen:** Funktioniert normal für alle Zeilen

### Wichtige Hinweise

1. **Nur horizontales Scrollen:** `-titlecolumns` wirkt nur beim **horizontalen** Scrollen (X-Achse)
2. **Vertikales Scrollen:** Beim vertikalen Scrollen (Y-Achse) scrollen **alle** Spalten mit - das ist das normale Verhalten
3. **Position:** Die fixen Spalten sind immer **links** (am Anfang)
4. **Wert:** Die Zahl gibt an, wie viele Spalten fixiert werden sollen

### Weitere Optionen

```tcl
# Erste Spalte fixieren
-titlecolumns 1

# Erste 3 Spalten fixieren
-titlecolumns 3

# Keine fixen Spalten (Standard)
-titlecolumns 0
```

### Vollständiges Beispiel mit Scrollbars

```tcl
package require tablelist_tile
package require scrollutil

# Scrollarea erstellen
set sa [scrollutil::scrollarea .sa]

# Tabelle mit fixen Spalten
set tbl [tablelist::tablelist .sa.tbl \
    -columns {
        0 "Name" left
        0 "PLZ"  left
        0 "Spalte 3" left
        0 "Spalte 4" left
        # ... weitere Spalten
    } \
    -titlecolumns 2 \  ;# Erste 2 Spalten (Name, PLZ) bleiben fest
    -stretch all \
    -height 15]

$sa setwidget $tbl
pack $sa -expand yes -fill both
```

### Siehe auch

- **Dokumentation:** `../tablelist7.9/doc/tablelistWidget.html` (Suche nach `-titlecolumns`)
- **Grundlagen:** `../starter/knownhow/tablelist-grundlagen.md`
