# Scrollutil - Scrolling-Bibliothek für Tcl/Tk

*Stand: 2026-04-29*

Scrollutil ist eine reine Tcl/Tk-Bibliothek von Csaba Nemethi, die das
Scrolling in Tk-Anwendungen grundlegend vereinfacht. Sie löst die
bekannten Probleme mit Mausrad-Events, scrollbaren Containern und
Scrollbar-Verwaltung durch eine konsistente, gut getestete API.

Version: 2.8 -- Lizenz: BSD-ähnlich -- Abhängigkeiten: Tcl/Tk 8.4+

Website: https://www.nemethi.de

---

## Übersicht der Komponenten

| Komponente | Zweck |
|------------|-------|
| scrollarea | Scrollbars für beliebige Widgets (Tablelist, Text, Canvas) |
| scrollableframe | Scrollbarer Container für beliebige Widget-Layouts |
| scrollsync | Synchronisiertes Scrollen mehrerer Widgets |
| scrollednotebook | Notebook mit scrollbarer Tab-Leiste und schliessbaren Tabs |
| plainnotebook | Notebook ohne Tab-Leiste (Seitenumschaltung per Code) |
| pagesman | Seitenverwaltung mit Vor/Zurück-Navigation |
| wheelEvent | Globale Mausrad-Event-Behandlung |

---

## Installation

### Methode 1: auto_path (empfohlen)

Das Verzeichnis `scrollutil2.8/` muss in einem Pfad liegen, den Tcl findet:

```tcl
# Relativ zum Script
set scriptDir [file dirname [info script]]
lappend auto_path [file join $scriptDir scrollutil2.8]

package require scrollutil_tile
```

### Methode 2: Direktes Laden

```tcl
source /pfad/zu/scrollutil2.8/scrollutil_tile.tcl
```

### Zwei Package-Varianten

| Package | Scrollbar-Typ | Verwendung |
|---------|---------------|------------|
| `scrollutil` | Tk-Scrollbars | Aeltere Anwendungen ohne ttk |
| `scrollutil_tile` | ttk::scrollbar | Standard für moderne Anwendungen |

In der Regel verwendet man `scrollutil_tile`.

---

## Scrollarea -- Scrollbars für beliebige Widgets

Die scrollarea ist der Ersatz für das manuelle Verdrahten von Scrollbars
mit `-xscrollcommand` und `-yscrollcommand`. Sie erkennt automatisch, ob
ein Widget horizontal, vertikal oder in beide Richtungen scrollbar ist.

### Grundmuster

```tcl
package require scrollutil_tile

# 1. Scrollarea erzeugen
set sa [scrollutil::scrollarea .sa]

# 2. Widget ALS KIND der Scrollarea erzeugen
set txt [text $sa.txt -wrap none]

# 3. Widget zuweisen
$sa setwidget $txt

# 4. Scrollarea einpacken
pack $sa -fill both -expand 1
```

Wichtig: Das scrollbare Widget muss ein direktes Kind der Scrollarea sein
(im Beispiel `$sa.txt`, nicht `.txt`).

### Scrollbar-Modi

Die Sichtbarkeit der Scrollbars lässt sich konfigurieren:

```tcl
set sa [scrollutil::scrollarea .sa \
    -xscrollbarmode dynamic \
    -yscrollbarmode static]
```

| Modus | Verhalten |
|-------|-----------|
| `static` | Scrollbar immer sichtbar |
| `dynamic` | Scrollbar erscheint nur bei Bedarf |
| `none` | Scrollbar ausgeblendet |

### Scrollarea mit Tablelist

Scrollutil ist speziell auf Tablelist abgestimmt. Die scrollarea
respektiert Header und Title-Columns:

```tcl
package require tablelist_tile
package require scrollutil_tile

set sa [scrollutil::scrollarea .sa \
    -respectheader 1 \
    -respecttitlecolumns 1]

set tbl [tablelist::tablelist $sa.tbl \
    -columns {0 "Name" left  0 "PLZ" left  0 "Ort" left} \
    -stretch all \
    -labelcommand tablelist::sortByColumn]
$sa setwidget $tbl

pack $sa -fill both -expand 1
```

Die Option `-respectheader 1` bewirkt, dass die vertikale Scrollbar
unterhalb des Tablelist-Headers beginnt.

### Scrollarea mit Text-Widget

```tcl
set sa [scrollutil::scrollarea .sa]
set txt [text $sa.txt -wrap word -width 80 -height 25]
$sa setwidget $txt
pack $sa -fill both -expand 1
```

### Autohide für Scrollbars

```tcl
set sa [scrollutil::scrollarea .sa \
    -autohidescrollbars 1 \
    -lockinterval 10]
```

Mit `-autohidescrollbars 1` verschwinden die Scrollbars nach einer kurzen
Verzoegerung, wenn der Mauszeiger den Bereich verlässt. Das
`-lockinterval` (in Millisekunden) verhindert Flackern bei schnellem
Hin- und Herbewegen.

### Widget abfragen

```tcl
# Welches Widget steckt in der Scrollarea?
set widget [$sa widget]

# Scrollarea eines Widgets ermitteln (Hilfsfunktion)
set sa [scrollutil::getscrollarea $widget]
```

---

## ScrollableFrame -- Scrollbarer Container

Der scrollableframe ist das Kernwidget für scrollbare Formulare,
Einstellungsdialoge und ähnliche Layouts mit vielen Widgets. Er ersetzt
das fehleranfaellige Canvas-plus-innerer-Frame-Pattern.

### Grundmuster

```tcl
package require scrollutil_tile

# Scrollarea + ScrollableFrame kombinieren
set sa [scrollutil::scrollarea .sa]
set sf [scrollutil::scrollableframe $sa.sf]
$sa setwidget $sf

# Content-Frame holen
set cf [$sf contentframe]

# Widgets im Content-Frame erzeugen
ttk::label $cf.lbl -text "Name:"
ttk::entry $cf.ent -width 30
grid $cf.lbl -row 0 -column 0 -sticky w -padx 4 -pady 2
grid $cf.ent -row 0 -column 1 -sticky ew -padx 4 -pady 2

pack $sa -fill both -expand 1
```

Der entscheidende Punkt: Alle Widgets werden als Kinder des
Content-Frames erzeugt (per `$sf contentframe`), nicht des
ScrollableFrame selbst.

### Vergleich: Manuelles Canvas vs. ScrollableFrame

Manuelles Canvas-Pattern (fehleranfällig, ~30 Zeilen):

```tcl
# NICHT EMPFOHLEN -- nur zur Illustration
canvas .cv -highlightthickness 0
ttk::scrollbar .sb -orient vertical -command {.cv yview}
.cv configure -yscrollcommand {.sb set}
ttk::frame .cv.inner
.cv create window 0 0 -anchor nw -window .cv.inner -tags innerWin

bind .cv.inner <Configure> {
    .cv configure -scrollregion [.cv bbox all]
}
bind .cv <Configure> {
    .cv itemconfigure innerWin -width [winfo width .cv]
}
# Für JEDES Kind-Widget einzeln:
bind $widget <Button-4> {.cv yview scroll -3 units}
bind $widget <Button-5> {.cv yview scroll  3 units}
bind $widget <MouseWheel> { ... }
```

Mit ScrollableFrame (5 Zeilen, korrekt):

```tcl
set sa [scrollutil::scrollarea .sa]
set sf [scrollutil::scrollableframe $sa.sf]
$sa setwidget $sf
set cf [$sf contentframe]
pack $sa -fill both -expand 1
```

### Dynamischer Inhalt

Wenn Widgets zur Laufzeit hinzugefügt oder entfernt werden (z.B. eine
Geräte-Liste), braucht man keine manuelle scrollregion-Aktualisierung.
Der scrollableframe erkennt Änderungen automatisch:

```tcl
proc updateDeviceList {sf devices} {
    set cf [$sf contentframe]

    # Alte Widgets entfernen
    foreach w [winfo children $cf] { destroy $w }

    # Neue Widgets erzeugen
    set row 0
    foreach dev $devices {
        ttk::label $cf.name$row -text [dict get $dev name]
        ttk::scale $cf.vol$row -from 0 -to 100 -orient horizontal
        grid $cf.name$row -row $row -column 0 -sticky w
        grid $cf.vol$row  -row $row -column 1 -sticky ew
        incr row
    }
}
```

### Widget sichtbar machen

Der `see`-Befehl scrollt ein bestimmtes Widget in den sichtbaren Bereich:

```tcl
# Widget sichtbar machen
$sf see $cf.entry5

# Mit Anker: nw = obere linke Ecke sichtbar
$sf see $cf.entry5 nw
```

Das ist besonders nützlich für Keyboard-Navigation:

```tcl
bind $cf.entry5 <<TraverseIn>> [list $sf see %W]
```

### Größe und Anpassung

```tcl
# Feste Größe
$sf configure -width 400 -height 300

# Content-Breite an Frame-Breite anpassen
$sf configure -fitcontentwidth 1

# Scroll-Increment (Pixel pro Scroll-Schritt)
$sf configure -yscrollincrement 20
```

Die Option `-fitcontentwidth 1` bewirkt, dass der Content-Frame immer
mindestens so breit ist wie der sichtbare Bereich. Das verhindert
horizontales Scrollen, wenn es nicht gewünscht ist.

---

## Mausrad-Event-Behandlung

Das größte Problem beim Scrollen in Tk: Mausrad-Events werden nicht
automatisch von Kind-Widgets zum scrollbaren Parent propagiert. Scrollutil
löst das mit drei Befehlen.

### createWheelEventBindings -- Globale Lösung

```tcl
# Einmal beim Start aufrufen -- gilt für die gesamte Anwendung
scrollutil::createWheelEventBindings all
```

Dieser eine Aufruf bewirkt:

- Mausrad-Events auf Kind-Widgets werden zum nächstgelegenen
  registrierten scrollbaren Container weitergeleitet
- Funktioniert plattformübergreifend (X11, Windows, macOS)
- Behandelt `<MouseWheel>`, `<Button-4>`, `<Button-5>`,
  `<TouchpadScroll>` und alle Shift-Varianten
- Verschachtelte scrollbare Container werden korrekt behandelt
  (der innerste wird gescrollt)

Statt `all` kann man auch einzelne Toplevel-Fenster angeben:

```tcl
scrollutil::createWheelEventBindings . .dialog
```

### enableScrollingByWheel -- Container registrieren

Für scrollbare Container, die nicht von scrollutil stammen (z.B. BWidget
ScrollableFrame oder iwidgets::scrolledframe), muss man das Scrollen
explizit aktivieren:

```tcl
scrollutil::enableScrollingByWheel $bwidgetSF
```

Scrollutil-eigene Widgets (scrollableframe) registrieren sich automatisch.

### adaptWheelEventHandling -- Widget-Konflikte loesen

Manche Widgets haben eigenes Mausrad-Verhalten, das mit dem Scrollen des
Containers kollidiert:

| Widget | Eigenes Mausrad-Verhalten |
|--------|---------------------------|
| ttk::combobox | Wert hoch/runter |
| ttk::spinbox | Wert hoch/runter |
| ttk::scale | Schieberegler bewegen |
| text | Text scrollen |
| listbox | Liste scrollen |
| tablelist | Tabelle scrollen |

Innerhalb eines ScrollableFrame will man aber, dass das Mausrad den
Container scrollt, nicht den Combobox-Wert aendert:

```tcl
scrollutil::adaptWheelEventHandling $combobox $spinbox $scale
```

Für dynamisch erzeugte Widgets in einem ScrollableFrame:

```tcl
foreach w [winfo children $cf] {
    if {[winfo class $w] in {TCombobox TScale TSpinbox}} {
        scrollutil::adaptWheelEventHandling $w
    }
}
```

### Vereinfachung: preparescroll

Ab Scrollutil 2.5 gibt es `preparescroll`, das alle obigen Aufrufe
automatisiert:

```tcl
set sf [scrollutil::scrollableframe $sa.sf]
# ... Widgets erzeugen ...
$sf preparescroll
```

Das durchsucht alle Kind-Widgets im Content-Frame und ruft
`adaptWheelEventHandling` automatisch für die richtigen Widget-Klassen
auf.

---

## ScrollSync -- Synchronisiertes Scrollen

Der scrollsync synchronisiert die Scroll-Position mehrerer Widgets.
Typischer Anwendungsfall: Zwei Listboxen oder Tabellen, die parallel
gescrollt werden sollen.

### Grundmuster

```tcl
# Scrollarea + ScrollSync
set sa [scrollutil::scrollarea .sa]
set ss [scrollutil::scrollsync $sa.ss]
$sa setwidget $ss

# Zwei Listboxen im ScrollSync
set lb1 [listbox $ss.lb1 -width 20]
set lb2 [listbox $ss.lb2 -width 20]
$ss setwidgets [list $lb1 $lb2]

# Layout
grid $lb1 $lb2 -sticky news
grid rowconfigure $ss 0 -weight 1
grid columnconfigure $ss 0 -weight 1 -uniform cols
grid columnconfigure $ss 1 -weight 1 -uniform cols

pack $sa -fill both -expand 1
```

Wenn der Benutzer in einer Listbox scrollt, folgt die andere automatisch.

### ScrollSync mit Tablelists

```tcl
set ss [scrollutil::scrollsync $sa.ss]
set tbl1 [tablelist::tablelist $ss.tbl1 \
    -columns {0 "Name" 0 "Wert"}]
set tbl2 [tablelist::tablelist $ss.tbl2 \
    -columns {0 "Ergebnis" 0 "Status"}]
$ss setwidgets [list $tbl1 $tbl2]
```

---

## ScrolledNotebook -- Notebook mit scrollbaren Tabs

Wenn ein Notebook viele Tabs hat, werden die Tab-Beschriftungen zu klein
oder verschwinden. Das scrollednotebook zeigt Scroll-Pfeile in der
Tab-Leiste und unterstützt schliessbare Tabs.

### Grundmuster

```tcl
package require scrollutil_tile

# Closetab-Style aktivieren
scrollutil::addclosetab My.TNotebook

set nb [scrollutil::scrollednotebook .nb -style My.TNotebook]

# Tabs hinzufügen
for {set i 0} {$i < 20} {incr i} {
    set f [ttk::frame $nb.tab$i]
    ttk::label $f.l -text "Inhalt von Tab $i"
    pack $f.l -expand 1
    $nb add $f -text "Tab $i"
}

pack $nb -fill both -expand 1
```

### Schliessbare Tabs

```tcl
scrollutil::addclosetab My.TNotebook

set nb [scrollutil::scrollednotebook .nb -style My.TNotebook \
    -forgetcommand onForget]

proc onForget {nb widget} {
    set answer [tk_messageBox -type yesno \
        -message "Tab wirklich schließen?"]
    return [expr {$answer eq "yes"}]
}
```

Die `-forgetcommand` wird aufgerufen bevor ein Tab geschlossen wird.
Gibt sie 0 zurück, wird das Schließen verhindert.

### Verschiebbare Tabs

Tabs im scrollednotebook sind standardmäßig per Drag-and-Drop
verschiebbar. Das Kontextmenue wird über das virtuelle Event
`<<MenuItemsRequested>>` befuellt:

```tcl
bind $nb <<MenuItemsRequested>> {populateMenu %W %d}

proc populateMenu {nb data} {
    lassign $data menu tabIdx
    $menu add command -label "Tab schließen" \
        -command [list $nb forget $tabIdx]
}
```

---

## PlainNotebook -- Notebook ohne Tab-Leiste

Das plainnotebook ist ein Notebook, das keine Tab-Leiste anzeigt. Die
Seitenumschaltung erfolgt ausschliesslich per Code. Das ist nützlich für
Wizard-Dialoge oder Konfigurationsseiten, bei denen die Navigation
über eine separate Baumansicht oder Buttonleiste gesteuert wird.

```tcl
set nb [scrollutil::plainnotebook .nb]
set page1 [ttk::frame $nb.p1]
set page2 [ttk::frame $nb.p2]
$nb add $page1 -text "Seite 1"
$nb add $page2 -text "Seite 2"

# Umschalten per Code
$nb select $page2
```

---

## PagesMan -- Seitenverwaltung

Der pagesman (Pages Manager) ergänzt das plainnotebook um eine
integrierte Navigation mit Vor/Zurück-Knoepfen und einem optionalen
Seitenindex:

```tcl
set pm [scrollutil::pagesman .pm]
# Seiten hinzufügen und konfigurieren
```

---

## Praxisbeispiel: Scrollbarer System-Tab

Dieses Beispiel zeigt die Integration in eine reale Anwendung --
einen System-Audio-Tab mit dynamisch erzeugten Geräte-Listen:

```tcl
package require scrollutil_tile

# Einmal global: Mausrad-Bindings für alle Widgets
scrollutil::createWheelEventBindings all

# System-Tab aufbauen
ttk::frame .nb.sys
.nb add .nb.sys -text " System "

set sa [scrollutil::scrollarea .nb.sys.sa]
set sf [scrollutil::scrollableframe $sa.sf]
$sa setwidget $sf
pack $sa -fill both -expand 1

set cf [$sf contentframe]

# Statische Header und Frames
ttk::label $cf.sinkHdr -text "Ausgabegeraete (Sinks)" \
    -font {TkDefaultFont 11 bold}
grid $cf.sinkHdr -row 0 -column 0 -sticky w

ttk::frame $cf.sinks
grid $cf.sinks -row 1 -column 0 -sticky ew

ttk::separator $cf.sep -orient horizontal
grid $cf.sep -row 2 -column 0 -sticky ew

ttk::label $cf.srcHdr -text "Mikrofone (Sources)" \
    -font {TkDefaultFont 11 bold}
grid $cf.srcHdr -row 3 -column 0 -sticky w

ttk::frame $cf.sources
grid $cf.sources -row 4 -column 0 -sticky ew

grid columnconfigure $cf 0 -weight 1
```

Dynamische Aktualisierung:

```tcl
proc updateDevices {cf} {
    # Alte Widgets entfernen
    foreach w [winfo children $cf.sinks] { destroy $w }

    # Geräte abfragen und Widgets erzeugen
    set row 0
    foreach dev [getAudioDevices] {
        set id [dict get $dev id]
        ttk::label $cf.sinks.name$row -text [dict get $dev name]
        ttk::scale $cf.sinks.vol$row -from 0 -to 100 \
            -orient horizontal -length 150
        ttk::button $cf.sinks.mute$row -text "Mute" -width 5

        grid $cf.sinks.name$row -row $row -column 0 -sticky w
        grid $cf.sinks.vol$row  -row $row -column 1 -padx 4
        grid $cf.sinks.mute$row -row $row -column 2

        # Scale ans Scroll-System anpassen
        scrollutil::adaptWheelEventHandling $cf.sinks.vol$row
        incr row
    }
}
```

---

## Plattformunterschiede bei Mausrad-Events

Scrollutil abstrahiert die plattformspezifischen Mausrad-Events:

| Plattform | Vertikales Scrollen | Horizontales Scrollen |
|-----------|--------------------|-----------------------|
| X11 (< Tk 8.7) | `<Button-4>`, `<Button-5>` | `<Shift-Button-4>`, `<Shift-Button-5>` |
| Windows | `<MouseWheel>` | `<Shift-MouseWheel>` |
| macOS | `<MouseWheel>`, `<Option-MouseWheel>` | `<Shift-MouseWheel>` |
| Tk 8.7+ (alle) | `<MouseWheel>` | `<Shift-MouseWheel>` |
| Touchpad | `<TouchpadScroll>` | `<TouchpadScroll>` |

Ohne scrollutil muss man all diese Varianten manuell behandeln.
Mit `createWheelEventBindings all` geschieht das automatisch.

---

## API-Referenz

### scrollutil::scrollarea

```tcl
scrollutil::scrollarea pathName ?optionen?
```

| Option | Typ | Standard | Beschreibung |
|--------|-----|----------|-------------|
| `-xscrollbarmode` | static/dynamic/none | dynamic | Horizontale Scrollbar |
| `-yscrollbarmode` | static/dynamic/none | static | Vertikale Scrollbar |
| `-autohidescrollbars` | boolean | 0 | Scrollbars automatisch ausblenden |
| `-lockinterval` | ms | 0 | Verzoegerung gegen Flackern |
| `-respectheader` | boolean | 1 | Tablelist-Header respektieren |
| `-respecttitlecolumns` | boolean | 1 | Tablelist-Titelspalten respektieren |
| `-setfocus` | boolean | 1 | Fokus bei Klick setzen |

Unterbefehle:

| Befehl | Beschreibung |
|--------|-------------|
| `$sa setwidget $w` | Widget zuweisen |
| `$sa widget` | Zugewiesenes Widget abfragen |
| `$sa cget -option` | Option abfragen |
| `$sa configure -option wert` | Option setzen |

### scrollutil::scrollableframe

```tcl
scrollutil::scrollableframe pathName ?optionen?
```

| Option | Typ | Beschreibung |
|--------|-----|-------------|
| `-width` | Pixel | Sichtbare Breite |
| `-height` | Pixel | Sichtbare Höhe |
| `-contentwidth` | Pixel | Mindestbreite des Content-Frame |
| `-contentheight` | Pixel | Mindesthoehe des Content-Frame |
| `-fitcontentwidth` | boolean | Content-Breite an sichtbare Breite anpassen |
| `-fitcontentheight` | boolean | Content-Höhe an sichtbare Höhe anpassen |
| `-xscrollincrement` | Pixel | Horizontaler Scroll-Schritt |
| `-yscrollincrement` | Pixel | Vertikaler Scroll-Schritt |

Unterbefehle:

| Befehl | Beschreibung |
|--------|-------------|
| `$sf contentframe` | Content-Frame abfragen |
| `$sf see $widget ?anker?` | Widget sichtbar machen |
| `$sf seerect x1 y1 x2 y2` | Rechteck sichtbar machen |
| `$sf xview ...` | Horizontale Ansicht steuern |
| `$sf yview ...` | Vertikale Ansicht steuern |
| `$sf preparescroll` | Mausrad-Anpassung automatisieren |
| `$sf preparescan` | Button-2-Scanning automatisieren |

### Mausrad-Befehle

| Befehl | Beschreibung |
|--------|-------------|
| `scrollutil::createWheelEventBindings all` | Globale Mausrad-Bindings erzeugen |
| `scrollutil::enableScrollingByWheel $container` | Container für Mausrad-Scrollen registrieren |
| `scrollutil::disableScrollingByWheel $container` | Registrierung aufheben |
| `scrollutil::adaptWheelEventHandling $w ...` | Widget-eigenes Mausrad-Verhalten umleiten |
| `scrollutil::addMouseWheelSupport $tag` | Mausrad-Support für Binding-Tag hinzufügen |
| `scrollutil::setFocusCheckWindow $w1 ... $parent` | Focus-Check-Fenster setzen |

### Hilfsfunktionen

| Befehl | Beschreibung |
|--------|-------------|
| `scrollutil::getscrollarea $widget` | Scrollarea eines Widgets ermitteln |
| `scrollutil::getscrollsync $widget` | ScrollSync eines Widgets ermitteln |

---

## Häufige Fehler und Lösungen

### Widget nicht als Kind der Scrollarea erzeugt

Falsch:

```tcl
set sa [scrollutil::scrollarea .sa]
set txt [text .txt]          ;# FALSCH: .txt statt $sa.txt
$sa setwidget $txt           ;# Fehler oder kein Scrollen
```

Richtig:

```tcl
set sa [scrollutil::scrollarea .sa]
set txt [text $sa.txt]       ;# Kind der Scrollarea
$sa setwidget $txt
```

### Widgets im ScrollableFrame statt im Content-Frame

Falsch:

```tcl
set sf [scrollutil::scrollableframe .sf]
ttk::label $sf.lbl -text "Test"   ;# FALSCH: im SF selbst
```

Richtig:

```tcl
set sf [scrollutil::scrollableframe .sf]
set cf [$sf contentframe]
ttk::label $cf.lbl -text "Test"   ;# Im Content-Frame
```

### Mausrad scrollt Combobox-Wert statt Container

Ohne `adaptWheelEventHandling` aendert das Mausrad den Combobox-Wert
statt den scrollableframe zu scrollen:

```tcl
# Nach dem Erzeugen der Combobox:
scrollutil::adaptWheelEventHandling $combobox

# Oder am Ende alles auf einmal:
$sf preparescroll
```

### createWheelEventBindings vergessen

Ohne diesen Aufruf funktionieren die Mausrad-Bindings in scrollbaren
Containern nicht. Der Aufruf muss einmal beim Programmstart erfolgen:

```tcl
package require scrollutil_tile
scrollutil::createWheelEventBindings all   ;# NICHT VERGESSEN
```

---

## Zusammenspiel mit anderen Nemethi-Bibliotheken

### Tablelist + Scrollutil

Die Standardkombination für scrollbare Tabellen:

```tcl
package require tablelist_tile
package require scrollutil_tile

scrollutil::createWheelEventBindings all

set sa [scrollutil::scrollarea .sa]
set tbl [tablelist::tablelist $sa.tbl \
    -columns {0 "Name" left  0 "Wert" right} \
    -stretch all \
    -labelcommand tablelist::sortByColumn]
$sa setwidget $tbl

pack $sa -fill both -expand 1
```

### Mentry + ScrollableFrame

Strukturierte Eingabefelder in einem scrollbaren Formular:

```tcl
package require mentry_tile
package require scrollutil_tile

set sa [scrollutil::scrollarea .sa]
set sf [scrollutil::scrollableframe $sa.sf]
$sa setwidget $sf
set cf [$sf contentframe]

# Datum-Mentry im scrollbaren Formular
set me [mentry::dateMentry $cf.date -format "DMY" -separator "."]
grid $me -row 0 -column 1

# Mentry-Einträge ans Scroll-System anpassen
scrollutil::setFocusCheckWindow {*}[$me entries] $me
scrollutil::adaptWheelEventHandling {*}[$me entries]
```

---

## Weitergehende Themen

### DPI-Skalierung

Scrollutil enthält Unterstützung für High-DPI-Displays. Die Variable
`scrollutil::scalingpct` gibt den aktuellen Skalierungsfaktor an:

```tcl
puts $scrollutil::scalingpct   ;# z.B. 100, 125, 150, 200
```

### SVG-Icons

Für skalierbare Icons in scrollednotebook-Tabs:

```tcl
if {$tk_version >= 8.7 || [catch {package require tksvg}] == 0} {
    set fmt $scrollutil::svgfmt
    image create photo icon -file icon.svg -format $fmt
}
```

### Scanning mit Maus-Button 2

In scrollableframe-Widgets kann der Benutzer mit gedrueckter mittlerer
Maustaste den Inhalt verschieben (ähnlich wie in einem PDF-Viewer):

```tcl
$sf preparescan
```

---

## Dateien und Verzeichnisstruktur

```
scrollutil2.8/
|-- pkgIndex.tcl              # Package-Index
|-- scrollutil.tcl            # Nicht-Tile-Version
|-- scrollutil_tile.tcl       # Tile-Version (Standard)
|-- scrollutilCommon.tcl      # Gemeinsamer Code
|-- scripts/
|   |-- scrollableframe.tcl   # ScrollableFrame-Widget
|   |-- scrollarea.tcl        # Scrollarea-Widget
|   |-- scrollsync.tcl        # ScrollSync-Widget
|   |-- scrollednotebook.tcl  # ScrolledNotebook-Widget
|   |-- plainnotebook.tcl     # PlainNotebook-Widget
|   |-- pagesman.tcl          # PagesMan-Widget
|   |-- wheelEvent.tcl        # Mausrad-Event-Behandlung
|   |-- notebookImages.tcl    # Bilder für Notebook-Tabs
|-- demos/                    # Beispiel-Scripte
|-- doc/                      # HTML-Dokumentation
```
