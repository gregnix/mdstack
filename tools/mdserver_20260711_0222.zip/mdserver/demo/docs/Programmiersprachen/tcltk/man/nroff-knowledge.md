# Nroff parsing knowledge

*Stand: 2026-04-29*

Lessons learned from building the man-viewer nroff parser
(nroffparser-0.2.tm) and comparing with Torsten Berg's
man2markdown.tcl (TIP 700).


## Tcl/Tk man page macros

Tcl/Tk man pages use standard nroff macros plus custom macros
defined in `man.macros`. The custom macros are:

TH, AP, AS, BS, BE, CS, CE, VS, VE, DS, DE, SO, SE, OP, UL, QW, PQ, QR, MT

Standard nroff macros used in Tcl/Tk pages:

SH, SS, PP, LP, P, TP, IP, RS, RE, nf, fi, br, sp, ta, so


## Macro reference

### Document structure

`.TH name section ?volume? ?date? ?source?` -- Title heading.
First macro in every man page.

`.SH "TITLE"` -- Section heading. Title may be quoted or bare.

`.SS "Subtitle"` -- Subsection heading.

### Paragraphs

`.PP`, `.LP`, `.P` -- New paragraph (all equivalent).

`.TP ?indent?` -- Tagged paragraph. Next line is the term,
subsequent lines are the description. Used for option lists.

`.IP term ?indent?` -- Indented paragraph with term.
`\(bu` as term creates bullet lists.

`.AP type name in/out` -- Argument paragraph for C API pages.
Creates a formatted argument entry with type, name and direction.

### Preformatted text

`.CS` / `.CE` -- Code section (Tcl/Tk custom).

`.DS` / `.DE` -- Display section (indented, unfilled).

`.nf` / `.fi` -- No-fill / fill mode (standard nroff).

### Indentation

`.RS` -- Relative indent start. Increases indent level.

`.RE` -- Relative indent end. Decreases indent level.

Important: must flush current list on both RS and RE,
otherwise nested items end up in the same flat list.

### Standard options

`.SO ?manpage?` -- Start standard options block.
Sets up tab stops and bold font. NOT the same as `.so` (include).

`.SE` -- End standard options. Adds reference to options manual.

`.OP cmdName dbName dbClass` -- Option paragraph.
Three-column format: command-line name, database name, database class.

### Inline macros

`.QW "text" ?trailing?` -- Quoted word. Wraps text in quotes.

`.PQ "text" ?trailing?` -- Parenthesized quoted word.

`.QR "from" "to"` -- Quoted range.

`.MT` -- Empty string. Equivalent to `.QW ""`.

`.UL text ?trailing?` -- Underline text.

### Version markers

`.VS ?version?` -- Version sidebar start. Marks new content.

`.VE` -- Version sidebar end.

### Box

`.BS` -- Box start.

`.BE` -- Box end.

### Other

`.AS ?type? ?name?` -- Set tab stops for `.AP` arguments.

`.br` -- Line break.

`.sp ?n?` -- Vertical space (n lines, default 1).

`.ta stop ...` -- Set tab stops. Formats: `3i` (inches),
`5.5c` (centimeters), `7.2cR` (with alignment suffix).

`.so file` -- Include file (rarely used, usually ignored).


## Escape sequences

### Font changes

`\fB` -- Bold. `\fI` -- Italic. `\fR`, `\fP` -- Roman (normal).

### Special characters

`\-` -- Minus/hyphen. `\.` -- Literal period.
`\e` -- Escape character (usually ignored).
`\\` -- Literal backslash.

### Two-character special names

Format: `\(xx` where xx is a two-letter name.

51 characters are supported in the parser:

Typography: bu (bullet), em (em-dash), en (en-dash), aq (apostrophe),
dq (double quote), oq/cq (single quotes), lq/rq (double quotes),
Fo/Fc (guillemets), ul (underscore).

Lines/box: br (box rule), bv (bar vertical), or (pipe).

Arrows: da (down), ua (up), -> (right), <- (left).

Math: mu (multiply), di (divide), pl (plus), mi (minus), eq (equals),
ge/le (greater/less equal), != (not equal), == (identical),
~~ (approximately), if (infinity), sr (square root), no (not).

Symbols: sc (section), co (copyright), rg (registered), tm (trademark),
dg/dd (daggers), ct (cent), de (degree).

Fractions: 14 (quarter), 12 (half), 34 (three-quarters).

Greek: *a (alpha), *b (beta), *g (gamma), *d (delta), *p (pi), *m (mu).

Accents: aa (acute), ga (grave).

### Numeric character escape

`\N'number'` -- Character by decimal ASCII code.
Example: `\N'34'` produces `"` (double quote, ASCII 34).

### Usage in Tcl/Tk pages

Only 3 special characters are actually used in the 229 Tcl/Tk
man pages: `\(bu` (77 times), `\(em` (12 times), `\(en` (11 times).
All others are supported but not encountered in practice.


## Tab stop formats

The `.ta` macro accepts these formats:

- `3i` -- 3 inches (approx. 30 characters)
- `5.5c` -- 5.5 centimeters (approx. 22 characters)
- `7.2cR` -- 7.2 cm, right-aligned (R suffix)
- `4cL` -- 4 cm, left-aligned (L suffix, default)
- `4cC` -- 4 cm, center-aligned (C suffix)
- `.25i` -- 0.25 inches (decimal with leading dot)
- `\w'...'u` -- Width expression (complex, skip in parser)

The man.macros file uses `.ta 5.5c 11c` for standard options
and `.ta 4c` for option paragraphs.


## AST design

The parser produces a flat list of AST nodes. Each node is a dict
with three keys: type, content, meta.

### Node types

heading, section, subsection, paragraph, list, pre, blank.

### Inline types

text, strong, emphasis. Stored as list of dicts with type and text keys.

### List kinds

tp (tagged paragraph), ip (indented paragraph), op (option paragraph),
ap (argument paragraph).

### Meta fields

heading: level, name, section, version, part, description.
section: level (1 for SH, 2 for SS).
paragraph: indentLevel (from RS/RE nesting).
list: kind, indentLevel.
blank: lines.

### Two-phase parsing

Phase 1 (`parseBlocks`): Line-by-line macro processing, builds
AST with raw text in content fields.

Phase 2 (`parseInlinesPhase`): Converts raw text content to
inline node lists (text/strong/emphasis) with escape processing.


## TIP 700 comparison

Torsten Berg's man2markdown.tcl (1409 lines, TIP 700 official)
converts nroff to Pandoc Markdown. It handles cross-references,
YAML frontmatter, bracketed spans and synopsis divs.

### Macros man2markdown handles

TH, SH, SS, PP, TP, IP, CS, CE, VS, VE, RS, RE, QW, PQ, QR.
Ignores: so, BS, BE, AS, ta.

### Macros man2markdown is missing

OP (37 Tk widget pages), SO/SE (36 Tk pages), AP (190 C API pages),
nf/fi, br, sp, LP/P, UL, MT, DS/DE, all special character escapes.

The nroffparser has all of these, making it a potential complement
to man2markdown for the missing macro coverage.

### SO vs so confusion

man2markdown groups `.SO` with `.so` in the ignore list.
These are completely different macros: `.SO` starts standard
options (custom Tcl/Tk), `.so` includes a file (standard nroff).


## Parser statistics

nroffparser-0.2.tm: 1862 lines, 28 procs, 34 macros handled.
Parses all 425 Tcl/Tk man pages (229 .n + 196 .3) without errors.
debug-0.2.tm: 1062 lines with generic toolkit, compat layer,
and nroff-specific extension (coverage tracking, breakpoints).


## Conversion pipelines

### Available now

```
.n  --> nroffparser --> AST --> nroffrenderer --> Tk text widget
.n  --> nroffparser --> AST --> n2txt --> plain text (basic)
.md --> mdparser --> mdmodel --> mdviewer --> Tk text widget
.md --> mdparser --> mdpdf --> pdf4tcl --> PDF
```

### Missing pieces

```
.n  --> nroffparser --> AST --> ast2md --> .md --> (all mdstack outputs)
.n  --> nroffparser --> AST --> html renderer --> HTML
.n  --> nroffparser --> AST --> pdf renderer --> PDF
.md --> mdparser --> html renderer --> HTML
.md --> mdparser --> txt renderer --> plain text
```

The shortest path to full coverage is `ast2md` (nroff AST to Markdown).
Once in Markdown, mdstack provides Tk, PDF and (future) HTML output.
Estimated size: 200-300 lines.

### Linux system tools for comparison

```
man ls                              # display via groff/nroff
groff -Tutf8 -mandoc file.1        # text output
groff -Thtml -mandoc file.1        # HTML output
groff -Tpdf -mandoc file.1         # PDF output
mandoc -T html file.1              # HTML (better than groff)
mandoc -T pdf file.1               # PDF
pandoc -f man -t markdown file.1    # Markdown (limited)
pandoc -f man -t gfm file.1        # GitHub Markdown
```

Note: `mandoc -T markdown` does not exist. pandoc's man-to-markdown
conversion is limited and does not handle Tcl/Tk custom macros.


## Open architecture questions

### Unified AST

mdparser and nroffparser produce different AST formats. A shared
document model would enable cross-format rendering without
intermediate Markdown conversion. The node types overlap
significantly: both have heading, paragraph, list, code/pre.
Differences are mainly in metadata (mdparser has frontmatter,
nroffparser has .TH fields) and list subtypes.

### ruledtext as alternative model

The ruledtext model (plain text + formatting spans with start/end
positions) maps more directly to Tk text tags than a tree AST.
For pure viewing this can be simpler. For export (PDF, HTML, Markdown)
a tree AST is more natural. The two models are complementary:
AST for parsing and export, ruledtext/spans for editing and overlay.
