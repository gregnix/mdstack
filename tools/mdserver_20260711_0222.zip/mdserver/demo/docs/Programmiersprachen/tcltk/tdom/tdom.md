# tdom - Referenzhandbuch

*Stand: 2026-05-28*

`tdom` ist der XML/HTML-Parser und die DOM-Implementierung für Tcl:
schnell (C-Erweiterung um expat), vollständig, mit XPath. Dieses Dokument
behandelt den praktischen Umgang mit dem DOM-Baum -- Parsen, Navigieren,
Lesen, Erzeugen, Serialisieren -- und vor allem die **Maschen und Fallen**,
über die man in der Praxis stolpert.

Ergänzt `tdom-grundlagen.md` (Schnelleinstieg); hier liegt der Fokus auf
Details und Fehlerquellen.

## Grundkonzept

Ein geparstes Dokument ist ein Baum aus **Knoten** (nodes). Jeder Knoten ist
in Tcl ein **Objekt-Befehl**, dessen Methoden den Knoten abfragen oder
verändern. Das Dokument selbst ist ebenfalls ein Befehl.

```tcl
package require tdom

set xml {<buch titel="Tcl"><kapitel>Eins</kapitel></buch>}
set doc  [dom parse $xml]        ;# Dokument-Befehl
set root [$doc documentElement]  ;# Wurzelelement <buch>

puts [$root nodeName]            ;# -> buch
puts [$root getAttribute titel]  ;# -> Tcl
puts [$root asText]              ;# -> Eins  (Textinhalt aller Nachfahren)

$doc delete                      ;# Speicher freigeben (siehe unten!)
```

Knoten-Befehle sehen aus wie `domNode0x55...` -- man hält sie in Variablen,
gibt sie an Methoden weiter und vergleicht sie mit `eq`/`ne`.

## Parsen

```tcl
set doc [dom parse $xml]              ;# XML-String
set doc [dom parse -html $html]       ;# HTML (tolerant, repariert Fehler)
set doc [dom parse -json $json]       ;# JSON -> DOM
set doc [dom parse -channel $chan]    ;# aus einem Kanal (Encoding des Kanals!)
set doc [dom parse -baseurl $url $xml] ;# Basis-URL für relative Referenzen
```

### Whitespace wird standardmäßig entfernt

**Wichtige Masche:** Anders als das Browser-DOM entfernt tdom Textknoten, die
nur aus Whitespace bestehen, schon beim Parsen. Eingerückte XML-Dateien
erzeugen also **keine** störenden Leertext-Knoten zwischen den Elementen.

```tcl
set xml "<a>\n  <b/>\n  <c/>\n</a>"

# DEFAULT: keine Whitespace-Knoten
set doc [dom parse $xml]
llength [[$doc documentElement] childNodes]   ;# -> 2  (b und c)

# Mit -keepEmpties: Whitespace bleibt erhalten
set doc2 [dom parse -keepEmpties $xml]
llength [[$doc2 documentElement] childNodes]  ;# -> 5  (\n, b, \n, c, \n)
```

Wer also bewusst signifikanten Whitespace braucht (z. B. zwischen Inline-Tags
in `<text:p>`), parst mit `-keepEmpties` -- sonst gehen führende/trailing
Leerzeichen in gemischtem Inhalt unter Umständen verloren.

### Schneller, aber unsauberer Parser

```tcl
# -simple: etwa doppelt so schnell, aber nicht voll XML-konform
set doc [dom parse -simple $xml]
```

Nur für vertrauenswürdige, wohlgeformte Eingaben.

### Bytes aus einem Container-Part parsen

ZIP-Container-Teile (ODF `content.xml`, `settings.xml`, eine Sub-Dokument-
`content.xml` …) kommen als **Bytes**, nicht als fertiger Tcl-String. Vor dem
Parsen nach UTF-8 dekodieren, sonst zerschießt es Nicht-ASCII:

```tcl
set bytes [$pkg part content.xml]                 ;# rohe Bytes aus dem ZIP
set doc   [dom parse [encoding convertfrom utf-8 $bytes]]
# ... lesen (getElementsByTagName, getAttribute … "") ...
$doc delete                                        ;# frischer Baum -> löschen!
```

Umgekehrt beim Zurückschreiben in den Container mit
`encoding convertto utf-8 [$node asXML …]`. Liefert eine Bibliotheks-API einen
frisch geparsten Baum zurück (z. B. `[$pkg tree content.xml]`), gehört das
`$doc delete` dem **Aufrufer** -- sonst sammeln sich Handles, gerade in Readern
und Schleifen.

## Speicher und Lebenszyklus -- die wichtigste Falle

tdom-Bäume liegen im **C-Speicher** und werden nicht vom Tcl-GC eingesammelt.
Es gibt zwei Erzeugungsformen mit *unterschiedlichem* Verhalten:

```tcl
# (1) An eine Variable gebunden -> wird automatisch frei, wenn die Variable
#     aus dem Scope fällt:
dom parse $xml doc
$doc documentElement
# ... am Ende des proc verschwindet 'doc' -> Baum wird automatisch freigegeben

# (2) Als Rückgabewert -> PERSISTENT, muss explizit gelöscht werden:
set doc [dom parse $xml]
# ... verarbeiten ...
$doc delete                  ;# sonst Memory-Leak!
```

```tcl
# FALSCH: persistenter Baum ohne delete -> Leak (besonders in Schleifen fatal)
foreach f $files {
    set doc [dom parse -file $f]
    verarbeite $doc
    # delete vergessen -> jeder Durchlauf leakt einen kompletten Baum
}

# RICHTIG:
foreach f $files {
    set doc [dom parse -file $f]
    try {
        verarbeite $doc
    } finally {
        $doc delete
    }
}
```

**Stale Handles:** Nach `$doc delete` (oder nachdem ein Knoten gelöscht wurde)
sind alle zugehörigen Knoten-Befehle ungültig. Ihre Verwendung wirft einen
Fehler ("invalid command name ...").

```tcl
set node [$root firstChild]
$doc delete
$node nodeName    ;# FEHLER: node-Befehl existiert nicht mehr
```

## Navigation

```tcl
$doc documentElement     ;# Wurzelelement
$node parentNode         ;# Elternknoten ("" bei Wurzel)
$node childNodes         ;# Liste der direkten Kinder
$node firstChild         ;# erstes Kind ("" wenn keins)
$node lastChild
$node nextSibling        ;# nächstes Geschwister ("" wenn keins)
$node previousSibling
$node hasChildNodes      ;# 1/0
$node ownerDocument      ;# das Dokument
```

Fehlende Nachbarn liefern den **leeren String**, keinen Fehler -- darauf prüft
man mit `eq ""`:

```tcl
for {set n [$root firstChild]} {$n ne ""} {set n [$n nextSibling]} {
    puts [$n nodeName]
}
```

## Knotentypen

`nodeType` liefert **String-Konstanten**, nicht die W3C-Zahlencodes:

```tcl
ELEMENT_NODE  TEXT_NODE  CDATA_SECTION_NODE  COMMENT_NODE
PROCESSING_INSTRUCTION_NODE
```

```tcl
# FALSCH: Vergleich mit der DOM-Zahl 1 -- trifft nie zu
if {[$n nodeType] == 1} { ... }

# RICHTIG:
if {[$n nodeType] eq "ELEMENT_NODE"} { ... }
```

Beim Iterieren über `childNodes` filtert man Elemente heraus, weil bei
gemischtem Inhalt auch Textknoten vorkommen:

```tcl
foreach c [$p childNodes] {
    switch -- [$c nodeType] {
        ELEMENT_NODE { puts "Element: [$c nodeName]" }
        TEXT_NODE    { puts "Text: [$c nodeValue]" }
    }
}
```

## Text lesen: asText vs. nodeValue

Das ist eine klassische Verwechslung:

```tcl
# asText: konkateniert den Text ALLER Nachfahren eines Elements
$element asText        ;# z.B. "Hallo Welt" aus <p>Hallo <b>Welt</b></p>

# nodeValue: der Wert EINES Knotens
#   - Textknoten  -> der Text
#   - Element     -> "" (Elemente haben keinen nodeValue)
$textnode nodeValue    ;# "Hallo "
$element  nodeValue    ;# "" (nicht das, was man oft erwartet!)
```

```tcl
# Häufiger Fehler: nodeValue auf einem Element erwartet den Inhalt
set titel [[$root selectNodes title] nodeValue]   ;# FALSCH -> ""
set titel [[$root selectNodes title] asText]       ;# RICHTIG

# Leere Elemente (z.B. Felder) liefern asText "":
$node asText           ;# bei <text:date/> -> ""
```

`$node text` ist äquivalent zu `asText` (gibt den gesamten Textinhalt zurück).

### asText konkateniert ohne Trenner

`asText` fügt die Textknoten aller Nachfahren **ohne Trennzeichen**
zusammen. Mehrere Kind-Absätze verschmelzen dadurch zu einem String:

```tcl
set doc [dom parse {<cell><p>Note</p><p>If you...</p></cell>}]
[[$doc documentElement] asText]    ;# -> "NoteIf you..." (kein Leerzeichen)
```

Das ist kein Fehler — die Absätze sind im Baum getrennt. Wer einen Trenner
braucht, iteriert über die Kindknoten und fügt ihn selbst ein:

```tcl
join [lmap n [$element childNodes] {$n asText}] " "   ;# -> "Note If you..."
```

## Attribute

```tcl
$node setAttribute name "wert"           ;# setzen (auch mit Präfix: style:name)
$node setAttribute n1 v1 n2 v2           ;# mehrere auf einmal
$node hasAttribute name                  ;# 1/0
$node removeAttribute name
$node attributes                         ;# Liste der Attributnamen
```

### getAttribute wirft bei fehlendem Attribut -- immer Default mitgeben

**Wichtigste Attribut-Masche:** Ohne `defaultValue` wirft `getAttribute` einen
Fehler, wenn das Attribut nicht existiert.

```tcl
# FALSCH: knallt, sobald 'style:name' fehlt
set n [$node getAttribute style:name]

# RICHTIG: Default angeben -> "" (oder ein sinnvoller Wert) bei Abwesenheit
set n [$node getAttribute style:name ""]
```

Faustregel: Sobald ein Attribut *optional* sein könnte, **immer** einen Default
übergeben. Das durchzieht praktisch jeden robusten tdom-Code.

```tcl
# Beim Suchen eines Knotens nach Attributwert:
foreach st [$root getElementsByTagName style:style] {
    if {[$st getAttribute style:name ""] eq $gesucht} { return $st }
}
```

## Suchen: getElementsByTagName vs. selectNodes

Zwei Wege, mit unterschiedlichem Verhalten:

### getElementsByTagName

```tcl
# Findet ALLE Nachfahren (rekursiv) mit diesem Tag-Namen
set zellen [$root getElementsByTagName table:table-cell]
```

Zwei Maschen:

```tcl
# (1) REKURSIV: findet auch tief verschachtelte Treffer, nicht nur direkte Kinder
#     -> verschachtelte Frames/Tabellen liefern auch ihre inneren <text:p> mit!
set ps [$frame getElementsByTagName text:p]   ;# evtl. mehr als gedacht

# (2) Matcht den LITERALEN, qualifizierten Namen inkl. Präfix.
#     "table:table-cell" matcht nicht "cell" und nicht den Namespace,
#     sondern exakt diesen Tag-String.
```

Will man nur **direkte** Kinder, iteriert man `childNodes` und filtert:

```tcl
proc directChildren {node tag} {
    set res {}
    foreach c [$node childNodes] {
        if {[$c nodeType] eq "ELEMENT_NODE" && [$c nodeName] eq $tag} {
            lappend res $c
        }
    }
    return $res
}
```

### selectNodes (XPath)

```tcl
$root selectNodes {//kapitel}                 ;# alle <kapitel> im Baum
$root selectNodes {kapitel}                   ;# direkte Kind-<kapitel>
$root selectNodes {//item[@type='neu']}       ;# mit Prädikat
$root selectNodes {string(//title)}           ;# Stringwert -> direkt der Text
$root selectNodes {count(//item)}             ;# Zahl
$root selectNodes {//item[1]}                 ;# erstes (XPath ist 1-basiert!)
$root selectNodes {//item[last()]}            ;# letztes
```

`string(...)` und `count(...)` liefern direkt Wert bzw. Zahl -- bequemer als
Knoten holen und `asText` aufrufen.

```tcl
# Statt:
set t [[$root selectNodes {//title}] asText]
# kürzer:
set t [$root selectNodes {string(//title)}]
```

## XPath mit Namespaces -- Präfixe müssen gebunden werden

Das ist die häufigste XPath-Falle bei "echten" Dokumenten (ODF, SVG, Atom …):
Ein Präfix im XPath ist **nicht** automatisch dasselbe wie im Quelltext. Man
muss die Präfix->URI-Zuordnung explizit übergeben.

```tcl
# FALSCH: Präfix 'text' ist dem XPath-Parser unbekannt -> Fehler/leer
$root selectNodes {//text:p}

# RICHTIG: Namespaces binden (eigene Präfixnamen wählbar)
set ns {
    text  urn:oasis:names:tc:opendocument:xmlns:text:1.0
    table urn:oasis:names:tc:opendocument:xmlns:table:1.0
}
$root selectNodes -namespaces $ns {//text:p}
```

Bei stark namespace-behafteten Dokumenten ist `getElementsByTagName` mit dem
literalen Präfixnamen oft pragmatischer als XPath mit Namespace-Bindung.

### XPath cachen bei wiederholten Abfragen

```tcl
# Dieselbe Query oft? -cache kompiliert sie einmal und merkt sie sich:
foreach row $rows {
    $row selectNodes -cache 1 {cell}
}
```

## Erzeugen und Manipulieren

```tcl
set doc  [dom createDocument root]      ;# leeres Dokument mit Wurzel <root>
set root [$doc documentElement]

set el [$doc createElement kapitel]     ;# Element (am Dokument erzeugen!)
$el setAttribute nr 1
set tx [$doc createTextNode "Inhalt"]
$el appendChild $tx
$root appendChild $el
```

Knoten werden **am Dokument** erzeugt (`$doc createElement ...`), dann in den
Baum gehängt. `createTextNode`, `createComment`, `createCDATASection`,
`createElementNS` analog.

### Reihenfolge zählt -- appendChild vs. insertBefore

`appendChild` hängt hinten an. Soll ein Kind an eine bestimmte Position
(viele Schemata, u. a. ODF, schreiben eine feste Kind-Reihenfolge vor), nutzt
man `insertBefore`:

```tcl
$parent insertBefore $neu $referenzKind   ;# fügt $neu VOR $referenzKind ein
```

**Move-Semantik (wichtig):** Hängt man mit `appendChild`/`insertBefore` einen
Knoten ein, der **bereits im Baum** steht, wird er von seiner alten Position
**verschoben**, nicht kopiert (DOM-Standard: move). Ein vorheriges
`removeChild` ist also unnötig.

```tcl
# Einen vorhandenen Knoten ans Ende seines Elternteils verschieben:
$parent appendChild $schonVorhandenerKnoten   ;# entfernt ihn implizit von der alten Stelle

# Praxis: ein Element, das laut Schema immer LETZTES Kind sein muss
# (z.B. ODS table:named-expressions als Epilog), nach jeder Einfügung
# davor einfach wieder ans Ende hängen -- kein removeChild nötig.
```

```tcl
# "Ersetzen" als robustes Muster: neu davor, alt löschen
$parent insertBefore $neu $alt
$alt delete
# (oder direkt:)
$parent replaceChild $neu $alt
```

### Fragmente einhängen

```tcl
$node appendXML {<extra a="1"><tief/></extra>}   ;# XML-String parsen+anhängen
$node appendFromList {extra {a 1} {{tief {} {}}}} ;# aus Tcl-Listenstruktur
```

`appendXML` ist praktisch, um vorgefertigte Schnipsel einzusetzen, ohne jeden
Knoten einzeln zu bauen.

### Löschen

```tcl
$node delete            ;# entfernt den Knoten (und Unterbaum) aus dem Baum
$parent removeChild $kind
```

## Die Live-Listen-Falle

`childNodes` liefert eine **Momentaufnahme als Tcl-Liste**. Wer beim Iterieren
gleichzeitig löscht oder einfügt, verschiebt sich den Boden unter den Füßen --
die in der Schleife gehaltenen Handles können auf bereits entfernte Knoten
zeigen.

```tcl
# FALSCH: während des Iterierens den Baum verändern
foreach c [$parent childNodes] {
    if {[$c nodeName] eq "weg"} {
        $c delete            ;# verändert die Kinderstruktur mitten im Lauf
    }
}
# Kann je nach Implementierung Knoten überspringen oder auf Stale-Handles laufen.

# RICHTIG: erst sammeln, was zu tun ist, dann ausführen
set zumLoeschen {}
foreach c [$parent childNodes] {
    if {[$c nodeName] eq "weg"} { lappend zumLoeschen $c }
}
foreach c $zumLoeschen { $c delete }
```

Gleiches gilt beim Einfügen in einer Schleife über `childNodes`: erst die
Referenzpunkte einsammeln, dann modifizieren.

## Serialisieren

```tcl
$node asXML                          ;# Teilbaum als XML-String
$node asXML -indent 4                ;# eingerückt (4 Leerzeichen)
$node asXML -indent none             ;# ohne jede Einrückung
$node asXML -xmlDeclaration 1        ;# mit <?xml ...?>
$node asXML -escapeNonASCII 1        ;# Nicht-ASCII als &#...; ausgeben
$node asXML -doctypeDeclaration 1
$node asXML -channel $chan           ;# direkt in einen Kanal schreiben
$node asList                         ;# Baum als verschachtelte Tcl-Liste
```

### -indent verändert den Textinhalt

**Falle:** `asXML -indent` fügt Whitespace (Zeilenumbrüche, Einrückung) als
Text zwischen die Elemente ein. Wer das Ergebnis wieder einparst oder wo
Whitespace signifikant ist (z. B. Absatztext), verändert damit den Inhalt.

```tcl
# Für Round-Trip / inhaltskritische Teile: OHNE indent serialisieren
set out [$root asXML -indent none]

# -indent ist für menschenlesbare Ausgabe gedacht, nicht für Daten-Treue.
```

Beim Schreiben in eine Datei das Encoding am Kanal setzen:

```tcl
set f [open out.xml w]
fconfigure $f -encoding utf-8
puts $f {<?xml version="1.0" encoding="UTF-8"?>}
puts $f [$root asXML -indent none]
close $f
```

## Namespaces beim Erzeugen -- Präfixe am Wurzelknoten deklarieren

Erzeugt man Elemente mit Präfix (`style:foo`), muss das Präfix über eine
`xmlns:`-Deklaration an einem Vorfahren (üblich: der Wurzel) gebunden sein --
sonst entsteht beim Serialisieren ein **ungebundenes Präfix**, das strenge
Parser/Validatoren als Fatal ablehnen.

```tcl
# FALSCH: style: nirgends deklariert -> Ausgabe hat ungebundenes Präfix
set el [$doc createElement style:style]
$root appendChild $el

# RICHTIG: xmlns:style an der Wurzel deklarieren (einmalig, im Gerüst)
$root setAttribute xmlns:style \
    urn:oasis:names:tc:opendocument:xmlns:style:1.0
# danach sind alle <style:...>-Elemente korrekt gebunden
```

`createElement style:style` erzeugt den Knoten zwar problemlos -- die Bindung
ist erst beim Serialisieren/Validieren relevant. Faustregel: alle benötigten
`xmlns:*` gehören ins Wurzel-Gerüst, bevor man Präfix-Elemente einhängt.

## HTML und JSON

```tcl
# HTML ist oft "kaputt" -- der HTML-Modus repariert tolerant:
set doc [dom parse -html $html]
foreach a [$doc selectNodes {//a[@href]}] {
    puts "[$a asText] -> [$a getAttribute href ""]"
}

# JSON wird in einen DOM-Baum überführt:
set doc [dom parse -json {{"name":"Tcl","jahre":[1,2,3]}}]
```

## Häufige Fehler (Kurzübersicht)

```tcl
# 1) Persistenten Baum nicht freigegeben
set doc [dom parse $xml] ; # ... ; $doc delete   <- nie vergessen

# 2) getAttribute ohne Default bei optionalem Attribut
$n getAttribute x        ;# FALSCH (wirft) ->  $n getAttribute x ""

# 3) nodeType gegen Zahlen vergleichen
[$n nodeType] == 1       ;# FALSCH  ->  [$n nodeType] eq "ELEMENT_NODE"

# 4) nodeValue auf Element statt asText
[$el nodeValue]          ;# "" ->  [$el asText]

# 5) Ungebundenes Namespace-Präfix beim Erzeugen
#    -> xmlns:PRAEFIX an der Wurzel deklarieren

# 6) XPath-Präfix ohne -namespaces
$root selectNodes {//ns:x}        ;# leer/Fehler
$root selectNodes -namespaces {ns URI} {//ns:x}

# 7) getElementsByTagName ist rekursiv (findet auch verschachtelte Treffer)

# 8) -indent bei datenkritischer Ausgabe (verändert Whitespace)
$root asXML              ;# besser: -indent none für Round-Trip

# 9) Stale Handle nach delete weiterbenutzt -> "invalid command name"

# 10) Whitespace-Annahme: tdom entfernt Leertext per Default
#     (mit -keepEmpties bleibt er)
# 11) appendChild kopiert NICHT -- ein bereits eingehängter Knoten wird
#     verschoben; redundantes removeChild davor ist unnötig
```

## Praxis-Muster

### Knoten mit fester Kind-Reihenfolge bauen

```tcl
# Schema verlangt Reihenfolge a -> b -> c. Erst Gruppen erzeugen, dann
# in der richtigen Reihenfolge anhängen.
set el [$doc createElement frame]
foreach kind {titel beschreibung bild} {
    if {[info exists data($kind)]} {
        set c [$doc createElement $kind]
        $c appendChild [$doc createTextNode $data($kind)]
        $el appendChild $c
    }
}
```

### Robustes Lesen mit Default

```tcl
proc attr {node name {default ""}} {
    return [$node getAttribute $name $default]
}
```

### Element nach Attributwert finden (direkte Kinder)

```tcl
proc findByName {parent tag attr value} {
    foreach c [$parent childNodes] {
        if {[$c nodeType] eq "ELEMENT_NODE"
            && [$c nodeName] eq $tag
            && [$c getAttribute $attr ""] eq $value} {
            return $c
        }
    }
    return ""
}
```

## Performance

- `dom parse -simple` für vertrauenswürdige, wohlgeformte Eingaben (≈ 2× schneller).
- `selectNodes -cache 1` bei häufig wiederholter XPath-Query.
- `getElementsByTagName` (C-Implementierung) ist meist schneller als ein
  XPath `//tag`; für simple Tag-Suchen bevorzugen.
- Große Bäume zeitnah mit `$doc delete` freigeben -- besonders in Schleifen.
- Für reine Streaming-Verarbeitung großer Dateien ohne kompletten Baum gibt es
  den Pull-Parser (`tdom::pullparser`) und den expat-SAX-Stil.

## Siehe auch

- `tdom-grundlagen.md` -- Schnelleinstieg
- `rl-json-grundlagen.md` -- JSON ohne DOM-Umweg
- `encoding-unicode.md` -- Encoding beim Lesen/Schreiben von Dateien
- `regexp-vollstaendig.md` -- wenn XML "von Hand" doch keine gute Idee ist

## Referenzen

- [tDOM Homepage](https://tdom.github.io/)
- [tDOM Handbuch (dom / domNode / domDoc)](https://tdom.github.io/man.html)
- [Tcler's Wiki: tDOM](https://wiki.tcl-lang.org/page/tDOM)

---

*Letzte Aktualisierung: 2026-05-28 (appendChild-Move-Semantik ergänzt)*
