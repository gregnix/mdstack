# PowerShell Einfuehrung

Einfuehrung in PowerShell mit Fokus auf Zusammenarbeit mit Tcl/Tk-Anwendungen.

## Grundlagen

### Was ist PowerShell?

PowerShell ist Microsofts objektorientierte Shell und Skriptsprache, basierend auf .NET. Im Gegensatz zu klassischen Shells wie Bash arbeitet PowerShell mit Objekten statt reinem Text. Das bedeutet: Ausgaben haben Eigenschaften und Methoden, die direkt angesprochen werden koennen.

### Versionen

PowerShell existiert in zwei Varianten:

| Version | Executable | Plattform |
|---------|------------|-----------|
| Windows PowerShell 5.1 | powershell.exe | nur Windows |
| PowerShell 7+ (Core) | pwsh.exe | Windows, Linux, macOS |

Fuer neue Projekte PowerShell 7+ bevorzugen (Cross-Platform, aktiv entwickelt).

### Starten

```powershell
# Windows PowerShell
powershell.exe

# PowerShell 7+
pwsh.exe

# Version pruefen
$PSVersionTable.PSVersion
```

## Syntax-Grundlagen

### Cmdlets

PowerShell-Befehle folgen dem Schema Verb-Substantiv:

```powershell
Get-Process           # Prozesse auflisten
Get-ChildItem         # Verzeichnisinhalt (wie ls/dir)
Set-Location          # Verzeichnis wechseln (wie cd)
New-Item              # Datei/Ordner erstellen
Remove-Item           # Loeschen
Copy-Item             # Kopieren
Move-Item             # Verschieben
```

### Aliase

Viele Unix-Befehle sind als Aliase vorhanden:

```powershell
ls        # Get-ChildItem
cd        # Set-Location
cp        # Copy-Item
mv        # Move-Item
rm        # Remove-Item
cat       # Get-Content
pwd       # Get-Location
clear     # Clear-Host
```

### Variablen

Variablen beginnen mit `$`:

```powershell
$name = "Gregor"
$zahl = 42
$liste = @("eins", "zwei", "drei")
$dict = @{Name = "Test"; Wert = 123}

# Typ explizit
[string]$text = "Hello"
[int]$nummer = 100
```

### Automatische Variablen

```powershell
$_              # Aktuelles Objekt in Pipeline
$PSScriptRoot   # Verzeichnis des aktuellen Skripts
$PWD            # Aktuelles Arbeitsverzeichnis
$HOME           # Home-Verzeichnis
$env:PATH       # Umgebungsvariable PATH
$null           # Null-Wert
$true / $false  # Boolesche Werte
$?              # Erfolg des letzten Befehls
$LASTEXITCODE   # Exit-Code des letzten externen Programms
```

## Pipeline und Objekte

### Pipeline-Grundlagen

Die Pipeline verbindet Befehle mit `|`:

```powershell
Get-Process | Where-Object CPU -gt 10 | Sort-Object CPU -Descending

# Kurzformen:
Get-Process | ? CPU -gt 10 | sort CPU -Desc
```

### Objekt-Zugriff

```powershell
# Eigenschaften auslesen
$proc = Get-Process -Name "pwsh"
$proc.Name
$proc.CPU
$proc.WorkingSet64

# Alle Eigenschaften anzeigen
$proc | Get-Member

# Bestimmte Eigenschaften auswaehlen
Get-Process | Select-Object Name, CPU, WorkingSet64
```

### Where-Object (Filtern)

```powershell
# Prozesse mit mehr als 100 MB RAM
Get-Process | Where-Object WorkingSet64 -gt 100MB

# Mit Scriptblock fuer komplexe Bedingungen
Get-Process | Where-Object { $_.CPU -gt 10 -and $_.Name -like "p*" }
```

### ForEach-Object

```powershell
# Jeden Eintrag verarbeiten
Get-ChildItem *.txt | ForEach-Object { 
    Write-Host "Datei: $($_.Name)"
}

# Kurzform
Get-ChildItem *.txt | % { $_.Name }
```

## Kontrollstrukturen

### If/Else

```powershell
if ($zahl -gt 10) {
    Write-Host "Gross"
} elseif ($zahl -eq 10) {
    Write-Host "Genau 10"
} else {
    Write-Host "Klein"
}
```

### Vergleichsoperatoren

| Operator | Bedeutung |
|----------|-----------|
| -eq | gleich |
| -ne | ungleich |
| -gt | groesser |
| -lt | kleiner |
| -ge | groesser oder gleich |
| -le | kleiner oder gleich |
| -like | Wildcard-Match |
| -match | RegEx-Match |
| -contains | Liste enthaelt Wert |
| -in | Wert in Liste |

### Switch

```powershell
switch ($wert) {
    "a" { "Option A" }
    "b" { "Option B" }
    default { "Unbekannt" }
}
```

### Schleifen

```powershell
# For
for ($i = 0; $i -lt 10; $i++) {
    Write-Host $i
}

# Foreach
foreach ($item in $liste) {
    Write-Host $item
}

# While
while ($bedingung) {
    # ...
}

# Do-While
do {
    # ...
} while ($bedingung)
```

## Funktionen

### Einfache Funktion

```powershell
function Say-Hello {
    param(
        [string]$Name = "Welt"
    )
    Write-Host "Hallo $Name!"
}

Say-Hello -Name "Gregor"
```

### Erweiterte Funktion

```powershell
function Get-FileInfo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [string]$Path,
        
        [switch]$Detailed
    )
    
    process {
        $file = Get-Item $Path
        if ($Detailed) {
            $file | Select-Object Name, Length, LastWriteTime
        } else {
            $file.Name
        }
    }
}

# Verwendung
Get-FileInfo -Path "test.txt" -Detailed
"file1.txt", "file2.txt" | Get-FileInfo
```

## Dateioperationen

### Lesen und Schreiben

```powershell
# Datei lesen
$inhalt = Get-Content datei.txt
$inhalt = Get-Content datei.txt -Raw          # Als ein String
$inhalt = Get-Content datei.txt -Encoding UTF8

# Datei schreiben
"Text" | Set-Content datei.txt
"Mehr Text" | Add-Content datei.txt           # Anhaengen
Set-Content datei.txt -Value $inhalt -Encoding UTF8

# CSV
$daten = Import-Csv daten.csv -Delimiter ";"
$daten | Export-Csv output.csv -NoTypeInformation

# JSON
$obj = Get-Content config.json | ConvertFrom-Json
$obj | ConvertTo-Json | Set-Content config.json
```

### Pfadoperationen

```powershell
# Pfade verbinden (plattformunabhaengig)
Join-Path $HOME "Dokumente" "datei.txt"

# Pfad aufloesen
Resolve-Path ".\relative\path"

# Pfadbestandteile
Split-Path "C:\Users\test\datei.txt" -Parent    # C:\Users\test
Split-Path "C:\Users\test\datei.txt" -Leaf      # datei.txt

# Existenz pruefen
Test-Path "datei.txt"
Test-Path "ordner" -PathType Container
```

## Externe Programme ausfuehren

### Grundlagen

```powershell
# Direkt ausfuehren
notepad.exe datei.txt

# Mit Argumenten
git commit -m "Nachricht"

# Ausgabe erfassen
$result = git status

# Exit-Code pruefen
git status
if ($LASTEXITCODE -ne 0) {
    Write-Error "Git-Fehler"
}
```

### Programme mit Leerzeichen im Pfad

```powershell
# Mit & (Call-Operator)
& "C:\Program Files\App\program.exe" -arg1 -arg2

# Argumente als Array
$args = @("-input", "file.txt", "-output", "out.txt")
& "C:\Program Files\App\program.exe" @args
```

### Start-Process

```powershell
# Im Hintergrund starten
Start-Process notepad.exe

# Warten auf Beendigung
Start-Process notepad.exe -Wait

# Mit Argumenten und erhoehten Rechten
Start-Process powershell.exe -ArgumentList "-File script.ps1" -Verb RunAs

# Ausgabe erfassen
$proc = Start-Process cmd.exe -ArgumentList "/c dir" `
    -NoNewWindow -Wait -PassThru `
    -RedirectStandardOutput "out.txt" -RedirectStandardError "err.txt"
```

## Zusammenarbeit mit Tcl/Tk

### Tcl-Skripte aus PowerShell starten

```powershell
# tclsh direkt aufrufen
& tclsh script.tcl

# Mit Argumenten
& tclsh script.tcl -input "daten.txt" -output "result.txt"

# wish fuer Tk-Anwendungen
& wish app.tcl

# Pfad zu tclsh/wish (wenn nicht im PATH)
$tclsh = "C:\Tcl\bin\tclsh.exe"
& $tclsh script.tcl
```

### Exit-Code auswerten

```powershell
# Tcl exit-Code pruefen
& tclsh script.tcl
if ($LASTEXITCODE -ne 0) {
    Write-Error "Tcl-Skript fehlgeschlagen mit Code $LASTEXITCODE"
    exit $LASTEXITCODE
}
```

### Ausgabe verarbeiten

```powershell
# Stdout erfassen
$result = & tclsh script.tcl 2>&1

# Zeilenweise verarbeiten
$lines = & tclsh report.tcl
foreach ($line in $lines) {
    if ($line -match "^ERROR:") {
        Write-Warning $line
    }
}
```

### Daten an Tcl uebergeben

```powershell
# Ueber Argumente
$datei = "C:\Daten\input.csv"
$ausgabe = "C:\Daten\output.pdf"
& tclsh process.tcl -input $datei -output $ausgabe

# Ueber Stdin (Pipe)
Get-Content daten.txt | & tclsh filter.tcl

# Ueber temporaere Datei
$temp = New-TemporaryFile
$daten | Set-Content $temp.FullName -Encoding UTF8
& tclsh process.tcl -file $temp.FullName
Remove-Item $temp.FullName

# Ueber Umgebungsvariable
$env:MY_CONFIG = "wert"
& tclsh script.tcl   ;# Tcl liest mit: set val $::env(MY_CONFIG)
```

### Tcl-Ausgabe als Objekte

```powershell
# JSON-Ausgabe von Tcl
$json = & tclsh export-json.tcl | ConvertFrom-Json
$json.results | ForEach-Object {
    Write-Host "$($_.name): $($_.value)"
}

# CSV-Ausgabe
$csv = & tclsh export-csv.tcl | ConvertFrom-Csv -Delimiter ";"
```

### Wrapper-Funktion

```powershell
function Invoke-Tcl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Script,
        
        [hashtable]$Arguments = @{},
        
        [string]$TclPath = "tclsh"
    )
    
    # Argumente als Liste aufbauen
    $argList = @($Script)
    foreach ($key in $Arguments.Keys) {
        $argList += "-$key"
        $argList += $Arguments[$key]
    }
    
    # Ausfuehren und Exit-Code pruefen
    $output = & $TclPath @argList 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        throw "Tcl-Fehler ($LASTEXITCODE): $output"
    }
    
    return $output
}

# Verwendung
$result = Invoke-Tcl -Script "process.tcl" -Arguments @{
    input = "daten.csv"
    output = "result.pdf"
    format = "A4"
}
```

### PowerShell aus Tcl aufrufen

Im Tcl-Skript:

```tcl
# PowerShell-Befehl ausfuehren
proc run_powershell {script} {
    set result [exec pwsh -NoProfile -Command $script]
    return $result
}

# Beispiel: Windows-Dienste abfragen
set services [run_powershell {Get-Service | Where-Object Status -eq Running | Select-Object -ExpandProperty Name}]
foreach svc [split $services "\n"] {
    puts "Dienst: $svc"
}

# PowerShell-Skript ausfuehren
proc run_ps_script {script_path args} {
    set cmd [list pwsh -NoProfile -File $script_path {*}$args]
    if {[catch {exec {*}$cmd} result]} {
        error "PowerShell-Fehler: $result"
    }
    return $result
}
```

### Plattformunabhaengige Erkennung

Im Tcl-Skript (analog zu auto_execok):

```tcl
proc has_powershell {} {
    # PowerShell 7+ (pwsh) bevorzugen
    if {[auto_execok pwsh] ne ""} {
        return "pwsh"
    }
    # Windows PowerShell als Fallback
    if {[auto_execok powershell] ne ""} {
        return "powershell"
    }
    return ""
}

proc invoke_powershell {command} {
    set ps [has_powershell]
    if {$ps eq ""} {
        error "PowerShell nicht gefunden"
    }
    return [exec $ps -NoProfile -Command $command]
}
```

## Cheatsheet: Haeufige Befehle

### Dateisystem

```powershell
ls                              # Verzeichnisinhalt
ls -Recurse -Filter "*.tcl"     # Rekursiv suchen
cd C:\Projekte                  # Verzeichnis wechseln
pwd                             # Aktuelles Verzeichnis
mkdir ordner                    # Ordner erstellen
cp quelle.txt ziel.txt          # Kopieren
mv alt.txt neu.txt              # Umbenennen/Verschieben
rm datei.txt                    # Loeschen
rm -Recurse ordner              # Ordner loeschen
cat datei.txt                   # Inhalt anzeigen
```

### Suchen und Filtern

```powershell
# Dateien nach Inhalt durchsuchen
Select-String -Path "*.tcl" -Pattern "proc main"

# Rekursiv in allen Unterordnern
Get-ChildItem -Recurse -Filter "*.tcl" | Select-String "package require"

# Dateien nach Datum
Get-ChildItem | Where-Object LastWriteTime -gt (Get-Date).AddDays(-7)

# Grosse Dateien finden
Get-ChildItem -Recurse | Where-Object Length -gt 10MB | Sort-Object Length -Desc
```

### Prozesse

```powershell
Get-Process                     # Alle Prozesse
Get-Process -Name "wish*"       # Nach Name
Stop-Process -Name "wish"       # Beenden
Stop-Process -Id 1234           # Nach PID beenden
```

### Netzwerk

```powershell
Test-Connection google.com      # Ping
Invoke-WebRequest https://example.com   # HTTP-Request
Invoke-RestMethod https://api.example.com/data   # REST-API (JSON)
```

### String-Operationen

```powershell
"text".ToUpper()                # GROSCHRIFT
"TEXT".ToLower()                # kleinschrift
"  text  ".Trim()               # Whitespace entfernen
"a,b,c".Split(",")              # In Array splitten
@("a","b","c") -join ","        # Array zu String
"text" -replace "e", "a"        # Ersetzen
"text" -match "ex"              # RegEx-Match (bool)
$Matches[0]                     # Letzter Match
```

### Datum und Zeit

```powershell
Get-Date                        # Aktuelles Datum/Zeit
Get-Date -Format "yyyy-MM-dd"   # Formatiert
(Get-Date).AddDays(-7)          # Vor 7 Tagen
[DateTime]::Parse("2025-01-23") # String parsen
```

## Cheatsheet: Tcl-Vergleich

| Aufgabe | Tcl | PowerShell |
|---------|-----|------------|
| Variable setzen | `set x 5` | `$x = 5` |
| Liste erstellen | `list a b c` | `@("a","b","c")` |
| Dict/Hash | `dict create k v` | `@{k = "v"}` |
| String-Laenge | `string length $s` | `$s.Length` |
| Substring | `string range $s 0 2` | `$s.Substring(0,3)` |
| Datei lesen | `read [open f r]` | `Get-Content f` |
| Datei schreiben | `puts $fd $text` | `$text \| Set-Content f` |
| Pfad verbinden | `file join a b` | `Join-Path a b` |
| Datei existiert | `file exists f` | `Test-Path f` |
| Programm suchen | `auto_execok cmd` | `Get-Command cmd -EA Silent` |
| Extern ausfuehren | `exec cmd args` | `& cmd args` |
| Fehler fangen | `catch {code} err` | `try {code} catch {$_}` |
| Schleife | `foreach x $list {..}` | `foreach ($x in $list) {..}` |
| Prozedur/Funktion | `proc name {args} {..}` | `function name {param(..) ..}` |

## Cheatsheet: Kurzreferenz

```powershell
# Hilfe
Get-Help Get-Process            # Hilfe zu Befehl
Get-Help Get-Process -Examples  # Nur Beispiele
Get-Command *process*           # Befehle suchen
Get-Member                      # Objekteigenschaften anzeigen

# Ausgabe
Write-Host "Text"               # Auf Konsole (kein Objekt)
Write-Output "Text"             # Als Objekt in Pipeline
Write-Error "Fehler"            # Fehler
Write-Warning "Warnung"         # Warnung

# Debugging
Set-PSDebug -Trace 1            # Befehle ausgeben
$DebugPreference = "Continue"   # Debug-Meldungen anzeigen
$VerbosePreference = "Continue" # Verbose-Meldungen anzeigen

# Profile
$PROFILE                        # Pfad zum Profil
notepad $PROFILE                # Profil bearbeiten
```

## Skript-Vorlage

```powershell
#Requires -Version 7.0

<#
.SYNOPSIS
    Kurzbeschreibung des Skripts.
.DESCRIPTION
    Ausfuehrliche Beschreibung.
.PARAMETER Input
    Eingabedatei.
.EXAMPLE
    .\script.ps1 -Input daten.csv
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ })]
    [string]$Input,
    
    [string]$Output = "output.txt",
    
    [switch]$Verbose
)

# Strict Mode aktivieren
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Hauptlogik
try {
    Write-Host "Verarbeite $Input..."
    
    # Tcl-Skript aufrufen
    $result = & tclsh process.tcl -input $Input -output $Output
    if ($LASTEXITCODE -ne 0) {
        throw "Tcl-Verarbeitung fehlgeschlagen"
    }
    
    Write-Host "Fertig: $Output"
}
catch {
    Write-Error "Fehler: $_"
    exit 1
}
```

## Siehe auch

- exec-externe-programme.md - Externe Programme aus Tcl
- auto-execok-plattform.md - Plattformunabhaengige Programmerkennung
- kompatibilitaet.md - Cross-Platform-Entwicklung
