# place — der begründete Ausnahmefall

*Stand: 2026-05-29*

## Einführung

`place` positioniert Widgets absolut oder relativ — pixelgenau, mit voller
Kontrolle. Genau diese Kontrolle macht es verlockend und meist zur
falschen Wahl. Dieses Kapitel zeigt, was `place` kann, wofür es wirklich
gut ist (Overlays, Verhältnis-Layouts) und warum es für Formulare die
schlechteste der drei Optionen ist.

---

## 9.1 Absolute und relative Positionierung

`place` kennt zwei Koordinatensysteme nebeneinander: absolut in Pixeln
(`-x`, `-y`) und relativ zur Eltern-Größe als Bruch zwischen 0.0 und 1.0
(`-relx`, `-rely`). Dasselbe gilt für die Größe (`-width`/`-height` gegen
`-relwidth`/`-relheight`):

```tcl
place .w -x 20 -y 10                       ;# 20px von links, 10px von oben
place .w -relx 0.5 -rely 0.5 -anchor center ;# in der Mitte des Parents
place .w -relwidth 1.0 -relheight 0.5       ;# volle Breite, halbe Höhe
```

`-anchor` legt fest, welcher Punkt des Widgets auf die Koordinate gesetzt
wird (Default `nw`, also obere linke Ecke). `-relx 0.5 -anchor center`
heißt „Mitte des Widgets auf die Mitte des Parents" — ein sauber
zentriertes Overlay.

Absolute und relative Angaben dürfen sich mischen; sie addieren sich.
`-relx 1.0 -x -10` bedeutet „rechter Rand minus 10 Pixel":

```tcl
place .w -relx 1.0 -x -10 -y 10 -anchor ne   ;# 10px vom rechten Rand
```

---

## 9.2 Wofür place wirklich gut ist

Es gibt zwei Fälle, in denen `place` die richtige und sauberste Wahl ist.

**Overlays über anderen Widgets.** Mit `-in` bezieht man die Koordinaten
auf ein *anderes* Widget statt auf den Parent. So legt man eine Markierung
oder einen Hinweis über ein bestehendes Widget, ohne dessen Layout zu
stören:

```tcl
# Eine dünne Linie über einem Text-Widget positionieren
frame .editor._marker -height 2 -bg "#c8d8e8"
::place .editor._marker -in .editor -x 0 -y 40 -relwidth 1.0 -height 2
raise .editor._marker
```

Zwei Details sind wichtig: `-in .editor` macht die Koordinaten relativ zu
`.editor`, und `raise` hebt das Overlay über den Inhalt — sonst läge es
darunter. (Zur Schreibweise `::place` siehe Abschnitt 8.4.)

**Verhältnis-Layouts**, bei denen ein Bereich immer einen festen Anteil
des Fensters einnehmen soll, unabhängig vom Inhalt:

```tcl
# Linke Hälfte / rechte Hälfte, exakt 50:50
place .left  -relx 0.0 -rely 0.0 -relwidth 0.5 -relheight 1.0
place .right -relx 0.5 -rely 0.0 -relwidth 0.5 -relheight 1.0
```

Für eine *verschiebbare* Teilung ist allerdings `ttk::panedwindow` die
bessere Wahl (Kapitel 18) — `place` lohnt sich nur, wenn das Verhältnis
fest bleiben soll.

---

## 9.3 Warum place selten die richtige Wahl für Formulare ist

`place` hat eine Eigenschaft, die es von `pack` und `grid`
unterscheidet und für Formulare disqualifiziert: **Es propagiert nicht.**

`pack` und `grid` berechnen die Größe des Eltern-Widgets aus den Kindern
und rechnen alles neu, wenn sich Inhalt, Schrift oder Fenstergröße ändern
(Kapitel 6). `place` tut das nicht. Ein per `place -x` gesetztes Widget
bleibt, wo es ist — auch wenn der Text länger wird, die Schrift größer
oder das Fenster anders skaliert. Das Eltern-Widget bekommt von seinen
`place`-Kindern auch keine Größe; es muss seine Größe selbst kennen.

Die Folge: Ein mit `place` gebautes Formular bricht, sobald sich
irgendetwas an Schrift, Sprache oder Auflösung ändert. Beschriftungen
überlappen, Felder ragen aus dem Fenster. Genau die automatische
Neuberechnung, die `grid` mühelos leistet, fehlt. Deshalb gilt:

> **Formulare und reguläre Layouts gehören zu `grid` (oder `pack`).**
> `place` ist für Overlays und feste Verhältnisse — nicht für Inhalt, der
> sich an Größe und Schrift anpassen soll.

---

## 9.4 place und die anderen Manager kombinieren

`place` ist von der „ein Manager pro Parent"-Regel (Kapitel 6)
ausgenommen, weil es die Eltern-Größe nicht beeinflusst. Man darf — und
soll — ein `place`-Overlay über ein `pack`- oder `grid`-Layout legen:

```tcl
# Hauptlayout mit grid, ein Hinweis-Badge per place darüber
ttk::frame .card
grid .card -row 0 -column 0 -sticky nsew
# ... .card mit grid füllen ...

ttk::label .card.badge -text "NEU" -background "#ffd54f"
place .card.badge -relx 1.0 -x -4 -y 4 -anchor ne   ;# oben rechts
```

Eine letzte, leicht übersehene Falle betrifft Namespaces: `place`, `raise`
und `lower` sind gewöhnliche Befehlsnamen und können in einem
`namespace eval` mit eigenen Prozeduren kollidieren. Wer in einem
Namespace eine Prozedur `place` definiert, ruft mit `place …` versehentlich
diese auf, nicht den Tk-Befehl. Die Absicherung ist, den Tk-Befehl global
zu qualifizieren:

```tcl
namespace eval mywidget {
    proc draw {} {
        ::place .line -x 10 -y 20    ;# eindeutig der Tk-Befehl
        ::raise .line
    }
}
```

Dasselbe gilt für `raise`, `lower` und andere kurze Befehlsnamen.

---

## Zusammenfassung

- `place` positioniert absolut (`-x`/`-y`) oder relativ (`-relx`/`-rely`),
  mit `-anchor` als Bezugspunkt; absolute und relative Angaben addieren
  sich.
- Stärken: Overlays (mit `-in` und `raise`) und feste Verhältnis-Layouts.
- `place` propagiert nicht und reagiert nicht auf Schrift-/Inhaltsgröße —
  daher ungeeignet für Formulare.
- Es darf als Overlay über `pack`/`grid` liegen; in Namespaces `::place`
  qualifizieren.

Damit sind alle drei Manager behandelt. Kapitel 10 setzt sie zu den
Mustern zusammen, die echte, mitwachsende Fenster ausmachen.
