# Häufige Fehler und Lösungen

*Stand: 2026-05-29*

Eine nach Symptom geordnete Sammlung der häufigsten Tk-Fehler aus diesem
Buch, je mit Ursache und Lösung.

## Layout

**Widget ist unsichtbar.** — Kein Geometry Manager aufgerufen. → `pack`,
`grid` oder `place` nicht vergessen. (Kapitel 6)

**Fenster „hängt" / Endlos-Neuberechnung.** — `pack` und `grid` im selben
Eltern-Widget gemischt. → Pro Frame genau ein Manager; Bereiche in eigene
Frames. (Kapitel 6)

**Widget wächst beim Vergrößern nicht mit.** — `-fill`/`-sticky` ohne
`-expand`/`-weight`. → Beides setzen: `pack … -fill both -expand 1` bzw.
`grid … -sticky nsew` plus `grid columnconfigure/rowconfigure … -weight 1`.
(Kapitel 6, 7, 8)

**Formularfelder bleiben schmal.** — Kein `columnconfigure -weight` auf der
Eingabe-Spalte. → `grid columnconfigure $f 1 -weight 1`. (Kapitel 8)

**Statusleiste wird beim Verkleinern abgeschnitten.** — Inhalt vor der
Statusleiste gepackt. → Ränder (Toolbar/Status) zuerst packen, Inhalt
zuletzt. (Kapitel 7)

**Widget liegt neben statt im Container.** — Als Kind des falschen Elters
erzeugt. → Pfadname muss die Hierarchie spiegeln: `.container.btn`, nicht
`.btn`. (Kapitel 1, 6)

**place-Layout bricht bei anderer Schrift/Sprache.** — `place` propagiert
nicht und passt sich nicht an. → Für Formulare `grid` nehmen; `place` nur
für Overlays/feste Verhältnisse. (Kapitel 9)

## Widgets und Optionen

**„unknown option -background" an einem Ttk-Widget.** — classic-Option an
Ttk-Widget. → Aussehen über `ttk::style configure`/`map` und `-style`.
(Kapitel 4, 24)

**Label zeigt Bild, aber nicht den Text.** — `-image` ohne `-compound`. →
`-compound left` (o.ä.) setzen. (Kapitel 13)

**Combobox liefert eine Zahl statt des Wertes.** — `current` (Index) statt
`get` (Wert) verwendet. → `get` nutzen. (Kapitel 15)

**Combobox-Wert mit Leerzeichen zerfällt.** — `-values` als String statt
Liste. → `-values [list "New York" "Berlin"]`. (Kapitel 15)

**Entry/Label zeigt nichts an.** — `-textvariable` auf lokale statt
globale/qualifizierte Variable. → `::name` oder `::app::name`. (Kapitel 29)

**Validierung schaltet sich von selbst ab.** — Der `-validatecommand`
ändert das Widget selbst. → Prüfprozedur darf nur prüfen und 0/1
zurückgeben, nicht eingreifen. (Kapitel 14)

## Ereignisse und Interaktion

**Variable im Binding wird zu früh aufgelöst.** — `$var` in `"…"` wird
schon bei der Definition ersetzt. → Code in `{…}` mit `$::var`, oder
Prozedur mit `%`-Codes als Argumenten aufrufen. (Kapitel 17, 20)

**Alle Schleifen-Buttons rufen mit demselben Wert auf.** — `{handle $i}`
löst `$i` erst beim Klick auf (= letzter Wert). → `-command [list handle
$i]`. (Kapitel 17)

**Beschleuniger im Menü tut nichts.** — `-accelerator` ist nur Anzeige. →
Zusätzlich `bind . <Control-s> {…}`. (Kapitel 17, 21)

**Kontextmenü erscheint an falscher Stelle.** — `%x %y` (Widget) statt
`%X %Y` (Bildschirm) an `tk_popup`. → `tk_popup .ctx %X %Y`. (Kapitel 21)

**Mein eigenes Binding greift nicht.** — Ein früheres bindtag fängt es mit
`break` ab, oder die Klassen-Bindings laufen zuerst. → `bindtags` prüfen.
(Kapitel 20)

## Event-Loop und Dialoge

**Oberfläche friert während einer Berechnung ein.** — Langer Code
blockiert den Event-Loop. → Arbeit mit `after` in Häppchen aufteilen.
(Kapitel 19)

**Doppelklick löst Aktion zweimal aus / Reentrancy.** — `update` im
laufenden Callback. → `update idletasks` zum Neuzeichnen, oder Button
vorher sperren. (Kapitel 19)

**Modaler Dialog kehrt sofort zurück / blockiert nicht.** — Nur `grab set`,
kein Warten. → Zusätzlich `tkwait window $dlg` oder `vwait`. (Kapitel 22)

**Dialog erscheint hinter dem Hauptfenster.** — Keine Transienz. →
`wm transient $dlg .`. (Kapitel 22)

**Dialog öffnet sich mehrfach.** — Kein Guard. → Vor `toplevel` mit
`winfo exists` prüfen und ggf. `raise` + `return`. (Kapitel 22)

## Darstellung

**`ttk::style lookup` liefert leeren String → Fehler.** — Option im Theme
nicht definiert. → Fallback-Kette (TFrame → Toplevel → fester Wert).
(Kapitel 24)

**Schriftgröße muss an vielen Stellen geändert werden.** — Inline-Font-
Specs verstreut. → Benannte Fonts (`font create`/`configure`). (Kapitel 25)

**Canvas-Item landet beim Scrollen am falschen Ort.** — Maus- statt
Canvas-Koordinaten verwendet. → `canvasx`/`canvasy` zur Umrechnung.
(Kapitel 26)

## Daten und Tests

**Treeview-Auswahl liefert kryptische IDs statt Daten.** — Treeview-Item-ID
≠ eigene Daten-ID. → Mapping pflegen (`itemMap`). (Kapitel 28)

**Text ändert sich nach Sprachwechsel nicht.** — Tk speichert `mc`-Ergebnis
als String. → Oberfläche neu aufbauen, Widgets durchgehen oder Neustart.
(Kapitel 32)

**Logik nur per Button-Klick testbar.** — Logik steckt im `-command`. →
Logik ins widgetfreie Modell ziehen, direkt testen. (Kapitel 30, 33)

## Verteilung

**Binär-Erweiterung lädt nicht aus dem Paket.** — `.so`/`.dll` kann nicht
direkt aus dem ZIP/Starkit geladen werden. → Beim Start in eine echte
Datei entpacken. (Kapitel 34)

**Schwarzes Konsolenfenster unter Windows.** — Mit `tclsh` statt `wish`
gestartet. → Für reine GUI-Apps `wish`/`wish90s`. (Kapitel 2, 34)
