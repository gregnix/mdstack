# Eine GUI-Anwendung verteilen

*Stand: 2026-05-29*

## Einführung

Eine fertige Anwendung muss zum Nutzer kommen — idealerweise als eine
Datei, die ohne vorinstalliertes Tcl/Tk startet. Dieses Kapitel gibt den
Überblick: was alles mit ausgeliefert werden muss, das klassische
Starpack/Starkit-Modell, das neuere zipkit unter Tcl 9 und ein paar
Plattform-Eigenheiten beim Start. Es ist bewusst ein Überblick — die
Tiefe des Paketierens füllt ein eigenes Werk.

---

## 34.1 Was mit ausgeliefert werden muss

Eine Tk-Anwendung besteht aus mehr als dem eigenen Code. Zum Lauf
gehören: der Tcl-Interpreter, die Tk-Bibliothek, die Tcl/Tk-Support-
Skripte, alle verwendeten Pakete (tdbc, tablelist, scrollutil … je nach
Anwendung) und die eigenen Dateien (Module, `msgs/`, `assets/`).

Den Nutzer all das einzeln installieren zu lassen ist fehleranfällig.
Deshalb bündelt man es zu **einer** ausführbaren Datei — einem Starpack
(klassisch) oder zipkit (Tcl 9). Beide Verfahren hängen ein Archiv mit
allen Anwendungsdateien an einen Interpreter, sodass eine Datei genügt.

Eine wichtige Einschränkung vorweg, weil sie überrascht: **Binär-
Erweiterungen (`.so`/`.dll`) lassen sich nicht direkt aus dem
eingebetteten Archiv laden.** Das Betriebssystem verlangt für Shared
Libraries eine echte Datei auf dem Dateisystem. Wer C-Erweiterungen nutzt,
muss sie beim Start in ein temporäres Verzeichnis entpacken (Starkits tun
das mit `vfs` automatisch). Reine Tcl-Pakete sind davon nicht betroffen.

---

## 34.2 Starpack / Starkit — der Überblick

Das klassische Modell unterscheidet zwei Stufen:

- **Starkit** (`.kit`) — ein Archiv mit den Anwendungsdateien, das einen
  separaten Interpreter (Tclkit) zum Start braucht.
- **Starpack** — ein Tclkit-Binary *mit* angehängtem Starkit: eine
  eigenständige ausführbare Datei.

Der Aufbau eines Starkits ist ein virtuelles Dateisystem (`.vfs`):

```
myapp.vfs/
├── main.tcl          ← Einstiegspunkt
├── lib/              ← eigene Pakete (mit pkgIndex.tcl)
│   └── myapp/
└── assets/
```

Die `main.tcl` startet die Anwendung; mit dem `starkit`-Paket findet sie
ihre Dateien:

```tcl
# main.tcl im Starkit
package require starkit
starkit::startup           ;# macht den Starkit-Inhalt zugänglich
package require myapp
myapp::main $argv
```

Gebaut wird mit dem Werkzeug `sdx`:

```bash
# Starkit (braucht Tclkit zum Start)
tclkit sdx.kit qwrap myapp.vfs -runtime tclkit-linux64
# Starpack (eigenständig)
tclkit sdx.kit wrap myapp -runtime tclkit-linux64
```

Das `-runtime` bestimmt den eingebetteten Interpreter und damit die
Zielplattform: Für jede Plattform (Linux, Windows, macOS) wrappt man mit
dem passenden Tclkit. Das Verfahren ist über Jahre erprobt und unter
Tcl 8.6 der Standard.

---

## 34.3 zipkit unter Tcl 9

Tcl 9 bringt ein moderneres Modell auf Basis von **zipfs** (einem
eingebetteten ZIP-Dateisystem). Ein **zipkit** ist das Tcl-9-Äquivalent
eines Starpacks: ein statisch gelinkter Interpreter mit angehängtem
ZIP-Archiv. Der entscheidende Mechanismus: Startet Tcl 9 und findet am
Programm ein eingebettetes Archiv mit einer `main.tcl` auf oberster Ebene,
führt es diese automatisch aus. Das Archiv ist unter `//zipfs:/app`
eingehängt.

Erzeugt wird ein zipkit mit `zipfs mkimg`:

```tcl
# Verzeichnisstruktur aufbauen
file delete -force myapp.vfs
file mkdir myapp.vfs
file copy $tcl_library [file join myapp.vfs tcl_library]
file copy $tk_library  [file join myapp.vfs tk_library]     ;# für GUI
file mkdir [file join myapp.vfs lib]
file copy /pfad/zu/meinpaket [file join myapp.vfs lib meinpaket]

# main.tcl als Einstiegspunkt
set f [open [file join myapp.vfs main.tcl] w]
puts $f {
    lappend auto_path //zipfs:/app/lib
    package require meinpaket
    meinpaket::main
}
close $f

# zipkit erzeugen (letzter Parameter: statischer Interpreter)
zipfs mkimg myapp.exe myapp.vfs myapp.vfs "" /pfad/zu/wish90s.exe
```

Statische Interpreter (`tclsh90s`/`wish90s`) für die jeweilige Plattform
bekommt man etwa von Magicsplat oder BAWT. Ein Unterschied zu Tcl-8.6-
Tclkits: zipkits werten weiterhin Umgebungsvariablen wie `TCLLIBPATH`
aus — wer das nicht will, setzt `auto_path` in der `main.tcl` explizit.

Wer Code schreiben will, der **sowohl** als klassischer Starkit als auch
als zipkit läuft, braucht eine kleine Erkennungsschicht, weil der
Basispfad der Anwendungsdateien unterschiedlich ist (`$starkit::topdir`
gegen `//zipfs:/app`):

```tcl
proc appTopDir {} {
    if {[info exists ::starkit::topdir]} {return $::starkit::topdir}
    if {[lsearch -exact [zipfs mount] "//zipfs:/app"] >= 0} {
        return "//zipfs:/app"
    }
    return [file dirname [info script]]    ;# ungepackt: das Skriptverzeichnis
}
set icon [file join [appTopDir] assets icon.png]
```

So findet die Anwendung ihre Ressourcen unabhängig davon, wie sie verpackt
wurde.

---

## 34.4 Plattform-Eigenheiten beim Start

Drei Punkte tauchen bei fast jeder Auslieferung auf.

**Konsolenfenster unter Windows.** Ein mit `tclsh`/`tclsh90s` gestartetes
Programm zeigt unter Windows eine Konsole, `wish`/`wish90s` nicht. Für
eine reine GUI-Anwendung wählt man den `wish`-Interpreter, damit kein
schwarzes Fenster mit aufgeht (Kapitel 2).

**Pro Plattform ein Build.** Sowohl Starpack als auch zipkit betten einen
plattformspezifischen Interpreter ein. Es gibt kein einzelnes Binary für
alle Systeme — man baut je eine Datei für Linux, Windows und macOS, jeweils
mit dem passenden Interpreter. Der Anwendungscode bleibt identisch.

**Ressourcen-Pfade.** Innerhalb eines Paketes liegen Dateien nicht im
normalen Dateisystem, sondern im eingebetteten Archiv. Pfade baut man
deshalb relativ zum Anwendungs-Topdir (Abschnitt 30.3) und nie absolut.
Bilder, Kataloge und Module liest Tk aus dem Archiv problemlos; nur Binär-
Erweiterungen brauchen den Umweg über eine echte Datei (Abschnitt 30.1).

Für die meisten Tk-Anwendungen ist unter Tcl 9 der zipkit-Weg der
geradlinigste, unter Tcl 8.6 der bewährte Starpack-Weg. Beide liefern, was
zählt: eine Datei, die der Nutzer startet, ohne vorher etwas zu
installieren.

---

## Zusammenfassung

- Auszuliefern sind Interpreter, Tk, Support-Skripte, alle Pakete und die
  eigenen Dateien — gebündelt zu einer ausführbaren Datei. Binär-
  Erweiterungen müssen beim Start in eine echte Datei entpackt werden.
- Klassisch: Starkit (Archiv) bzw. Starpack (Archiv + Interpreter), gebaut
  mit `sdx`, je Plattform mit passendem `-runtime`.
- Tcl 9: zipkit über `zipfs mkimg`, `main.tcl` unter `//zipfs:/app` wird
  automatisch ausgeführt; Erkennungsschicht für portablen Code.
- Plattform: `wish` gegen Konsole unter Windows, ein Build je Plattform,
  Ressourcen-Pfade relativ zum Anwendungs-Topdir.

Das letzte Kapitel führt alles zusammen — eine vollständige kleine
Anwendung von der Skizze bis zum Schliff.
