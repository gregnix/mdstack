#!/usr/bin/env tclsh
# migrate-to-bookkit.tcl -- Teilordner aufloesen, bookkit-Dateinamen (NNN-*.md)
#
#   tclsh migrate-to-bookkit.tcl          # Vorschau
#   tclsh migrate-to-bookkit.tcl -apply
#
# Danach (aus 00Books/):
#   tclsh bookkit/tools/book-build.tcl TclTk-Benutzeroberflaechen/ -number

set apply 0
if {[lindex $argv 0] eq "-apply"} { set apply 1 }

set bookdir [file dirname [file normalize [info script]]]
cd $bookdir

# Lesereihenfolge laut INHALTSVERZEICHNIS (Kap. 1-38, dann Anhaenge A-F)
set moves {
    VORWORT.md                                              000-vorwort.md
    100-grundlagen/kapitel-01-mentales-modell.md            010-mentales-modell.md
    100-grundlagen/kapitel-02-erstes-fenster.md             020-erstes-fenster.md
    100-grundlagen/kapitel-03-widgets-erzeugen.md           030-widgets-erzeugen.md
    100-grundlagen/kapitel-04-classic-vs-ttk.md             040-classic-vs-ttk.md
    150-gui-grundsaetze/kapitel-05-gute-gui-grundsaetze.md  050-gute-gui-grundsaetze.md
    200-layout/kapitel-06-geometry-modell.md                060-geometry-modell.md
    200-layout/kapitel-07-pack.md                           070-pack.md
    200-layout/kapitel-08-grid.md                             080-grid.md
    200-layout/kapitel-09-place.md                          090-place.md
    200-layout/kapitel-10-layout-patterns.md                100-layout-patterns.md
    200-layout/kapitel-11-responsive-layout.md              110-responsive-layout.md
    200-layout/kapitel-12-desktop-patterns.md               120-desktop-patterns.md
    300-kern-widgets/kapitel-13-label-anzeige.md            130-label-anzeige.md
    300-kern-widgets/kapitel-14-eingabe-validierung.md      140-eingabe-validierung.md
    300-kern-widgets/kapitel-15-auswahl.md                  150-auswahl.md
    300-kern-widgets/kapitel-16-text-widget.md              160-text-widget.md
    300-kern-widgets/kapitel-17-buttons-aktionen.md         170-buttons-aktionen.md
    300-kern-widgets/kapitel-18-container.md                180-container.md
    400-interaktion/kapitel-19-event-loop.md                190-event-loop.md
    400-interaktion/kapitel-20-bindings.md                  200-bindings.md
    400-interaktion/kapitel-21-menues.md                    210-menues.md
    400-interaktion/kapitel-22-dialoge-toplevels.md         220-dialoge-toplevels.md
    400-interaktion/kapitel-23-fokus-tastatur.md            230-fokus-tastatur.md
    500-darstellung/kapitel-24-ttk-theming.md               240-ttk-theming.md
    500-darstellung/kapitel-25-schrift-farbe-bild.md          250-schrift-farbe-bild.md
    500-darstellung/kapitel-26-canvas.md                    260-canvas.md
    500-darstellung/kapitel-27-ttk-style-vertiefung.md      270-ttk-style-vertiefung.md
    600-daten-in-der-ui/kapitel-28-treeview.md              280-treeview.md
    600-daten-in-der-ui/kapitel-29-variablen-bindung.md     290-variablen-bindung.md
    600-daten-in-der-ui/kapitel-30-ui-und-logik.md          300-ui-und-logik.md
    700-praxis/kapitel-31-anwendung-strukturieren.md        310-anwendung-strukturieren.md
    700-praxis/kapitel-32-i18n.md                           320-i18n.md
    700-praxis/kapitel-33-gui-testen.md                     330-gui-testen.md
    700-praxis/kapitel-34-verteilen.md                      340-verteilen.md
    700-praxis/kapitel-35-fallstudie.md                     350-fallstudie.md
    550-gui-design/kapitel-36-visuelle-hierarchie.md        360-visuelle-hierarchie.md
    550-gui-design/kapitel-37-human-interface-guidelines.md 370-human-interface-guidelines.md
    550-gui-design/kapitel-38-designsystem-tcltk.md         380-designsystem-tcltk.md
    900-anhaenge/anhang-a-widget-uebersicht.md              800-anhang-widget-uebersicht.md
    900-anhaenge/anhang-b-glossar.md                        810-anhang-glossar.md
    900-anhaenge/anhang-c-fehler.md                         820-anhang-fehler.md
    900-anhaenge/anhang-d-checkliste.md                     830-anhang-checkliste.md
    900-anhaenge/anhang-e-designsystem.md                   840-anhang-designsystem.md
    900-anhaenge/anhang-f-layout-referenz.md                850-anhang-layout-referenz.md
}

set emptyDirs {
    100-grundlagen 150-gui-grundsaetze 200-layout 300-kern-widgets
    400-interaktion 500-darstellung 600-daten-in-der-ui 700-praxis
    550-gui-design 900-anhaenge
}

proc doMove {src dst apply} {
    global bookdir
    set from [file join $bookdir $src]
    set to   [file join $bookdir $dst]
    if {[file exists $to]} {
        puts "  SKIP (Ziel existiert): $dst"
        return
    }
    if {![file exists $from]} {
        if {[file exists $to]} {
            puts "  OK (bereits migriert): $dst"
        } else {
            puts "  FEHLT: $src"
        }
        return
    }
    if {!$apply} {
        puts "  mv $src -> $dst"
        return
    }
    file rename $from $to
    puts "  OK $dst"
}

puts [expr {$apply ? "Migration (apply):" : "Vorschau (dry-run):"}]
foreach {src dst} $moves { doMove $src $dst $apply }

if {$apply} {
    foreach d $emptyDirs {
        set p [file join $bookdir $d]
        if {[file isdirectory $p]} {
            set left [glob -nocomplain -directory $p *]
            if {[llength $left] == 0} {
                file delete $p
                puts "  rmdir $d"
            } else {
                puts "  WARN $d nicht leer: $left"
            }
        }
    }
    puts "\nFertig. Naechster Schritt:"
    puts "  cd [file dirname $bookdir]"
    puts "  tclsh bookkit/tools/book-build.tcl [file tail $bookdir]/ -number"
} else {
    puts "\nZum Ausfuehren: tclsh migrate-to-bookkit.tcl -apply"
}
