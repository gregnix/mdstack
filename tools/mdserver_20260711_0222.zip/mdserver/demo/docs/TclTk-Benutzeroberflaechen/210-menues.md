# Menüs

*Stand: 2026-05-29*

## Einführung

Menüs sind in Tk classic-Widgets (kein Ttk-Pendant, Kapitel 4) und folgen
einem eigenen, etwas altertümlichen Modell: ein `menu`-Widget, das
Einträge per Unterbefehl bekommt, und eine Menüleiste, die man dem
Toplevel zuweist. Dieses Kapitel zeigt die Menüleiste, die vier
Eintragstypen, das Kontextmenü per Rechtsklick und den Umgang mit
Beschleunigern samt Plattform-Unterschieden.

---

## 21.1 Menüleiste am Toplevel

Eine Menüleiste ist ein `menu`-Widget, das man einem Toplevel über dessen
`-menu`-Option zuweist. Die einzelnen Menüs (Datei, Bearbeiten …) sind
wiederum `menu`-Widgets, die als Cascade-Einträge eingehängt werden:

```tcl
# die Leiste selbst
menu .menubar
. configure -menu .menubar          ;# der Hauptfenster-Leiste zuweisen

# ein "Datei"-Menü als Untermenü der Leiste
menu .menubar.file -tearoff 0
.menubar add cascade -label "Datei" -menu .menubar.file -underline 0

# Einträge im Datei-Menü
.menubar.file add command -label "Neu"   -command action::new -accelerator "Ctrl+N"
.menubar.file add command -label "Öffnen" -command action::open -accelerator "Ctrl+O"
.menubar.file add separator
.menubar.file add command -label "Beenden" -command {destroy .}
```

Zwei Konventionen lohnen sich. `-tearoff 0` schaltet die abreißbare
gestrichelte Linie ab, die heute kaum jemand erwartet — ohne sie wirkt
das Menü altmodisch. `-underline 0` unterstreicht den ersten Buchstaben
als Mnemonic (Alt+D für „Datei"), was zur Tastaturbedienung gehört
(Kapitel 23).

---

## 21.2 Kommando-, Cascade-, Check- und Radio-Einträge

Ein Menü kennt vier Eintragstypen, alle über `add`:

```tcl
# command -- führt einen Befehl aus
.m add command -label "Speichern" -command action::save

# cascade -- öffnet ein Untermenü
menu .m.export -tearoff 0
.m add cascade -label "Exportieren" -menu .m.export
.m.export add command -label "Als PDF" -command {export pdf}

# checkbutton -- schaltet eine Variable um (Häkchen im Menü)
.m add checkbutton -label "Zeilennummern" -variable ::showLines

# radiobutton -- eine aus mehreren Optionen
.m add radiobutton -label "Hell"  -variable ::theme -value light
.m add radiobutton -label "Dunkel" -variable ::theme -value dark
```

`checkbutton`- und `radiobutton`-Einträge nutzen dieselbe
`-variable`-Kopplung wie die gleichnamigen Widgets (Kapitel 15): Das
Häkchen bzw. der Punkt im Menü spiegelt den Variablenwert, und die
Variable lässt sich auch von außen setzen — das Menü zieht mit. So
braucht man keinen separaten Code, um den Menüzustand zu synchronisieren.

Einträge lassen sich nachträglich ändern und sperren — angesprochen über
ihren Index oder ihr Label:

```tcl
.m entryconfigure "Speichern" -state disabled   ;# Eintrag sperren
.m entryconfigure "Speichern" -state normal      ;# wieder freigeben
```

---

## 21.3 Kontextmenü per Rechtsklick

Ein Kontextmenü ist ein gewöhnliches `menu`-Widget, das man nicht in eine
Leiste hängt, sondern auf Rechtsklick an der Mausposition aufpoppt —
mit `tk_popup`:

```tcl
menu .ctx -tearoff 0
.ctx add command -label "Ausschneiden" -command schneiden
.ctx add command -label "Kopieren"     -command kopieren
.ctx add command -label "Einfügen"     -command einfuegen

# Rechtsklick -- an Bildschirmkoordinaten %X,%Y aufpoppen
bind .editor <Button-3> {tk_popup .ctx %X %Y}
```

Wichtig sind die **großen** Koordinaten `%X %Y` (relativ zum Bildschirm,
Kapitel 20), nicht die kleinen `%x %y` (relativ zum Widget) — `tk_popup`
erwartet Bildschirmkoordinaten. Auf manchen Plattformen ist die rechte
Maustaste `<Button-3>`, unter macOS zusätzlich `<Button-2>` oder
Control-Klick; wer portabel sein will, bindet mehrere oder nutzt ein
virtuelles Event (Kapitel 20).

---

## 21.4 Beschleuniger und Plattform-Unterschiede

Hier wiederholt sich der Punkt aus Kapitel 17, weil er hier am häufigsten
auftritt: `-accelerator` ist **nur Beschriftung**. Es zeigt „Ctrl+S"
rechts im Menü an, aber es löst nichts aus. Die Wirkung kommt allein vom
`bind`:

```tcl
.menubar.file add command -label "Speichern" -accelerator "Ctrl+S" \
    -command action::save
bind . <Control-s> {action::save}     ;# erst das macht das Kürzel wirksam
```

Vergisst man das `bind`, steht das Kürzel im Menü, tut aber nichts — eine
der häufigsten kleinen Lücken in Tk-Oberflächen.

Bei den Plattform-Unterschieden ist der Modifizierer der Knackpunkt: Was
unter Linux und Windows `Control` ist, ist unter macOS `Command`. Statt
beide überall doppelt zu binden, definiert man ein virtuelles Event
einmal plattformneutral (Kapitel 20):

```tcl
event add <<Save>> <Control-s> <Command-s>
bind . <<Save>> {action::save}
.menubar.file add command -label "Speichern" -command action::save \
    -accelerator [expr {[tk windowingsystem] eq "aqua" ? "Cmd+S" : "Ctrl+S"}]
```

`tk windowingsystem` liefert `aqua` (macOS), `win32` (Windows) oder `x11`
(Linux/Unix) — so passt man die *Beschriftung* an, während das virtuelle
Event die *Funktion* plattformneutral hält. Auf macOS gehören zudem
bestimmte Menüs an besondere Plätze (das Anwendungsmenü, das Hilfe-Menü);
das ist eine Feinheit für portable Anwendungen und über spezielle
Menünamen wie `.menubar.apple` und `.menubar.help` lösbar.

---

## Zusammenfassung

- Eine Menüleiste ist ein `menu`-Widget, dem Toplevel über `-menu`
  zugewiesen; einzelne Menüs hängt man als `cascade` ein. `-tearoff 0`
  abschalten.
- Vier Eintragstypen: `command`, `cascade`, `checkbutton`, `radiobutton`;
  Check/Radio koppeln über `-variable` wie die Widgets.
  `entryconfigure` ändert/sperrt Einträge.
- Kontextmenü per `tk_popup .ctx %X %Y` auf `<Button-3>` — Bildschirm-
  koordinaten, nicht Widget-Koordinaten.
- `-accelerator` ist nur Anzeige; die Funktion macht das `bind`.
  Plattformneutral über virtuelle Events und `tk windowingsystem` für die
  Beschriftung.

Vom Menü, das oft Dialoge öffnet, führt der Weg direkt zum nächsten
Kapitel: Dialoge und eigene Fenster.
