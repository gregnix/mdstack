# Fokus, Tastatur, Bedienbarkeit

*Stand: 2026-05-29*

## Einführung

Eine Oberfläche, die nur mit der Maus bedienbar ist, ist halb fertig.
Tastaturbedienung ist nicht nur Komfort für Vielnutzer, sondern auch eine
Frage der Zugänglichkeit. Dieses Kapitel behandelt den Fokus — welches
Widget Tastatureingaben bekommt — die übliche Tastatur-Navigation und
Mnemonics, und schließt mit der Bedienung-ohne-Maus als praktischem
Prüfstein für die ganze Oberfläche.

---

## 23.1 Fokus-Reihenfolge und `-takefocus`

Genau ein Widget hat zu jeder Zeit den **Tastaturfokus**; seine Eingaben
landen dort. Den Fokus setzt man programmgesteuert mit `focus`:

```tcl
focus .form.name          ;# Tastatureingaben gehen jetzt an dieses Entry
focus -force .dlg.ok      ;# Fokus erzwingen (z.B. beim Öffnen eines Dialogs)
```

Mit `<Tab>` wandert der Fokus von Widget zu Widget. Die **Reihenfolge**
ergibt sich aus der Erzeugungs- bzw. Stapelreihenfolge im Widget-Baum —
nicht aus der Bildschirmposition. Wer Widgets in einer anderen Reihenfolge
erzeugt, als sie gelesen werden sollen, bekommt eine verwirrende
Tab-Reihenfolge. Die saubere Lösung ist, Widgets in der logischen
Reihenfolge zu erzeugen; notfalls ordnet `raise`/`lower` die
Stapelreihenfolge um.

Welche Widgets der Fokus überhaupt anspringt, steuert `-takefocus`:

```tcl
ttk::entry  .e                       ;# nimmt Fokus (Default für Eingabe)
ttk::label  .l -text "nur Anzeige"   ;# nimmt normalerweise keinen Fokus
ttk::frame  .f -takefocus 0          ;# explizit überspringen
ttk::button .b -takefocus 1          ;# explizit einbeziehen
```

Eingabe-Widgets nehmen den Fokus standardmäßig, reine Anzeige-Widgets
nicht. `-takefocus 0` nimmt ein Widget bewusst aus der Tab-Kette; das
braucht man selten, aber es ist der richtige Schalter, wenn ein Container
fälschlich Fokus zieht.

---

## 23.2 `<Tab>`, `<Return>`, Default-Button

Drei Tastatur-Konventionen erwartet jeder Nutzer, und sie kosten wenig:

**`<Tab>` weiter, `<Shift-Tab>` zurück** — das macht Tk von selbst,
solange die Erzeugungsreihenfolge stimmt (Abschnitt 20.1). Hier ist meist
nichts zu tun außer der richtigen Reihenfolge.

**`<Return>` löst den Default-Button aus.** In einem Dialog soll Enter das
Naheliegende tun (meist OK). Das verbindet man explizit (Kapitel 17):

```tcl
ttk::button .dlg.ok -text "OK" -default active -command {set ::result ok}
bind .dlg <Return> {.dlg.ok invoke}
bind .dlg <Escape> {.dlg.cancel invoke}
```

`-default active` hebt den Button optisch hervor, das `bind` macht Enter
wirksam. `<Escape>` auf den Abbrechen-Button gehört zum selben Muster —
zusammen erlauben sie, einen Dialog komplett ohne Maus zu bedienen.

**Fokus beim Öffnen setzen.** Ein Dialog, der den Fokus nicht ins erste
Feld setzt, zwingt zum Mausklick:

```tcl
focus .dlg.e      ;# direkt ins erste Eingabefeld
```

---

## 23.3 Mnemonics und `-underline`

Ein Mnemonic ist der unterstrichene Buchstabe, der zusammen mit `Alt` ein
Element aktiviert — bei Menüs (Kapitel 21) und Buttons. `-underline` gibt
den Index des zu unterstreichenden Zeichens an:

```tcl
ttk::button .save -text "Speichern" -underline 0 -command action::save
# unterstreicht das "S"; Alt+S soll den Button auslösen
```

`-underline` zeichnet die Unterstreichung — die *Wirkung* (Alt+S löst aus)
muss bei Buttons über ein Binding ergänzt werden, ähnlich dem
Accelerator-Muster:

```tcl
bind . <Alt-s> {.save invoke}
```

Bei Menüeinträgen (`-underline`) ist die Alt-Navigation dagegen
eingebaut — dort genügt das `-underline`. Wichtig ist Konsistenz: keine
zwei Elemente mit demselben Mnemonic, sonst wird die Zuordnung
mehrdeutig.

---

## 23.4 Bedienbarkeit ohne Maus als Prüfstein

Der einfachste Test, ob eine Oberfläche tastaturbedienbar ist: die Maus
weglegen und versuchen, jede Funktion zu erreichen. Eine kurze Checkliste,
die die Punkte dieses Kapitels bündelt:

1. **Kommt der Fokus überall hin?** Mit `<Tab>` jede Eingabe, jeden
   Button durchlaufen — ohne Sackgasse, ohne übersprungenes Feld.
2. **Stimmt die Tab-Reihenfolge?** Folgt sie der Lese-Reihenfolge? Wenn
   nicht, ist die Erzeugungsreihenfolge schuld (20.1).
3. **Tut `<Return>` das Erwartete?** In Dialogen OK, in Formularen das
   Abschicken — über Default-Button und `bind`.
4. **Bricht `<Escape>` ab?** In jedem Dialog auf Abbrechen gebunden.
5. **Haben Menüs und wichtige Buttons Mnemonics?** Und sind sie
   eindeutig?
6. **Funktionieren die Beschleuniger wirklich?** `-accelerator` ist nur
   Anzeige; das `bind` muss da sein (Kapitel 17, 21).

Diese sechs Fragen kosten wenige Minuten und heben die Bedienqualität
spürbar. Sie sind auch der Grund, warum Tastatur kein nachträglicher
Aufsatz sein sollte: Wer Fokus-Reihenfolge und Default-Buttons von Anfang
an mitdenkt, bekommt Zugänglichkeit fast geschenkt — wer sie nachrüstet,
kämpft mit verdrehten Tab-Ketten.

---

## Zusammenfassung

- Ein Widget hat den Fokus; `focus`/`focus -force` setzt ihn,
  `-takefocus` steuert, ob ein Widget in die Tab-Kette gehört.
- Die Tab-Reihenfolge folgt der Erzeugungs-/Stapelreihenfolge, nicht der
  Bildschirmposition — Widgets in logischer Reihenfolge erzeugen.
- `<Return>` an den Default-Button (`-default active` + `bind`),
  `<Escape>` an Abbrechen; Fokus beim Öffnen ins erste Feld.
- Mnemonics über `-underline` (bei Buttons mit `Alt`-`bind` ergänzen);
  eindeutig halten.
- Der Maus-weglegen-Test mit der Sechs-Punkte-Liste prüft die
  Tastaturbedienbarkeit schnell und zuverlässig.

Damit ist Teil 4 abgeschlossen — die Oberfläche reagiert nun auf Maus und
Tastatur. Teil 5 wendet sich ihrem Aussehen zu: Theming, Schrift, Farbe,
Bild und der Canvas.
