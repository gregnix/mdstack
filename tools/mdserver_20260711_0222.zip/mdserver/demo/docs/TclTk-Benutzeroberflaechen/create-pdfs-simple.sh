#!/bin/bash
# create-pdfs-simple.sh - Einfache PDF-Erstellung (ohne Syntax-Highlighting)
# Benoetigt: pandoc, xelatex (texlive-xetex)

echo "=== PDF-Erstellung (einfach) ==="
echo ""

PANDOC_OPTS="--pdf-engine=xelatex \
    -V documentclass=scrartcl \
    -V papersize=a4 \
    -V lang=de \
    -V geometry=margin=2.5cm \
    -V colorlinks=true \
    -V linkcolor=blue \
    -V fontsize=11pt \
    --listings \
    --toc \
    --number-sections"

create_pdf() {
    local name=$1
    shift
    local files="$@"
    echo -n "Erstelle ${name}.pdf... "
    if pandoc $files -o "${name}.pdf" $PANDOC_OPTS 2>/dev/null; then
        echo "OK"
    else
        echo "FEHLER"
    fi
}

create_pdf "teil1-grundlagen"      100-grundlagen/*.md
create_pdf "teil2-layout"          200-layout/*.md
create_pdf "teil3-kern-widgets"    300-kern-widgets/*.md
create_pdf "teil4-interaktion"     400-interaktion/*.md
create_pdf "teil5-darstellung"     500-darstellung/*.md
create_pdf "teil6-daten-in-der-ui" 600-daten-in-der-ui/*.md
create_pdf "teil7-praxis"          700-praxis/*.md
create_pdf "anhaenge"              900-anhaenge/*.md

echo ""
echo -n "Erstelle tk-gui-komplett.pdf... "
ALL_FILES=$(find 100-* 200-* 300-* 400-* 500-* 600-* 700-* 900-* -name "*.md" 2>/dev/null | sort)
if pandoc VORWORT.md $ALL_FILES -o "tk-gui-komplett.pdf" $PANDOC_OPTS 2>/dev/null; then
    echo "OK"
else
    echo "FEHLER"
fi

echo ""
echo "=== Ergebnis ==="
ls -lh *.pdf 2>/dev/null || echo "Keine PDFs erstellt"
