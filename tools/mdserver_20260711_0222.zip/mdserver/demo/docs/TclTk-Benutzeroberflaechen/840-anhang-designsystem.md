# Designsystem — Kurzreferenz

*Stand: 2026-06-16*
*Volltext:* [Kapitel 34](../550-gui-design/kapitel-38-designsystem-tcltk.md)  

Einseitige **Nachschlagetabelle** — beim Entwerfen neuer Dialoge und
Fenster griffbereit. Details und Begründungen in Kapitel 38.

---

## E.1 Abstände (Padding)

| Token | px | Typische Verwendung |
|-------|-----|---------------------|
| xs | 4 | Icon innen |
| sm | 8 | Frame, Toolbar |
| md | 12 | Formular-Rand, Button |
| lg | 16 | Zwischen Sektionen |

---

## E.2 Typografie

| Rolle | Größe | Style |
|-------|-------|-------|
| Body | 11 pt | `configure . -font` |
| Überschrift | 14 pt bold | `Header.TLabel` |
| Hinweis | 9 pt, muted | `Hint.TLabel` |

Font: `DejaVu Sans` oder System-Äquivalent (Kap. 25).

---

## E.3 Farben (hell, Beispiel)

| Rolle | Hex | Style |
|-------|-----|-------|
| Primär | `#2563eb` | `Primary.TButton` |
| Gefahr | `#dc2626` | `Danger.TButton` |
| Text muted | `#6b7280` | `Hint.TLabel` |
| Hintergrund | `#f5f5f5` | `TFrame` |

Nur **eine** Primärfarbe pro Ansicht. Rot = Zerstörung/Fehler.

---

## E.4 Buttons

| Typ | Style | Regel |
|-----|-------|-------|
| Hauptaktion | `Primary.TButton` | max. 1 pro Dialog |
| Standard | `TButton` | — |
| Abbrechen | `TButton` | rechts, ohne Primary |
| Löschen | `Danger.TButton` | Abstand zu OK |

Mindestbreite ~80 px oder `padding {12 6}`.

---

## E.5 Formular-Grid

```
column 0: Label, sticky e, minsize 100
column 1: Control, sticky ew, weight 1
pady 4 pro Zeile
```

---

## E.6 Fenster-Gerüst (pack)

```
toolbar  → top, fill x
status   → bottom, fill x
body     → fill both, expand 1
```

Inhalt von `body`: meist `grid` oder `panedwindow` / `notebook`.

---

## E.7 Container-Wahl

| Bedarf | Widget |
|--------|--------|
| Reiter | `ttk::notebook` |
| Größe ziehbar | `ttk::panedwindow` |
| Benannte Gruppe | `ttk::labelframe` |
| Neutral | `ttk::frame` |

---

## E.8 Startup

```tcl
package require ui::theme
::ui::theme::init    ;# vor app::view::build
```

---

## E.9 Checkliste (Kurz)

- [ ] Tokens statt Ad-hoc-Pixel
- [ ] Eine Primary-Aktion?
- [ ] Formular 2-Spalten-Grid?
- [ ] `wm minsize` gesetzt?
- [ ] Statuszeile für Systemzustand?
- [ ] Kap. 5 + Anhang D durchgegangen?
