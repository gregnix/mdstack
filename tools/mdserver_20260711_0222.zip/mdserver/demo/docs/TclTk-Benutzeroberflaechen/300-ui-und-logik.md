# UI und Logik trennen

*Stand: 2026-05-29*

## Einführung

Tk erzwingt keine Trennung von Anzeige und Logik (Kapitel 1) — und genau
deshalb verrutscht sie so leicht. Ein `-command`, der „schnell" eine
Datei schreibt; ein Binding, das nebenbei rechnet; ein Widget, das seinen
Wert direkt in die Datenbank schreibt. Jede dieser Abkürzungen wirkt
harmlos und summiert sich zu einer Oberfläche, in der Darstellung und
Geschäftslogik untrennbar verwoben sind. Dieses Kapitel zeigt, wie man das
mit Tk-Bordmitteln vermeidet — ein schlankes MVC, Observer über virtuelle
Events, und das Prinzip dahinter.

---

## 30.1 Warum Trennung in Tk besonders leicht verrutscht

In strenger objektorientierten Toolkits liegt zwischen Widget und Logik
oft schon eine Schicht. In Tk ist der direkte Weg immer der kürzeste: Der
`-command` eines Buttons *kann* die ganze Anwendung enthalten, das
Binding *kann* direkt in die Daten schreiben. Nichts hindert daran — und
das ist die Falle.

Die Folgen zeigen sich später: Eine Logik, die in einem `-command`-Skript
steckt, lässt sich nicht testen, ohne den Button zu klicken. Eine
Berechnung in einem Binding lässt sich nicht wiederverwenden. Eine
Anwendung, in der zehn Widgets direkt auf die Daten zugreifen, lässt sich
nicht umbauen, ohne zehn Stellen anzufassen. Die Trennung ist also keine
akademische Sauberkeit, sondern die Voraussetzung für Test- und
Wartbarkeit.

---

## 30.2 Ein schlankes MVC für Tk

Das Grundmuster trennt drei Rollen, ohne ein schweres Framework:

- **Modell** — die Daten und die Operationen darauf. Kennt keine Widgets.
- **View** — die Widgets. Kennt das Modell nur lesend, enthält keine
  Logik.
- **Controller** — verbindet beides: reagiert auf Ereignisse, ruft
  Modell-Operationen, aktualisiert die View.

Mit Namespaces (Kapitel 31) bildet man die drei Rollen sauber ab:

```tcl
namespace eval model {
    variable records {}
    proc add {satz}  {variable records; lappend records $satz; notify}
    proc all {}      {variable records; return $records}
    proc notify {}   {event generate . <<ModelChanged>>}   ;# meldet Änderung
}

namespace eval view {
    proc build {parent} {
        ttk::treeview $parent.tv -columns {name} -show headings
        $parent.tv heading name -text "Name"
        pack $parent.tv -fill both -expand 1
        bind . <<ModelChanged>> {view::refresh}     ;# auf Modell hören
    }
    proc refresh {} {
        .tv delete [.tv children {}]
        foreach satz [model::all] {                  ;# Modell nur LESEN
            .tv insert {} end -values [list [dict get $satz name]]
        }
    }
}

namespace eval controller {
    proc onAdd {} {                                  ;# Ereignis -> Logik
        model::add [dict create name $::form(name)]
        set ::form(name) ""
    }
}
```

Der entscheidende Punkt: Die View **liest** das Modell und **hört** auf
seine Änderungsmeldung, aber sie ruft keine ändernden Operationen auf —
das tut der Controller. Das Modell kennt keine Widgets; es meldet nur „ich
habe mich geändert" und überlässt es der View, sich neu zu zeichnen.

---

## 30.3 Observer über virtuelle Events

Wie meldet das Modell seine Änderung, ohne die View zu kennen? Über ein
**virtuelles Event** (Kapitel 20) — Tks eingebauter Observer-Mechanismus.
Das Modell *sendet*, beliebig viele Views *hören*:

```tcl
# Sender (Modell) -- kennt keine Empfänger
event generate . <<ModelChanged>>

# Empfänger (beliebig viele Views) -- kennen keinen Sender
bind . <<ModelChanged>> {hauptView::refresh}
bind . <<ModelChanged>> {+statusleiste::refresh}    ;# "+" hängt an, ersetzt nicht
```

Das `+` vor dem Skript ist hier wichtig: Es *ergänzt* ein weiteres
Binding, statt das vorhandene zu ersetzen — so können mehrere Views
unabhängig auf dasselbe Event hören. Damit ist die Kopplung lose: Eine
neue Ansicht bindet sich selbst ein, ohne dass das Modell geändert werden
muss. Das ist das Observer-Muster mit reinen Bordmitteln, ohne eigene
Observer-Liste, ohne Callback-Registry.

Für Ereignisse mit Nutzdaten kann man Detail-Informationen über das Event
mitgeben oder — pragmatischer — die geänderten Daten im Modell ablegen und
die View sie beim Refresh abholen lassen. Letzteres ist meist klarer: Das
Event sagt nur „es hat sich etwas geändert", die View fragt das Modell,
*was*.

---

## 30.4 Testbarkeit als Nebenprodukt

Die Trennung zahlt sich beim Testen aus. Liegt die Logik im Modell und ist
sie von Widgets unabhängig, lässt sie sich ohne laufende Oberfläche prüfen
(Kapitel 33):

```tcl
# Test ganz ohne GUI -- das Modell kennt keine Widgets
model::add [dict create name "Test"]
assert {[llength [model::all]] == 1}
```

Hätte der Hinzufügen-Code im `-command` des Buttons gesteckt, wäre dieser
Test nur über einen synthetischen Klick möglich gewesen. So aber ist die
Logik direkt aufrufbar.

Das verallgemeinert sich zu einem Prinzip, das man als Leitsatz mitnehmen
kann:

> **Die Oberfläche ist eine Projektion des Zustands; jede
> Benutzerinteraktion ist eine benannte Aktion.**

Daraus folgen drei Regeln, die das ganze Kapitel zusammenfassen:

1. **Widgets enthalten keine Geschäftslogik.** Ein `-command` ruft eine
   benannte Aktion auf, er *ist* nicht die Aktion (Kapitel 17).
2. **Aktionen sind benannt und zentral.** Sie liegen an einer Stelle und
   werden von Button, Menü und Tastatur gleichermaßen aufgerufen.
3. **Der Zustand ist beobachtbar.** Änderungen melden sich (über virtuelle
   Events oder Traces), und die Anzeige reagiert darauf, statt aktiv
   nachgezogen zu werden.

Wer diese drei Regeln befolgt, bekommt die Trennung fast geschenkt — und
mit ihr Testbarkeit, Wiederverwendbarkeit und die Freiheit, die
Oberfläche umzubauen, ohne die Logik anzufassen. Für größere Anwendungen
lohnt es, dieses Muster in eine kleine wiederverwendbare Schicht zu gießen
(eine Aktions-Registry, ein beobachtbarer Zustands-Container); für
kleinere reichen die hier gezeigten Bordmittel — Namespaces als Schichten,
virtuelle Events als Observer, benannte Prozeduren als Aktionen.

---

## Zusammenfassung

- Tk erzwingt keine Trennung; gerade deshalb diszipliniert man sich
  selbst, sonst verweben sich Anzeige und Logik unentwirrbar.
- Schlankes MVC mit Namespaces: Modell (kennt keine Widgets), View (liest
  das Modell, hört auf Änderungen), Controller (verbindet, mutiert).
- Observer über virtuelle Events: Modell sendet `event generate`, Views
  hören mit `bind` (`+` zum Anhängen) — lose Kopplung mit Bordmitteln.
- Logik im Modell ist ohne GUI testbar. Leitsatz: UI ist Projektion des
  Zustands, Interaktion ist benannte Aktion; Widgets ohne Logik, Aktionen
  zentral, Zustand beobachtbar.

Damit ist Teil 6 abgeschlossen — die Oberfläche zeigt Daten und bleibt von
der Logik getrennt. Teil 7 führt alles zur Praxis: eine Anwendung
strukturieren, internationalisieren, testen, verteilen und in einer
Fallstudie zusammenführen.
