# [grid]{.index} — die Tabelle

*Stand: 2026-05-29*

## Einführung

`grid` ordnet Widgets in einem Raster aus Zeilen und Spalten an. Für
Formulare — Beschriftung links, Eingabefeld rechts, untereinander — ist
es der natürliche Manager und in der Praxis der meistgenutzte. Dieses
Kapitel zeigt das Raster, die Ausrichtung mit `-sticky`, das
Zusammenspannen von Zellen und die eine Zeile Code, ohne die kein
`grid`-Layout mitwächst: `grid columnconfigure … -weight`.

---

## 8.1 Zeilen und Spalten, `-sticky`

Man platziert ein Widget über Zeile und Spalte:

```tcl
ttk::label .l1 -text "Name:"
ttk::entry .e1
ttk::label .l2 -text "Stadt:"
ttk::entry .e2

grid .l1 -row 0 -column 0
grid .e1 -row 0 -column 1
grid .l2 -row 1 -column 0
grid .e2 -row 1 -column 1
```

Es geht auch kürzer: `grid` nimmt mehrere Widgets als eine Zeile, wobei
`-` eine Zelle nach links zusammenfasst und `x` eine Zelle leer lässt:

```tcl
grid .l1 .e1     ;# Zeile 0: Spalte 0 und 1
grid .l2 .e2     ;# Zeile 1
```

`-sticky` bestimmt, an welche Zellränder ein Widget „klebt" und damit, in
welche Richtung es die Zelle ausfüllt:

```tcl
grid .e1 -sticky w       ;# linksbündig
grid .e1 -sticky e       ;# rechtsbündig
grid .e1 -sticky we      ;# horizontal füllen
grid .e1 -sticky nsew    ;# in alle Richtungen füllen
```

Für Eingabefelder in Formularen ist `-sticky we` der Normalfall: Das Feld
soll die volle Spaltenbreite nutzen. Beschriftungen bekommen meist
`-sticky w`, damit sie linksbündig stehen.

---

## 8.2 `-columnspan`/`-rowspan`

Ein Widget kann sich über mehrere Spalten oder Zeilen erstrecken:

```tcl
# Eine Überschrift über zwei Spalten
ttk::label .head -text "Adresse" -anchor w
grid .head -row 0 -column 0 -columnspan 2 -sticky we

# Ein mehrzeiliges Textfeld über zwei Zeilen
text .notes -height 4
grid .notes -row 1 -column 1 -rowspan 2 -sticky nsew
```

`-columnspan`/`-rowspan` ist das Mittel für Formulare, die nicht streng
zweispaltig sind — ein Kommentarfeld, das die ganze Breite einnimmt, eine
Gruppenüberschrift, ein Button-Block am unteren Rand.

---

## 8.3 `grid columnconfigure -weight` — die wichtigste Zeile

Standardmäßig sind Spalten und Zeilen genau so breit/hoch wie ihr
breitester/höchster Inhalt. Wird das Fenster größer, bleibt der
Zusatzplatz **ungenutzt** — das Raster wächst nicht mit. Damit eine
Spalte den Zusatzplatz aufnimmt, gibt man ihr ein Gewicht:

```tcl
grid columnconfigure . 1 -weight 1   ;# Spalte 1 nimmt Zusatzbreite
grid rowconfigure    . 2 -weight 1   ;# Zeile 2 nimmt Zusatzhöhe
```

Das `-weight` ist relativ: Zwei Spalten mit `-weight 1` und `-weight 2`
teilen den Zusatzplatz im Verhältnis 1:2. Eine Spalte mit Gewicht 0 (der
Default) wächst nie.

Zusammen mit `-sticky` ergibt das die Standardregel aus Kapitel 6: Das
*Gewicht* gibt den Platz an die Spalte, das *sticky* lässt das Widget ihn
ausfüllen. Beides zusammen — sonst bleibt das Formular klein:

```tcl
ttk::label .l -text "Name:"
ttk::entry .e
grid .l -row 0 -column 0 -sticky w  -padx 4 -pady 2
grid .e -row 0 -column 1 -sticky we -padx 4 -pady 2
grid columnconfigure . 1 -weight 1     ;# Eingabe-Spalte wächst mit
```

In diesem typischen Label/Entry-Formular bekommt nur die **Eingabe-Spalte**
(Spalte 1) Gewicht — die Beschriftungs-Spalte (0) soll schmal bleiben.

---

## 8.4 `-uniform` und `-minsize`

Zwei Feinsteller für gleichmäßige Raster:

**`-uniform`** zwingt mehrere Spalten (oder Zeilen) auf dieselbe Breite,
indem man ihnen denselben Gruppennamen gibt:

```tcl
# Drei gleich breite Spalten für ein Button-Raster
grid columnconfigure . 0 -weight 1 -uniform col
grid columnconfigure . 1 -weight 1 -uniform col
grid columnconfigure . 2 -weight 1 -uniform col
```

Ohne `-uniform` würde eine Spalte mit breiterem Inhalt mehr Platz
bekommen; mit `-uniform col` teilen sich alle Spalten der Gruppe den Raum
gleichmäßig — wichtig für saubere Button-Reihen oder Tabellen-Köpfe.

**`-minsize`** gibt einer Spalte/Zeile eine Mindestausdehnung, auch wenn
ihr Inhalt schmaler wäre:

```tcl
grid columnconfigure . 0 -minsize 80   ;# Label-Spalte mind. 80px
```

---

## 8.5 Das Formular-Muster, das immer trägt

Das folgende Muster trägt für nahezu jedes zweispaltige Formular und ist
es wert, im Gedächtnis zu bleiben:

```tcl
proc formRow {parent row label widget} {
    ttk::label $parent.l$row -text $label -anchor w
    grid $parent.l$row -row $row -column 0 -sticky w  -padx 4 -pady 3
    grid $widget       -row $row -column 1 -sticky we -padx 4 -pady 3
}

ttk::frame .f
pack .f -fill both -expand 1 -padx 8 -pady 8

ttk::entry .f.name
ttk::entry .f.city
ttk::combobox .f.country -values {Deutschland Österreich Schweiz}

formRow .f 0 "Name:"  .f.name
formRow .f 1 "Stadt:" .f.city
formRow .f 2 "Land:"  .f.country

grid columnconfigure .f 1 -weight 1     ;# nur die Eingabe-Spalte wächst
```

Drei Dinge machen es robust: der umschließende Frame mit `pack … -expand 1`
(damit das Formular im Fenster mitwächst), `-sticky we` an den Eingaben
(damit sie die Spalte füllen) und das einzelne `columnconfigure … -weight 1`
auf Spalte 1 (damit die Spalte den Zusatzplatz bekommt). Fehlt die letzte
Zeile, bleiben die Eingabefelder schmal, egal wie groß das Fenster wird —
der mit Abstand häufigste `grid`-Fehler.

---

## Zusammenfassung

- `grid` ordnet in Zeilen/Spalten; `-sticky` steuert Ausrichtung und
  Füllen der Zelle.
- `-columnspan`/`-rowspan` spannt über mehrere Zellen.
- `grid columnconfigure/rowconfigure … -weight` gibt einer Spalte/Zeile
  Zusatzplatz — ohne sie wächst nichts mit.
- `-uniform` erzwingt gleiche Breiten, `-minsize` eine Untergrenze.
- Das tragfähige Formular-Muster: Frame mit `-expand`, Eingaben mit
  `-sticky we`, Gewicht auf der Eingabe-Spalte.

`pack` und `grid` decken zusammen praktisch jedes Layout ab. Der dritte
Manager, `place`, ist der Ausnahmefall — mächtig, aber selten richtig.
Kapitel 9 zeigt, wofür er gut ist und wofür nicht.
