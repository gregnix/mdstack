#!/usr/bin/env tclsh
# build-pdf-docir.tcl -- Build the whole book into one PDF using the pure-Tcl
# DocIR pipeline (no LaTeX, no pandoc, no Docker):
#
#     mdstack::parser  ->  docir::md::fromAst  ->  docir::pdf::render
#                                                   (via pdf4tcl / pdf4tcllib)
#
# Usage:
#     tclsh build-pdf-docir.tcl [output.pdf] [book-dir]
#
# Defaults: output = TclTk-Benutzeroberflaechen.pdf, book-dir = script dir.
#
# Module discovery (first hit wins per repo):
#   1. env vars DOCIR_HOME / MDSTACK_HOME / PDF4TCL_HOME / PDF4TCLLIB_HOME
#      (each pointing at the repo root that contains the marker file below)
#   2. sibling repos found by scanning a few base dirs (REPOS_DIR, script
#      parents, ~/code/git/github, ~/lib/tcltk, /usr/local/lib/tcltk)
#   3. whatever is already on tcl::tm::path / auto_path (system/user install)

set scriptDir [file dirname [file normalize [info script]]]

# --- search bases for auto-discovery ---
set searchBases {}
if {[info exists env(REPOS_DIR)]}     { lappend searchBases $env(REPOS_DIR) }
lappend searchBases \
    $scriptDir \
    [file dirname $scriptDir] \
    [file dirname [file dirname $scriptDir]] \
    [file join $env(HOME) code git github] \
    [file join $env(HOME) lib tcltk] \
    /usr/local/lib/tcltk

# Find a repo root that contains markerRel; return "" if not found.
proc discover {envVar markerRel} {
    global env searchBases
    if {[info exists env($envVar)] && [file exists [file join $env($envVar) {*}$markerRel]]} {
        return $env($envVar)
    }
    foreach base $searchBases {
        if {![file isdirectory $base]} continue
        if {[file exists [file join $base {*}$markerRel]]} { return $base }
        foreach sub [glob -nocomplain -directory $base -type d *] {
            if {[file exists [file join $sub {*}$markerRel]]} { return $sub }
            foreach sub2 [glob -nocomplain -directory $sub -type d *] {
                if {[file exists [file join $sub2 {*}$markerRel]]} { return $sub2 }
            }
        }
    }
    return ""
}

proc addTm {dir} {
    # add to tcl::tm::path, tolerating ancestor/descendant conflicts
    if {$dir ne "" && [file isdirectory $dir] && $dir ni [tcl::tm::path list]} {
        catch {tcl::tm::path add $dir}
    }
}

# marker files identify each repo and pin down its module directory
set docirRoot   [discover DOCIR_HOME      {lib tm docir-0.1.tm}]
set mdstackRoot [discover MDSTACK_HOME    {lib mdstack-0.1.tm}]
set pdftclRoot  [discover PDF4TCL_HOME    {pdf4tcl.tcl}]
set pdflibRoot  [discover PDF4TCLLIB_HOME {lib pdf4tcllib-0.2.tm}]

if {$docirRoot   ne ""} { addTm [file join $docirRoot lib tm] }
if {$mdstackRoot ne ""} { addTm [file join $mdstackRoot lib] }
if {$pdflibRoot  ne ""} { addTm [file join $pdflibRoot lib] }
if {$pdftclRoot  ne ""} { lappend auto_path $pdftclRoot }

# --- load packages ---
foreach {pkg hint} {
    pdf4tcl          "PDF4TCL_HOME=<pdf4tcl repo>"
    mdstack::parser  "MDSTACK_HOME=<mdstack repo>"
    mdstack::pdf     "MDSTACK_HOME=<mdstack repo> (and docir, pdf4tcllib)"
} {
    if {[catch {package require $pkg} err]} {
        puts stderr "FEHLER: '$pkg' nicht ladbar: $err"
        puts stderr "  Tipp: passenden Repo-Pfad setzen, z. B. $hint"
        puts stderr "  oder REPOS_DIR=<Ordner mit den vier Repos>"
        exit 1
    }
}

# --- arguments ---
set outFile [expr {[llength $argv] >= 1 ? [lindex $argv 0] : "TclTk-Benutzeroberflaechen.pdf"}]
set bookDir [expr {[llength $argv] >= 2 ? [lindex $argv 1] : $scriptDir}]

# --- collect markdown files in reading order ---
#   VORWORT, chapters 1..38 (by numeric chapter number), appendices A..F
set files {}
if {[file exists [file join $bookDir VORWORT.md]]} {
    lappend files [file join $bookDir VORWORT.md]
}
set chaps {}
foreach f [glob -nocomplain -directory $bookDir -join * kapitel-*.md] {
    if {[regexp {kapitel-0*([0-9]+)-} [file tail $f] -> n]} {
        lappend chaps [list [scan $n %d] $f]
    }
}
foreach pair [lsort -integer -index 0 $chaps] { lappend files [lindex $pair 1] }
foreach f [lsort [glob -nocomplain -directory [file join $bookDir 900-anhaenge] anhang-*.md]] {
    lappend files $f
}
if {[llength $files] == 0} {
    puts stderr "FEHLER: keine Markdown-Dateien in $bookDir gefunden."
    exit 1
}
puts "Stelle [llength $files] Dateien zusammen ..."

# --- concatenate + parse + render ---
set md ""
foreach f $files {
    set fh [open $f r]; fconfigure $fh -encoding utf-8
    append md [read $fh] "\n\n"; close $fh
}
set ast [mdstack::parser::parse $md]
# Render the pipeline directly down to docir::pdf::render so we can pass
# -generateToc: mdstack::pdf::export maps only a fixed option set and does
# not forward generateToc/tocTitle/tocDepth.
package require docir::md
set ir [::docir::md::fromAst $ast]
::docir::pdf::render $ir $outFile [dict create \
    title       "Benutzeroberflächen mit Tcl/Tk" \
    author      "gregnix" \
    paper       a4 \
    footer      "%p" \
    generateToc 1 \
    tocTitle    "Inhaltsverzeichnis" \
    tocDepth    2]

puts "Fertig: $outFile ([file size $outFile] Bytes)"
