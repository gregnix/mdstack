# Checkliste — Erweiterung (Zielversion Weg C)

*Stand: 2026-06-16*

Dieses Dokument ist die **Zielversion** von Anhang D nach Weg C und Phase 5.
Kapitelverweise nutzen die **neue Nummerierung** (38 Kapitel). Die bestehende
Datei im Werk (Stand 2026-05-29) bleibt bis zur Einpflege unverändert.

**Bezug:** Reviewer-Abgleich,
[Kap. 5.9](../150-gui-grundsaetze/kapitel-05-gute-gui-grundsaetze.md) (Checkliste Erstentwurf),
[Anhang E](anhang-e-designsystem.md)

---

## Verwendung

1. **Erstentwurf** eines neuen Fensters → Abschnitt „Gestaltung — Erstentwurf" (aus Kap. 5.9)
2. **Während der Entwicklung** → technische Abschnitte nach Bedarf
3. **Vor Release** → alle Abschnitte + „Release-Checkliste" am Ende abhaken

---

# Checkliste für gute Tk-Oberflächen

*Stand: 2026-06-16 (Ziel nach Weg C)*

Eine Prüfliste zum Abhaken vor dem Ausliefern — gegliedert nach den
Teilen des Buches. Jeder Punkt verweist auf das Kapitel mit der
Begründung.

---

## Gestaltung — Erstentwurf (Kap. 5)

*Vor dem ersten ernsthaften Layout — aus Kap. 5.9*

- [ ] Ist klar, was die **eine** Hauptaufgabe dieses Fensters ist? (Kap. 5.1)
- [ ] Gibt es höchstens **eine** visuell dominante Aktion? (Kap. 5.1, 36.2)
- [ ] Sind Beschriftungen **verständlich** (keine internen Kürzel)? (Kap. 5.1)
- [ ] Sind gleiche Aktionen **gleich benannt und platziert**? (Kap. 5.2)
- [ ] Zeigt die Oberfläche den **Systemzustand** (gespeichert, busy, Fehler)? (Kap. 5.3)
- [ ] Gibt es **keine** unnötigen Bestätigungsdialoge? (Kap. 5.3)
- [ ] Sind Optionen **gruppiert**, nicht in einer endlosen Liste? (Kap. 5.4)
- [ ] Sind Farben **zurückhaltend** (kein Regenbogen)? (Kap. 5.5, 38)
- [ ] Sind **Tastatur**-Wege für Hauptaktionen vorgesehen? (Kap. 5.6)
- [ ] Würde ein Fremder in 30 Sekunden wissen, **wo er klicken soll**? (Kap. 5.1)

*Diagnose „wirkt alt":* Kap. 5.8 — acht typische Fehler prüfen.

---

## Gestaltung — Designsystem (Kap. 36–38, Anhang E)

- [ ] Durchgängig **Ttk**; classic nur wo nötig (`text`, `canvas`, …) (Kap. 4)
- [ ] Abstände aus **Anhang E.1** (8/12 px Raster), nicht pro Widget improvisiert (Kap. 38, E)
- [ ] Schrift **zentral** definiert, nicht `-font` an jedem Widget (Kap. 25, E.2)
- [ ] Höchstens **eine** Primärfarbe pro Ansicht; Rot nur für Gefahr/Fehler (Kap. 38, E.3)
- [ ] Formular: Zwei-Spalten-Grid nach **E.5** (Labels `sticky e`, Felder `sticky ew`)
- [ ] Dialog: höchstens ein `Primary.TButton` (Kap. 27, E.4)
- [ ] Toolbar: Gruppen mit Trennern; seltene Aktionen im Menü (Kap. 12, E.7)
- [ ] Statuszeile für Zustand und Kurzhinweise (Kap. 12, E.8)
- [ ] Icons einheitliche Größe; Icon-only nur mit Tooltip (Kap. 36.4)
- [ ] Visuelle Hierarchie: eine Akzent-Aktion, Weißraum zwischen Gruppen (Kap. 36)

---

## Struktur und Modell (Kap. 30–31)

- [ ] Logik liegt im Modell/Service, nicht im `-command` oder Binding (Kap. 30)
- [ ] Aktionen sind benannt und zentral; Button, Menü, Tastatur rufen
      dieselbe Aktion (Kap. 17, 30)
- [ ] Zustandsänderungen melden sich (virtuelle Events/Traces), die
      Anzeige reagiert darauf (Kap. 29, 30)
- [ ] Code in Module/Namespaces getrennt; nur Exportiertes als API (Kap. 31)
- [ ] Schichten View / Application / Services eingehalten (Kap. 31.5)
- [ ] Abhängigkeiten beim Start geprüft, Fehlen bricht ab — keine stille
      Notlösung (Kap. 31)

---

## Layout (Kap. 6–12)

- [ ] Pro Eltern-Widget genau ein Geometry Manager (Kap. 6)
- [ ] Mitwachsende Bereiche haben `-expand`/`-weight` **und**
      `-fill`/`-sticky`, auf jeder Ebene der Kette (Kap. 6, 11)
- [ ] Formular-Eingabespalten haben `columnconfigure -weight` (Kap. 8)
- [ ] Ränder (Toolbar/Status) vor dem Inhalt gepackt (Kap. 7)
- [ ] Feste Innenbereiche über `propagate 0`, nicht über `place` (Kap. 6, 10)
- [ ] `place` nur für Overlays/feste Verhältnisse (Kap. 9)
- [ ] `wm minsize` gesetzt; Fenster lässt sich nicht unbrauchbar
      verkleinern (Kap. 11)
- [ ] **Resize-Test** (7 Schritte) durchgespielt (Kap. 11.8)
- [ ] Fenster entspricht einem bekannten **Desktop-Pattern** (Explorer, Editor, …) (Kap. 12)
- [ ] Widget-Baum dokumentiert oder nachvollziehbar (Anhang F)

---

## Widgets (Kap. 13–18)

- [ ] Ttk verwendet, wo verfügbar; classic nur, wo nötig (Kap. 4)
- [ ] classic-Widgets (`text`/`canvas`/`listbox`) an Theme-Hintergrund
      angeglichen (Kap. 4, 24)
- [ ] Eingaben validiert, wo nötig; Prüfprozedur greift nicht ein (Kap. 14)
- [ ] `-textvariable`/`-variable` auf global/qualifizierte Variablen (Kap. 29)

---

## Interaktion (Kap. 19–23)

- [ ] Keine lange Arbeit im Callback; Häppchen über `after` (Kap. 19)
- [ ] `update idletasks` statt `update` zum Neuzeichnen (Kap. 19)
- [ ] Modale Dialoge: `grab set` **und** `tkwait`/`vwait` (Kap. 22)
- [ ] Dialoge mit `wm transient` und `winfo exists`-Guard (Kap. 22)
- [ ] Beschleuniger im Menü durch `bind` wirksam gemacht (Kap. 17, 21)
- [ ] Plattform-Modifizierer beachtet (`Control`/`Command`) (Kap. 21)

---

## Tastatur und Bedienbarkeit (Kap. 23)

- [ ] Tab-Reihenfolge folgt der Lese-Reihenfolge (Kap. 23)
- [ ] `<Return>` löst Default-Button, `<Escape>` bricht ab (Kap. 23)
- [ ] Fokus beim Öffnen ins erste Feld (Kap. 23)
- [ ] Mnemonics an Menüs/wichtigen Buttons, eindeutig (Kap. 21, 23)
- [ ] Maus-weglegen-Test bestanden (Kap. 23)

---

## Darstellung (Kap. 24–27)

- [ ] Benannte Fonts statt verstreuter Specs (Kap. 13, 25)
- [ ] Strukturfarben aus dem Theme (`ttk::style lookup` + Fallback),
      feste Farben nur für inhaltliche Akzente (Kap. 24, 25)
- [ ] Ttk-Aussehen über Styles, nicht über Widget-Optionen (Kap. 24, 27)
- [ ] HiDPI bedacht: Schriftgrößen in Punkten, wenig feste Pixel (Kap. 25, 11.6)

---

## Daten (Kap. 28–30)

- [ ] Treeview-Item-IDs und Daten-IDs über ein Mapping getrennt (Kap. 28)
- [ ] Mehrwertige Auswahl explizit synchronisiert (`<<…Select>>`),
      nicht über eine einzelne Variable (Kap. 15, 28, 29)

---

## Human Interface Guidelines (Kap. 37)

- [ ] Fehlermeldungen in **Nutzersprache** mit Handlungsvorschlag (Kap. 37.6)
- [ ] Keine Bestätigung bei harmlosen Aktionen (Kap. 37, 5.3)
- [ ] Systemstatus sichtbar während längerer Arbeit (Kap. 37.5)

---

## Internationalisierung (falls relevant, Kap. 32)

- [ ] Alle sichtbaren Texte über `mc` (Kap. 32)
- [ ] Format-Strings ganz in `mc`, nicht zusammengestückelt (Kap. 32)
- [ ] Layout verträgt längere Übersetzungen (`-wraplength`, kein festes
      Pixelmaß) (Kap. 32)

---

## Tests und Verteilung (Kap. 33–34)

- [ ] Geschäftslogik mit `tcltest` ohne GUI geprüft (Kap. 33)
- [ ] Verhalten über `event generate`/`invoke` geprüft (Kap. 33)
- [ ] Als eine Datei verteilbar (Starpack/zipkit), je Plattform (Kap. 34)
- [ ] `wish` für reine GUI (keine Windows-Konsole) (Kap. 2, 34)
- [ ] Binär-Erweiterungen werden beim Start entpackt (Kap. 34)
- [ ] Ressourcen-Pfade relativ zum Anwendungs-Topdir (Kap. 34)

---

## Release-Checkliste (Projektabschluss)

*Kompakte Abhakliste — z. B. am Ende der Fallstudie (Kap. 35.7) oder vor jedem Release.*

### Bedienbarkeit

- [ ] Tab-Reihenfolge stimmt
- [ ] Esc schließt Dialog / bricht ab
- [ ] Enter aktiviert Standardbutton
- [ ] Tastaturbedienung für Hauptaufgabe möglich
- [ ] Fokus beim Öffnen sinnvoll gesetzt

### Layout und Fenster

- [ ] Fenster skalierbar (Wachstumskette vollständig)
- [ ] Mindestgröße gesetzt und getestet
- [ ] Notebook: jeder Reiter einzeln bei verschiedenen Größen geprüft

### Gestaltung

- [ ] Kontrast ausreichend (Text lesbar, Hinweise nicht zu blass)
- [ ] Icons konsistent (Größe, Stil)
- [ ] Buttons in einer Gruppe gleichwertig formatiert; Primär-Button erkennbar
- [ ] Keine gemischten classic/Ttk-Buttons in derselben Leiste

### Qualität

- [ ] Fehlermeldungen verständlich und handlungsorientiert
- [ ] Anhang E eingehalten oder bewusst dokumentierte Abweichung
- [ ] Anhang D vollständig durchgegangen

---

## Fußnote

Wer diese Liste durchgeht, fängt die überwiegende Mehrheit der Probleme
ab, die eine Tk-Oberfläche unbenutzbar oder schwer wartbar machen. Sie ist
kein Ersatz für die Kapitel, sondern deren Verdichtung — im Zweifel beim
verlinkten Kapitel nachlesen.

**Neu gegenüber Stand 2026-05-29:** Abschnitte Gestaltung (Erstentwurf +
Designsystem), HIG, Release-Checkliste; Kapitelverweise auf Weg-C-Nummerierung;
Verweise auf Kap. 5.8, 11, 12, 31.5, 36–38, Anhänge E–F.

---

## Einpflege-Hinweis

Bei Umsetzung in `anhang-d-checkliste.md`:

1. Datei durch diesen Inhalt ersetzen (oder Abschnitte „Gestaltung" und
   „Release-Checkliste" einfügen und Verweise anpassen).
2. Stand-Datum auf Einpflege-Datum setzen.
3. In Kap. 5.9, 35.7 und README auf „Anhang D" verlinken.
