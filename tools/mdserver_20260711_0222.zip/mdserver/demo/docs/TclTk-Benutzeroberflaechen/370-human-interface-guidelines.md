# Human Interface Guidelines — praxisnah

*Stand: 2026-06-16*

## Einführung

**Human Interface Guidelines (HIG)** fassen Jahrzehnte Usability-Forschung
in Regeln zusammen. Sie sind nicht Tk-spezifisch — aber jede Regel lässt
sich auf Widgets, Layout und Interaktion **übersetzen**.

Dieses Kapitel folgt dem Muster: **Regel → Warum → Tk-Beispiel**.

**Voraussetzung:** Kapitel 5, 19–23 (Events, Dialoge, Tastatur).  
**Ergänzt:** Anhang D (technische Checkliste).

---

## 37.1 Fitts' Law — Zielgröße und Abstand

**Regel:** Zeit zum Anklicken hängt von Entfernung und **Zielgröße** ab.
Große, nahe Ziele sind schneller zu treffen.

**Warum:** Hauptaktionen sollen Fehlklicks minimieren; destruktive Aktionen
sollen nicht aus Versehen neben OK liegen.

**Tk:**

```tcl
# Häufige Aktion: großzügiges Padding
ttk::style configure Primary.TButton -padding {16 8}

# Destruktiv: Abstand zum Primary
ttk::button .dlg.delete -text "Delete" -style Danger.TButton
pack .dlg.delete -side right -padx {16 4}   ;# nicht padx 2 neben OK
```

Toolbar-Icons: Mindestklickfläche ~24×24 px auch wenn das Glyph kleiner ist
(`-padding` um das Icon).

---

## 37.2 Hick's Law — Wahlmenge

**Regel:** Mehr gleichwertige Optionen → längere Entscheidungszeit.

**Warum:** Menüs mit 40 Top-Level-Einträgen überfordern; Assistenten führen
Schritt für Schritt.

**Tk:**

- Menü **hierarchisch** (Cascade), nicht alles in einer Ebene (Kap. 21)
- Einstellungen in **Notebook-Reiter** (Kap. 12.4), nicht 30 Checkboxen
  untereinander
- Assistent statt einem Dialog mit 15 Radio-Buttons (Kap. 12.5)

---

## 37.3 Miller's Law — Gruppierung (7±2)

**Regel:** Kurzzeitgedächtnis faßt begrenzt viele Einheiten auf einmal.

**Warum:** Sieben Reiter oder sieben gleichrangige Toolbar-Gruppen sind ein
Soft-Limit — darüber Gruppierung oder Untermenüs.

**Tk:** `ttk::labelframe` für 3–5 verwandte Checkboxen; zweite Gruppe in
eigenem Frame mit Abstand (`pady 12`).

---

## 37.4 Gestaltgesetze

| Gesetz | Bedeutung | Tk |
|--------|-----------|-----|
| **Nähe** | Nahe stehendes gehört zusammen | `padding` + Frame, nicht Leerzeile in `pack` |
| **Ähnlichkeit** | Gleiches Aussehen = gleiche Funktion | Ein Style pro Button-Typ |
| **Geschlossenheit** | Rahmen schließt visuell ab | `labelframe` sparsam |
| **Kontinuität** | Auge folgt Linien | Ausrichtung Spalte 0/1 in `grid` |

---

## 37.5 Nielsens zehn Heuristiken (Kurzfassung + Tk)

| # | Heuristik | Tk-Umsetzung |
|---|-----------|--------------|
| 1 | Sichtbarkeit des Systemstatus | `textvariable` auf Status-Label; `configure -state disabled` während Arbeit |
| 2 | Sprache der Nutzer, nicht des Systems | Labels ohne Dateiendungen/errno |
| 3 | Nutzerkontrolle und Freiheit | **Abbrechen**, Undo im `text`, Rückgängig wo möglich |
| 4 | Konsistenz und Standards | Kap. 5.2; Plattform-Modifizierer Kap. 21 |
| 5 | Fehlervermeidung | `validatecommand` (Kap. 14), Defaults, deaktivierte illegale Aktionen |
| 6 | Wiedererkennung statt Erinnerung | Menü **und** Toolbar für dieselbe Aktion; sichtbare Labels |
| 7 | Flexibilität und Effizienz | Tastaturkürzel + Maus; Experten-Menü optional |
| 8 | Ästhetik und Minimalismus | Kap. 36; keine Zier-Frames |
| 9 | Fehler erkennen, beheben, erklären | `tk_messageBox -icon error` mit **Handlung** („Datei ist schreibgeschützt — wählen Sie einen anderen Pfad") |
| 10 | Hilfe und Dokumentation | F1, Statuszeilen-Hinweise, Kontext-Hilfe |

---

## 37.6 Fehlermeldungen

**Regel:** Sage, was passiert ist **und** was der Nutzer tun kann.

```tcl
# SCHLECHT
tk_messageBox -message "Error 13"

# BESSER
tk_messageBox -icon error -title "Save failed" \
    -message "Could not write to /var/app/config.ini: permission denied.\nChoose another location or run as administrator."
```

In der Anwendung: Fehlertext aus `service`-Schicht, nicht roher `errorInfo`
an den Nutzer (Kap. 31.5).

---

## 37.7 Undo und Rückgängig

- **`text` / `entry`:** eingebautes Undo (Kap. 16) nicht abschalten ohne Grund
- **Anwendungszustand:** explizites Undo (Befehlsliste) oder Bestätigung bei
  irreversiblen Aktionen
- **Nielsen #3:** Nutzer sollen experimentieren können, ohne Angst vor
  Datenverlust

---

## Zusammenfassung

- Fitts → große nahe Hauptaktionen, destruktive Aktionen mit Abstand.
- Hick → weniger gleichwertige Optionen sichtbar; Hierarchie und Schritte.
- Miller → Gruppen à ~5–7 Einträge.
- Gestalt → Nähe, Ähnlichkeit, Ausrichtung im Layout.
- Nielsen → Tabelle als Review-Liste vor Release; Fehlertexte handlungsorientiert.

Kapitel 38 / Anhang E fassen die **konkreten Zahlen** (Padding, Fonts,
Farben) als Designsystem zusammen.
