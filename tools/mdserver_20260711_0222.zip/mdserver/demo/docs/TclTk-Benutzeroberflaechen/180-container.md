# Container-Widgets

*Stand: 2026-05-29*

## Einführung

Container halten andere Widgets zusammen und geben dem Layout Struktur.
Vier sind wichtig: `frame`/`ttk::frame` als universeller Behälter,
`labelframe` als umrandete Gruppe, `ttk::notebook` für Reiter und
`ttk::panedwindow` für verschiebbare Trenner. Dieses Kapitel zeigt jeden
und klärt am Ende, wann ein eigenes Fenster (`toplevel`) der bessere
Container ist als ein Frame.

---

## 18.1 `frame` / `ttk::frame` und `labelframe`

Der **Frame** ist der Arbeitspferd-Container — unsichtbar, ohne eigenen
Inhalt, da, um andere Widgets aufzunehmen und (entscheidend aus Kapitel 6)
um je einen Geometry Manager zu kapseln:

```tcl
ttk::frame .toolbar
pack .toolbar -side top -fill x
ttk::button .toolbar.new -text "Neu"
pack .toolbar.new -side left
```

Frames sind billig; man verwendet sie großzügig, um komplexe Layouts in
beherrschbare Bereiche zu zerlegen. Jeder Frame darf intern einen anderen
Manager verwenden — der eine `pack`, der nächste `grid`.

Der **Labelframe** ist ein Frame mit Rahmen und Titel — ideal, um
zusammengehörige Optionen sichtbar zu gruppieren:

```tcl
ttk::labelframe .opt -text "Einstellungen"
pack .opt -fill x -padx 8 -pady 8
ttk::checkbutton .opt.a -text "Automatisch speichern"
ttk::checkbutton .opt.b -text "Backups behalten"
pack .opt.a .opt.b -anchor w -padx 8 -pady 2
```

Der Titel macht die Gruppierung für den Nutzer lesbar, ohne dass man
selbst eine Überschrift platzieren und einen Rahmen zeichnen muss.

---

## 18.2 `ttk::notebook` — Reiter

Das **Notebook** zeigt mehrere Seiten, von denen jeweils eine über einen
Reiter sichtbar wird. Jede Seite ist ein Frame, der dem Notebook
hinzugefügt wird:

```tcl
ttk::notebook .nb
pack .nb -fill both -expand 1

ttk::frame .nb.allg
ttk::frame .nb.erw
.nb add .nb.allg -text "Allgemein"
.nb add .nb.erw  -text "Erweitert"

# Inhalt in die Seiten
ttk::label .nb.allg.info -text "Allgemeine Einstellungen"
pack .nb.allg.info -padx 16 -pady 16
```

Die hinzugefügten Frames müssen **Kinder des Notebooks** sein (Pfadname
`.nb.…`). Auf einen Reiterwechsel reagiert man über das virtuelle Event
`<<NotebookTabChanged>>` (Kapitel 20); den aktiven Reiter liefert
`.nb select`.

---

## 18.3 `panedwindow` — verschiebbare Trenner

Das **Panedwindow** teilt seinen Raum in Bereiche, deren Größenverhältnis
der Nutzer mit einem Trenner (Sash) verschieben kann — die saubere Lösung
für „Liste links, Inhalt rechts":

```tcl
ttk::panedwindow .pw -orient horizontal
pack .pw -fill both -expand 1

ttk::frame .pw.left
ttk::frame .pw.right
.pw add .pw.left  -weight 1
.pw add .pw.right -weight 3      ;# rechter Bereich bekommt mehr Zuwachs

ttk::treeview .pw.left.tree
pack .pw.left.tree -fill both -expand 1
text .pw.right.text -wrap word
pack .pw.right.text -fill both -expand 1
```

`-orient horizontal` legt die Bereiche nebeneinander, `vertical`
übereinander. Das `-weight` beim `add` steuert, wie der *Zusatzplatz*
beim Vergrößern des Fensters verteilt wird (hier 1:3) — die
Ausgangsteilung kann der Nutzer danach frei verschieben.

Wie schon in Kapitel 9 erwähnt: Für eine *verschiebbare* Teilung ist das
Panedwindow dem `place`-Verhältnis-Layout vorzuziehen; `place` lohnt nur
für *feste* Verhältnisse.

---

## 18.4 Wann ein Toplevel besser ist als ein Frame

Frames und Notebooks halten alles in *einem* Fenster. Manchmal will man
aber ein *zweites* Fenster — ein eigenständiges `toplevel`. Es ist der
richtige Container, wenn:

- der Inhalt unabhängig vom Hauptfenster bewegt, vergrößert oder
  geschlossen werden soll (ein Werkzeug-Palette, ein Log-Fenster),
- es sich um einen Dialog handelt, der den Nutzer aus dem normalen Fluss
  holt (Kapitel 22),
- der Inhalt eine eigene Menüleiste oder einen eigenen Titel braucht.

```tcl
toplevel .tools
wm title .tools "Werkzeuge"
ttk::button .tools.b -text "Aktion"
pack .tools.b -padx 12 -pady 12
```

Ein `toplevel` ist ein vollwertiges Fenster mit eigenem `wm`-Handling
(Kapitel 2). Es bleibt classic (es gibt kein `ttk::toplevel`), nimmt aber
Ttk-Widgets als Inhalt auf wie jeder andere Container. Die Faustregel:
Solange Inhalt zum selben Fenster gehört, nimm einen Frame oder ein
Notebook; sobald er ein eigenes Fenster sein soll, ein Toplevel.

---

## Zusammenfassung

- `ttk::frame` ist der universelle Behälter und das Mittel, um je einen
  Geometry Manager pro Bereich zu kapseln; großzügig einsetzen.
- `ttk::labelframe` gruppiert sichtbar mit Titel und Rahmen.
- `ttk::notebook` zeigt Reiter-Seiten (Frames als Kinder hinzufügen,
  `<<NotebookTabChanged>>` zum Reagieren).
- `ttk::panedwindow` bietet verschiebbare Bereiche; `-weight` verteilt den
  Zusatzplatz.
- Ein `toplevel` ist der richtige Container, sobald der Inhalt ein eigenes
  Fenster sein soll.

Teil 3 ist damit abgeschlossen — die Bausteine stehen. Teil 4 wendet sich
dem zu, was sie zum Leben erweckt: dem Event-Loop, Bindings, Menüs und
Dialogen.
