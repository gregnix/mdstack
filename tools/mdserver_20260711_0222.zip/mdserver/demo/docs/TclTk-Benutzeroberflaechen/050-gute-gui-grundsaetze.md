# Was macht eine gute GUI aus?

*Stand: 2026-06-16*

## Einführung

Die Kapitel 1 bis 4 haben erklärt, **wie Tk funktioniert**: Widget-Baum,
Geometry Manager, Event-Loop, classic gegen Ttk. Bevor Sie Wochen mit
`pack` und `grid` verbringen, lohnt ein kurzer Blick auf ein anderes
Thema: **was Menschen an einer Oberfläche als gut oder schlecht empfinden**.

Dieses Kapitel ist bewusst **technikarm**. Es beschreibt keine Befehle im
Detail — die kommen ab Kapitel 6. Es liefert Kriterien, an denen Sie
eigene Fenster messen können, und verweist später auf vertiefende Kapitel
zu Layout (9–11), Bedienbarkeit (20), Gestaltung (32–34) und die Checkliste
in Anhang D.

**Voraussetzung:** Kapitel 1–2 (Modell, erstes Fenster).  
**Leser ohne GUI-Erfahrung:** dieses Kapitel nicht überspringen.

---

## 5.1 Einfachheit und Aufgabenfokus

Eine gute Oberfläche beantwortet zu jedem Zeitpunkt eine klare Frage:
*Was soll ich hier als Nächstes tun?*

- **Eine Hauptaufgabe pro Fenster** — oder pro Reiter in einem Notebook.
  Ein Dialog „Datei speichern" speichert; er mischt nicht fünf andere
  Verwaltungsfunktionen hinein.
- **Eine primäre Aktion** — visuell hervorgehoben (später: `Primary.TButton`,
  Kapitel 24). Im Dialog „Speichern" ist das **Speichern**, nicht Abbrechen.
- **Sekundäres zurückhalten** — seltene Optionen ins Menü, in „Erweitert…"
  oder in einen zweiten Reiter.

> **Schlecht:** Ein Formular mit zwölf gleich großen Buttons in einer Reihe —
> keiner sticht hervor, der Nutzer muss lesen statt scannen.  
> **Besser:** Eine Buttonleiste mit einem hervorgehobenen **OK** und
> zurückhaltendem **Cancel**; seltene Aktionen nur im Menü **File**.

---

## 5.2 Konsistenz

Nutzer lernen Ihre Anwendung nicht Seite für Seite — sie **übertragen**
Gewohnheiten von einem Dialog auf den nächsten.

- **Gleiche Wörter** für gleiche Aktionen: nicht mal „Delete", mal „Remove",
  mal „Clear".
- **Gleiche Positionen:** OK rechts unten, Abbrechen daneben — in *jedem*
  Dialog (plattformabhängig: unter macOS kann die Reihenfolge anders sein;
  Kapitel 21).
- **Gleiche Abstände** — nicht in einem Formular 4 Pixel Rand, im nächsten
  20 (Kapitel 38 / Anhang E: Raster 8/12 px).
- **Gleiche Tastenkürzel** — Strg+S speichert überall, nicht nur im Editor.

Tk macht Konsistenz nicht von selbst — sie ist eine **Disziplin** beim
Bauen. Zentral definierte Styles und Aktionen (Kapitel 17, 27) helfen.

---

## 5.3 Vorhersehbarkeit

Der Nutzer sollte nicht raten müssen, was ein Klick bewirkt.

- **Sichtbarer Zustand** — „Gespeichert" / „Geändert" in der Statuszeile;
  Fortschrittsbalken bei langen Vorgängen (Kapitel 19).
- **Enter und Escape** — im Dialog bestätigen bzw. abbrechen (Kapitel 23).
- **Bestätigung nur bei irreversiblem Schaden** — „Wirklich löschen?" ja;
  bei „Einstellung ändern" nein.

> **Schlecht:** **Löschen** ohne Rückfrage, ohne Undo.  
> **Besser:** Rückfrage oder Rückgängig (wo das `text`-Widget es schon
> mitbringt, Kapitel 16; sonst Anwendungslogik).

---

## 5.4 Informationsdichte

Mehr Widgets bedeuten nicht mehr Nutzen.

- **Gruppieren** — `labelframe` oder Notebook-Reiter statt einer langen
  Liste aller Optionen (Kapitel 18).
- **Progressive Disclosure** — Standardoptionen sichtbar, Expertenwerte
  unter „Erweitert".
- **Tabellen** — nur Spalten zeigen, die zur Aufgabe gehören; Rest optional
  (Kapitel 28).

Wenn alles gleich laut schreit, hört niemand zu.

---

## 5.5 Farbe und visueller Lärm

Farbe ist ein **Akzent**, kein Dekor.

- Wenige Farben: neutrale Flächen, ein Primärton, ein Warn-/Fehlerton.
- **Rot** für Zerstörung und Fehler — nicht für normale Hinweise.
- Bunte Toolbars mit sieben Button-Farben wirken spielerisch, nicht
  professionell.

In Ttk steuert man das über Styles (Kapitel 24), nicht über `-background`
am einzelnen Widget.

---

## 5.6 Tastatur und Maus

Eine gute Desktop-Oberfläche ist **nicht** eine Webseite, die nur mit der
Maus bedienbar ist.

- Häufige Aktionen per Tastatur (Menü-Beschleuniger, Kapitel 21).
- Tab-Reihenfolge folgt der Lesereihenfolge (Kapitel 23).
- Der **Maus-weglegen-Test:** lässt sich die Hauptaufgabe nur mit Tastatur
  erledigen?

Das ist keine Nische — Barrierefreiheit, Power-User und schnelle Datenerfassung
profitieren gleichermaßen.

---

## 5.8 Warum sehen viele Tk-Programme „alt“ aus?

Viele Menschen assoziieren mit Tk sofort ein Bild: graue Kästen, wuchtige
Schrift, Buttons in einer endlosen Reihe — „Windows 95". Das ist **unfair**:
Tk und Ttk können heute moderne Desktop-Oberflächen liefern. Was oft schiefgeht,
sind **Gewohnheiten beim Bauen**, nicht die Technik.

Dieser Abschnitt sammelt die häufigsten Ursachen — jeweils mit **Schlecht** und
**Besser**. Die technische Umsetzung folgt in den Kapiteln 6–12 (Layout),
21–27 (Darstellung) und 36–38 (Gestaltung); Anhang E fasst die Regeln als
Nachschlagewerk zusammen.

---

### 5.8.1 Falsche Abstände (alles klebt zusammen)

**Schlecht** — Widgets ohne `padding`, ohne `pady`, Labels direkt am Eingabefeld:

```
[Name:][________________]
[Email:][_______________]
[Phone:][_______________]
[Save][Cancel][Delete][Help][About]
```

**Besser** — Raster 8/12 px, Luft zwischen Zeilen und Button-Gruppen:

```
  Name
  [________________________]

  E-Mail
  [________________________]

              [Abbrechen]  [Speichern]
```

In Tk: `ttk::frame -padding {12 12}`; Formular `grid -pady 4`; Buttons in
eigenem Frame mit `padx` zwischen Primär- und Sekundäraktion (Anhang E.5).

---

### 5.8.2 Keine Gruppierung

**Schlecht** — 40 Optionen in einer flachen Liste, alles gleich wichtig:

```
☐ Option A   ☐ Option B   ☐ Option C   …   ☐ Option Z
```

**Besser** — `labelframe` oder Notebook-Reiter nach Aufgabe:

```
┌─ Allgemein ─────────────────┐
│ Sprache: [de ▼]             │
│ Start:   [Letzte Datei ▼]   │
└─────────────────────────────┘
┌─ Erweitert ─────────────────┐
│ ☑ Debug-Log                 │
└─────────────────────────────┘
```

Siehe Kapitel 5.4 (Informationsdichte), Kapitel 18 (Container).

---

### 5.8.3 Zu viele gleichwertige Widgets

**Schlecht** — Toolbar mit 20 Text-Buttons nebeneinander:

```
[New][Open][Save][SaveAs][Print][Preview][Cut][Copy][Paste][Find]…
```

**Besser** — Gruppen, Trennlinien, Icons mit Tooltip, seltene Aktionen ins Menü:

```
[📄][📂] | [💾] | [✂][📋] | …     (Rest unter Datei →)
```

Siehe Kapitel 11.3 (Toolbar-Pattern), Kapitel 36 (visuelle Hierarchie).

---

### 5.8.4 Keine visuelle Hierarchie

**Schlecht** — alle Buttons gleich groß, gleiche Schrift überall, kein Primär-Button:

```
        [ OK ]  [ Abbrechen ]  [ Hilfe ]
```

**Besser** — **eine** dominante Aktion (`Primary.TButton`), Rest zurückhaltend:

```
                    [ Abbrechen ]  [■ OK ■]
```

Siehe Kapitel 24/27 (ttk-Styles), Kapitel 36.2 (Akzent-Button).

---

### 5.8.5 Fehlende Ausrichtung

**Schlecht** — Labels mal links, mal über dem Feld, Spalten nicht im Raster:

```
Vorname: [____]     Nachname:
         [____]
E-Mail: [____________________]
```

**Besser** — festes Zwei-Spalten-Grid, Labels `sticky e`, Felder `sticky ew`:

```
     Vorname: [____________]    Nachname: [____________]
      E-Mail: [_______________________________________]
```

Siehe Anhang E.5, Kapitel 8 (`grid`).

---

### 5.8.6 Gemischte Fonts und Classic-Tk-Mischung

**Schlecht** — `button` (classic) neben `ttk::button`, Times neben Helvetica,
`-font` an jedem Widget einzeln gesetzt:

```
[ classic Button ]  [ Ttk Button ]   ← unterschiedliche Höhe
```

**Besser** — durchgängig **Ttk**; Schrift zentral (Kapitel 25, Anhang E.2):

```tcl
ttk::style configure TButton -font {DejaVu Sans 10}
# alle Widgets erben oder nutzen benannte Styles
```

Regel: **Kein** `button`/`label`/`entry` (classic) in neuen Oberflächen,
außer `text`/`canvas` erzwingen es (Kapitel 2.4).

---

### 5.8.7 Falsche Farben

**Schlecht** — jede Toolbar-Schaltfläche eigene `-background`, Regenbogen,
Rot für normale Hinweise:

```
[blau][grün][gelb][rot „Info“][lila]
```

**Besser** — neutrale Flächen, **eine** Primärfarbe, Rot nur für Gefahr:

| Rolle | Verwendung |
|-------|------------|
| Grau/Weiß | Hintergrund, Flächen |
| Blau (ein Ton) | Primäraktion |
| Rot | Löschen, Fehler |

Farben über **ttk::style**, nicht `-background` pro Widget (Kapitel 24, 38).

---

### 5.8.8 Fehlende Weißräume und feste Fenstergröße

**Schlecht** — Fenster exakt auf Designer-Monitor berechnet; verkleinern →
überlappende Widgets, abgeschnittene Texte:

```
wm geometry . 800x600   ;# und nirgends -weight / -expand
```

**Besser** — Wachstumskette, Mindestgröße, Statuszeile:

```tcl
wm minsize . 640 480
# .body mit grid rowconfigure 0 -weight 1
# .content sticky nsew
```

Siehe Kapitel 11 (Responsives Layout), Anhang F.

---

### 5.8.9 Das Standardgerüst (Zielbild)

Viele „alte" Tk-Fenster sind ein einzelner Frame mit Widgets — **ohne** die
Zonen einer modernen Desktop-App. Zielbild für dieses Buch (Details Kap. 11,
Anhang F):

```
+--------------------------------------------------+
| Menü                                             |
+--------------------------------------------------+
| Toolbar                                          |
+-------------+------------------------------------+
| Navigation  |                                    |
| (Treeview)  |         Hauptbereich               |
|             |                                    |
+-------------+------------------------------------+
| Statusbar                                        |
+--------------------------------------------------+
```

Die **Tutorial-Anwendung** des Buches (siehe Vorwort, Kapitel 35) baut dieses
Gerüst Schritt für Schritt auf — ab Kapitel 2 ein leeres Fenster, ab Kapitel 11
das vollständige Layout.

---

### 5.8.10 Kurzdiagnose

Wenn eine Oberfläche „alt" wirkt, in dieser Reihenfolge prüfen:

1. Alles **Ttk**? (nicht classic `button`/`label`)
2. **Abstände** einheitlich? (Anhang E.1)
3. **Eine** Hauptaktion sichtbar?
4. **Gruppiert** statt endloser Liste?
5. Fenster **skalierbar**? (Kapitel 11)
6. Farben **zurückhaltend** über Styles?

Mehr als zwei „Nein" — zuerst dieses Kapitel und Anhang E, dann weiter coden.

---

### § 5.8 — Zusammenfassung

- Der „Tk sieht alt aus"-Eindruck kommt meist von **Layout- und Gestaltungsfehlern**,
  nicht von Tk selbst.
- Die acht Muster oben wiederholen sich in fast jedem schlechten Dialog.
- **Ttk + Raster + Hierarchie + Wachstumskette** sind der schnellste Hebel.
- Die Checkliste in § 5.9 und die Master-Liste in Anhang D ergänzen diese
  qualitative Diagnose um Ja/Nein-Fragen.

*Nächster Abschnitt:* § 5.9 Checkliste — erster Entwurf (bisher § 5.7).

## 5.9 Checkliste — erster Entwurf

Vor dem ersten ernsthaften Layout diese Fragen mit **Ja/Nein** beantworten:

| # | Frage |
|---|--------|
| 1 | Ist klar, was die **eine** Hauptaufgabe dieses Fensters ist? |
| 2 | Gibt es höchstens **eine** visuell dominante Aktion? |
| 3 | Sind Beschriftungen **verständlich** (keine internen Kürzel)? |
| 4 | Sind gleiche Aktionen **gleich benannt und platziert**? |
| 5 | Zeigt die Oberfläche den **Systemzustand** (gespeichert, busy, Fehler)? |
| 6 | Gibt es **keine** unnötigen Bestätigungsdialoge? |
| 7 | Sind Optionen **gruppiert**, nicht in einer endlosen Liste? |
| 8 | Sind Farben **zurückhaltend** (kein Regenbogen)? |
| 9 | Sind **Tastatur**-Wege für Hauptaktionen vorgesehen? |
| 10 | Würde ein Fremder in 30 Sekunden wissen, **wo er klicken soll**? |

Drei oder mehr „Nein" — zuerst das Konzept schärfen, dann `grid` konfigurieren.

---

## Zusammenfassung

- Gute GUIs sind **einfach, konsistent, vorhersehbar** und angemessen dicht.
- Farbe und Hierarchie dienen der Aufgabe, nicht der Dekoration.
- Tastatur und Maus sind gleichberechtigt.
- Die Zehn-Punkte-Checkliste ist der Brückenschlag zu den technischen
  Kapiteln ab Teil 2.

Als Nächstes: **Teil 2 — Layout** — wie Tk Größe und Position mechanisch
verteilt (Kapitel 6 ff.). Die Gestaltungsprinzipien aus diesem Kapitel
bleiben der Maßstab, an dem jedes Layout zu messen ist.
