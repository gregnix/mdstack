# Benutzeroberflächen mit Tcl/Tk

*Stand: 2026-06-16 (Ziel nach Erweiterung Weg C)*

Ein deutschsprachiges Lehrbuch zum Bauen von **professionellen Desktop-Oberflächen**
mit Tcl/Tk — mit Fokus auf das *Modell* hinter Tk (Widget-Baum, Geometry Management,
Event-Loop) **und** auf Gestaltung (Konsistenz, Muster, Designsystem).

## Zielgruppe

- Programmierer mit Vorkenntnissen, die GUIs mit Tcl/Tk bauen wollen
- Tcl-Entwickler, die Layout-Verhalten und Event-Loop wirklich verstehen wollen
- Umsteiger aus Web-/Retained-Mode-Welten
- Entwickler, die nicht nur funktionierende, sondern **gut bedienbare** Oberflächen wollen

## Leitlinie

Keine Magie, keine stillen Notlösungen. Tk verhält sich erklärbar; das Buch macht
die Regeln sichtbar. Gestaltung ist kein Anhang — sie ist Teil des Handwerks.

## Umfang

| Kennzahl | Wert (Ziel) |
|----------|-------------|
| Teile | 8 (+ GUI-Grundsätze, GUI-Design) |
| Kapitel | 38 |
| Anhänge | 6 |
| Sprache | Deutsch (Code Englisch) |
| Tcl/Tk-Fokus | 9.x, mit 8.6-Hinweisen |

## Beispielcode

Lauffähige Demos zu vielen Kapiteln liegen unter [`examples/`](examples/README.md).
Start z. B. mit `wish examples/notizbuch/main.tcl` (Fallstudie Kap. 31/35).

## PDF und HTML bauen (bookkit)

```bash
cd ..
tclsh bookkit/tools/book-build.tcl TclTk-Benutzeroberflaechen/ -number
```

Ausgabe: `TclTk-Benutzeroberflaechen.pdf` / `.html` in `00Books/`. Details: [`BOOKKIT.md`](BOOKKIT.md), Kapitelliste in [`book.tcl`](book.tcl).

## Struktur
