# Bindings und virtuelle Events

*Stand: 2026-05-29*

## Einführung

Ein Binding verknüpft ein Ereignis — Mausklick, Tastendruck, Fokuswechsel
— mit Code. `bind` ist der Befehl dafür, aber das Verhalten hat mehr
Tiefe, als es zunächst scheint: die Prozent-Substitutionen, die dem Code
die Ereignisdaten liefern, die `bindtags`-Reihenfolge, die bestimmt,
*welche* Bindings in welcher Folge feuern, und virtuelle Events als
abstrahierte, plattformunabhängige Ereignisse.

---

## 20.1 `bind` — Widget, Klasse, `all`

Die Grundform verknüpft ein Ereignis an einem Widget mit einem Skript:

```tcl
bind .b <Button-1>     {puts "linke Maustaste"}
bind .e <Return>       {abschicken}
bind .e <KeyRelease>   {filtern}
bind .c <Motion>       {puts "Maus bei %x,%y"}
```

Ereignisse stehen in spitzen Klammern. Sie kombinieren Modifizierer,
Typ und Detail: `<Control-s>`, `<Shift-Button-1>`, `<Double-Button-1>`,
`<KeyPress-Escape>`. Tastenereignisse kann man auch als einzelnes
druckbares Zeichen schreiben (`bind .e a {…}`), Sonderzeichen über ihren
Keysym (`<Return>`, `<Escape>`, `<Tab>`, `<BackSpace>`).

`bind` wirkt nicht nur auf einzelne Widgets, sondern auf drei Ebenen — und
genau das macht es mächtig:

```tcl
bind .e        <Return> {...}    ;# nur dieses eine Widget
bind Entry     <Return> {...}    ;# alle Entry-Widgets (die Klasse)
bind all       <F1>     {hilfe}  ;# jedes Widget der Anwendung
```

Welche dieser Bindings feuern und in welcher Reihenfolge, klärt
Abschnitt 17.3.

---

## 20.2 Die Prozent-Substitutionen

Das Binding-Skript bekommt die Ereignisdaten über **Prozent-Codes**, die
Tk vor der Ausführung ersetzt:

| Code | Bedeutung |
|------|-----------|
| `%W` | das Widget, an dem das Ereignis auftrat |
| `%x` `%y` | Mauskoordinaten relativ zum Widget |
| `%X` `%Y` | Mauskoordinaten relativ zum Bildschirm |
| `%K` | Keysym der Taste (z.B. `Return`, `a`, `Escape`) |
| `%A` | das eingegebene Zeichen (druckbar) |
| `%s` | Zustand der Modifizierer (Shift, Control …) |
| `%b` | gedrückte Maustaste |

```tcl
bind .c <Button-1>   {puts "Klick bei %x,%y in %W"}
bind .e <KeyPress>   {puts "Taste: %K (Zeichen: %A)"}
```

Hier lauert die wichtigste Binding-Falle, und sie ist eine
Substitutionsfalle (Kapitel 1). Die Prozent-Codes ersetzt **Tk** beim
Ereignis — `$`-Variablen ersetzt aber **Tcl** schon bei der
*Definition* des Bindings:

```tcl
# FALSCH: $msg wird beim Klick aufgelöst -- existiert es dann noch?
set msg "Hallo"
bind .b <Button-1> {puts "$msg bei %x,%y"}

# RICHTIG (a): Wert jetzt einbetten, %-Codes als Literal lassen -- mit list
bind .b <Button-1> [list puts "$msg bei %x,%y"]   ;# Achtung: %x,%y werden so NICHT ersetzt!

# RICHTIG (b): Code in {} und Variable global/namespace ansprechen
bind .b <Button-1> {puts "$::msg bei %x,%y"}
```

Variante (b) ist meist der saubere Weg: `{…}` lässt die Prozent-Codes für
Tk stehen, und `$::msg` löst Tcl erst beim Ereignis auf. Wer einen festen
Wert einbetten *und* Prozent-Codes nutzen will, ruft im Binding eine
Prozedur auf und übergibt die Codes als Argumente:

```tcl
proc onClick {w x y wert} {puts "$wert bei $x,$y in $w"}
bind .b <Button-1> [list onClick %W %x %y $msg]
```

Das ist das robusteste Muster überhaupt: ein kurzes Binding, das die
Prozent-Codes und feste Werte an eine echte Prozedur weiterreicht. So
bleibt die Logik testbar und die Substitution eindeutig.

---

## 20.3 `bindtags` — die Reihenfolge der Behandlung

Wenn an einem Widget ein Ereignis auftritt, durchläuft Tk eine **Liste
von Binding-Tags** und feuert für jeden passende Bindings — in dieser
Reihenfolge. Die Standardliste eines Widgets ist:

```tcl
bindtags .e
;# -> .e Entry . all
;#    Widget  Klasse  Toplevel  all
```

Also: erst die widget-eigenen Bindings, dann die der Klasse (hier
`Entry` — das ist, wo das Standardverhalten des Widgets sitzt!), dann die
des Toplevels, zuletzt `all`. Diese Reihenfolge erklärt mehreres:

- Ein widget-eigenes Binding feuert *vor* dem Klassen-Standard. Will man
  das Standardverhalten ganz verhindern, bricht man die Kette mit
  `break` ab:

```tcl
bind .e <Return> {abschicken; break}   ;# break stoppt die weiteren Tags
```

- Das Standardverhalten eines Widgets (Cursor bewegen, Text einfügen)
  steckt in den **Klassen**-Bindings, nicht im Widget. Wer es ändern
  will, ändert die Klasse — oder schiebt eigene Logik davor.

Man kann die Tag-Liste auch umordnen oder eigene Tags einfügen — etwa um
einer Gruppe von Widgets gemeinsames Verhalten zu geben, ohne jedes
einzeln zu binden:

```tcl
# eigenes Tag "Gefahr" vor die Klasse setzen
bindtags .delBtn {Gefahr .delBtn Button . all}
bind Gefahr <Button-1> {if {![bestaetigt]} break}
```

`bindtags` ist selten nötig, aber wenn man es braucht, gibt es keinen
Ersatz — und es ist der Schlüssel zum Verständnis, warum manche Bindings
„nicht greifen" (sie werden von einem früheren Tag mit `break`
abgefangen).

---

## 20.4 Eigene virtuelle Events (`<<…>>`)

Virtuelle Events stehen in doppelten spitzen Klammern und abstrahieren
von konkreten physischen Ereignissen. Tk bringt einige mit —
`<<ComboboxSelected>>`, `<<ListboxSelect>>`, `<<NotebookTabChanged>>`
(Kapitel 15, 18) — und man kann eigene definieren.

Auf ein virtuelles Event bindet man wie auf ein physisches:

```tcl
bind .lb <<ListboxSelect>> {aktualisiereDetails}
```

Eigene virtuelle Events sind das Mittel, um **Komponenten zu entkoppeln**:
Ein Teil der Anwendung *meldet* ein Ereignis, andere Teile *reagieren*
darauf, ohne dass der Sender die Empfänger kennt:

```tcl
# irgendwo: ein Ereignis auslösen
event generate . <<DatenGeladen>>

# anderswo: darauf reagieren
bind . <<DatenGeladen>> {refreshAlleAnsichten}
```

Das ist die Grundlage des Observer-Musters in Tk (Kapitel 30): Statt dass
der ladende Code alle Ansichten direkt aufruft, sendet er ein
`<<DatenGeladen>>`, und jede Ansicht hört selbst darauf. Neue Ansichten
binden sich ein, ohne dass der Sender geändert werden muss — lose
Kopplung mit Bordmitteln.

Man kann ein virtuelles Event auch fest an physische binden, sodass es
plattformübergreifend funktioniert:

```tcl
event add <<Speichern>> <Control-s> <Command-s>   ;# Linux/Win UND macOS
bind . <<Speichern>> {action::save}
```

So schreibt man die Reaktion einmal gegen `<<Speichern>>` und überlässt
Tk die Zuordnung der plattformabhängigen Tasten — sauberer, als überall
`Control` *und* `Command` zu binden.

---

## Zusammenfassung

- `bind` verknüpft Ereignisse mit Code, auf drei Ebenen: Widget, Klasse,
  `all`.
- Prozent-Codes (`%W`, `%x`, `%K` …) liefern Ereignisdaten; sie ersetzt
  Tk, `$`-Variablen ersetzt Tcl schon bei der Definition. Robustestes
  Muster: kurzes Binding ruft Prozedur mit `%`-Codes als Argumenten auf.
- `bindtags` legt Reihenfolge und Umfang fest (Widget → Klasse →
  Toplevel → `all`); Standardverhalten sitzt in der Klasse, `break`
  stoppt die Kette.
- Virtuelle Events (`<<…>>`) abstrahieren und entkoppeln; eigene löst man
  mit `event generate` aus und kann sie über `event add` plattformneutral
  an physische Tasten binden.

Das nächste Kapitel wendet Bindings und Aktionen auf ein konkretes
Element an, das beides bündelt: das Menü.
