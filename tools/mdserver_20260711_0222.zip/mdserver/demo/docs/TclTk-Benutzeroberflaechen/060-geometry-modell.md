# Das Geometry-Management-Modell

*Stand: 2026-05-29*

## Einführung

Die meiste Zeit, die mit Tk-Layout verloren geht, geht an einem
fehlenden Modell verloren — nicht an einem einzelnen Befehl. Wer
versteht, *wer* in Tk über Größe und Position entscheidet und nach
welchen Regeln, schreibt Layout fast nebenbei. Wer es nicht versteht,
schiebt `-fill`, `-expand`, `-sticky` und `-weight` so lange hin und her,
bis es zufällig passt — und wundert sich beim nächsten Fenster.

Dieses Kapitel klärt das Modell, bevor die folgenden Kapitel die drei
konkreten Manager behandeln. Es ist das wichtigste Kapitel in Teil 2.

---

## 6.1 Wer entscheidet über Größe und Position

Ein Widget legt seine Größe und Position **nicht selbst** fest. Das tut
ein **Geometry Manager** — `pack`, `grid` oder `place`. Erzeugt man ein
Widget, ohne es einem Manager zu übergeben, existiert es im Baum, aber es
wird nie gezeichnet:

```tcl
ttk::button .btn -text "Klick"
# .btn existiert -- ist aber unsichtbar, kein Manager hat es platziert
pack .btn
# jetzt sichtbar
```

Das ist die erste und folgenreichste Tatsache: Sichtbarkeit ist nicht
Eigenschaft des Widgets, sondern Folge des Managements. „Mein Widget ist
weg" heißt fast immer „kein Manager".

---

## 6.2 Requested size gegen tatsächliche Größe

Jedes Widget meldet eine **gewünschte Größe** (requested size) — die
Größe, die es bräuchte, um seinen Inhalt natürlich darzustellen. Ein
Label mit dem Text „Stadt:" möchte so breit sein wie dieser Text plus
Rand; ein Entry mit `-width 30` möchte 30 Zeichen breit sein.

```tcl
ttk::label .l -text "Stadt:"
winfo reqwidth  .l    ;# gewünschte Breite (aus dem Inhalt)
winfo reqheight .l    ;# gewünschte Höhe
winfo width     .l    ;# tatsächliche Breite (vom Manager vergeben)
```

Der Geometry Manager nimmt diese Wünsche als Ausgangspunkt und entscheidet
dann, wie viel Platz ein Widget *tatsächlich* bekommt — abhängig vom
verfügbaren Raum und von den Layout-Optionen. Die Differenz zwischen
`reqwidth` und `width` ist genau der Stoff, aus dem `-fill`, `-expand`,
`-sticky` und `-weight` gemacht sind: Sie steuern, was mit dem *Zusatz-
oder Mangelplatz* geschieht.

Ein wichtiger Nebeneffekt: Ändert sich der Inhalt (anderer Text, andere
Schrift), ändert sich die gewünschte Größe — und `pack`/`grid` rechnen das
Layout automatisch neu. Genau das kann `place` nicht (Kapitel 9), weshalb
es für Formulare ungeeignet ist.

---

## 6.3 Die eine Regel: pro Eltern-Widget *ein* Manager

Die zentrale Regel des gesamten Layouts lautet:

> **In einem Eltern-Widget verwaltet man alle Kinder mit demselben
> Manager.** `pack` und `grid` im selben Parent zu mischen ist verboten.

Der Grund liegt im Modell: `pack` und `grid` berechnen die Größe des
Eltern-Widgets aus den Kindern. Verwalten beide dieselben Kinder,
verlangen sie widersprüchliche Größen, und Tk kann in eine
Endlos-Neuberechnung geraten — die Oberfläche hängt.

```tcl
# FALSCH -- pack und grid im selben Parent "."
ttk::label .l -text "Name:"
ttk::entry .e
pack .l
grid .e          ;# Konflikt im selben Eltern-Widget

# RICHTIG -- ein Frame pro Layoutbereich, je ein Manager darin
ttk::frame .form
pack .form -fill both -expand 1
ttk::label .form.l -text "Name:"
ttk::entry .form.e
grid .form.l .form.e -sticky we     ;# grid nur innerhalb .form
```

`place` ist von dieser Regel ausgenommen, weil es die Eltern-Größe nicht
beeinflusst (Abschnitt 5.4) — man darf ein `place`-Overlay über ein
`pack`- oder `grid`-Layout legen. Für `pack` gegen `grid` aber gilt die
Regel strikt.

Die praktische Konsequenz prägt jedes größere Tk-Layout: Man baut es aus
**Frames als Containern**, und in jedem Frame regiert genau ein Manager.
Frames sind in Tk billig; großzügig eingesetzt sind sie das Mittel, mit
dem komplexe Layouts beherrschbar bleiben.

---

## 6.4 Master, Slave und die Propagation

In der Tk-Sprache heißt das verwaltende Eltern-Widget **Master**, das
verwaltete Kind **Slave** (neuere Doku: *content*). `pack` und `grid`
geben die Größenwünsche der Slaves nach oben weiter — die
**Größen-Propagation**: Ein Frame, der drei Buttons enthält, wird genau
so groß, wie die Buttons zusammen brauchen.

Manchmal will man das *nicht* — etwa wenn ein Frame eine feste Größe
behalten soll, unabhängig von seinem Inhalt. Dafür schaltet man die
Propagation ab:

```tcl
ttk::frame .box -width 200 -height 120
pack .box
pack propagate .box 0     ;# .box behält 200x120, ignoriert Inhalt
# (für grid: grid propagate .box 0)
```

Ohne `propagate 0` würde `.box` auf die gewünschte Größe seiner Kinder
schrumpfen oder wachsen. Mit `propagate 0` gilt die per `-width`/`-height`
gesetzte Größe. Das ist der saubere Weg zu fixen Bereichen — nicht das
Erraten von Pixelwerten mit `place`.

---

## 6.5 Wann das Fenster „nicht wachsen will"

Ein häufiges Rätsel: Man zieht das Fenster größer, aber der Inhalt bleibt
oben links kleben und der Rest wird grau. Im Modell ist das kein Rätsel,
sondern die Standardeinstellung: Zusatzplatz wird **nicht** verteilt,
solange man es nicht verlangt.

- Bei `pack` braucht das mitwachsende Widget `-expand 1` (darf den
  Zusatzplatz beanspruchen) *und* `-fill both` (soll ihn auch ausfüllen).
- Bei `grid` braucht die betroffene **Zeile und Spalte**
  `-weight 1` (`grid columnconfigure`/`grid rowconfigure`) *und* das
  Widget `-sticky nsew` (soll die Zelle ausfüllen).

```tcl
# pack: der Textbereich soll allen Zusatzplatz bekommen
text .t
pack .t -fill both -expand 1

# grid: Zelle 0,0 soll wachsen
grid .t -row 0 -column 0 -sticky nsew
grid rowconfigure    . 0 -weight 1
grid columnconfigure . 0 -weight 1
```

`-fill`/`-sticky` ohne `-expand`/`-weight` ist der klassische Fehler: Das
Widget füllt brav seine zugewiesene Zelle — aber die Zelle selbst
bekommt keinen Zusatzplatz, also bleibt alles klein. Erst das Paar aus
„darf wachsen" (`-expand`/`-weight`) und „soll ausfüllen"
(`-fill`/`-sticky`) ergibt ein mitwachsendes Layout.

> **Merksatz:** `-expand`/`-weight` verteilt den *Platz an die Zelle*,
> `-fill`/`-sticky` verteilt den *Platz vom Widget in der Zelle*. Man
> braucht beides.

---

## Zusammenfassung

- Sichtbarkeit kommt vom Geometry Manager, nicht vom Widget.
- Widgets melden eine gewünschte Größe; der Manager vergibt die
  tatsächliche und verteilt Zusatz-/Mangelplatz.
- Pro Eltern-Widget genau ein Manager (`pack` *oder* `grid`); `place`
  darf als Overlay darüberliegen. Komplexe Layouts baut man aus Frames.
- `pack/grid propagate $w 0` hält einen Bereich auf fester Größe.
- Mitwachsen braucht das Paar `-expand`/`-weight` (Zelle) **und**
  `-fill`/`-sticky` (Widget).

Mit diesem Modell sind die folgenden Kapitel zu `pack`, `grid` und
`place` nur noch Konkretisierung. Kapitel 7 beginnt mit dem einfachsten
Manager — `pack`.
