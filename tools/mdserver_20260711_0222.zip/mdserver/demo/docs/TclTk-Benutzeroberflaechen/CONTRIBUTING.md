# Mitwirkung an diesem Buch

Dieses Werk ist ein deutschsprachiges Lehrbuch zum Bauen von
Benutzeroberflächen mit Tcl/Tk. Korrekturen, Ergänzungen und neue
Kapitel sind willkommen.

## Was beigetragen werden kann

### Korrekturen
- Sachfehler (Tk-API, Widget-Verhalten, Beispiele)
- Veraltete Informationen (Tcl/Tk-Versionen)
- Code-Beispiele, die nicht laufen
- Tippfehler, sprachliche Glätte
- Umlaut-Inkonsistenzen

### Ergänzungen
- Praxis-Patterns aus eigener Erfahrung
- Plattform-Hinweise (macOS, Linux, Windows)
- Spezifische Layout- oder Event-Probleme mit Lösung
- Neue Tk-9-Features

### Was nicht passt
- Reine Tcl-Sprachgrundlagen ohne GUI-Bezug (eigenes Werk)
- Datenbank-/SQL-Themen (eigenes Werk)
- Erschöpfende Build-/Paket-Themen (eigenes Werk)

## Stil

- Fließtext Deutsch, Code Englisch (Bezeichner, Kommentare, Strings)
- Erst das Modell, dann die Befehle
- Keine Magie: Regeln sichtbar machen, nicht hinter Faustregeln verstecken
- Code-Beispiele lauffähig halten
