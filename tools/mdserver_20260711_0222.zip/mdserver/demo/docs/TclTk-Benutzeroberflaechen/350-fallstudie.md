# Fallstudie — eine vollständige kleine Anwendung

*Stand: 2026-05-29*

## Einführung

Dieses Kapitel führt zusammen, was die vorherigen einzeln behandelt haben.
Wir bauen eine kleine, aber vollständige Anwendung — einen Notiz-Verwalter
— und gehen vom Entwurf über Layout und Logik bis zum Schliff. Der Code
ist bewusst klein gehalten, aber er folgt allen Prinzipien des Buches:
getrennte Logik, ein Manager pro Frame, Aktionen statt Logik im
`-command`, Tastaturbedienung.

---

## 35.1 Anforderung und Skizze

Die Anwendung soll Notizen verwalten: eine Liste links, der Inhalt der
gewählten Notiz rechts, oben eine Toolbar (Neu, Löschen), unten eine
Statuszeile. Eine Notiz hat einen Titel und einen Text. Daraus ergibt sich
das Drei-Zonen-Layout aus Kapitel 10, mit einem `panedwindow` für die
Teilung Liste/Inhalt:

```
┌─────────────────────────────────────┐
│ [Neu] [Löschen]            Toolbar   │
├──────────────┬──────────────────────┤
│ Notizliste   │ Titel: [__________]  │
│ - Einkauf    │                      │
│ - Ideen      │ [ Textbereich      ] │
│ - ...        │ [                  ] │
├──────────────┴──────────────────────┤
│ 3 Notizen                  Status    │
└─────────────────────────────────────┘
```

Die Trennung aus Kapitel 30 leitet die Aufteilung in Code: ein **Modell**
(die Notizen), eine **View** (die Widgets) und **Aktionen** (Neu, Löschen,
Speichern), verbunden über ein virtuelles Event.

---

## 35.2 Modell und Aktionen

Zuerst die widgetfreie Logik — sie kennt keine Widgets und ist für sich
testbar (Kapitel 33):

```tcl
namespace eval model {
    variable notes {}          ;# Liste von dicts: {id .. title .. body ..}
    variable nextId 1
    variable current ""        ;# id der gewählten Notiz

    proc all {} {variable notes; return $notes}

    proc add {} {
        variable notes; variable nextId
        set id $nextId; incr nextId
        lappend notes [dict create id $id title "Neue Notiz" body ""]
        changed; return $id
    }
    proc delete {id} {
        variable notes
        set notes [lmap n $notes {expr {[dict get $n id] == $id ? [continue] : $n}}]
        changed
    }
    proc update {id title body} {
        variable notes
        set notes [lmap n $notes {
            if {[dict get $n id] == $id} {
                dict set n title $title; dict set n body $body
            }
            set n
        }]
        changed
    }
    proc get {id} {
        variable notes
        foreach n $notes {if {[dict get $n id] == $id} {return $n}}
        return ""
    }
    proc changed {} {event generate . <<NotesChanged>>}   ;# Observer melden
}

namespace eval actions {
    proc new {} {
        set id [model::add]
        set model::current $id
        event generate . <<SelectNote>> -data $id
    }
    proc delete {} {
        if {$model::current ne ""} {
            model::delete $model::current
            set model::current ""
        }
    }
}
```

Das Modell meldet jede Änderung mit `<<NotesChanged>>`, ohne die View zu
kennen — das Observer-Muster aus Kapitel 30. Die Aktionen ändern nur das
Modell; sie zeichnen nichts.

---

## 35.3 Layout und Widgets

Die View baut das Drei-Zonen-Layout und hört auf die Modell-Events. Ränder
zuerst, Hauptbereich zuletzt (Kapitel 7); ein `panedwindow` für die
Teilung (Kapitel 18); `grid` mit Gewicht im Detailbereich (Kapitel 8):

```tcl
namespace eval view {
    proc build {} {
        # Toolbar (oben), Status (unten) -- zuerst, damit sie Platz behalten
        ttk::frame .tb
        pack .tb -side top -fill x
        ttk::button .tb.new -text "Neu" -command actions::new
        ttk::button .tb.del -text "Löschen" -command actions::delete
        pack .tb.new .tb.del -side left -padx 2 -pady 2

        ttk::label .status -anchor w -textvariable ::statusText
        pack .status -side bottom -fill x

        # geteilter Hauptbereich
        ttk::panedwindow .pw -orient horizontal
        pack .pw -fill both -expand 1

        ttk::frame .pw.left
        ttk::treeview .pw.left.tv -show tree -selectmode browse
        pack .pw.left.tv -fill both -expand 1
        .pw add .pw.left -weight 1

        ttk::frame .pw.right -padding 8
        ttk::label .pw.right.lt -text "Titel:"
        ttk::entry .pw.right.title -textvariable ::ui(title)
        text .pw.right.body -wrap word -undo 1
        grid .pw.right.lt    .pw.right.title -sticky we -pady {0 6}
        grid .pw.right.body  -            -sticky nsew -columnspan 2
        grid columnconfigure .pw.right 1 -weight 1
        grid rowconfigure    .pw.right 1 -weight 1
        .pw add .pw.right -weight 3

        # auf Modell- und Auswahl-Events hören (Observer)
        bind . <<NotesChanged>> {view::refreshList}
        bind .pw.left.tv <<TreeviewSelect>> {view::onSelect}
        bind . <<SelectNote>> {view::selectInList %d}

        view::refreshList
    }

    variable itemMap; array set itemMap {}      ;# Treeview-ID -> Notiz-ID

    proc refreshList {} {
        variable itemMap; array unset itemMap
        .pw.left.tv delete [.pw.left.tv children {}]
        foreach n [model::all] {
            set item [.pw.left.tv insert {} end -text [dict get $n title]]
            set itemMap($item) [dict get $n id]
        }
        set ::statusText "[llength [model::all]] Notizen"
    }

    proc onSelect {} {
        variable itemMap
        set sel [.pw.left.tv selection]
        if {$sel eq ""} return
        showNote $itemMap([lindex $sel 0])
    }

    proc showNote {id} {
        set n [model::get $id]
        if {$n eq ""} return
        set model::current $id
        set ::ui(title) [dict get $n title]
        .pw.right.body delete 1.0 end
        .pw.right.body insert end [dict get $n body]
    }
}
```

Jeder Bereich (`.tb`, `.pw.left`, `.pw.right`) ist ein eigener Frame mit
genau einem Manager (Kapitel 6). Die Treeview-ID wird über `itemMap` mit
der Notiz-ID verbunden (Kapitel 28). Anzeige-Werte hängen über
`-textvariable` an `::ui(...)` (Kapitel 29).

---

## 35.4 Schliff: Speichern, Menü, Tastatur, Persistenz

Drei Dinge heben die Anwendung von „funktioniert" auf „benutzbar".

**Speichern bei Bedarf.** Verlässt der Nutzer das Titelfeld oder den Text,
schreibt die View die Änderung ins Modell zurück:

```tcl
bind .pw.right.title <FocusOut> {view::commit}
bind .pw.right.body  <FocusOut> {view::commit}
proc view::commit {} {
    if {$model::current eq ""} return
    model::update $model::current $::ui(title) [.pw.right.body get 1.0 end-1c]
}
```

**Menü und Tastatur.** Dieselben Aktionen über ein Menü und Kürzel
erreichbar machen — die Aktion ist schon zentral definiert (Kapitel 17,
21, 23):

```tcl
menu .m
. configure -menu .m
menu .m.file -tearoff 0
.m add cascade -label "Datei" -menu .m.file -underline 0
.m.file add command -label "Neue Notiz" -command actions::new -accelerator "Ctrl+N"
.m.file add command -label "Löschen" -command actions::delete
.m.file add separator
.m.file add command -label "Beenden" -command {view::commit; destroy .}
bind . <Control-n> {actions::new}
```

**Persistenz.** Beim Beenden die Notizen sichern, beim Start laden — als
einfache Datei. Hier zeigt sich der Wert der Trennung: Das Speichern
arbeitet auf dem Modell, nicht auf den Widgets.

```tcl
proc model::save {path} {
    variable notes
    set f [open $path w]; fconfigure $f -encoding utf-8
    puts $f $notes; close $f
}
proc model::load {path} {
    variable notes
    if {![file exists $path]} return
    set f [open $path r]; fconfigure $f -encoding utf-8
    set notes [read $f]; close $f
    changed
}
wm protocol . WM_DELETE_WINDOW {view::commit; model::save $::dataFile; destroy .}
```

Der Start fügt alles zusammen — schlank, wie die `main.tcl` aus Kapitel 31:

```tcl
package require Tk
set ::dataFile [file join [file dirname [info script]] notes.txt]
set ::statusText ""
view::build
model::load $::dataFile
wm title . "Notizen"
wm minsize . 480 320
```

Die fertige Anwendung ist klein, aber sie ist keine Spielerei: getrennte
Logik (testbar), beobachtbarer Zustand (`<<NotesChanged>>`), Aktionen
statt Logik in Callbacks, ein Manager pro Frame, Tastaturbedienung,
saubere Persistenz beim Beenden. Genau diese Eigenschaften unterscheiden
eine Oberfläche, die mit der Anwendung mitwächst, von einer, die mit der
ersten Erweiterung in sich zusammenfällt.

---

## 35.5 Welches Desktop-Pattern?

Die Notiz-Anwendung aus diesem Kapitel ist kein exotisches Layout — sie
folgt einem **Explorer + Editor-Hybrid** (Kapitel 12.2 und 12.3):

| Zone | Widget | Pattern |
|------|--------|---------|
| Toolbar oben | `ttk::frame` + Buttons | Standardgerüst (Anhang F) |
| Links | `listbox` oder `treeview` | Navigation / Master |
| Rechts | `entry` + `text` | Detail / Editor |
| Unten | `ttk::label` | Statuszeile |

```
┌─────────────────────────────────────┐
│ [Neu] [Löschen]            Toolbar   │  ← Kap. 12.3
├──────────────┬──────────────────────┤
│ Notizliste   │ Titel: [__________]  │  ← Master-Detail
│              │ [ Texteditor       ] │
├──────────────┴──────────────────────┤
│ Status: 3 Notizen                   │  ← Kap. 12.2
└─────────────────────────────────────┘
```

**Warum das wichtig ist:** Wer das Pattern benennen kann, findet in Kap. 12
und Anhang F sofort wiederverwendbare Gerüste — statt jedes Mal neu zu
`pack`en.

**Übung:** Skizzieren Sie Ihre App in Anhang F — welche Zonen fehlen?
Braucht sie eine Sidebar (`panedwindow`) oder reicht `grid`?

Wenn Sie das Buch mit der **Tutorial-Notizbuch-App** (`examples/notizbuch/`)
linear gebaut haben, ist dies dieselbe Anwendung — hier mit vollständiger
Modell-/View-Trennung aus Kap. 30–31.


## 35.6 Designsystem angewendet

Bisher nutzt die Fallstudie Standard-Ttk. Für ein **einheitliches** Erscheinungsbild
binden Sie am Start das Designsystem aus Kapitel 38 ein (Kurzreferenz Anhang E).

```tcl
# lib/ui/theme.tcl — vor Erzeugung der Widgets sourcen
namespace eval ::ui::theme {
    proc init {} {
        ttk::style theme use clam
        ttk::style configure TFrame       -background "#f5f5f5"
        ttk::style configure TLabel       -font {DejaVu Sans 11}
        ttk::style configure Header.TLabel -font {DejaVu Sans 14 bold}
        ttk::style configure Primary.TButton \
            -font {DejaVu Sans 11 bold}
        # Primärfarbe nur für Primary.TButton (Kap. 27, Anhang E.3)
        ttk::style map Primary.TButton \
            -background [list active #1d4ed8 pressed #1e40af]
    }
}
```

In `main.tcl`:

```tcl
package require Tk
source [file join [file dirname [info script]] lib ui theme.tcl]
::ui::theme::init
# danach erst View aufbauen
```

**Konkrete Anpassungen in der Fallstudie:**

| Element | Vorher | Nachher (Anhang E) |
|---------|--------|---------------------|
| Toolbar-Buttons | `TButton` | `Toolbutton` oder einheitliche Höhe |
| **Neu** / Hauptaktion | wie Löschen | optional ein Primary nur im Dialog „Speichern" |
| Formular Titel | `entry` Standard | `padding` am umgebenden Frame `{12 12}` |
| Statuszeile | feste Pixelhöhe | `TLabel`, `anchor w`, `padding {4 2}` |
| Löschen | normaler Button | `Danger.TButton` oder Rückfrage (Kap. 37) |

> **Schlecht:** Nach `theme::init` einzelne `button` (classic) in der Toolbar —
> andere Höhe, anderes Grau.  
> **Besser:** durchgängig Ttk; `text` für Editor bleibt classic, Hintergrund
> an `ttk::style lookup TFrame -background` angeglichen (Kap. 4).

**Vorher/Nachher:** Einmal Screenshots mit Default-`clam` und einmal nach
`::ui::theme::init` — Unterschied oft nur Abstand, eine Primärfarbe und
Font-Stufen; der Effekt wirkt „moderner" (Kap. 36.5 Galerie).


## 35.7 Release-Checkliste — Resize, Tastatur, Abnahme

Bevor Sie die Fallstudie (oder eine eigene App) als „fertig" betrachten,
gehen Sie diese Listen durch. Sie verdichten Kap. 11.8 (Resize-Test),
Kap. 23 (Tastatur) und [Anhang D](../900-anhaenge/anhang-d-checkliste.md).

### A. Resize-Test (7 Schritte)

Am **Hauptfenster** der Notiz-App:

1. [ ] **Startgröße** — Toolbar, Liste, Editor, Status sichtbar und lesbar?
2. [ ] **Halbe Bildschirmbreite** — keine überlappenden Widgets; `text` scrollt?
3. [ ] **`wm minsize`** — auf Minimum ziehen: nichts abgeschnitten?
4. [ ] **Maximiert** — wächst der **Editor** (`text`), nicht nur Randabstand?
5. [ ] **Nur Höhe / nur Breite** ändern — Panedwindow-Teiler noch sinnvoll?
6. [ ] Falls **Notebook** (Einstellungen): jeden Reiter einzeln bei schmaler Breite?
7. [ ] **Tab-Reihenfolge** bei schmalem Fenster noch logisch (Liste → Titel → Text)?

Typische Fixes wenn ein Punkt scheitert:

```tcl
wm minsize . 520 360
grid rowconfigure .body 0 -weight 1
grid columnconfigure .body 1 -weight 1
.text configure -wrap word
```

Siehe Kapitel 11.2 (Wachstumskette).

### B. Tastatur und Dialoge

| # | Prüfung | Erwartung | Kap. |
|---|---------|-----------|------|
| 1 | Tab im Hauptfenster | Liste → Titel → Text → Toolbar (sinnvolle Reihenfolge) | 23 |
| 2 | Strg+N (oder Menü) | Neue Notiz | 21 |
| 3 | Strg+S | Speichern / Status „Gespeichert" | 21, 30 |
| 4 | Entf / Delete | Löschen mit Rückfrage | 37 |
| 5 | Dialog **Speichern unter** | Enter = OK, Escape = Abbrechen | 23 |
| 6 | Modaler Dialog | `grab`, `transient`, Fokus im ersten Feld | 22 |
| 7 | **Maus-weglegen-Test** | Neue Notiz, Titel ändern, speichern — nur Tastatur | 23 |

### C. Release-Checkliste (Kurz — zum Abhaken)

*Vollständige Version: Anhang D, Abschnitt „Release-Checkliste"*

**Bedienbarkeit**

- [ ] Tab-Reihenfolge stimmt
- [ ] Esc schließt Dialog / bricht ab
- [ ] Enter aktiviert Standardbutton
- [ ] Tastaturbedienung für Hauptaufgabe möglich
- [ ] Fokus beim Öffnen sinnvoll gesetzt

**Layout**

- [ ] Fenster skalierbar (Wachstumskette vollständig)
- [ ] Mindestgröße gesetzt und getestet

**Gestaltung**

- [ ] Kontrast ausreichend (Text im `text`-Widget lesbar)
- [ ] Buttons konsistent (Ttk, Anhang E)
- [ ] Primär-Button in Dialogen erkennbar
- [ ] Fehlermeldungen verständlich (z. B. „Datei nicht schreibbar — anderen Ordner wählen")

**Qualität**

- [ ] `tcltest` für `model::` ohne Tk grün (Kap. 33)
- [ ] Anhang D stichprobenartig durchgegangen

### D. Protokoll (optional)

Kurz notieren — z. B. in `TESTING.md` im Projekt:

```
Datum: __________  Tester: __________
Fenster: Notiz-App  Build: __________

Resize 1–7:    [ ] ok  [ ] Fix in Zeile ___ 
Tastatur 1–7:  [ ] ok  [ ] Fix: ___
Release C:     ___/16 Punkte offen

Notizen:
```


### Fazit der Erweiterung (§ 35.5–35.7)

- Die Fallstudie ist ein **Explorer-Editor-Hybrid** — benennbar und wiederholbar.
- **Designsystem** (`::ui::theme::init`) zieht Abstände, Fonts und Primärbutton zusammen.
- **Release** heißt: Resize-Test, Tastatur, Anhang D — nicht nur „läuft auf meinem Rechner".

Damit endet der praktische Bogen des Buches: von Kap. 5 (Kriterien) über Layout
und Widgets bis zur abnahmefähigen kleinen Anwendung. Anhang D bleibt als
Nachschlagewerk für die **nächste** GUI.

## Zusammenfassung

- Vom Entwurf zur Anwendung: Skizze → Modell/Aktionen → View/Layout →
  Schliff. Die Trennung der Schichten (Kapitel 30) strukturiert alles.
- Das Modell kennt keine Widgets und meldet Änderungen über ein virtuelles
  Event; Aktionen mutieren nur das Modell; die View liest, hört und
  zeichnet.
- Layout aus Frames mit je einem Manager, `panedwindow` für die Teilung,
  Treeview mit ID-Mapping, `-textvariable` für die Felder.
- Schliff macht den Unterschied: Speichern bei `<FocusOut>`, Menü und
  Kürzel auf dieselben Aktionen, Persistenz auf dem Modell beim Beenden.

Damit schließt das Buch. Die Anhänge dienen als Nachschlagewerk: eine
Widget-Übersicht (classic gegen Ttk), ein Glossar, häufige Fehler mit
Lösungen und eine Checkliste für gute Tk-Oberflächen.
