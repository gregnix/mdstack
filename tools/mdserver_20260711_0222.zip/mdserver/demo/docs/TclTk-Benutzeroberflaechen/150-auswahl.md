# Auswahl-Widgets

*Stand: 2026-05-29*

## Einführung

Vier Widgets decken Auswahl ab: `checkbutton` und `radiobutton` für
Ja/Nein und Eine-aus-mehreren, `ttk::combobox` für eine Dropdown-Auswahl
mit optionaler freier Eingabe und `listbox` für sichtbare Listen. Alle
koppeln ihren Zustand an Variablen — und genau da liegen die häufigsten
Missverständnisse, etwa Index gegen Wert bei der Combobox.

---

## 15.1 `checkbutton` und `radiobutton` mit `-variable`

Ein **Checkbutton** schaltet eine Variable zwischen zwei Werten um
(Default `1`/`0`):

```tcl
ttk::checkbutton .agb -text "AGB akzeptiert" -variable ::agbOk
set ::agbOk      ;# -> 0 oder 1, je nach Häkchen
```

Eigene Werte statt 1/0 gehen über `-onvalue`/`-offvalue`:

```tcl
ttk::checkbutton .news -text "Newsletter" -variable ::news \
    -onvalue "ja" -offvalue "nein"
```

Mehrere **Radiobuttons**, die sich dieselbe Variable teilen, bilden eine
Gruppe — genau einer ist aktiv, und die Variable hält seinen `-value`:

```tcl
foreach {text wert} {Klein s Mittel m Groß l} {
    ttk::radiobutton .size_$wert -text $text -variable ::size -value $wert
    pack .size_$wert -anchor w
}
set ::size m     ;# wählt vorab "Mittel"
```

Die Gruppenbildung entsteht allein dadurch, dass alle dieselbe
`-variable` nennen. Setzt man die Variable im Code, wechselt die Auswahl
in der Oberfläche mit — wieder die Variablen-Bindung aus Kapitel 29, die
Anzeige und Zustand zusammenhält.

---

## 15.2 `ttk::combobox`

Eine Combobox verbindet ein Eingabefeld mit einer Auswahlliste:

```tcl
ttk::combobox .land -values {Deutschland Österreich Schweiz} \
    -textvariable ::land
pack .land
```

`-values` erwartet eine **echte Liste**. Bei Werten mit Leerzeichen ist
die explizite Listenbildung Pflicht, sonst zerfällt der Wert:

```tcl
# FALSCH -- "New York" wird zu zwei Einträgen
.ort configure -values "New York Berlin"
# RICHTIG
.ort configure -values [list "New York" "Berlin"]
```

Soll der Nutzer *nur* aus der Liste wählen und nichts Eigenes tippen
dürfen, setzt man `-state readonly`:

```tcl
ttk::combobox .land -values {...} -state readonly
```

Eine zentrale Verwechslung: `get` liefert den **Wert**, `current` den
**Index**:

```tcl
.land get        ;# -> "Österreich"  (der Text)
.land current    ;# -> 1             (die Position in -values)
```

Wer den ausgewählten Eintrag braucht, nimmt `get`. `current` ist nur
nützlich, wenn man die Position in der Liste wissen will.

Auf eine Auswahl reagiert man über das virtuelle Event
`<<ComboboxSelected>>` (Kapitel 20):

```tcl
bind .land <<ComboboxSelected>> {
    puts "gewählt: [.land get]"
}
```

Für dynamische Listen füllt `-postcommand` die Werte, *bevor* die
Dropdown aufklappt:

```tcl
ttk::combobox .cb -postcommand {.cb configure -values [aktuelleListe]}
```

---

## 15.3 `listbox` und Selektionsmodi

Die `listbox` ist ein classic-Widget (kein Ttk-Pendant, Kapitel 4) und
zeigt eine scrollbare Liste:

```tcl
listbox .lb -height 8
pack .lb -fill both -expand 1
foreach eintrag {Apfel Birne Kirsche Dattel} {
    .lb insert end $eintrag
}
```

`-selectmode` legt fest, wie viel ausgewählt werden kann:

```tcl
.lb configure -selectmode browse    ;# genau einer (Default für Einzelauswahl)
.lb configure -selectmode single    ;# genau einer, kein Ziehen
.lb configure -selectmode extended  ;# mehrere mit Shift/Strg
.lb configure -selectmode multiple  ;# mehrere per Einzelklick
```

Die aktuelle Auswahl liefert `curselection` als **Indizes**, den Text
holt man per `get`:

```tcl
set indices [.lb curselection]          ;# z.B. {0 2}
foreach i $indices {
    puts [.lb get $i]                    ;# Text am Index
}
```

Auf Auswahländerung reagiert man über `<<ListboxSelect>>`:

```tcl
bind .lb <<ListboxSelect>> {
    set sel [.lb curselection]
    if {[llength $sel]} { puts "gewählt: [.lb get [lindex $sel 0]]" }
}
```

Eine Listbox bringt keine eingebaute Scrollbar mit — die verbindet man
selbst (Muster wie in Kapitel 10):

```tcl
ttk::scrollbar .sb -orient vertical -command {.lb yview}
.lb configure -yscrollcommand {.sb set}
pack .sb -side right -fill y
pack .lb -side left -fill both -expand 1
```

---

## 15.4 Mehrfachauswahl und Synchronisation

Für reine Anzeige- und Auswahllisten genügt die Listbox. Sobald aber
mehrere Spalten, Sortierung oder Baumstruktur ins Spiel kommen, ist
`ttk::treeview` (Kapitel 28) die bessere Wahl — die Listbox bleibt das
Werkzeug für einfache, einspaltige Auswahl.

Ein wiederkehrendes Bedürfnis ist, die Listbox-Auswahl mit einem
Datenmodell synchron zu halten. Da die Listbox selbst keine
Variablen-Kopplung für die Auswahl bietet (anders als Check-/Radiobutton),
führt man sie explizit über `<<ListboxSelect>>` nach:

```tcl
set ::auswahl {}
bind .lb <<ListboxSelect>> {
    set ::auswahl {}
    foreach i [.lb curselection] { lappend ::auswahl [.lb get $i] }
}
```

Das ist kein Mangel des Widgets, sondern eine bewusste Grenze: Wo eine
Auswahl mehrwertig und geordnet ist, gibt es keine sinnvolle einzelne
Variable, die sie spiegelt — also macht man die Synchronisation sichtbar
und explizit, statt sie zu verstecken.

---

## Zusammenfassung

- `checkbutton`/`radiobutton` koppeln über `-variable`; Radiobuttons
  bilden eine Gruppe, indem sie dieselbe Variable teilen.
- `ttk::combobox`: `-values` als echte Liste, `-state readonly` gegen
  freie Eingabe, `get` (Wert) gegen `current` (Index),
  `<<ComboboxSelected>>` als Reaktion.
- `listbox` ist classic, kennt `-selectmode` (browse/single/extended/
  multiple), liefert `curselection` als Indizes und braucht eine manuell
  verbundene Scrollbar.
- Mehrwertige Auswahl synchronisiert man explizit über
  `<<ListboxSelect>>`; für Spalten/Bäume nimmt man `treeview`.

Das nächste Kapitel widmet sich dem mächtigsten Anzeige- und
Eingabe-Widget überhaupt — dem Text-Widget.
