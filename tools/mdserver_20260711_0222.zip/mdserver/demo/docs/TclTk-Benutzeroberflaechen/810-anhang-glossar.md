# Glossar

*Stand: 2026-05-29*

Kurzdefinitionen der zentralen Begriffe dieses Buches. Verweise nennen das
Kapitel, in dem der Begriff eingeführt wird.

**Binding** — Verknüpfung eines Ereignisses (Klick, Tastendruck) mit
einem Skript, hergestellt mit `bind`. (Kapitel 20)

**bindtags** — geordnete Liste von Binding-Ebenen (Widget, Klasse,
Toplevel, `all`), die Tk bei einem Ereignis nacheinander durchläuft.
(Kapitel 20)

**Canvas** — Zeichenfläche mit Retained-Mode-Items; einziges Tk-Widget,
bei dem man eine verwaltete Item-Liste pflegt. (Kapitel 26)

**cget / configure** — Widget-Unterbefehle zum Lesen (`cget`) und
Setzen/Lesen (`configure`) von Optionen. (Kapitel 3)

**classic Tk** — der ursprüngliche Widget-Satz; Aussehen über Optionen.
(Kapitel 4)

**Event-Loop** — die zentrale Schleife, die Ereignisse, Timer und
Neuzeichnen abarbeitet; läuft nicht, solange eigener Code läuft.
(Kapitel 2, 19)

**event generate** — erzeugt ein Ereignis künstlich; Grundlage für
GUI-Tests. (Kapitel 33)

**Geometry Manager** — `pack`, `grid` oder `place`; bestimmt Position und
Größe eines Widgets. Ohne Manager bleibt ein Widget unsichtbar.
(Kapitel 6)

**grab** — lenkt alle Eingaben auf ein Fenster; macht zusammen mit
`tkwait`/`vwait` einen Dialog modal. `grab` allein blockiert nicht.
(Kapitel 22)

**grid** — tabellarischer Geometry Manager (Zeilen/Spalten); Standard für
Formulare. (Kapitel 8)

**Image** — von Tk verwaltetes Bildobjekt (`image create photo`),
unabhängig vom Widget, das es anzeigt. (Kapitel 25)

**Item (Canvas/Treeview)** — ein verwaltetes Element mit eigener ID; im
Canvas eine Grafik, im Treeview eine Zeile. (Kapitel 26, 28)

**Mark** — benannte, mitwandernde Position im Text-Widget. (Kapitel 16)

**Megawidget** — zusammengesetztes Widget, das sich nach außen wie ein
einzelnes verhält; meist mit TclOO gekapselt. (Kapitel 31)

**Mnemonic** — unterstrichener Buchstabe, der mit `Alt` ein Element
aktiviert; gesetzt über `-underline`. (Kapitel 21, 23)

**msgcat** — Tcls Message-Catalog-System für Übersetzungen; zentraler
Befehl `mc`. (Kapitel 32)

**Option-Datenbank** — zentraler Speicher für classic-Widget-Defaults,
gefüllt mit `option add`; wirkt nur bei Erzeugung. (Kapitel 3)

**pack** — linearer Geometry Manager; stapelt Widgets in eine Richtung.
(Kapitel 7)

**Pfadname** — Name eines Widgets, der zugleich seine Position im
Widget-Baum codiert (`.frame.button`). (Kapitel 1)

**place** — absoluter/relativer Geometry Manager; für Overlays und feste
Verhältnisse, nicht für Formulare (propagiert nicht). (Kapitel 9)

**Propagation** — Weitergabe der Größenwünsche der Kinder an das
Eltern-Widget; abschaltbar mit `pack/grid propagate $w 0`. (Kapitel 6)

**requested size** — die Größe, die ein Widget aus seinem Inhalt
wünscht; Ausgangspunkt für den Geometry Manager. (Kapitel 6)

**Starpack / Starkit** — klassisches Auslieferungsformat: Anwendung (+
Interpreter) in einer Datei. (Kapitel 34)

**State (Ttk)** — Zustand eines Ttk-Widgets (`active`, `disabled`,
`focus`, `invalid` …), der sein Aussehen beeinflusst. (Kapitel 24)

**Style (Ttk)** — benannte Sammlung von Aussehen-Eigenschaften je
Widget-Klasse; gesetzt mit `ttk::style configure`/`map`. (Kapitel 24)

**Tag** — benannter Bereich/Gruppe: im Text-Widget für Formatierung und
Verhalten, im Canvas/Treeview für Gruppen. (Kapitel 16, 26, 28)

**Toplevel** — eigenständiges Fenster (`.` oder mit `toplevel` erzeugt),
vom Fenstermanager verwaltet. (Kapitel 2, 22)

**trace** — Mechanismus, der Code bei Lesen/Schreiben/Löschen einer
Variable ausführt; Brücke zwischen Daten und Anzeige. (Kapitel 29)

**Ttk (Themed Tk)** — neuerer, vom System-Theme gestalteter Widget-Satz
(`ttk::`); Aussehen über Styles. (Kapitel 4)

**update / update idletasks** — verarbeitet anstehende Events (`update`,
inkl. Eingaben, Reentrancy-Gefahr) bzw. nur Idle-Aufgaben/Neuzeichnen
(`update idletasks`). (Kapitel 19)

**Variablen-Bindung** — Kopplung von Widget und Variable über
`-textvariable`/`-variable`; bidirektional, wo sinnvoll. (Kapitel 29)

**virtuelles Event** — abstrahiertes Ereignis in `<<…>>`; Grundlage des
Observer-Musters in Tk. (Kapitel 20, 30)

**vwait** — betritt den Event-Loop und blockiert, bis eine Variable
gesetzt wird; verschachtelt nicht parallel. (Kapitel 19, 22)

**Widget-Baum** — die Eltern-Kind-Hierarchie aller Widgets, codiert über
Pfadnamen. (Kapitel 1)

**zipkit** — Tcl-9-Auslieferungsformat auf zipfs-Basis; `main.tcl` unter
`//zipfs:/app` wird automatisch ausgeführt. (Kapitel 34)
