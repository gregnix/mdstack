#!/usr/bin/env wish
# Kap. 31 — Megawidget mit TclOO (SearchBar)
package require Tk
wm title . "Kap. 31 — Megawidget"

oo::class create SearchBar {
    variable Frame Entry Callback

    constructor {parent onSearch} {
        set Callback $onSearch
        set Frame [ttk::frame $parent.search]
        set Entry [ttk::entry $Frame.e]
        set me [self]
        ttk::button $Frame.b -text "Suchen" -command [list $me Search]
        pack $Entry -side left -fill x -expand 1
        pack $Frame.b -side left -padx {4 0}
        bind $Entry <Return> [list $me Search]
    }

    method Search {} {
        variable Callback Entry
        uplevel #0 [list {*}$Callback [$Entry get]]
    }
    method widget {} {
        variable Frame
        return $Frame
    }
    method clear {} {
        variable Entry
        $Entry delete 0 end
    }
}

set ::result ""
ttk::label .res -textvariable ::result -padding 12
pack .res -fill x

set bar [SearchBar new . {apply {{text} {
    set ::result "Suche: [string trim $text]"
}} }]
pack [$bar widget] -fill x -padx 12 -pady 12

ttk::button .clr -text "clear()" -command [list $bar clear]
pack .clr -padx 12
