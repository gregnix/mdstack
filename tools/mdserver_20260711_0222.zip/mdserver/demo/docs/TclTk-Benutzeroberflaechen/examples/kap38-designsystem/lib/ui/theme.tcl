# Kap. 38 — Designsystem (lib/ui/theme.tcl)
namespace eval ::ui::theme {}
set ::ui::theme::libdir [file normalize [file join [file dirname [info script]] .. .. .. lib]]

namespace eval ::ui::token {
    variable space_sm 8
    variable space_md 12
    variable color_primary "#2563eb"
    variable color_danger  "#dc2626"
    variable color_muted   "#6b7280"
    variable color_bg      "#f5f5f5"
}

namespace eval ::ui::theme {
    proc init {} {
        variable ::ui::token
        source [file join $::ui::theme::libdir ui-fonts.tcl]
        ::book::fonts::ensure

        ttk::style theme use clam
        option add *Font [::book::fonts::get body]
        ttk::style configure . -background $::ui::token::color_bg
        ttk::style configure TFrame -background $::ui::token::color_bg
        ttk::style configure TLabel -background $::ui::token::color_bg \
            -font [::book::fonts::get body]
        ttk::style configure Header.TLabel -font [::book::fonts::get head]
        ttk::style configure Primary.TButton -font [::book::fonts::get primary]
        ttk::style configure Danger.TButton -foreground $::ui::token::color_danger
        ttk::style configure Muted.TLabel -foreground $::ui::token::color_muted
    }
}

package provide ui::theme 1.0
