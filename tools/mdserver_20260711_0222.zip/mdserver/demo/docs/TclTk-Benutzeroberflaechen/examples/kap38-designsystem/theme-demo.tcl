#!/usr/bin/env wish
# Kap. 38 — Designsystem-Demo
set here [file dirname [file normalize [info script]]]
source [file join $here lib ui theme.tcl]
package require Tk
::ui::theme::init

wm title . "Kap. 38 — Designsystem"
wm geometry . 480x280

ttk::label .h -text "Design-Tokens angewendet" -style Header.TLabel
pack .h -padx $::ui::token::space_md -pady $::ui::token::space_md

ttk::labelframe .f -text "Aktionen" -padding $::ui::token::space_md
pack .f -fill x -padx $::ui::token::space_md -pady $::ui::token::space_sm

ttk::button .f.ok  -text "Speichern" -style Primary.TButton
ttk::button .f.del -text "Löschen" -style Danger.TButton
ttk::button .f.cn  -text "Abbrechen"
pack .f.ok .f.del .f.cn -side left -padx 4

ttk::label .hint -text "Einheitliche Abstände, Schrift, Button-Hierarchie." \
    -style Muted.TLabel -padding $::ui::token::space_md
pack .hint -anchor w
