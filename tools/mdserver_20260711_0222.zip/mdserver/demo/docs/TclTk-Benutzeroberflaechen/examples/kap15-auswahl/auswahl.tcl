#!/usr/bin/env wish
# Kap. 15 — Auswahl-Widgets
package require Tk
wm title . "Kap. 15 — Auswahl"

set ::backup 1
set ::fmt pdf
set ::lang de
set ::summary ""

ttk::labelframe .f -text "Export" -padding 12
pack .f -fill both -expand 1 -padx 12 -pady 12

ttk::checkbutton .f.bk -text "Backup erstellen" -variable ::backup
ttk::radiobutton .f.r1 -text "PDF"  -value pdf  -variable ::fmt
ttk::radiobutton .f.r2 -text "HTML" -value html -variable ::fmt
ttk::label .f.ll -text "Sprache:"
ttk::combobox .f.lang -values {de en fr} -textvariable ::lang -state readonly -width 8
ttk::label .f.lf -text "Format:"
ttk::label .f.out -textvariable ::summary -foreground "#666"
pack .f.bk -anchor w -pady 2
pack .f.lf -anchor w -pady {8 2}
pack .f.r1 .f.r2 -anchor w -padx 16
pack .f.ll .f.lang -side left -pady 8 -padx {0 8}
pack .f.out -anchor w -pady 8

proc refreshSummary {} {
    set ::summary "Gewählt: $::fmt, Backup=$::backup, Sprache=$::lang"
}
foreach v {backup fmt lang} {
    trace add variable ::$v write {apply {{args} { refreshSummary }}}
}
refreshSummary
