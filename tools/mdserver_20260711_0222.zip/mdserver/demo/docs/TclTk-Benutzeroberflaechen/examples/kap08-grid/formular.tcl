#!/usr/bin/env wish
# Kap. 8 — grid-Formular (Kapitel 8.1, 8.3)
package require Tk
wm title . "Kap. 8 — grid Formular"
ttk::labelframe .f -text "Adresse" -padding 12
pack .f -fill both -expand 1 -padx 12 -pady 12

ttk::label .f.ln -text "Name:"
ttk::entry .f.en
ttk::label .f.ls -text "Stadt:"
ttk::entry .f.es
ttk::label .f.ln2 -text "Notiz:"
text .f.notes -height 4 -width 40

grid .f.ln  -row 0 -column 0 -sticky e  -padx {0 8} -pady 4
grid .f.en   -row 0 -column 1 -sticky ew -pady 4
grid .f.ls   -row 1 -column 0 -sticky e  -padx {0 8} -pady 4
grid .f.es   -row 1 -column 1 -sticky ew -pady 4
grid .f.ln2  -row 2 -column 0 -sticky ne -padx {0 8} -pady 4
grid .f.notes -row 2 -column 1 -sticky nsew -pady 4

grid columnconfigure .f 1 -weight 1
grid rowconfigure    .f 2 -weight 1
