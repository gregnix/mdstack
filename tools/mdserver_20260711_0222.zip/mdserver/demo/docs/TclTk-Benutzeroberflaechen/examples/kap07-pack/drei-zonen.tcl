#!/usr/bin/env wish
# Kap. 7 — pack: side, fill, expand (Kapitel 7.1–7.2)
package require Tk
wm title . "Kap. 7 — pack"
ttk::frame .top
ttk::label  .top.l -text "Toolbar (top, fill x)"
pack .top.l -padx 8 -pady 4
pack .top -side top -fill x

text .content -wrap word -height 8
.content insert end "Hauptbereich: -fill both -expand 1\n\nFenster vergrößern — dieser Bereich wächst mit."
pack .content -fill both -expand 1 -padx 4 -pady 4

ttk::label .status -text "Statuszeile (bottom, fill x)" -relief sunken -padding 4
pack .status -side bottom -fill x
