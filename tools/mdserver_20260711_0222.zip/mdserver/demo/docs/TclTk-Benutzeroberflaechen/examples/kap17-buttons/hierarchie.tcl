#!/usr/bin/env wish
# Kap. 17 — Button-Hierarchie
package require Tk
source [file join [file dirname [info script]] .. lib ui-fonts.tcl]
::book::fonts::ensure
wm title . "Kap. 17 — Buttons"

ttk::style configure Primary.TButton -font [::book::fonts::get primarySm]

ttk::labelframe .dlg -text "Speichern?" -padding 16
pack .dlg -fill both -expand 1 -padx 20 -pady 20

ttk::label .dlg.msg -text "Änderungen vor dem Schließen speichern?"
pack .dlg.msg -pady {0 16}

ttk::frame .dlg.btn
pack .dlg.btn -fill x
ttk::button .dlg.btn.cancel -text "Abbrechen" -command {destroy .}
ttk::button .dlg.btn.save   -text "Speichern" -style Primary.TButton \
    -command { tk_messageBox -message "Gespeichert." -type ok; destroy . }
pack .dlg.btn.save   -side right -padx 4
pack .dlg.btn.cancel -side right -padx 4

bind . <Escape> {destroy .}
bind . <Return> {.dlg.btn.save invoke}
