#!/usr/bin/env wish
# Kap. 22 — Dialoge und modales Toplevel
package require Tk
wm title . "Kap. 22 — Dialoge"

proc showModal {} {
    set w .modal
    if {[winfo exists $w]} { destroy $w }
    toplevel $w
    wm title $w "Einstellungen"
    wm transient $w .
    wm geometry $w 320x160+[expr {[winfo rootx .]+40}]+[expr {[winfo rooty .]+40}]
    ttk::label $w.l -text "Modales Fenster — Hauptfenster blockiert nicht\n(wm grab ist optional hier weggelassen)." \
        -padding 12 -justify left
    pack $w.l -fill both -expand 1
    ttk::button $w.ok -text "Schließen" -command [list destroy $w]
    pack $w.ok -pady 8
    bind $w <Escape> [list destroy $w]
}

ttk::frame .f -padding 20
pack .f -fill both -expand 1
ttk::button .f.msg -text "tk_messageBox" -command {
    tk_messageBox -title "Info" -message "Native Meldung des Systems." -type ok
}
ttk::button .f.modal -text "Modales Toplevel" -command showModal
pack .f.msg .f.modal -pady 6 -fill x
