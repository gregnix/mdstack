#!/usr/bin/env wish
# Kap. 27 — ttk::style
package require Tk
source [file join [file dirname [info script]] .. lib ui-fonts.tcl]
::book::fonts::ensure
wm title . "Kap. 27 — Ttk-Styles"

ttk::style theme use clam
ttk::style configure Header.TLabel -font [::book::fonts::get head]
ttk::style configure Primary.TButton -font [::book::fonts::get primarySm]
ttk::style configure Danger.TButton -foreground #b00020

ttk::label .h -text "Stil-Vergleich" -style Header.TLabel
pack .h -padx 16 -pady {16 8}

ttk::frame .f -padding 12
pack .f -fill x -padx 16
ttk::button .f.std -text "Standard TButton"
ttk::button .f.pri -text "Primary.TButton" -style Primary.TButton
ttk::button .f.dan -text "Danger.TButton" -style Danger.TButton
pack .f.std .f.pri .f.dan -side left -padx 4

ttk::labelframe .g -text "Gruppe" -padding 8
pack .g -fill x -padx 16 -pady 16
ttk::label .g.l -text "Labelframe + einheitliche Abstände (padding 8)."
