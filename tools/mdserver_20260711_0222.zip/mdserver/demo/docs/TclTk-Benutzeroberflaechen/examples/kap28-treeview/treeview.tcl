#!/usr/bin/env wish
# Kap. 28 — treeview als Tabelle und Baum
package require Tk
wm title . "Kap. 28 — Treeview"
wm geometry . 560x320

ttk::notebook .nb
pack .nb -fill both -expand 1 -padx 8 -pady 8

ttk::frame .nb.tab
ttk::frame .nb.tree
.nb add .nb.tab -text "Tabelle"
.nb add .nb.tree -text "Baum"

ttk::treeview .nb.tab.tv -columns {name size date} -show headings -height 8
pack .nb.tab.tv -fill both -expand 1 -padx 4 -pady 4
.nb.tab.tv heading name  -text "Name"
.nb.tab.tv heading size  -text "Größe"
.nb.tab.tv heading date  -text "Datum"
.nb.tab.tv insert {} end -values {"Dokument.txt" "12 KB" "2026-01-15"}
.nb.tab.tv insert {} end -values {"Bild.png" "245 KB" "2026-01-14"}

ttk::treeview .nb.tree.tv -show tree -height 10
pack .nb.tree.tv -fill both -expand 1 -padx 4 -pady 4
set docs [.nb.tree.tv insert {} end -text "Dokumente" -open 1]
set work [.nb.tree.tv insert $docs end -text "Arbeit"]
.nb.tree.tv insert $work end -text "Bericht.docx"
.nb.tree.tv insert $docs end -text "Privat"
