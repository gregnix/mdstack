#!/usr/bin/env wish
# Kap. 21 — Menüleiste und Kontextmenü
package require Tk
wm title . "Kap. 21 — Menüs"

namespace eval action {
    proc new {}  { tk_messageBox -message "Neu" -type ok }
    proc open {} { tk_messageBox -message "Öffnen" -type ok }
}

menu .menubar
. configure -menu .menubar
menu .menubar.file -tearoff 0
.menubar add cascade -label "Datei" -menu .menubar.file -underline 0
.menubar.file add command -label "Neu"    -command action::new -accelerator "Ctrl+N"
.menubar.file add command -label "Öffnen" -command action::open -accelerator "Ctrl+O"
.menubar.file add separator
.menubar.file add command -label "Beenden" -command destroy

menu .menubar.view -tearoff 0
.menubar add cascade -label "Ansicht" -menu .menubar.view
set ::showLines 1
.menubar.view add checkbutton -label "Zeilennummern" -variable ::showLines

menu .ctx -tearoff 0
.ctx add command -label "Kopieren" -command { tk_messageBox -message "Kopieren" }
.ctx add command -label "Einfügen" -command { tk_messageBox -message "Einfügen" }

ttk::label .hint -text "Rechtsklick für Kontextmenü.\nMenü Datei → Neu (Ctrl+N)." \
    -padding 24 -justify left
pack .hint -fill both -expand 1
bind .hint <Button-3> {tk_popup .ctx %X %Y}
bind . <Control-n> action::new
bind . <Control-o> action::open
