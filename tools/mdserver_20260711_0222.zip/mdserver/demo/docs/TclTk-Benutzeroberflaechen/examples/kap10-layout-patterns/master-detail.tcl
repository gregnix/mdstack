#!/usr/bin/env wish
# Kap. 10/12 — Master-Detail mit panedwindow
package require Tk
source [file join [file dirname [info script]] .. lib ui-fonts.tcl]
::book::fonts::ensure
wm title . "Kap. 10 — Master-Detail"
wm geometry . 640x400

ttk::frame .tb
ttk::button .tb.new -text "Neu"
pack .tb.new -side left -padx 4 -pady 4
pack .tb -side top -fill x

ttk::panedwindow .pw -orient horizontal
pack .pw -fill both -expand 1

listbox .pw.left -exportselection 0
foreach item {Alpha Beta Gamma Delta} { .pw.left insert end $item }
.pw add .pw.left -weight 1

ttk::frame .pw.right -padding 8
ttk::label .pw.right.h -text "Details" -font [::book::fonts::get detail]
ttk::label .pw.right.d -text "Eintrag links wählen." -wraplength 320
pack .pw.right.h -anchor w
pack .pw.right.d -anchor w -pady 8
.pw add .pw.right -weight 2

bind .pw.left <<ListboxSelect>> {
    set sel [.pw.left curselection]
    if {$sel ne ""} {
        .pw.right.d configure -text "Ausgewählt: [.pw.left get $sel]"
    }
}

ttk::label .status -text "Status: bereit" -relief sunken -padding 4
pack .status -side bottom -fill x
