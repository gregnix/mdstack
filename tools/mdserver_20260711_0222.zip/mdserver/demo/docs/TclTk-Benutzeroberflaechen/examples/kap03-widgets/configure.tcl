#!/usr/bin/env wish
# Kap. 3 — Widget erzeugen, configure, cget
package require Tk
source [file join [file dirname [info script]] .. lib ui-fonts.tcl]
::book::fonts::ensure
wm title . "Kap. 3 — Widgets"

ttk::label .l -text "Hallo"
pack .l -padx 12 -pady 8

set ::size 11
proc bumpFont {} {
    incr ::size 2
    font configure [::book::fonts::get body] -size $::size
    .info configure -text "Schriftgröße: $::size pt"
}

ttk::button .b -text "Größer" -command bumpFont
pack .b -padx 12 -pady 4

ttk::label .info -text "Schriftgröße: 11 pt" -foreground "#666"
pack .info -padx 12 -pady 8

ttk::style configure TLabel -font [::book::fonts::get body]
