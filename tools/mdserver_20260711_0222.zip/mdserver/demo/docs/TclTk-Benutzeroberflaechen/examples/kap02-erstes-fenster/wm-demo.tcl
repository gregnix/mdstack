#!/usr/bin/env wish
# Kap. 2 — wm, geometry, minsize (Kapitel 2.2)
package require Tk
wm title    . "Kap. 2 — wm"
wm geometry . 480x320+100+80
wm minsize  . 320 240
ttk::label .info -text "Titel, Größe und Mindestgröße per wm gesetzt." -padding 16
pack .info -fill both -expand 1
