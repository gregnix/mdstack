#!/usr/bin/env wish
# Kap. 2 — WM_DELETE_WINDOW abfangen (Kapitel 2.5)
package require Tk
wm title . "Kap. 2 — Beenden bestätigen"
ttk::label .l -text "Schließen-Kreuz oder Button — Rückfrage erscheint." -padding 20
ttk::button .quit -text "Beenden" -command {
    if {[tk_messageBox -type yesno -icon question \
            -title "Beenden" -message "Wirklich beenden?"] eq "yes"} {
        destroy .
    }
}
pack .l .quit -padx 12 -pady 8
wm protocol . WM_DELETE_WINDOW {
    if {[tk_messageBox -type yesno -icon question \
            -title "Beenden" -message "Wirklich beenden?"] eq "yes"} {
        destroy .
    }
}
