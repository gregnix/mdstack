#!/usr/bin/env wish
# Kap. 2 — kleinstes Fenster (Kapitel 2.1)
package require Tk
wm title . "Kap. 2 — Hallo Tk"
button .hello -text "Hallo Tk" -command exit
pack .hello -padx 20 -pady 20
