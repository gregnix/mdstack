#!/usr/bin/env tclsh
# Prüft Modul-Dateien ohne GUI auf Syntaxfehler.
set root [file dirname [info script]]
set ok 0
set fail 0
foreach f {
    lib/ui-fonts.tcl
    notizbuch/lib/model.tcl
    notizbuch/lib/actions.tcl
} {
    set path [file join $root $f]
    if {![file exists $path]} continue
    if {[catch {uplevel #0 [list source $path]} err]} {
        puts "FAIL  $f\n      $err"
        incr fail
    } else {
        puts "OK    $f"
        incr ok
    }
}
puts "\n$ok ok, $fail failed (GUI-Demos bitte mit wish starten)"
exit [expr {$fail > 0}]
