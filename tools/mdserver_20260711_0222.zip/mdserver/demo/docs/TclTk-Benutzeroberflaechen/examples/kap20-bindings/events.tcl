#!/usr/bin/env wish
# Kap. 20 — Bindings und virtuelle Events
package require Tk
wm title . "Kap. 20 — Bindings"

set ::count 0
set ::log ""

ttk::label .info -text "Klick, Doppelklick, Taste c, oder Button unten."
pack .info -padx 12 -pady 8

ttk::label .out -textvariable ::log -relief sunken -padding 8 -anchor w
pack .out -fill x -padx 12 -pady 4

ttk::button .fire -text "Virtuelles Event auslösen" \
    -command {event generate . <<DemoPing>>}
pack .fire -pady 8

bind . <<DemoPing>> {
    append ::log "Event <<DemoPing>> empfangen\n"
    .out configure -textvariable ::log
}
bind . <Button-1> {
    append ::log "Einfachklick\n"
}
bind . <Double-Button-1> {
    append ::log "Doppelklick\n"
}
bind . <Key-c> {
    append ::log "Taste c\n"
}
