#!/usr/bin/env wish
# Kap. 18 — Notebook, Panedwindow, Labelframe
package require Tk
wm title . "Kap. 18 — Container"
wm geometry . 560x360

ttk::notebook .nb
pack .nb -fill both -expand 1 -padx 8 -pady 8

ttk::frame .nb.allg
ttk::frame .nb.erw
.nb add .nb.allg -text "Allgemein"
.nb add .nb.erw  -text "Erweitert"

ttk::labelframe .nb.allg.opt -text "Optionen" -padding 8
pack .nb.allg.opt -fill x -padx 8 -pady 8
ttk::checkbutton .nb.allg.opt.a -text "Automatisch speichern"
ttk::checkbutton .nb.allg.opt.b -text "Backups behalten"
pack .nb.allg.opt.a .nb.allg.opt.b -anchor w -pady 2

ttk::panedwindow .nb.erw.pw -orient horizontal
pack .nb.erw.pw -fill both -expand 1 -padx 4 -pady 4
listbox .nb.erw.pw.left
.nb.erw.pw.left insert 0 "Eintrag A" "Eintrag B"
ttk::label .nb.erw.pw.right -text "Detailbereich\n(Sash ziehen)" -padding 12
.nb.erw.pw add .nb.erw.pw.left  -weight 1
.nb.erw.pw add .nb.erw.pw.right -weight 2

bind .nb <<NotebookTabChanged>> {
    set t [.nb tab [.nb select] -text]
    wm title . "Kap. 18 — Reiter: $t"
}
