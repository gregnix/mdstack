# Beispielcode zum Buch *Benutzeroberflächen mit Tcl/Tk*

Lauffähige Demos zu den Kapiteln. Start mit **wish** (Tk 8.6 oder 9.x):

```bash
wish examples/kap02-erstes-fenster/hello.tcl
wish examples/notizbuch/main.tcl
```

Alle Demos sind bewusst **klein und selbsterklärend** — jeweils ein Fenster, ein Konzept.

## Übersicht

| Verzeichnis / Datei | Kapitel | Inhalt |
|---------------------|---------|--------|
| `kap02-erstes-fenster/` | 2 | Hallo-Fenster, `wm`, sauberes Beenden |
| `kap03-widgets/` | 3 | `configure`, `cget` |
| `kap04-classic-ttk/` | 4 | classic vs. Ttk nebeneinander |
| `kap07-pack/` | 7 (Datei 07) | `pack`: side, fill, expand, Drei-Zonen-Gerüst |
| `kap08-grid/` | 8 | Formular mit `grid` und `-weight` |
| `kap10-layout-patterns/` | 10 | Master-Detail mit `panedwindow` |
| `kap12-desktop-patterns/` | 12 | Toolbar + Status + Hauptbereich |
| `kap14-eingabe/` | 14 | Entry, Validierung, `FocusOut` |
| `kap15-auswahl/` | 15 | Checkbutton, Radiobutton, Combobox |
| `kap16-text/` | 16 | Text-Widget, Tags |
| `kap17-buttons/` | 17 | Button-Hierarchie, `-default` |
| `kap18-container/` | 18 | Notebook, Panedwindow, Labelframe |
| `kap20-bindings/` | 20 | Events, virtuelle Events, `%`-Platzhalter |
| `kap21-menues/` | 21 | Menüleiste, Kontextmenü, Beschleuniger |
| `kap22-dialoge/` | 22 | `tk_messageBox`, modales Toplevel |
| `kap26-canvas/` | 26 | Items, Tags, Scrollregion |
| `kap27-ttk-style/` | 27 | Eigene `ttk::style`-Klassen |
| `kap28-treeview/` | 28 | Tabelle und Baum |
| `kap29-variablen/` | 29 | `-textvariable`, Trace, `FocusOut` |
| `kap31-megawidget/` | 31 | TclOO-Suchleiste (Megawidget) |
| `kap38-designsystem/` | 38 | Design-Tokens, `::ui::theme::init` |
| `lib/ui-fonts.tcl` | — | gemeinsame `font create`-Hilfe für ttk (statt `{DejaVu Sans …}`) |
| `notizbuch/` | 31, 35 | Vollständige Fallstudie (Modell/View/Aktionen) |

Kapitel ohne eigenes Skript (Konzept, Checklisten, HIG): 1, 3–6, 9, 11, 13, 16, 19, 23–25, 30, 32–37, Anhänge — oft in `notizbuch/` oder anderen Demos mit abgedeckt.

## Syntax prüfen (ohne GUI)

```bash
tclsh examples/check-syntax.tcl
```

## Notizbuch-App (Kap. 35)

```bash
wish examples/notizbuch/main.tcl
```

Speichert Notizen in `examples/notizbuch/notes.txt` beim Beenden.
