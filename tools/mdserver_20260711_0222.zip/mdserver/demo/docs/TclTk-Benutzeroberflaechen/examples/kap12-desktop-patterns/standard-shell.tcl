#!/usr/bin/env wish
# Kap. 12 — Standardgerüst: Toolbar, Hauptbereich, Status
package require Tk
wm title . "Kap. 12 — Desktop-Pattern"
wm geometry . 640x400

ttk::frame .tb
ttk::button .tb.open -text "Öffnen"
ttk::button .tb.save -text "Speichern"
pack .tb.open .tb.save -side left -padx 4 -pady 4
pack .tb -side top -fill x

text .main -wrap word
.main insert end "Hauptbereich (-fill both -expand 1)\n\nToolbar oben, Status unten — Anhang F."
pack .main -fill both -expand 1 -padx 4 -pady 4

ttk::label .status -text "Bereit" -relief sunken -padding 4 -anchor w
pack .status -side bottom -fill x
