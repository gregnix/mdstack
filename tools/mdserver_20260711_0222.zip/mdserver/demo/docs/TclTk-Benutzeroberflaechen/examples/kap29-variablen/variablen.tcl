#!/usr/bin/env wish
# Kap. 29 — textvariable und Trace
package require Tk
wm title . "Kap. 29 — Variablen"

set ::name ""
set ::preview "(leer)"

ttk::labelframe .f -text "Live-Vorschau" -padding 12
pack .f -fill both -expand 1 -padx 12 -pady 12

ttk::label .f.ln -text "Name:"
ttk::entry .f.en -textvariable ::name -width 30
ttk::label .f.lp -textvariable ::preview -foreground "#2563eb" -wraplength 360

grid .f.ln -row 0 -column 0 -sticky e -padx {0 8} -pady 4
grid .f.en -row 0 -column 1 -sticky ew -pady 4
grid .f.lp -row 1 -column 0 -columnspan 2 -sticky w -pady 8
grid columnconfigure .f 1 -weight 1

trace add variable ::name write {apply {{n1 n2 op} {
    set t [string trim $::name]
    if {$t eq ""} {
        set ::preview "(leer)"
    } else {
        set ::preview "Hallo, $t!"
    }
}}}
