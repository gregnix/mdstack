#!/usr/bin/env wish
# Kap. 26 — Canvas: Items, Tags, Scrollen
package require Tk
wm title . "Kap. 26 — Canvas"
wm geometry . 520x400

canvas .c -background white -scrollregion {0 0 800 600} \
    -xscrollcommand {.hsb set} -yscrollcommand {.vsb set}
ttk::scrollbar .vsb -orient vertical   -command {.c yview}
ttk::scrollbar .hsb -orient horizontal -command {.c xview}
grid .c   -row 0 -column 0 -sticky nsew
grid .vsb -row 0 -column 1 -sticky ns
grid .hsb -row 1 -column 0 -sticky ew
grid rowconfigure . 0 -weight 1
grid columnconfigure . 0 -weight 1

.c create rectangle 50 50 200 120 -fill "#e0e0e0" -outline black -tags box
.c create oval 120 40 220 100 -fill orange -tags box
.c create text 280 80 -text "Tags: box" -anchor w
.c create line 10 10 100 100 -fill blue -width 2 -tags line

ttk::frame .tb
ttk::button .tb.yellow -text "box → gelb" -command {.c itemconfigure box -fill yellow}
ttk::button .tb.red    -text "line → rot"  -command {.c itemconfigure line -fill red}
pack .tb.yellow .tb.red -side left -padx 4 -pady 4
grid .tb -row 2 -column 0 -columnspan 2 -sticky ew

bind .c <ButtonPress-1> {%W scan mark %x %y}
bind .c <B1-Motion>     {%W scan dragto %x %y 1}
