# Kap. 35 — Modell (widgetfrei, testbar)
namespace eval model {
    variable notes {}
    variable nextId 1
    variable current ""

    proc all {} { variable notes; return $notes }

    proc add {} {
        variable notes
        variable nextId
        set id $nextId
        incr nextId
        lappend notes [dict create id $id title "Neue Notiz" body ""]
        changed
        return $id
    }

    proc delete {id} {
        variable notes
        set notes [lmap n $notes {
            if {[dict get $n id] == $id} { continue }
            set n
        }]
        changed
    }

    proc update {id title body} {
        variable notes
        set notes [lmap n $notes {
            if {[dict get $n id] == $id} {
                dict set n title $title
                dict set n body $body
            }
            set n
        }]
        changed
    }

    proc get {id} {
        variable notes
        foreach n $notes {
            if {[dict get $n id] == $id} { return $n }
        }
        return ""
    }

    proc changed {} {
        event generate . <<NotesChanged>>
    }

    proc save {path} {
        variable notes
        set f [open $path w]
        fconfigure $f -encoding utf-8
        puts $f $notes
        close $f
    }

    proc load {path} {
        variable notes
        if {![file exists $path]} { return }
        set f [open $path r]
        fconfigure $f -encoding utf-8
        set notes [read $f]
        close $f
        if {$notes eq ""} { set notes {} }
        variable nextId
        set nextId 1
        foreach n $notes {
            set id [dict get $n id]
            if {$id >= $nextId} { set nextId [expr {$id + 1}] }
        }
        changed
    }
}
