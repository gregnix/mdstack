# Kap. 35 — View (Widgets, hört auf Modell-Events)
namespace eval view {
    variable itemMap
    array set itemMap {}

    proc build {} {
        ttk::frame .tb
        pack .tb -side top -fill x
        ttk::button .tb.new -text "Neu" -command actions::new
        ttk::button .tb.del -text "Löschen" -command actions::delete
        pack .tb.new .tb.del -side left -padx 2 -pady 2

        ttk::label .status -anchor w -textvariable ::statusText
        pack .status -side bottom -fill x

        ttk::panedwindow .pw -orient horizontal
        pack .pw -fill both -expand 1

        ttk::frame .pw.left
        ttk::treeview .pw.left.tv -show tree -selectmode browse
        pack .pw.left.tv -fill both -expand 1
        .pw add .pw.left -weight 1

        ttk::frame .pw.right -padding 8
        ttk::label .pw.right.lt -text "Titel:"
        ttk::entry .pw.right.title -textvariable ::ui(title)
        text .pw.right.body -wrap word -undo 1
        grid .pw.right.lt    .pw.right.title -sticky we -pady {0 6}
        grid .pw.right.body  -            -sticky nsew -columnspan 2
        grid columnconfigure .pw.right 1 -weight 1
        grid rowconfigure    .pw.right 1 -weight 1
        .pw add .pw.right -weight 3

        bind . <<NotesChanged>> {view::refreshList}
        bind .pw.left.tv <<TreeviewSelect>> {view::onSelect}
        bind . <<SelectNote>> {view::selectInList %d}
        bind .pw.right.title <FocusOut> {view::commit}
        bind .pw.right.body  <FocusOut> {view::commit}

        buildMenu
        refreshList
    }

    proc buildMenu {} {
        menu .m
        . configure -menu .m
        menu .m.file -tearoff 0
        .m add cascade -label "Datei" -menu .m.file -underline 0
        .m.file add command -label "Neue Notiz" -command actions::new -accelerator "Ctrl+N"
        .m.file add command -label "Löschen" -command actions::delete
        .m.file add separator
        .m.file add command -label "Beenden" -command {view::commit; view::quit}
        bind . <Control-n> actions::new
    }

    proc quit {} {
        view::commit
        model::save $::dataFile
        destroy .
    }

    proc refreshList {} {
        variable itemMap
        array unset itemMap
        array set itemMap {}
        .pw.left.tv delete [.pw.left.tv children {}]
        foreach n [model::all] {
            set item [.pw.left.tv insert {} end -text [dict get $n title]]
            set itemMap($item) [dict get $n id]
        }
        set ::statusText "[llength [model::all]] Notizen"
    }

    proc onSelect {} {
        variable itemMap
        set sel [.pw.left.tv selection]
        if {$sel eq ""} { return }
        showNote $itemMap([lindex $sel 0])
    }

    proc selectInList {id} {
        variable itemMap
        foreach {item noteId} [array get itemMap] {
            if {$noteId == $id} {
                .pw.left.tv selection set $item
                .pw.left.tv see $item
                showNote $id
                return
            }
        }
    }

    proc showNote {id} {
        set n [model::get $id]
        if {$n eq ""} { return }
        set model::current $id
        set ::ui(title) [dict get $n title]
        .pw.right.body delete 1.0 end
        .pw.right.body insert end [dict get $n body]
    }

    proc commit {} {
        if {$model::current eq ""} { return }
        model::update $model::current $::ui(title) [.pw.right.body get 1.0 end-1c]
    }
}
