# Designsystem für Notizbuch (Kap. 35.6)
namespace eval ::ui::theme {}
set ::ui::theme::libdir [file normalize [file join [file dirname [info script]] .. .. .. lib]]

namespace eval ::ui::theme {
    proc init {} {
        source [file join $::ui::theme::libdir ui-fonts.tcl]
        ::book::fonts::ensure

        ttk::style theme use clam
        ttk::style configure TFrame -background "#f5f5f5"
        ttk::style configure TLabel -font [::book::fonts::get body]
        ttk::style configure Header.TLabel -font [::book::fonts::get head]
        ttk::style configure Primary.TButton -font [::book::fonts::get primary]
    }
}
