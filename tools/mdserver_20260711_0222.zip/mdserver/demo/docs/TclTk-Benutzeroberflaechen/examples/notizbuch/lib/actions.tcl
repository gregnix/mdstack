# Kap. 35 — Aktionen (ändern nur das Modell)
namespace eval actions {
    proc new {} {
        set id [model::add]
        set model::current $id
        event generate . <<SelectNote>> -data $id
    }

    proc delete {} {
        if {$model::current ne ""} {
            model::delete $model::current
            set model::current ""
        }
    }
}
