#!/usr/bin/env wish
# Kap. 31 + 35 — Notizbuch-Fallstudie
package require Tk

set here [file dirname [file normalize [info script]]]
set ::dataFile [file join $here notes.txt]
set ::statusText ""
array set ::ui {title ""}

source [file join $here lib ui theme.tcl]
source [file join $here lib model.tcl]
source [file join $here lib actions.tcl]
source [file join $here lib view.tcl]

::ui::theme::init
view::build
model::load $::dataFile

wm title . "Notizen — Kap. 35"
wm minsize . 480 320
wm protocol . WM_DELETE_WINDOW view::quit

# Erste Notiz anlegen, wenn leer
if {[llength [model::all]] == 0} {
    actions::new
}
