#!/usr/bin/env wish
# Kap. 14 — Eingabe und Validierung
package require Tk
wm title . "Kap. 14 — Validierung"

set ::email ""
set ::hint ""

ttk::labelframe .f -text "Kontakt" -padding 12
pack .f -fill x -padx 12 -pady 12

ttk::label .f.le -text "E-Mail:"
ttk::entry .f.ee -textvariable ::email
ttk::label .f.lh -textvariable ::hint -foreground "#b00020"

grid .f.le -row 0 -column 0 -sticky e -padx {0 8} -pady 4
grid .f.ee -row 0 -column 1 -sticky ew -pady 4
grid .f.lh -row 1 -column 1 -sticky w

grid columnconfigure .f 1 -weight 1

proc validateEmail {} {
    set e [string trim $::email]
    if {$e eq ""} {
        set ::hint ""
        return
    }
    if {![regexp {^[^@\s]+@[^@\s]+\.[^@\s]+$} $e]} {
        set ::hint "Ungültige E-Mail-Adresse"
    } else {
        set ::hint "OK"
        .f.lh configure -foreground "#2e7d32"
    }
}
bind .f.ee <FocusOut> validateEmail
bind .f.ee <KeyRelease> {
    .f.lh configure -foreground "#b00020"
    set ::hint ""
}
