#!/usr/bin/env wish
# Kap. 16 — Text-Widget
package require Tk
source [file join [file dirname [info script]] .. lib ui-fonts.tcl]
::book::fonts::ensure
wm title . "Kap. 16 — Text"

text .t -wrap word -undo 1 -height 12 -width 50
set bodyFamily [font actual [::book::fonts::get body] -family]
font create TextBold   -family $bodyFamily -size 11 -weight bold
font create TextItalic -family $bodyFamily -size 11 -slant italic
.t insert end "Mehrzeiliger Editor\n\nTags: "
.t insert end "fett" bold
.t insert end " und "
.t insert end "kursiv" italic
.t tag configure bold   -font TextBold
.t tag configure italic -font TextItalic
pack .t -fill both -expand 1 -padx 12 -pady 12

ttk::label .status -text "Strg+Z = undo" -relief sunken -padding 4
pack .status -fill x
