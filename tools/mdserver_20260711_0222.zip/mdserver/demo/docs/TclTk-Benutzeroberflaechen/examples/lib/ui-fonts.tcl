# Gemeinsame Schrift-Objekte für Beispiele (Tk 8.6/9.x).
# ttk::style -font braucht font-Namen, keine {DejaVu Sans 11 bold}-Listen.
namespace eval ::book::fonts {
    variable ready 0

    proc ensure {} {
        variable ready
        if {$ready} { return }
        set family [font actual TkDefaultFont -family]
        foreach {name size weight} {
            body      11 normal
            head      14 bold
            primary   11 bold
            primarySm 10 bold
            detail    12 bold
        } {
            set fname book.$name
            catch {font delete $fname}
            if {$weight eq "bold"} {
                font create $fname -family $family -size $size -weight bold
            } else {
                font create $fname -family $family -size $size
            }
        }
        set ready 1
    }

    proc get {name} {
        ensure
        return book.$name
    }
}
