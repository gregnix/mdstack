#!/usr/bin/env wish
# Kap. 4 — classic Tk vs. Ttk
package require Tk
wm title . "Kap. 4 — classic vs. Ttk"

ttk::labelframe .c -text "classic Tk" -padding 8
ttk::labelframe .t -text "Ttk" -padding 8
pack .c .t -side left -fill both -expand 1 -padx 8 -pady 8

button .c.b -text "classic Button" -command {}
entry .c.e
pack .c.b .c.e -fill x -pady 2

ttk::button .t.b -text "TButton"
ttk::entry .t.e
pack .t.b .t.e -fill x -pady 2

ttk::label .hint -text "Ttk übernimmt Theme/Farben vom System — classic wirkt oft „retro“."
pack .hint -side bottom -fill x -padx 8 -pady 4
