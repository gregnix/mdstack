# Variablen-Bindung als Klebstoff

*Stand: 2026-05-29*

## Einführung

Schon mehrfach im Buch tauchte `-textvariable` und `-variable` auf — die
Kopplung eines Widgets an eine Tcl-Variable. Dieses Kapitel nimmt den
Mechanismus dahinter ernst: Wie genau verbinden Widgets sich mit
Variablen, wie macht `trace` daraus eine Brücke in *beide* Richtungen, und
wo hat dieser Klebstoff seine Grenzen. Variablen-Bindung ist das
einfachste Mittel, Anzeige und Daten zu koppeln — und das, das man am
ehesten überstrapaziert.

---

## 29.1 `-textvariable` und `-variable`

Viele Widgets koppeln ihren Inhalt oder Zustand an eine Variable:

```tcl
ttk::entry .e -textvariable ::name              ;# Inhalt <-> ::name
ttk::label .l -textvariable ::status            ;# Anzeige <- ::status
ttk::checkbutton .c -variable ::aktiv            ;# Zustand <-> ::aktiv (0/1)
ttk::radiobutton .r -variable ::modus -value a   ;# Auswahl <-> ::modus
```

Die Kopplung ist **bidirektional**, wo es Sinn ergibt: Tippt der Nutzer
ins Entry, ändert sich `::name`; setzt der Code `::name`, ändert sich die
Anzeige. Beim Label ist sie einseitig (nur Code → Anzeige), beim
Checkbutton wieder beidseitig.

Der Geltungsbereich ist entscheidend. Ein Widget löst seinen
Variablennamen **global** auf, nicht im lokalen Prozedur-Scope. Deshalb
nimmt man `::name` (global) oder eine voll qualifizierte
Namespace-Variable (`::app::name`) — eine lokale Variable in einer
Prozedur wäre für das Widget unsichtbar:

```tcl
proc baueFormular {} {
    set name ""                          ;# lokal -- das Widget sieht das NICHT
    ttk::entry .e -textvariable name     ;# sucht globales "name", findet evtl. nichts
}
# richtig: ttk::entry .e -textvariable ::app::name   (qualifiziert)
```

Dieser Punkt ist die häufigste Ursache für „mein Entry zeigt nichts an"
oder „der Wert kommt nicht an": ein Scope-Missverständnis, kein
Widget-Problem.

---

## 29.2 `trace` als Brücke zwischen Daten und Anzeige

`-textvariable` koppelt Widget und Variable. Will man darüber hinaus auf
*jede* Änderung einer Variable reagieren — etwa um abgeleitete Anzeigen zu
aktualisieren — nutzt man `trace`. `trace` führt Code aus, wenn eine
Variable gelesen, geschrieben oder gelöscht wird:

```tcl
trace add variable ::name write aktualisiereTitel

proc aktualisiereTitel {varName index op} {
    upvar 1 $varName wert
    wm title . "Bearbeite: $wert"
}
```

Der Callback bekommt drei Argumente: den Variablennamen, den Array-Index
(leer bei einfachen Variablen) und die Operation (`read`/`write`/`unset`).
Da er im Kontext des Aufrufers läuft, braucht eine Prozedur `upvar`, um an
den Wert zu kommen.

Damit baut man die Brücke, die mehrere Anzeigen synchron hält, ohne sie
einzeln anzustoßen: Ein Entry schreibt über `-textvariable` in `::name`,
und ein `trace` auf `::name` aktualisiert den Fenstertitel, eine
Statuszeile, einen abgeleiteten Wert — alle reagieren auf dieselbe Quelle.

Zwei Dinge sind wichtig. Erstens der **Rekursionsschutz**: Während ein
read- oder write-Callback läuft, deaktiviert Tcl die Traces auf *dieser*
Variable. Ändert der Callback die Variable selbst (etwa
Großschreibung erzwingen), löst das den Trace also **nicht** erneut aus —
keine Endlosschleife:

```tcl
proc grossSchreiben {varName index op} {
    upvar 1 $varName wert
    set wert [string toupper $wert]   ;# löst den Trace NICHT erneut aus
}
trace add variable ::code write grossSchreiben
```

Zweitens das **Aufräumen**: Ein Trace bleibt bestehen, bis man ihn
entfernt. Wer Widgets zerstört, deren Variablen aber weiter getract
werden, hängt Callbacks ins Leere. Bei Cleanup den Trace entfernen:

```tcl
trace remove variable ::name write aktualisiereTitel
trace info variable ::name      ;# zeigt alle aktiven Traces
```

---

## 29.3 Arrays als Formular-Modell

Ein elegantes Muster für Formulare: ein **Array** als Modell, dessen
Elemente an die einzelnen Felder gekoppelt sind. Jedes Feld bindet an
`::form(feldname)`:

```tcl
ttk::entry .name  -textvariable ::form(name)
ttk::entry .email -textvariable ::form(email)
ttk::spinbox .age -textvariable ::form(alter) -from 0 -to 150
```

Das gesamte Formular liegt dann in *einer* Datenstruktur. Auslesen,
zurücksetzen und Befüllen werden zu Array-Operationen:

```tcl
proc formularLeeren {} {
    array set ::form {name "" email "" alter ""}
}
proc formularLaden {satz} {
    foreach {k v} $satz { set ::form($k) $v }   ;# Widgets ziehen mit
}
proc formularLesen {} {
    return [array get ::form]
}
```

Ein `array`-Trace kann zusätzlich auf jede Änderung *irgendeines* Feldes
reagieren — etwa um einen „geändert"-Status zu setzen:

```tcl
trace add variable ::form write {apply {{n i op} {set ::geaendert 1}}}
```

So spiegelt das Array das Formular, die Widgets spiegeln das Array, und ein
Trace fängt Änderungen zentral ab — viel Synchronisation, fast ohne
Synchronisations-Code.

---

## 29.4 Grenzen der Bindung — wo expliziter Code besser ist

Variablen-Bindung ist verführerisch, und genau darin liegt ihre Gefahr.
Sie passt hervorragend für **einfache, einwertige** Kopplungen: ein Feld,
ein Wert, eine Anzeige. Sie passt **schlecht**, sobald:

- die Beziehung **mehrwertig** ist (eine Listbox-Mehrfachauswahl, eine
  Treeview-Auswahl) — dafür gibt es keine sinnvolle einzelne Variable,
  man synchronisiert explizit über das jeweilige `<<…Select>>`-Event
  (Kapitel 15, 28);
- die Anzeige eine **Transformation** der Daten ist (formatiertes Datum,
  berechnete Summe) — der Trace müsste dann formatieren, was Logik in den
  Trace zieht, wo sie schwer zu finden ist;
- **viele** Traces auf dieselben Variablen wirken — dann wird die
  Reihenfolge der Effekte unübersichtlich, und ein Fehler in einem
  Callback lässt die ursprüngliche Schreiboperation fehlschlagen (read-/
  write-Trace-Fehler propagieren).

Die „keine Magie"-Haltung gilt auch hier: Variablen-Bindung versteckt die
Aktualisierung, und das ist genau dann gut, wenn die Kopplung trivial ist
— und genau dann schlecht, wenn jemand später nachvollziehen muss, *warum*
sich eine Anzeige geändert hat. Faustregel: Bindung für die einfache
Spiegelung von Werten; expliziter Code (oder das Observer-Muster aus
Kapitel 30), sobald Logik, Transformation oder mehrwertige Beziehungen ins
Spiel kommen.

---

## Zusammenfassung

- `-textvariable`/`-variable` koppeln Widgets bidirektional an Variablen;
  der Name wird global aufgelöst, daher `::name` oder qualifiziert — die
  häufigste Fehlerquelle ist ein Scope-Missverständnis.
- `trace add variable … write` reagiert auf Änderungen; Callback-Signatur
  `{name index op}`, Zugriff per `upvar`; Rekursionsschutz verhindert
  Endlosschleifen, Traces bei Cleanup entfernen.
- Arrays (`::form(feld)`) als Formular-Modell bündeln Felder in einer
  Struktur; ein `array`-Trace fängt Änderungen zentral.
- Bindung für triviale Wert-Spiegelung; bei Logik, Transformation oder
  mehrwertigen Beziehungen lieber expliziter Code oder das Observer-Muster.

Das letzte Kapitel von Teil 6 zieht die Konsequenz aus diesen Grenzen:
wie man UI und Logik sauber trennt, statt beide im Widget-Code zu
verheddern.
