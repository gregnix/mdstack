# Das Text-Widget

*Stand: 2026-05-29*

## Einführung

Das `text`-Widget ist das mächtigste in Tk: ein vollwertiger
mehrzeiliger Editor, eine Anzeigefläche für formatierten Text, ein
Container für eingebettete Widgets und Bilder. Es hat kein Ttk-Pendant
(Kapitel 4) und steuert sein Aussehen über Optionen und — der Kern dieses
Kapitels — über **Tags**. Wer Tags, Indizes und Marks verstanden hat,
beherrscht das Widget; alles andere folgt daraus.

---

## 16.1 Indizes, Marks, Tags — das Modell

Drei Begriffe bilden das Modell des Text-Widgets.

**Indizes** bezeichnen Positionen. Die wichtigste Form ist
`Zeile.Spalte`, wobei Zeilen ab 1 und Spalten ab 0 zählen. Dazu kommen
symbolische Indizes:

```tcl
text .t
.t insert end "Hallo Welt"
.t index 1.0        ;# Anfang (Zeile 1, Spalte 0)
.t index end        ;# hinter dem letzten Zeichen
.t index "1.0 + 5 chars"   ;# Arithmetik auf Indizes
.t index "insert"   ;# Position der Einfügemarke
```

**Marks** sind benannte Positionen, die mit dem Text *mitwandern*, wenn
davor eingefügt oder gelöscht wird. Zwei sind eingebaut: `insert` (die
Cursor-Position) und `current` (unter der Maus). Eigene Marks setzt man
selbst:

```tcl
.t mark set meineMarke "1.0 + 3 chars"
.t mark gravity meineMarke left   ;# bleibt links vom eingefügten Text
```

**Tags** sind benannte Bereiche, die Formatierung *und* Verhalten tragen
können — der nächste Abschnitt.

---

## 16.2 Tags für Formatierung und Verhalten

Ein Tag ist ein Name, den man Textbereichen zuweist und für den man
Eigenschaften konfiguriert. Damit formatiert man Teile des Textes
unterschiedlich, ohne den Text zu zerschneiden:

```tcl
.t tag configure ueberschrift -font {Helvetica 14 bold} -foreground "#1a3c6e"
.t tag configure warnung      -foreground red

.t insert end "Titel\n" ueberschrift
.t insert end "Normaler Text, "
.t insert end "und das hier ist wichtig" warnung
```

Tags lassen sich auch nachträglich auf Bereiche legen und wieder
entfernen:

```tcl
.t tag add    warnung 2.0 2.10     ;# Bereich markieren
.t tag remove warnung 2.0 2.10     ;# Markierung entfernen
.t tag ranges warnung              ;# alle Bereiche dieses Tags
```

**Tag-Priorität entscheidet bei Überlappung**, und sie folgt der
**Erstellungsreihenfolge**: Ein später erzeugter Tag hat höhere Priorität
als ein früherer. Überlappen sich zwei Tags mit widersprüchlicher
Eigenschaft (etwa Vordergrundfarbe), gewinnt der zuletzt konfigurierte.
Wer die Reihenfolge explizit will, nutzt `tag raise`/`tag lower`:

```tcl
.t tag raise warnung           ;# warnung über alle anderen
.t tag raise warnung normal    ;# warnung knapp über "normal"
```

Tags tragen auch **Verhalten**: Bindings auf einen Tag feuern, wenn das
Ereignis über getaggtem Text passiert — die Grundlage für anklickbare
Links im Text:

```tcl
.t tag configure link -foreground blue -underline 1
.t tag bind link <Button-1> {puts "Link geklickt"}
.t tag bind link <Enter> {.t configure -cursor hand2}
.t tag bind link <Leave> {.t configure -cursor xterm}
.t insert end "Hier klicken" link
```

### Benannte Fonts statt Inline-Specs

Wer viele Tags formatiert, sollte **benannte Fonts** (Kapitel 25) nutzen
statt Font-Specs an jedem Tag. Dann ändert eine Stelle die Schrift
überall:

```tcl
font create viewer_h1 -family Helvetica -size 16 -weight bold
.t tag configure h1 -font viewer_h1

# später global ändern -- alle h1-Tags ziehen mit:
font configure viewer_h1 -size 20
```

Inline-Specs (`-font {Helvetica 16 bold}`) an Dutzenden Tags sind
dagegen über das ganze Programm verstreut und nur mühsam zentral zu
ändern.

---

## 16.3 Undo/Redo eingebaut

Das Text-Widget bringt eine vollständige Undo-Historie mit — man muss sie
nur einschalten:

```tcl
text .t -undo 1 -autoseparators 1
```

`-undo 1` aktiviert die Historie, `-autoseparators 1` setzt automatisch
Trennpunkte zwischen Bearbeitungsschritten (sonst würde ein einziges
Undo den gesamten Text zurücknehmen). Auslösen über die Widget-Befehle
oder die Standard-Tastenkürzel:

```tcl
.t edit undo
.t edit redo
.t edit reset       ;# Historie leeren
.t edit modified    ;# wurde seit dem letzten reset geändert? (0/1)
```

`edit modified` ist nützlich, um einen „ungespeicherte Änderungen"-Status
zu führen, ohne selbst mitzuzählen — wieder ein Fall, in dem das Widget
schon kann, was man sonst von Hand nachbauen würde.

---

## 16.4 Eingebettete Fenster und Bilder

Das Text-Widget kann andere Widgets und Bilder *im Textfluss* aufnehmen —
sie wandern mit dem Text wie ein Zeichen:

```tcl
# ein Button mitten im Text
ttk::button .t.go -text "Start"
.t window create end -window .t.go

# ein Bild im Text
image create photo logo -file logo.png
.t image create end -image logo
```

Das macht aus dem Text-Widget eine kleine Layout-Maschine: Formulare mit
erklärendem Fließtext, Hilfeseiten mit eingebetteten Schaltflächen,
Rich-Text-Anzeigen. Eingebettete Fenster müssen Kinder des Text-Widgets
sein (Pfadname `.t.…`), damit sie korrekt mitwandern.

Für reines Scrollen verbindet man eine Scrollbar wie bei der Listbox
(Kapitel 15); das Text-Widget bringt `-yscrollcommand`/`-xscrollcommand`
dafür mit.

---

## Zusammenfassung

- Das Modell besteht aus Indizes (Positionen, `Zeile.Spalte` und
  symbolisch), Marks (mitwandernde benannte Positionen) und Tags.
- Tags tragen Formatierung *und* Verhalten (`tag bind`); bei Überlappung
  gewinnt der zuletzt erzeugte/konfigurierte — steuerbar mit
  `tag raise`/`tag lower`.
- Benannte Fonts an Tags statt Inline-Specs machen Schriftänderungen
  zentral.
- `-undo 1 -autoseparators 1` schaltet die eingebaute Undo-Historie ein;
  `edit modified` führt den Geändert-Status.
- `window create`/`image create` betten Widgets und Bilder in den
  Textfluss ein.

Nach den Anzeige- und Eingabe-Widgets folgt das auslösende Element jeder
Oberfläche — der Button und das, was an ihm hängt.
