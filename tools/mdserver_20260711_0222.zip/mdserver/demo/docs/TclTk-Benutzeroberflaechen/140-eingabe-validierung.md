# Eingabe und Validierung

*Stand: 2026-05-29*

## Einführung

Texteingabe in einer Zeile leistet das `entry`-Widget (`ttk::entry`),
Zahleneingabe mit Auf-/Ab-Knöpfen die `spinbox` (`ttk::spinbox`). Der
interessante Teil ist die **Validierung**: Tk bietet dafür ein eigenes
Protokoll, das überraschend oft missverstanden wird. Dieses Kapitel zeigt
das Protokoll vollständig — und warum „keine Magie" auch hier die richtige
Haltung ist.

---

## 14.1 `entry` / `ttk::entry`

Ein Eingabefeld:

```tcl
ttk::entry .e -width 30
pack .e
```

Inhalt setzen und lesen geht über Widget-Befehle *oder* über eine
gekoppelte Variable:

```tcl
.e insert 0 "Vorgabe"     ;# Text einfügen (Position 0 = Anfang)
.e delete 0 end           ;# leeren
set wert [.e get]         ;# auslesen

ttk::entry .e2 -textvariable ::name   ;# alternativ über Variable
set ::name "Vorgabe"                  ;# setzt zugleich die Anzeige
```

Die Variablen-Kopplung (Kapitel 29) ist für Formulare meist angenehmer:
Man liest und schreibt die Variable, nicht das Widget. Ein Passwortfeld
entsteht durch Maskierung der Zeichen:

```tcl
ttk::entry .pw -show "•" -textvariable ::passwort
```

`-state readonly` macht ein Feld unveränderlich, aber kopierbar;
`-state disabled` sperrt es ganz (und grau).

---

## 14.2 `spinbox` für Zahlen

Die `ttk::spinbox` ist ein Entry mit Auf-/Ab-Knöpfen und einem Wertebereich:

```tcl
ttk::spinbox .age -from 0 -to 150 -increment 1 -textvariable ::alter
pack .age
```

`-from`/`-to` setzen den Bereich, `-increment` die Schrittweite. Für eine
feste Auswahlliste statt eines Bereichs gibt es `-values`:

```tcl
ttk::spinbox .size -values {XS S M L XL} -textvariable ::groesse
```

Wichtig: Die Spinbox-Knöpfe halten den Wert *nur*, wenn man sie benutzt.
Tippt der Nutzer von Hand etwas Ungültiges ein (Buchstaben, eine Zahl
außerhalb des Bereichs), verhindert die Spinbox das **nicht** automatisch.
Wer das will, braucht Validierung — und damit das Protokoll aus dem
nächsten Abschnitt.

---

## 14.3 Das `-validate`/`-validatecommand`-Protokoll

Tk kann bei jeder Änderung eine Prüfprozedur aufrufen, die `1` (erlaubt)
oder `0` (abgelehnt) zurückgibt. Zwei Optionen steuern das:

- `-validate` *wann* geprüft wird: `key` (bei jedem Tastendruck), `focus`,
  `focusin`, `focusout`, `all` oder `none`.
- `-validatecommand` *was* geprüft wird — ein Befehl, der `1` oder `0`
  liefert.

Der `-validatecommand` bekommt seine Informationen über
**Prozent-Substitutionen**, analog zu Bindings (Kapitel 20). Die
wichtigsten:

| Code | Bedeutung |
|------|-----------|
| `%P` | der Wert, *wie er nach* der Änderung wäre (proposed) |
| `%S` | der Text, der eingefügt/gelöscht wird |
| `%s` | der Wert *vor* der Änderung |
| `%d` | Art: 1 = Einfügen, 0 = Löschen, -1 = revalidate |
| `%W` | der Widget-Pfad |

Ein Feld, das nur Ziffern erlaubt:

```tcl
proc validateDigits {proposed} {
    return [expr {$proposed eq "" || [string is integer -strict $proposed]}]
}

ttk::entry .num -validate key -validatecommand {validateDigits %P}
pack .num
```

Geprüft wird `%P` — der *vorgeschlagene* Wert. Liefert die Prozedur `0`,
verwirft Tk die Änderung; das Feld bleibt unverändert. Den leeren String
lässt man bewusst zu, sonst kann der Nutzer das Feld nie löschen.

> **Stolperfalle:** Verändert der `-validatecommand` selbst das Widget
> (etwa per `.num delete`/`.num insert`), schaltet Tk die Validierung
> stillschweigend ab (`-validate` wird auf `none` gesetzt). Eine
> Prüfprozedur soll **nur prüfen und zurückgeben**, nicht eingreifen. Wer
> den Inhalt korrigieren will, tut das außerhalb — etwa in einem
> `<FocusOut>`-Binding.

---

## 14.4 Eingabe-Masken ohne Magie

Strukturierte Eingaben — Datum, IP-Adresse, Telefonnummer — lassen sich
mit dem Validierungsprotokoll von Hand bauen, werden aber schnell
fummelig. Hier zahlt sich die „keine Magie"-Haltung doppelt aus: Statt
eine komplizierte Tasten-für-Tasten-Maske selbst zu schreiben, prüft man
am Ende der Eingabe das *Ergebnis* — das ist robuster und besser lesbar.

```tcl
# Datumsfeld: bei Verlassen prüfen, nicht bei jedem Tastendruck quälen
proc checkDate {w} {
    set v [$w get]
    if {$v eq "" || ![catch {clock scan $v -format "%d.%m.%Y"}]} {
        $w state !invalid          ;# Ttk-Zustand zurücksetzen
    } else {
        $w state invalid           ;# markiert das Feld als ungültig
    }
}

ttk::entry .date -textvariable ::datum
bind .date <FocusOut> {checkDate %W}
```

`$w state invalid` setzt einen Ttk-**Zustand**, den das Theme sichtbar
macht (Kapitel 24) — meist ein roter Rahmen. Das ist sauberer als ein
hartcodiertes `-foreground red`, weil es zum Theme passt.

Für wirklich strukturierte Felder (Datum, IP, Kreditkarte) gibt es das
Fremd-Widget **`mentry`** (Multi-Entry) von Csaba Nemethi, das mehrere
verbundene Felder mit automatischer Navigation kapselt:

```tcl
package require mentry
mentry::dateMentry .d DE       ;# Datumsfeld TT.MM.JJJJ
.d put 0 "31.12.2026"
set datum [.d get]
```

Ob man `mentry` einsetzt, ist dieselbe Abwägung wie bei `scrollutil`
(Kapitel 10): Komfort gegen eine zusätzliche auszuliefernde Abhängigkeit.
Mit Bordmitteln kommt man über das Validierungsprotokoll und eine Prüfung
beim Verlassen des Feldes weit genug für die meisten Fälle.

---

## Zusammenfassung

- `ttk::entry` nimmt Text, `ttk::spinbox` Zahlen/Werte; beide koppelt man
  bequem über `-textvariable`.
- Die Spinbox erzwingt ihren Bereich nur über die Knöpfe, nicht bei
  Handeingabe — dafür braucht es Validierung.
- Das Protokoll: `-validate` (wann) + `-validatecommand` (was), gespeist
  über Prozent-Codes; `%P` ist der vorgeschlagene Wert. Die Prozedur darf
  nur prüfen, nicht eingreifen.
- Für komplexe Masken lieber das Ergebnis bei `<FocusOut>` prüfen und
  `state invalid` setzen, oder `mentry` als Fremd-Widget nutzen.

Das nächste Kapitel behandelt die Auswahl-Widgets: Checkbutton,
Radiobutton, Combobox und Listbox — und wie ihre `-variable`-Kopplung
funktioniert.
