# Dialoge und Toplevels

*Stand: 2026-05-29*

## Einführung

Ein Dialog holt den Nutzer aus dem normalen Fluss: eine Frage, eine
Dateiauswahl, eine Eingabe. Tk bietet für die Standardfälle fertige
Dialoge — die man zuerst probieren sollte — und für alles andere das
`toplevel` als Baustein. Der heikle Teil ist „modal": Ein Dialog, der
*blockiert*, bis der Nutzer geantwortet hat, braucht mehr als ein
`grab` — und genau hier scheitern viele erste Versuche.

---

## 22.1 Die fertigen Dialoge

Bevor man einen Dialog selbst baut, lohnt der Blick auf die eingebauten.
Sie sind plattformnah, brauchen keine Layout-Arbeit und decken die
häufigsten Fälle ab:

```tcl
# Frage / Meldung
set antwort [tk_messageBox -type yesno -icon question \
    -title "Beenden" -message "Wirklich beenden?"]
if {$antwort eq "yes"} {destroy .}

# Datei öffnen / speichern
set datei [tk_getOpenFile -filetypes {{"Textdateien" .txt} {"Alle" *}}]
set ziel  [tk_getSaveFile -defaultextension .txt]

# Verzeichnis / Farbe wählen
set ordner [tk_chooseDirectory]
set farbe  [tk_chooseColor -initialcolor "#3366cc"]
```

`tk_messageBox` liefert das gewählte Wort zurück (`yes`, `no`, `ok`,
`cancel` …), die Datei-Dialoge den gewählten Pfad oder den leeren String
bei Abbruch. Diese Dialoge sind **bereits modal** und blockieren von
selbst, bis der Nutzer antwortet — man muss nichts weiter tun. Unter
Tcl/Tk 9 nutzen sie zudem moderne System-Dialoge (etwa den aktuellen
Datei-Dialog unter Windows) und skalieren auf HiDPI-Displays.

Die Faustregel: **Standard-Dialog zuerst.** Erst wenn keiner passt, baut
man einen eigenen.

---

## 22.2 Ein eigenes `toplevel` als Dialog

Ein eigener Dialog ist ein `toplevel` mit Inhalt. Das Grundgerüst:

```tcl
proc frageName {} {
    toplevel .dlg
    wm title .dlg "Name eingeben"
    wm transient .dlg .          ;# gehört zum Hauptfenster (s.u.)

    ttk::label .dlg.l -text "Ihr Name:"
    ttk::entry .dlg.e -textvariable ::dlgName
    ttk::button .dlg.ok     -text "OK"        -command {set ::dlgResult ok}
    ttk::button .dlg.cancel -text "Abbrechen" -command {set ::dlgResult cancel}

    grid .dlg.l .dlg.e -padx 8 -pady 8 -sticky we
    grid .dlg.cancel .dlg.ok -padx 8 -pady {0 8}
    # ... modal machen: nächster Abschnitt ...
}
```

`wm transient .dlg .` stellt die Eltern-Beziehung zum Hauptfenster her.
Das hat zwei sichtbare Effekte: Der Dialog erscheint *über* dem
Hauptfenster (nicht dahinter) und wird mit ihm geschlossen, statt als
Waise zurückzubleiben. Für jeden Dialog sinnvoll.

---

## 22.3 Modal werden — `grab`, `wait`, Rückgabe

Hier sitzt der häufigste Irrtum. Viele meinen, `grab set` mache einen
Dialog modal. Es lenkt zwar alle Eingaben auf den Dialog — aber es
**blockiert nicht**: Der Code läuft sofort weiter, der Dialog ist noch gar
nicht beantwortet.

```tcl
# FALSCH: kehrt sofort zurück, $::dlgResult ist noch leer
grab set .dlg
return $::dlgResult
```

Modal wird ein Dialog erst, wenn man zusätzlich **wartet** — mit
`tkwait window` (wartet, bis das Fenster zerstört wird) oder `vwait`
(wartet auf eine Variable):

```tcl
proc frageName {} {
    # ... Dialog wie oben aufbauen ...
    set ::dlgResult ""
    wm protocol .dlg WM_DELETE_WINDOW {set ::dlgResult cancel}

    grab set .dlg                 ;# Eingaben auf den Dialog lenken
    focus .dlg.e                  ;# Fokus ins erste Feld
    vwait ::dlgResult             ;# HIER blockieren, bis OK/Abbrechen

    grab release .dlg
    destroy .dlg
    return [expr {$::dlgResult eq "ok" ? $::dlgName : ""}]
}

set name [frageName]              ;# blockiert sauber bis zur Antwort
```

Der Ablauf: `grab set` fängt die Eingaben, `vwait ::dlgResult` betritt den
Event-Loop und kehrt erst zurück, wenn ein Button (oder das
Schließkreuz über `WM_DELETE_WINDOW`) die Variable setzt. Danach räumt man
auf und gibt das Ergebnis zurück.

> **Merksatz:** `grab set` lenkt die Eingabe, `tkwait`/`vwait` blockiert.
> Modal braucht **beides**.

Und die Warnung aus Kapitel 19 gilt hier konkret: `vwait` betritt den
Event-Loop. Ruft der Dialog-Code selbst wieder einen modalen Dialog auf,
verschachteln sich die `vwait`-Aufrufe — sie laufen nicht parallel, der
äußere kehrt erst nach dem inneren zurück. Solange man Dialoge sauber
nacheinander öffnet, ist das unkritisch; man sollte nur wissen, warum
tiefe Verschachtelung verklemmen kann.

---

## 22.4 Position, Transienz, Zentrierung

Ein paar Feinheiten heben einen eigenen Dialog auf das Niveau der
eingebauten.

**Zentrieren** über dem Hauptfenster, statt ihn an einer Zufallsposition
erscheinen zu lassen:

```tcl
proc zentriere {dlg ueber} {
    update idletasks      ;# Größen müssen berechnet sein
    set x [expr {[winfo rootx $ueber] + ([winfo width  $ueber] - [winfo width  $dlg]) / 2}]
    set y [expr {[winfo rooty $ueber] + ([winfo height $ueber] - [winfo height $dlg]) / 2}]
    wm geometry $dlg +$x+$y
}
```

Das `update idletasks` ist nötig, damit `winfo width`/`height` die
tatsächlichen Größen liefern (Kapitel 6) — vorher kennt Tk sie noch nicht.

**Doppeltes Öffnen abfangen.** Ein zweiter Klick auf „Einstellungen" darf
keinen zweiten Dialog stapeln. Vor dem `toplevel` prüfen, ob er schon
existiert:

```tcl
proc zeigeEinstellungen {} {
    if {[winfo exists .settings]} {
        raise .settings           ;# vorhandenen nach vorn holen
        focus .settings
        return                     ;# wichtig: hier verlassen
    }
    toplevel .settings
    # ...
}
```

`winfo exists` (Kapitel 3) ist hier der Wächter. Ohne diesen Guard
entstehen Dialog-Stapel — ein verbreiteter Fehler bei nicht-modalen
Werkzeugfenstern.

**Modal nur, wenn nötig.** Ein modaler Dialog blockiert den Nutzer. Für
eine Bestätigung ist das richtig; für eine Werkzeug-Palette oder ein
Log-Fenster ist es störend. Solche Fenster baut man als nicht-modales
`toplevel` *ohne* `grab`/`vwait` — sie bleiben offen, und Haupt- wie
Werkzeugfenster sind gleichzeitig bedienbar.

---

## Zusammenfassung

- Standard-Dialoge (`tk_messageBox`, `tk_getOpenFile`, `tk_getSaveFile`,
  `tk_chooseDirectory`, `tk_chooseColor`) zuerst probieren — sie sind
  bereits modal und plattformnah.
- Eigene Dialoge sind `toplevel` mit Inhalt; `wm transient $dlg .` für die
  Eltern-Beziehung.
- Modal = `grab set` (Eingabe lenken) **plus** `tkwait window`/`vwait`
  (blockieren). `grab` allein blockiert nicht.
- Zentrieren nach `update idletasks`; doppeltes Öffnen mit `winfo exists`
  abfangen; modal nur, wenn der Nutzer wirklich aufgehalten werden soll.

Das letzte Kapitel von Teil 4 schließt die Interaktion ab mit dem, was
eine Oberfläche ohne Maus bedienbar macht: Fokus und Tastatur.
