# Desktop-Patterns

*Stand: 2026-06-16*

## Einführung

Die Kapitel 10 und 11 haben Bausteine und Wachstumsketten geliefert. In der
Praxis fragt man selten „soll ich `pack` oder `grid` nehmen?", sondern:
*Wie sieht ein Datei-Explorer aus? Wie ein Einstellungsdialog? Wie ein
Editor?*

Dieses Kapitel sammelt **wiederkehrende Anwendungsmuster** des Desktop —
als Widget-Baum, Manager-Zuordnung und kompaktes Tcl-Gerüst. Es ersetzt
kein Kapitel über einzelne Widgets (Teil 3), sondern zeigt, wie Container
aus Kapitel 18 (`notebook`, `panedwindow`, `labelframe`) in bekannte
Fensterformen zusammensetzt werden.

**Voraussetzung:** Kapitel 10–11, Kapitel 18 (Container), Kapitel 22
(Dialoge). **Verweist auf:** Anhang F (Referenz-Layout), Kapitel 30–31
(UI/Logik, Struktur).

---

## 12.1 Vorgehen: Skizze → Baum → Manager

Bevor Code geschrieben wird, drei Schritte — in dieser Reihenfolge:

1. **Skizze** — Zonen auf Papier oder ASCII (Toolbar? Sidebar? Reiter?)
2. **Widget-Baum** — Pfadnamen festlegen (`.body.left.tree`, nicht `.t1`)
3. **Manager** — pro Frame genau einer; Zonen meist `pack`, Inhalt meist
   `grid`

> **Schlecht:** Sofort `ttk::treeview .tv` und `pack`/`grid` nach Gefühl.  
> **Besser:** Baum wie in Anhang F, dann erst Widgets erzeugen.

Die Wachstumskette aus Kapitel 11 gilt für **jedes** Pattern.

---

## 12.2 Pattern: Explorer (Master-Detail)

**Erkennungsmerkmal:** Liste oder Baum links, Detail rechts; Toolbar oben,
Status unten.

```
.
├── .toolbar
├── .body
│   ├── .body.left    → treeview (Ordner/Baum)
│   └── .body.right   → text / treeview / preview
└── .status
```

```tcl
# Zonen
ttk::frame .toolbar
ttk::frame .body
ttk::label .status -anchor w -textvariable ::app(status)
pack .toolbar -side top -fill x
pack .status  -side bottom -fill x
pack .body    -fill both -expand 1

# Split
ttk::frame .body.left -width 240
pack .body.left -side left -fill y
pack propagate .body.left 0

ttk::frame .body.right
pack .body.right -side left -fill both -expand 1

ttk::treeview .body.left.tree -show {tree headings} -columns {size}
pack .body.left.tree -fill both -expand 1

text .body.right.detail -wrap word -yscrollcommand {.body.right.sb set}
ttk::scrollbar .body.right.sb -orient vertical -command {.body.right.detail yview}
pack .body.right.sb     -side right -fill y
pack .body.right.detail -fill both -expand 1
```

**Interaktion:** `bind .body.left.tree <<TreeviewSelect>>` → Detail
aktualisieren. Die Logik gehört in `app::actions` (Kapitel 31.5), nicht
in den Binding-Body mit 40 Zeilen `file read`.

**Variante:** `ttk::panedwindow` statt fester Sidebar — Nutzer zieht die
Trennlinie (Abschnitt 11.7).

---

## 12.3 Pattern: Editor (Dokument + Seitenleiste)

**Erkennungsmerkmal:** Großes `text`-Widget, optional Gliederung links,
Menü und Toolbar.

```
.
├── .menu
├── .toolbar
├── .main          (panedwindow)
│   ├── .sidebar   → treeview / listbox
│   └── .editor    → text
└── .status
```

```tcl
menu .menu
. configure -menu .menu
# … File/Edit-Einträge (Kap. 21) …

ttk::frame .toolbar
pack .toolbar -side top -fill x

ttk::panedwindow .main -orient horizontal
pack .main -fill both -expand 1

ttk::treeview .main.outline -show {tree headings} -columns {}
text .main.editor -wrap word -undo 1 \
    -yscrollcommand {.main.ysb set} -xscrollcommand {.main.xsb set}
ttk::scrollbar .main.ysb -orient vertical   -command {.main.editor yview}
ttk::scrollbar .main.xsb -orient horizontal -command {.main.editor xview}

.main add .main.outline -weight 1
.main add .main.editor  -weight 4

ttk::label .status -anchor w -textvariable ::app(status)
pack .status -side bottom -fill x
```

**classic `text`:** Hintergrund an Theme anbinden (Kapitel 24.4):

```tcl
.main.editor configure -background [themeBackground]
```

---

## 12.4 Pattern: Einstellungen (Notebook + Formular)

**Erkennungsmerkmal:** Mehrere thematische Gruppen als Reiter; pro Tab ein
Formular im Grid (Kapitel 8.5).

```
.
└── .nb
     ├── Tab General
     ├── Tab Display
     └── Tab Advanced
```

```tcl
ttk::notebook .nb
pack .nb -fill both -expand 1 -padx 12 -pady 12

foreach {tab title} {general General display Display advanced Advanced} {
    ttk::frame .nb.$tab
    .nb add .nb.$tab -text $title
}

# Beispiel: Tab „General"
set f .nb.general
ttk::label $f.lblName -text "Name:"
ttk::entry  $f.entName -textvariable ::cfg(name)
grid $f.lblName  -row 0 -column 0 -sticky e  -padx {0 8} -pady 4
grid $f.entName  -row 0 -column 1 -sticky ew -pady 4
grid columnconfigure $f 1 -weight 1

# Buttonleiste unten (Dialog-Muster)
ttk::frame .buttons
ttk::button .buttons.ok     -text "OK"     -command app::actions::saveSettings
ttk::button .buttons.cancel -text "Cancel" -command app::actions::closeSettings
pack .buttons.cancel -side right -padx 4
pack .buttons.ok     -side right
pack .buttons -side bottom -fill x -padx 12 -pady 8
```

Einstellungsfenster sind oft **modale Toplevels** (Kap. 22) mit fester
`minsize` — Inhalt wächst, Dialog nicht beliebig schrumpfbar.

---

## 12.5 Pattern: Assistent (Wizard)

**Erkennungsmerkmal:** Schritt 1 … n, Zurück/Weiter, gleicher Rahmen.

**Nicht:** Für jeden Schritt ein neues `toplevel`. **Sondern:** ein Frame
`.wizard.page`, dessen Kinder ausgetauscht werden.

```tcl
namespace eval wizard {
    variable step 1
    variable maxStep 3

    proc showStep {n} {
        variable step
        set step $n
        set p .wizard.page
        foreach w [winfo children $p] { destroy $w }
        # Inhalt je nach $n aufbauen — z. B. buildStep$n $p
        buildStep$n $p
        updateNav
    }

    proc updateNav {} {
        variable step maxStep
        .wizard.back configure -state [expr {$step > 1 ? "normal" : "disabled"}]
        .wizard.next configure -text [expr {$step < $maxStep ? "Next" : "Finish"}]
    }
}

ttk::frame .wizard
pack .wizard -fill both -expand 1
ttk::frame .wizard.page
pack .wizard.page -fill both -expand 1
ttk::frame .wizard.nav
ttk::button .wizard.back   -text "Back"   -command { wizard::showStep [expr {$wizard::step - 1}] }
ttk::button .wizard.next   -text "Next"   -command { wizard::next }
ttk::button .wizard.cancel -text "Cancel" -command { destroy . }
pack .wizard.cancel -side right -padx 4
pack .wizard.next   -side right
pack .wizard.back   -side right -padx 4
pack .wizard.nav -side bottom -fill x
wizard::showStep 1
```

Zustand (Eingaben aus früheren Schritten) liegt in `variable ::wizardData`
oder im Model (Kap. 30) — nicht in nicht-exportierten Widget-Pfaden.

---

## 12.6 Pattern: Modales Suchfenster

**Erkennungsmerkmal:** Kleines Fenster, Fokus im Suchfeld, Ergebnisliste,
Enter wählt, Escape schließt.

```tcl
proc search::open {} {
    toplevel .search
    wm title .search "Search"
    wm transient .search .
    wm geometry .search 480x360

    ttk::entry .search.q
  pack .search.q -fill x -padx 8 -pady 8
    ttk::treeview .search.results -show {headings} -columns {path}
    pack .search.results -fill both -expand 1 -padx 8 -pady {0 8}

    bind .search.q <KeyRelease> [list search::runQuery]
    bind .search.q <Return>     [list search::activateSelection]
    bind .search   <Escape>     [list search::close]

    grab set .search
    focus .search.q
    tkwait window .search
}

proc search::close {} {
    grab release .search
    destroy .search
}
```

Vollständige Modalität: `grab` + `tkwait` (Kap. 22). Suche selbst in
`app::service` — das Fenster zeigt nur Ergebnisse.

---

## 12.7 Pattern: Master-Detail mit Panedwindow

Wenn der Nutzer das Verhältnis links/rechts **ziehen** soll:

```tcl
ttk::panedwindow .p -orient horizontal
pack .p -fill both -expand 1

ttk::treeview .p.master -show {headings} -columns {name}
ttk::frame .p.detail
text .p.detail.t -wrap word

.p add .p.master -weight 1
.p add .p.detail -weight 3

after idle { .p sashpos 0 260 }
```

`weight` steuert, wie Zusatzplatz verteilt wird, wenn das Fenster wächst
(Kapitel 11).

---

## 12.8 Pattern: Sidebar-Navigation

**Erkennungsmerkmal:** Feste schmale Spalte mit Einträgen; rechts wechselt
**ein** Inhaltsframe (nicht das ganze Fenster).

```tcl
ttk::frame .nav -width 180
pack .nav -side left -fill y
pack propagate .nav 0

ttk::frame .content
pack .content -side left -fill both -expand 1

set ::nav(current) ""
proc nav::show {page} {
    set ::nav(current) $page
    foreach w [winfo children .content] { destroy $w }
    # page = settings, about, … — jeweils build proc
    nav::build$page .content
}

ttk::button .nav.settings -text "Settings" -command { nav::show settings }
ttk::button .nav.about    -text "About"    -command { nav::show about }
pack .nav.settings -fill x -padx 4 -pady 2
pack .nav.about    -fill x -padx 4 -pady 2
nav::show settings
```

Aktiver Eintrag: `state selected` oder eigener Style `Nav.TButton`
(Kapitel 24).

---

## 12.9 Pattern-Vergleich

| Pattern | Zonen (pack) | Innerer Manager | Schlüssel-Widget |
|---------|--------------|-----------------|------------------|
| Explorer | ✓ | pack / grid | treeview |
| Editor | ✓ | panedwindow | text |
| Einstellungen | optional | grid pro Tab | notebook |
| Wizard | ✓ | grid in `.page` | frame (tauschen) |
| Suche | — (toplevel) | pack | entry + treeview |
| Master-Detail | ✓ | panedwindow | treeview + detail |
| Sidebar-Nav | ✓ | frame tauschen | buttons + content |

---

## 12.10 Übung

1. Ein Pattern aus der Tabelle wählen  
2. Widget-Baum zeichnen (Anhang F als Vorlage)  
3. Minimalgerüst unter 100 Zeilen — ohne Geschäftslogik  
4. Resize-Test aus Kapitel 11.8  

---

## Zusammenfassung

- Desktop-Patterns sind **Layout-Rezepte**, keine neuen Tk-Features.
- Immer: Skizze → Baum → ein Manager pro Frame → Wachstumskette prüfen.
- Explorer, Editor und Einstellungen decken den Großteil realer Tools ab;
  Wizard, Suche und Sidebar sind Varianten mit gleicher Disziplin.
- Interaktion und Dateizugriff gehören in Application/Services (Kap. 31.5),
  nicht in anonyme Callback-Rumpfe.

Teil 2 (Layout) endet hier. Teil 3 behandelt die einzelnen Widgets im Detail —
dieses Kapitel kann man beim Bau einer konkreten App parallel als
Nachschlagewerk nutzen.
