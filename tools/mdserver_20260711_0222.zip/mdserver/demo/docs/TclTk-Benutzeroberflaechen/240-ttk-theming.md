# [Ttk]{.index}-Theming und Styles

*Stand: 2026-05-29*

## Einführung

Kapitel 4 hat erklärt, *dass* Ttk sein Aussehen über Styles steuert und
nicht über Einzeloptionen. Dieses Kapitel zeigt, *wie*. Das Style-System
ist mächtig und anfangs etwas sperrig, weil es mit drei Begriffen
arbeitet — Style, State, Layout — und weil `ttk::style lookup` gern leere
Strings zurückgibt. Wer das Modell einmal hat, färbt, gestaltet und
themt Ttk-Oberflächen kontrolliert, statt gegen das Theme anzukämpfen.

---

## 24.1 Das Style-Modell: Style, State, Layout

Drei Begriffe tragen das System.

**Style** ist eine benannte Sammlung von Aussehen-Eigenschaften, die einer
Widget-*Klasse* zugeordnet ist. Jede Ttk-Klasse hat einen Standard-Style,
dessen Name mit `T` beginnt: `TButton`, `TLabel`, `TEntry`, `TFrame`,
`TCombobox`. Eigene Varianten benennt man mit einem Präfix vor dem
Klassen-Style: `Danger.TButton`, `Header.TLabel`.

**State** ist der Zustand eines Widgets — `active` (Maus darüber),
`pressed`, `disabled`, `focus`, `selected`, `readonly`, `invalid`,
`background`. Dasselbe Widget kann je Zustand anders aussehen, und das
Style-System erlaubt, Eigenschaften *pro Zustand* zu setzen (Abschnitt
21.2). Die Zustände setzt man mit `state`/`instate` (Kapitel 17).

**Layout** ist der innere Aufbau eines Widgets aus *Elementen* (etwa
Rahmen, Pfeil, Beschriftung bei einer Combobox). Das Layout muss man
selten anfassen, aber es erklärt, warum manche Eigenschaft an einem
Widget nicht greift — sie gehört zu einem Element, das im Layout an
anderer Stelle sitzt. Für den Alltag genügen Style und State.

```tcl
ttk::style theme names    ;# -> clam alt default classic (eingebaut)
ttk::style theme use      ;# aktuelles Theme
ttk::style theme use clam ;# Theme wechseln
```

Welches Theme aktiv ist, bestimmt das Aussehen aller Widgets. `clam` ist
auf allen Plattformen verfügbar und gut anpassbar; die plattformnativen
Themes (`aqua` auf macOS, `vista` unter Windows) sehen am besten aus,
lassen sich aber weniger frei umgestalten.

---

## 24.2 `style configure` und `style map`

Zwei Befehle decken fast allen Bedarf.

**`style configure`** setzt Eigenschaften, die *unabhängig vom Zustand*
gelten:

```tcl
ttk::style configure TButton -padding {12 6} -font {Helvetica 11}
ttk::style configure Header.TLabel -font {Helvetica 16 bold} -foreground "#1a3c6e"

ttk::button .ok -text "OK"                       ;# nutzt TButton-Defaults
ttk::label  .h  -text "Titel" -style Header.TLabel ;# nutzt die eigene Variante
```

Eine eigene Variante (`Header.TLabel`) erbt vom Klassen-Style (`TLabel`)
und überschreibt nur das Genannte. Man weist sie über `-style` zu.

**`style map`** setzt Eigenschaften *pro Zustand* — eine Liste aus
Zustand/Wert-Paaren:

```tcl
ttk::style map TButton \
    -background {active "#4a90d9" pressed "#2c6cb0" disabled "#d0d0d0"} \
    -foreground {disabled "#888888"}
```

Hier bekommt der Button bei Maus-darüber (`active`) einen, beim Drücken
(`pressed`) einen anderen Hintergrund, und im gesperrten Zustand graue
Schrift. `map` ist der Grund, warum ein roter „Löschen"-Button beim
Überfahren dunkler werden kann, ohne dass man Events von Hand bindet —
das Theme zeichnet die Zustände selbst.

Der häufigste Anfängerfehler bleibt der aus Kapitel 4: `ttk::button .b
-background red` tut nichts. Die Farbe gehört in den Style, nicht ans
Widget:

```tcl
# FALSCH -- Option am Widget wird ignoriert
ttk::button .b -text "Löschen" -background red

# RICHTIG -- Style definieren und zuweisen
ttk::style configure Danger.TButton -foreground white
ttk::style map Danger.TButton -background {!disabled "#c0392b" active "#e74c3c"}
ttk::button .b -text "Löschen" -style Danger.TButton
```

Das `!disabled` ist ein negierter Zustand („wenn *nicht* disabled") — so
behält der Button seine Farbe in allen normalen Zuständen, wird aber im
gesperrten Zustand vom Theme-Default übernommen.

---

## 24.3 Ein eigenes Theme als Default setzen

Statt jeden Style einzeln zu konfigurieren, kann man zu Programmstart ein
Basis-Theme wählen und gezielt nachjustieren — das ergibt ein konsistentes
eigenes Aussehen, ohne ein komplettes Theme von Grund auf zu schreiben:

```tcl
proc setupTheme {} {
    ttk::style theme use clam                     ;# anpassbare Basis
    ttk::style configure . -font {Helvetica 11}   ;# "." = für alle Styles
    ttk::style configure TButton -padding {10 5}
    ttk::style configure TEntry -padding 3
    ttk::style configure Header.TLabel -font {Helvetica 16 bold}
    # ... weitere Styles ...
}
setupTheme
```

`ttk::style configure . -font …` (der Punkt als „Wurzel-Style") setzt eine
Eigenschaft für *alle* Styles, die sie nicht selbst überschreiben — der
saubere Weg, eine einheitliche Schrift über die ganze Anwendung zu legen,
ohne jeden Style einzeln zu nennen.

Für umschaltbare Themes (hell/dunkel) bündelt man die Konfiguration in
Prozeduren und ruft beim Wechsel die passende auf — analog zum
Theme-System, das man für das Text-Widget über Tags baut (Kapitel 16):
eine Default-Konfiguration, und das Dunkel-Theme überschreibt nur die
Farben.

---

## 24.4 `style lookup` zum Auslesen von Werten

`ttk::style lookup` liest einen Wert aus dem aktuellen Theme — gebraucht
vor allem, um classic-Widgets an das Ttk-Aussehen anzugleichen
(Kapitel 4):

```tcl
set bg [ttk::style lookup TFrame -background]
text .editor -background $bg
```

Hier lauert eine Falle: `lookup` gibt einen **leeren String** zurück, wenn
das Theme die Option nicht definiert, der Style nicht existiert oder die
Eigenschaft ungesetzt ist. Ein leerer Wert an einem classic-Widget führt
zum Fehler. Deshalb immer mit einer **Fallback-Kette** absichern:

```tcl
proc themeBackground {} {
    set bg [ttk::style lookup TFrame -background]
    if {$bg ne ""} {return $bg}
    set bg [. cget -background]        ;# Toplevel-Farbe als zweite Wahl
    if {$bg ne ""} {return $bg}
    return "#f0f0f0"                   ;# letzter Rückfall
}
canvas .c -background [themeBackground] -highlightthickness 0
```

Eine konkrete Anwendung dieser Technik ist der **Ersatz für
`ttk::separator`**, der sich bei manchen Themes nicht zuverlässig
einfärben lässt. Wo eine bestimmte Trennlinien-Farbe nötig ist, baut man
sie als schmalen Canvas mit Theme-Hintergrund:

```tcl
proc separator {path {orient vertical}} {
    set bg [themeBackground]
    if {$orient eq "vertical"} {
        canvas $path -width 13 -height 24 -highlightthickness 0 -bd 0 -bg $bg
        $path create line 6 4 6 20 -fill "#999999" -width 1
    } else {
        canvas $path -width 24 -height 13 -highlightthickness 0 -bd 0 -bg $bg
        $path create line 4 6 20 6 -fill "#999999" -width 1
    }
    return $path
}
```

Das ist kein Eingeständnis von Magie, sondern das Gegenteil: Wo das Theme
eine verlässliche Zusage verweigert, nimmt man ein Widget, das volle
Kontrolle gibt (den Canvas, Kapitel 26) — sichtbar und nachvollziehbar.

---

**Kapitel 27** vertieft `ttk::style`: eigene Themes, `theme create`, `layout` und `element` — für den Fall, dass `configure`/`map` nicht ausreichen.

## Zusammenfassung

- Drei Begriffe: Style (benannte Eigenschaften je Klasse), State
  (Zustand), Layout (innerer Element-Aufbau, selten nötig).
- `style configure` für zustandsunabhängige Eigenschaften, `style map`
  für zustandsabhängige; eigene Varianten als `Präfix.TKlasse`, zugewiesen
  per `-style`.
- `style configure . -opt val` setzt eine Eigenschaft für alle Styles;
  Themes wechselt `theme use`.
- `style lookup` kann leer zurückgeben — immer mit Fallback-Kette
  absichern; für nicht zuverlässig stylbare Elemente (separator) den
  Canvas als kontrollierbaren Ersatz.

Vom Aussehen der Widgets geht es im nächsten Kapitel zu den Bausteinen,
aus denen es besteht: Schriften, Farben und Bilder.
