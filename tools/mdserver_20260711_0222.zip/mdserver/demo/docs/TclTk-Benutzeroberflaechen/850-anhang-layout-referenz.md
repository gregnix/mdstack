# Referenz-Layout (Widget-Baum)

*Stand: 2026-06-16*

Dieser Anhang ist **Nachschlagewerk**: ein Standard-Anwendungsfenster als
Widget-Baum, Manager-Zuordnung und Minimalgerüst. Er ergänzt Kapitel 10
(Patterns), Kapitel 11 (Responsive) und Kapitel 12 (Desktop-Patterns).

---

## F.1 Standard-Anwendungsfenster (ASCII)

```
.  (toplevel)
├── .toolbar          pack: top, fill x
├── .body             pack: fill both, expand 1
│   ├── .body.left    pack: left, fill y        [optional]
│   │   └── .body.left.tree    treeview
│   └── .body.right   pack: left, fill both, expand 1
│       └── .body.right.nb    notebook
│            ├── Tab „Dokument“  → text
│            └── Tab „Tabelle“   → treeview
└── .status           pack: bottom, fill x
```

**Manager-Regel:** `pack` nur für die **Zonen** (toolbar, body, status).
Innerhalb von `.body.right.nb.*` jeweils **ein** Manager pro Tab-Inhalt
(meist `grid`).

---

## F.2 Dieselbe Struktur (Mermaid)

Für HTML/PDF-Pipelines mit Mermaid-Unterstützung:

```mermaid
flowchart TB
  root[". (toplevel)"]
  tb[".toolbar — pack top fill x"]
  body[".body — pack fill both expand"]
  st[".status — pack bottom fill x"]
  left[".body.left — pack left fill y"]
  right[".body.right — pack left fill both expand"]
  tree["treeview"]
  nb["notebook"]
  tab1["text"]
  tab2["treeview"]
  root --> tb
  root --> body
  root --> st
  body --> left
  body --> right
  left --> tree
  right --> nb
  nb --> tab1
  nb --> tab2
```

Ohne Mermaid im PDF reicht F.1.

---

## F.3 Minimalgerüst (lauffähig)

```tcl
#!/usr/bin/env wish
package require Tk

# --- Zonen (pack) ---
ttk::frame .toolbar
ttk::button .toolbar.open -text "Open"
pack .toolbar.open -side left -padx 4 -pady 4
pack .toolbar -side top -fill x

ttk::label .status -text "Ready" -anchor w
pack .status -side bottom -fill x

ttk::frame .body
pack .body -fill both -expand 1

# --- Body: links Baum, rechts Notebook ---
ttk::frame .body.left -width 220
pack .body.left -side left -fill y
pack propagate .body.left 0

ttk::treeview .body.left.tree -show {tree headings} -columns {name}
.body.left.tree heading name -text "Name"
pack .body.left.tree -fill both -expand 1

ttk::frame .body.right
pack .body.right -side left -fill both -expand 1

ttk::notebook .body.right.nb
pack .body.right.nb -fill both -expand 1

ttk::frame .body.right.nb.doc
text .body.right.nb.doc.t -wrap word -yscrollcommand {.body.right.nb.doc.sb set}
ttk::scrollbar .body.right.nb.doc.sb -orient vertical \
    -command {.body.right.nb.doc.t yview}
grid .body.right.nb.doc.t -row 0 -column 0 -sticky nsew
grid .body.right.nb.doc.sb -row 0 -column 1 -sticky ns
grid rowconfigure    .body.right.nb.doc 0 -weight 1
grid columnconfigure .body.right.nb.doc 0 -weight 1

ttk::treeview .body.right.nb.table -columns {a b} -show headings
.body.right.nb.table heading a -text "A"
.body.right.nb.table heading b -text "B"

.body.right.nb add .body.right.nb.doc    -text "Document"
.body.right.nb add .body.right.nb.table -text "Table"

# --- Fenster ---
wm title . "Reference Layout"
wm minsize . 640 400
wm geometry . 900x560
```

---

## F.4 Manager-Tabelle

| Widget-Pfad | Manager | Wichtige Optionen |
|-------------|---------|-------------------|
| `.toolbar` | pack | `-side top -fill x` |
| `.status` | pack | `-side bottom -fill x` |
| `.body` | pack | `-fill both -expand 1` |
| `.body.left` | pack | `-side left -fill y`, `propagate 0` |
| `.body.left.tree` | pack | `-fill both -expand 1` |
| `.body.right` | pack | `-side left -fill both -expand 1` |
| `.body.right.nb` | pack | `-fill both -expand 1` |
| Tab-Inhalt | grid | `rowconfigure/columnconfigure -weight 1` |

---

## F.5 Varianten (Kurzverweis)

| Anwendungstyp | Abweichung vom Standard | Kapitel |
|---------------|-------------------------|---------|
| Nur Editor | kein `.body.left`, nur `text` | 11.3 |
| Einstellungen | `.body` = direkt `notebook`, kein Split | 11.4 |
| Master-Detail | `panedwindow` statt festem `.body.left` | 11.7 |
| Wizard | `.body` = ein `.page` Frame, Inhalt tauschen | 11.5 |

---

## F.6 Checkliste „Baum vor Code"

- [ ] Skizze (ASCII oder F.1) gezeichnet
- [ ] Pro Frame genau ein Manager notiert
- [ ] Wachstumskette für `.body.right` markiert (Kap. 11)
- [ ] `wm minsize` gesetzt
- [ ] Resize-Test (Kap. 11.8) durchgeführt
