# [pack]{.index} — der Stapler

*Stand: 2026-05-29*

## Einführung

`pack` ist der älteste und für lineare Anordnungen einfachste Geometry
Manager. Er stapelt Widgets in eine Richtung — und genau das macht ihn
stark für Toolbars, Statusleisten und den groben Aufbau eines Fensters,
aber unhandlich für tabellarische Formulare (dafür ist `grid` da, Kapitel
8). Dieses Kapitel zeigt das Hohlraum-Modell hinter `pack`, das
Zusammenspiel der drei wichtigen Optionen und die Muster, die wirklich
tragen.

---

## 7.1 Grundprinzip: stapeln in eine Richtung

`pack` behandelt das Eltern-Widget als **Hohlraum**. Jeder `pack`-Aufruf
nimmt einen Streifen von einer Seite dieses Hohlraums weg und setzt das
Widget hinein; der Rest bleibt für die nächsten Aufrufe übrig.

```tcl
ttk::button .b1 -text "Oben"
ttk::button .b2 -text "Darunter"
pack .b1 -side top
pack .b2 -side top
```

`.b1` nimmt einen Streifen oben, `.b2` den nächsten Streifen vom
verbleibenden Raum — ebenfalls oben, also direkt darunter. Die
**Reihenfolge der Aufrufe** ist damit Teil der Bedeutung (Abschnitt 6.4).

---

## 7.2 `-side`, `-fill`, `-expand` im Zusammenspiel

Drei Optionen tragen `pack`. Sie greifen ineinander, und genau dieses
Zusammenspiel ist der Kern.

**`-side`** — von welcher Seite der Streifen genommen wird:

```tcl
pack .w -side top      ;# Standard
pack .w -side bottom
pack .w -side left
pack .w -side right
```

**`-fill`** — ob das Widget den ihm zugewiesenen Streifen ausfüllt:

```tcl
pack .w -fill x        ;# in der Breite füllen
pack .w -fill y        ;# in der Höhe füllen
pack .w -fill both     ;# beides
```

**`-expand`** — ob das Widget *zusätzlichen* freien Platz beanspruchen
darf, wenn der Hohlraum größer ist als nötig:

```tcl
pack .w -expand 1
```

Wie Kapitel 6 betont: `-fill` und `-expand` sind ein Paar. `-expand 1`
gibt dem Widget Anspruch auf Zusatzplatz; `-fill both` sorgt dafür, dass
es ihn auch einnimmt statt nur zentriert dazustehen. Der mitwachsende
Hauptbereich eines Fensters braucht beides:

```tcl
text .content
pack .content -fill both -expand 1
```

---

## 7.3 `-padx`/`-pady` gegen `-ipadx`/`-ipady`

Zwei Sorten Abstand, die man leicht verwechselt:

```tcl
pack .w -padx 10 -pady 5     ;# AUSSEN: Abstand um das Widget herum
pack .w -ipadx 8 -ipady 4    ;# INNEN: Widget wird selbst größer
```

`-padx`/`-pady` lassen Luft zwischen Widget und Nachbarn; das Widget
bleibt gleich groß. `-ipadx`/`-ipady` vergrößern das Widget selbst, indem
sie seinen Inhalt mit Innenrand umgeben. Für Abstände zwischen Buttons
nimmt man `-padx`; um einen Button „fetter" zu machen, `-ipadx`.

Beide akzeptieren auch ein Paar für ungleiche Ränder:

```tcl
pack .w -padx {12 4}     ;# links 12, rechts 4
```

---

## 7.4 Reihenfolge ist Bedeutung

Weil jeder Aufruf einen Streifen vom Rest wegnimmt, ändert die
Reihenfolge das Ergebnis. Das prägnanteste Beispiel ist die Statusleiste:

```tcl
# FALSCH: Inhalt zuerst, Statusleiste danach
text .content
pack .content -fill both -expand 1
ttk::label .status -text "Bereit" -anchor w
pack .status -side bottom -fill x
# Beim Verkleinern frisst .content den Platz -- .status wird abgeschnitten

# RICHTIG: Statusleiste (und Toolbar) ZUERST packen
ttk::label .status -text "Bereit" -anchor w
pack .status -side bottom -fill x
ttk::frame .toolbar
pack .toolbar -side top -fill x
text .content
pack .content -fill both -expand 1
```

Die Regel dahinter: Ränder zuerst, expandierender Inhalt zuletzt. Wer den
expandierenden Bereich früh packt, gibt ihm den Platz, den die später
gepackten Ränder dann nicht mehr sicher bekommen. Erst Toolbar oben,
Statusleiste unten — dann der Inhalt, der den Rest füllt.

---

## 7.5 Tragfähige Muster

**Toolbar:** horizontale Knöpfe links, Rest frei.

```tcl
ttk::frame .toolbar
pack .toolbar -side top -fill x
foreach {name text} {new Neu open Öffnen save Speichern} {
    ttk::button .toolbar.$name -text $text
    pack .toolbar.$name -side left -padx 2 -pady 2
}
```

**Drei-Zonen-Fenster:** Toolbar oben, Statusleiste unten, Inhalt
dazwischen — das Grundgerüst fast jeder Anwendung.

```tcl
ttk::frame .toolbar
pack .toolbar -side top -fill x
ttk::label .status -anchor w -text "Bereit"
pack .status -side bottom -fill x
ttk::frame .main
pack .main -fill both -expand 1      ;# füllt, was übrig bleibt
```

In `.main` baut man dann mit `grid` oder einem weiteren `pack`/Frame
weiter — je ein Manager pro Frame (Kapitel 6).

**Rechtsbündige Dialog-Buttons:** OK rechts, Abbrechen daneben.

```tcl
ttk::frame .btns
pack .btns -side bottom -fill x -pady 6
ttk::button .btns.ok     -text "OK"
ttk::button .btns.cancel -text "Abbrechen"
pack .btns.ok     -side right -padx {4 8}
pack .btns.cancel -side right
```

Mit `-side right` reiht sich der zuerst gepackte Button ganz rechts ein,
der nächste links daneben — daher OK vor Abbrechen, wenn OK rechts außen
stehen soll.

---

## Zusammenfassung

- `pack` stapelt in eine Richtung; das Eltern-Widget ist ein Hohlraum,
  von dem jeder Aufruf einen Streifen nimmt.
- `-side` wählt die Seite, `-fill` füllt den Streifen, `-expand 1` greift
  nach Zusatzplatz; mitwachsen braucht `-fill both -expand 1`.
- `-padx`/`-pady` ist Außenabstand, `-ipadx`/`-ipady` vergrößert das
  Widget selbst.
- Reihenfolge ist Bedeutung: Ränder (Toolbar/Statusleiste) zuerst,
  expandierender Inhalt zuletzt.

`pack` deckt lineare und grobe Layouts ab. Sobald es um Zeilen-und-
Spalten-Raster geht — also um fast jedes Formular — ist `grid` das
bessere Werkzeug. Das ist Kapitel 8.
