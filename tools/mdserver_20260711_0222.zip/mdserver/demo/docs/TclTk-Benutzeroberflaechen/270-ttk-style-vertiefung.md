# ttk::style im Detail — Themes und Layouts

*Stand: 2026-06-16*

## Einführung

Kapitel 24 hat das Style-Modell eingeführt: `configure`, `map`, `theme use`,
`lookup` mit Fallback-Kette. Für den Alltag — ein paar Farben, ein
`Header.TLabel`, classic-Widgets anpassen — reicht das.

Wer ein **eigenes Erscheinungsbild** will (Firmenfarben, kompakte Toolbar,
hell/dunkel umschaltbar), stößt schnell an Grenzen: `theme create`,
`layout`, `element` und `theme settings` sind in der offiziellen Dokumentation
dünn und in Foren verstreut. Dieses Kapitel schließt die Lücke.

**Voraussetzung:** Kapitel 4 (classic vs. Ttk), Kapitel 24.  
**Verweist auf:** Kapitel 38 / Anhang E (Designsystem), Kapitel 25 (Fonts).

---

## 27.1 Architektur: Theme → Style → Layout → Element

Vier Ebenen — von außen nach innen:

| Ebene | Befehl (Auswahl) | Was sie tut |
|-------|------------------|-------------|
| **Theme** | `theme use`, `theme create` | Gesamtpaket aller Styles |
| **Style** | `style configure`, `style map` | Aussehen je Widget-Klasse |
| **Layout** | `style layout` | Anordnung der Elemente im Widget |
| **Element** | `style element create` | Einzelne Zeichenflächen (selten nötig) |

Kapitel 24 arbeitete vor allem auf **Style**-Ebene. Dieses Kapitel ergänzt
**Theme** und **Layout**.

---

## 27.2 `theme create` und Vererbung

Ein neues Theme leitet man von einem bestehenden ab — üblich: `clam`
(plattformneutral, gut anpassbar):

```tcl
ttk::style theme create myapp -parent clam
ttk::style theme use myapp
```

`-parent` bestimmt, was nicht überschrieben wird. Ohne eigenes `layout`
für `TButton` gilt das Layout von `clam`.

**Wann `theme create`?** Wenn man das Aussehen **bündeln** und ggf.
exportieren will (`theme settings`, Abschnitt 24.5). Wenn nur zehn
`configure`-Zeilen reichen, genügt `theme use clam` + Anpassungen wie in
Kapitel 24.3.

```tcl
proc ::ui::theme::init {} {
    if {"myapp" ni [ttk::style theme names]} {
        ttk::style theme create myapp -parent clam
    }
    ttk::style theme use myapp
    ttk::style configure . -font {DejaVu Sans 11}
    ttk::style configure TButton -padding {10 5}
    # Primary / Danger (Kap. 24.2)
    ttk::style configure Primary.TButton -foreground white
    ttk::style map Primary.TButton \
        -background [list !disabled "#2563eb" active "#1d4ed8" disabled "#ccc"]
}
```

`::ui::theme::init` einmal beim Start — z. B. aus `main.tcl` vor `build`.

---

## 27.3 `style layout` lesen und anpassen

Das Layout eines Widgets ist ein verschachtelter Baum aus **Elementen**:

```tcl
puts [ttk::style layout TButton]
# typisch: border → focus → padding → label
```

**Use case:** Kompakter Toolbar-Button ohne großen Rahmen — eigenes Layout
für `Toolbutton.TButton`:

```tcl
ttk::style layout Toolbutton.TButton {
    Toolbutton.border -sticky nswe -children {
        Toolbutton.focus -sticky nswe -children {
            Toolbutton.padding -sticky nswe -children {
                Toolbutton.label -side left -sticky {}
            }
        }
    }
}
ttk::style configure Toolbutton.TButton -padding {4 2}
ttk::button .tb.save -text "Save" -style Toolbutton.TButton
```

**Vorsicht:** Ein falsches Layout lässt Buttons kollabieren oder riesig
werden. Vor dem Ändern das Original mit `puts [ttk::style layout TButton]`
speichern.

**Regel:** Layout nur anfassen, wenn `configure`/`map` nicht reichen —
Padding und Farben sind fast immer Style-Ebene.

---

## 27.4 `style element` (Überblick)

Elemente definieren, *wie* gezeichnet wird (`image`, `vsapi`, `rect`, …).
Das ist Theme-Autoren-Thema; für Anwendungsentwicklung selten nötig.

Ein pragmatischer Umgang:

1. Von `clam` erben  
2. Farben und Fonts per `configure`/`map`  
3. Nur bei hartnäckigen Sonderfällen `element create` — dann Manpage und
   ein Minimalbeispiel aus dem Tcl-Core-Theme als Vorlage

Dieses Buch ersetzt keine vollständige Theme-Engine-Dokumentation; es
verhindert, dass man `element` zu früh anfasst.

---

## 27.5 `theme settings` — Theme exportieren und laden

```tcl
set data [ttk::style theme settings myapp]
# $data als Tcl-Dict in Datei speichern — Wartung, Versionierung

# Auf anderem System / nach Änderung:
ttk::style theme create myapp -parent clam
ttk::style theme settings myapp $data
ttk::style theme use myapp
```

Nützlich für Teams: ein „Theme-Paket" neben der Anwendung, ohne alle
`configure`-Zeilen im Code.

---

## 27.6 Hell und Dunkel umschalten

Zwei Prozeduren, die **dieselben Style-Namen** mit anderen Werten füllen:

```tcl
namespace eval ::ui::theme {
    variable mode light

    proc applyLight {} {
        variable mode
        set mode light
        ttk::style theme use myapp
        _configureColors \
            bg "#f5f5f5" fg "#111" \
            primary "#2563eb" danger "#dc2626"
        _syncClassicWidgets
    }

    proc applyDark {} {
        variable mode
        set mode dark
        ttk::style theme use myapp
        _configureColors \
            bg "#1e1e1e" fg "#e5e5e5" \
            primary "#3b82f6" danger "#ef4444"
        _syncClassicWidgets
    }

    proc _configureColors {args} {
        foreach {k v} [array get [dict create {*}$args]] {
            # bg/fg auf TFrame, TLabel, … mappen
        }
        ttk::style configure TFrame -background $bg
        ttk::style configure TLabel -background $bg -foreground $fg
        # Primary.TButton, Danger.TButton map …
    }

    proc _syncClassicWidgets {} {
        set bg [ttk::style lookup TFrame -background]
        foreach w [winfo children .] {
            _syncClassicRecursive $w $bg
        }
    }
    proc _syncClassicRecursive {w bg} {
        if {[winfo class $w] in {Text Canvas Listbox}} {
            catch {$w configure -background $bg}
        }
        foreach c [winfo children $w] { _syncClassicRecursive $c $bg }
    }
}
```

Ttk allein reicht nicht: `text`, `canvas`, `listbox` brauchen die
Synchronisation aus Kapitel 24.4.

---

## 27.7 Primary-, Secondary- und Danger-Buttons

Designsystem (Kap. 38) in Styles gießen:

```tcl
ttk::style configure Primary.TButton -font {DejaVu Sans 11 bold}
ttk::style map Primary.TButton -background \
    [list !disabled "#2563eb" active "#1d4ed8" pressed "#1e40af" disabled "#bbb"]

ttk::style configure Danger.TButton -foreground white
ttk::style map Danger.TButton -background \
    [list !disabled "#dc2626" active "#b91c1c" disabled "#bbb"]

# Secondary: Standard TButton oder flacher Toolbutton-Stil
```

**Eine** Primary-Aktion pro Dialog oder Abschnitt — nicht jeden Button blau
malen (Kap. 5 GUI-Grundsätze).

---

## 27.8 Fehlerbilder

| Symptom | Ursache | Abhilfe |
|---------|---------|---------|
| `-background` am Widget ignoriert | Ttk-Regel | Style, nicht Widget (Kap. 24.2) |
| `lookup` liefert `""` | Option im Theme undefiniert | Fallback-Kette (Kap. 24.4) |
| Button plötzlich winzig | Layout zerstört | Layout zurücksetzen / Parent-Theme |
| Dark Mode nur halb | classic-Widgets vergessen | `_syncClassicWidgets` |
| Theme wechselt nicht | `theme use` vor `configure` vergessen | Reihenfolge: create → use → configure |

---

## 27.9 Debugging-Hilfen

```tcl
# Aktuelles Theme
puts [ttk::style theme use]

# Alle Optionen eines Styles
puts [ttk::style configure TButton]

# Effektiver Wert inkl. Vererbung
puts [ttk::style lookup TButton -background]

# Layout inspizieren
puts [ttk::style layout TButton]
```

Bei „warum sieht mein Combobox-Pfeil so aus?" — Layout ausgeben und mit
`clam` vergleichen.

---

## Zusammenfassung

- `theme create -parent clam` bündelt ein anwendungseigenes Theme; `theme
  use` aktiviert es.
- `style layout` steuert die innere Struktur — nur bei Toolbar/Sonderformen
  nötig; Farben bleiben bei `configure`/`map`.
- `theme settings` exportiert/importiert Themes; hell/dunkel = zwei
  Konfigurationsläufe + classic-Sync.
- Primary/Danger-Styles tragen das Designsystem; Fehlerbilder sind
  überwiegend Vererbung und classic-Ttk-Mix.

Damit ist das Style-System für typische Desktop-Anwendungen erschöpfend
abgedeckt. Kapitel 25 ergänzt Schriften und Bilder; das Designsystem
(Kap. 38 / Anhang E) fasst die empfohlenen Werte tabellarisch zusammen.
