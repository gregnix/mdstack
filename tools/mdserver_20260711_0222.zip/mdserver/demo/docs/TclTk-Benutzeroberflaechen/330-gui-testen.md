# Oberflächen testen

*Stand: 2026-05-29*

## Einführung

„GUIs kann man nicht testen" ist ein verbreiteter Irrtum. Vieles an einer
Oberfläche ist sehr wohl testbar — wenn man weiß, *was* und *wie*. Dieses
Kapitel grenzt das Testbare ab, zeigt das synthetische Erzeugen von
Ereignissen mit `event generate`, den richtigen Einsatz von `update` im
Test und das wichtigste Prinzip: Logik vor Darstellung testen.

---

## 33.1 Was an einer GUI überhaupt testbar ist

Eine Oberfläche zerfällt für den Test in drei Schichten mit sehr
unterschiedlicher Testbarkeit:

- **Logik** (das Modell aus Kapitel 30): vollständig testbar, ohne
  laufende GUI. Hier liegt der größte Hebel.
- **Verhalten** (Bindings, Aktionen, Widget-Reaktionen): testbar über
  synthetische Ereignisse und das Abfragen von Widget-Zuständen.
- **Aussehen** (Pixel, Farben, exaktes Layout): kaum sinnvoll
  automatisiert testbar — das prüft man mit dem Auge.

Die Konsequenz ist eine Prioritätenfolge: Den Großteil der Tests richtet
man auf die Logik (die dank Trennung gar keine GUI braucht), einen
kleineren Teil auf das Verhalten, und das Aussehen prüft man manuell.
Genau deshalb war Kapitel 30 die Voraussetzung für dieses — eine
Anwendung, deren Logik im Widget-Code steckt, ist schwer testbar; eine mit
getrennter Logik fast von selbst.

---

## 33.2 Events synthetisch erzeugen (`event generate`)

Um Verhalten zu testen, muss man Ereignisse auslösen, ohne zu klicken.
`event generate` erzeugt jedes Tk-Ereignis künstlich:

```tcl
event generate .b <Button-1>              ;# Klick auf .b
event generate .e <KeyPress> -keysym a    ;# Taste "a" in .e
event generate .e <Return>                ;# Enter
event generate .lb <<ListboxSelect>>      ;# virtuelles Event
```

Damit lässt sich ein Ablauf nachstellen und das Ergebnis prüfen:

```tcl
# Test: Klick auf "Hinzufügen" fügt einen Datensatz hinzu
set ::form(name) "Test"
event generate .toolbar.add <Button-1>
update                                     ;# Event verarbeiten lassen
assert {[llength [model::all]] == 1}
```

Für Buttons ist `invoke` oft direkter als ein synthetischer Klick, weil es
den `-command` ohne Koordinaten auslöst und den Zustand respektiert
(Kapitel 17):

```tcl
.toolbar.add invoke
```

`event generate` braucht man, wo es um das Ereignis *selbst* geht
(Tastendruck, Mausbewegung, Fokuswechsel), `invoke` wo es um die
*Aktion* geht.

---

## 33.3 `update` im Test richtig einsetzen

Tk verarbeitet Ereignisse im Event-Loop (Kapitel 19). In einem Test läuft
der Loop aber nicht von selbst — ein synthetisches Event landet in der
Queue und wird erst verarbeitet, wenn der Loop drankommt. Im Test stößt
man das mit `update` an:

```tcl
event generate .e <Return>
update                  ;# jetzt wird das Return-Binding ausgeführt
```

Ohne `update` würde der Test die Wirkung des Events prüfen, bevor es
verarbeitet wurde — und fehlschlagen. `update idletasks` reicht, wenn es
nur ums Neuzeichnen geht; für die Verarbeitung von Eingabe-Events braucht
es das volle `update`.

Die Reentrancy-Warnung aus Kapitel 19 entschärft sich im Test, weil hier
kein Nutzer dazwischenklickt — `update` ist im kontrollierten Testablauf
unproblematischer als in der laufenden Anwendung. Trotzdem hält man Tests
schlank: ein Event, ein `update`, eine Prüfung.

Tk-Tests brauchen ein Display. Auf Servern ohne Bildschirm nutzt man ein
virtuelles X-Display (etwa `Xvfb` unter Linux), damit `package require Tk`
gelingt — die Tests selbst bleiben unverändert.

---

## 33.4 Logik vor Darstellung testen

Das Wichtigste zum Schluss, weil es alles andere relativiert: Der
wertvollste Test berührt die GUI gar nicht. Liegt die Logik im Modell und
ist von Widgets unabhängig (Kapitel 30), prüft man sie direkt — schnell,
stabil, ohne Display:

```tcl
package require tcltest
namespace import tcltest::*

test add-1 "Hinzufügen erhöht die Anzahl" -body {
    model::reset
    model::add [dict create name "A"]
    model::add [dict create name "B"]
    llength [model::all]
} -result 2

test validate-1 "leerer Name ist ungültig" -body {
    model::isValid [dict create name ""]
} -result 0

cleanupTests
```

`tcltest` ist Tcls eingebautes Test-Framework: `test name beschreibung
-body {…} -result erwartet` vergleicht das Ergebnis des Körpers mit der
Erwartung. Solche Tests laufen in Millisekunden und ohne `wish` — sie sind
das Rückgrat einer testbaren Anwendung.

Für das Verhalten ergänzt man Widget-Tests (mit `event generate`/`invoke`
und `update`), die prüfen, dass die *Verdrahtung* stimmt: dass der Button
die Aktion auslöst, dass das Binding feuert, dass ein gesperrtes Widget
nicht reagiert. Aber die *Geschäftsregeln* — was ein gültiger Datensatz
ist, wie eine Berechnung läuft — gehören in die widgetfreien Logik-Tests.

Die Faustregel: Wenn ein Test nur über das Klicken eines Buttons möglich
ist, steckt zu viel Logik im Button. Das ist kein Test-Problem, sondern
ein Struktur-Hinweis — und führt zurück zu Kapitel 30.

---

## Zusammenfassung

- Drei Schichten: Logik (voll testbar, ohne GUI), Verhalten (über
  synthetische Events), Aussehen (manuell). Den Großteil der Tests auf die
  Logik richten.
- `event generate` erzeugt Ereignisse künstlich (Tasten, Klicks,
  virtuelle Events); `invoke` löst Aktionen direkt aus.
- Im Test stößt `update` die Event-Verarbeitung an; ohne Display ein
  virtuelles X (Xvfb).
- `tcltest` für widgetfreie Logik-Tests als Rückgrat; lässt sich etwas nur
  per Button-Klick testen, steckt zu viel Logik im Widget.

Das vorletzte Kapitel widmet sich der Auslieferung: wie aus der getesteten
Anwendung ein verteilbares Programm wird.
