# Schriften, Farben, Bilder

*Stand: 2026-05-29*

## Einführung

Drei Darstellungs-Bausteine ziehen sich durch jede Oberfläche: Schrift,
Farbe und Bild. Bei allen dreien gibt es einen bequemen, verstreuten Weg
und einen zentralen, wartbaren — und in allen dreien ist der zentrale
der richtige. Dieses Kapitel zeigt benannte Fonts statt Inline-Specs,
den Umgang mit Farben und Systemfarben, und das Laden und Skalieren von
`photo`-Bildern samt HiDPI.

---

## 25.1 Benannte Fonts gegen Font-Specs

Eine Schrift lässt sich in Tk auf zwei Weisen angeben. Als **Spec** —
eine Liste aus Familie, Größe, Stil — direkt am Widget:

```tcl
ttk::label .l -font {Helvetica 14 bold}
```

Oder als **benannter Font**, einmal erzeugt und überall referenziert:

```tcl
font create H1 -family Helvetica -size 16 -weight bold
ttk::label .l -font H1
.t tag configure h1 -font H1        ;# auch am Text-Widget-Tag
```

Der Unterschied zeigt sich bei der Wartung. Wer Specs an Dutzenden
Widgets verstreut, muss zum Ändern der Schriftgröße jede Stelle suchen.
Ein benannter Font ändert sich an **einer** Stelle, und alle Widgets, die
ihn nutzen, ziehen automatisch mit:

```tcl
font configure H1 -size 20    ;# alle H1-Nutzer werden sofort größer
```

Das ist dieselbe Logik wie bei den Tags im Text-Widget (Kapitel 16) und
bei den Styles (Kapitel 24): einmal definieren, überall referenzieren.
Für jede Oberfläche, die mehr als eine Handvoll Schriften nutzt — oder
die eine umschaltbare Schriftgröße bieten will — sind benannte Fonts die
richtige Wahl.

Tk bringt zudem **vordefinierte benannte Fonts** mit, die dem System
folgen: `TkDefaultFont`, `TkTextFont`, `TkFixedFont`, `TkHeadingFont`,
`TkMenuFont`. Wer auf ihnen aufbaut, bekommt automatisch die Systemschrift
in der richtigen Größe:

```tcl
font create H1 -font TkDefaultFont    ;# erbt System-Defaults
font configure H1 -size 16 -weight bold
```

---

## 25.2 Farben benennen, Systemfarben, Kontrast

Farben gibt man als Hex-Wert (`#rrggbb`), als benannte Farbe (`red`,
`steelblue`, `gray30`) oder als Systemfarbe an. Für eigene Akzente sind
Hex-Werte am verlässlichsten:

```tcl
.t tag configure warnung -foreground "#c0392b"
canvas .c -background "#1e1e1e"
```

Wichtiger als die Schreibweise ist die **Quelle**. Wer feste Farben in
eine Ttk-Oberfläche schreibt, riskiert, dass sie beim Theme-Wechsel oder
unter einem dunklen Systemschema nicht mehr passen — heller Text auf
plötzlich hellem Grund. Deshalb gilt wie in Kapitel 24: Hintergrund- und
Standard-Vordergrundfarben besser aus dem Theme lesen
(`ttk::style lookup`) als raten, und eigene Akzentfarben so wählen, dass
sie gegen beide Theme-Varianten genug **Kontrast** haben.

Für classic-Widgets, die das Theme nicht kennen, ist das Angleichen an
den Theme-Hintergrund (Kapitel 4, 24) der Weg, optische Brüche zu
vermeiden. Die Faustregel: feste Farben sparsam und nur dort, wo sie
inhaltlich gemeint sind (Warnrot, Erfolgsgrün) — Strukturfarben aus dem
Theme.

---

## 25.3 `photo`-Images laden und skalieren

Bilder verwaltet Tk als **Image-Objekte**, die man einmal erzeugt und an
beliebig vielen Widgets referenziert. Der gängige Typ ist `photo`:

```tcl
image create photo logo -file logo.png      ;# PNG/GIF nativ (Tk 8.6+)
ttk::label .l -image logo
ttk::button .b -image logo -text "Start" -compound left
```

Tk 8.6 und 9 lesen PNG und GIF von Haus aus; für JPEG und weitere Formate
braucht es das `Img`-Paket. Ein Image-Objekt lebt unabhängig vom Widget —
zerstört man das Widget, bleibt das Image bestehen (und belegt Speicher),
bis man es selbst freigibt:

```tcl
image delete logo     ;# Image-Objekt freigeben
```

**Skalieren** geht über `copy` mit `-subsample` (verkleinern) oder `-zoom`
(vergrößern) in ein zweites Image — beides nur in ganzzahligen Faktoren:

```tcl
image create photo logoKlein
logoKlein copy logo -subsample 2 2    ;# auf die Hälfte verkleinern
image create photo logoGross
logoGross copy logo -zoom 2 2          ;# auf das Doppelte vergrößern
```

Für stufenlose, qualitativ gute Skalierung reichen die Bordmittel nicht;
dafür nutzt man Erweiterungen wie `Img` oder verarbeitet das Bild vor dem
Laden. Die eingebaute `copy`-Skalierung ist für Icons in festen Stufen
gedacht, nicht für freie Größenanpassung.

---

## 25.4 Hochauflösende Displays und Skalierung

Auf HiDPI-Displays (Retina, 4K) wirken in Pixeln gemessene Größen winzig.
Tk steuert die globale Skalierung über `tk scaling` — den Faktor zwischen
Punkten und Pixeln:

```tcl
tk scaling              ;# aktuellen Faktor lesen
tk scaling 2.0          ;# z.B. für ein hochauflösendes Display
```

Schriftgrößen in **Punkten** (positive Zahl bei `font`) skalieren mit
`tk scaling` automatisch mit; Größen in **Pixeln** (negative Zahl, etwa
`-size -16`) nicht. Wer auf verschiedenen Displays gut aussehen will,
gibt Schriftgrößen daher in Punkten an und überlässt die Umrechnung der
Skalierung.

Unter Tcl/Tk 9 ist die HiDPI-Behandlung deutlich besser geworden: Die
Standard-Dialoge (Kapitel 22) und das Padding der Container skalieren
automatisch, und auf Plattformen mit System-DPI übernimmt Tk den Faktor
oft von selbst. Für eigene Pixelmaße — etwa feste Frame-Größen oder
Canvas-Koordinaten — bleibt man aber selbst verantwortlich: Wer überall
mit benannten Fonts und relativen Maßen arbeitet, hat es hier am
einfachsten, wer feste Pixel verstreut, am schwersten.

---

## Zusammenfassung

- Benannte Fonts (`font create`/`font configure`) statt verstreuter
  Specs: einmal definieren, überall referenzieren, zentral ändern; auf
  `TkDefaultFont` & Co. aufbauen für Systemnähe.
- Farben als Hex für Akzente, Strukturfarben aus dem Theme
  (`ttk::style lookup`); feste Farben sparsam, mit Blick auf Kontrast in
  hellem und dunklem Schema.
- `image create photo` lädt PNG/GIF (JPEG via `Img`); Skalieren über
  `copy -subsample`/`-zoom` nur in ganzen Stufen; Images selbst freigeben.
- `tk scaling` steuert HiDPI; Schriftgrößen in Punkten skalieren mit,
  Pixelmaße nicht — Tcl/Tk 9 nimmt vieles automatisch ab.

Das letzte Kapitel von Teil 5 verlässt die fertigen Widgets und betritt
die freie Zeichenfläche — den Canvas.
