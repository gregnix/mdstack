# Responsives Desktop-Layout

*Stand: 2026-06-16*

## Einführung

Kapitel 10 hat gezeigt, wie echte Fenster aufgebaut werden und welche
Checkliste „mitwachsendes" Layout trägt. Trotzdem passiert es ständig:
Die Oberfläche sieht bei der Größe des Entwicklers gut aus — und bricht
zusammen, sobald der Nutzer das Fenster verkleinert, auf einen kleineren
Monitor wechselt oder die Taskleiste Platz wegnimmt.

Dieses Kapitel behandelt **Desktop-Responsive-Layout** im Tk-Sinn: nicht
CSS-Media-Queries, sondern die **Wachstumskette** von Toplevel bis zum
Widget, Mindestgrößen, typische Fehlerbilder und ein systematischer Test.
HiDPI wird nur angerissen; Details stehen in Kapitel 25.

**Voraussetzung:** Kapitel 6 (Geometry-Modell), Kapitel 7–10 (Manager und
Patterns). **Verweist auf:** Anhang F (Referenz-Layout), Kapitel 12
(Desktop-Patterns), Anhang D (Checkliste).

---

## 11.1 Das Problem der „Designer-Größe"

Viele Tk-Programme werden einmal mit fester Geometrie entwickelt:

```tcl
wm geometry . 1024x768+100+100
```

Das ist als **Startgröße** in Ordnung — als **einzige** gültige Größe
nicht. Symptome:

- Buttons werden abgeschnitten, wenn die Statusleiste nach oben rutscht
- Eine Spalte bleibt schmal, obwohl Platz da wäre
- Der Hauptbereich wächst nicht mit, nur leerer Rand um ein kleines Widget
- Scrollbars fehlen, weil der Inhalt überläuft statt zu scrollen

Die Ursache ist fast nie „Tk kann das nicht". Es ist eine **unterbrochene
Kette** aus `-expand`, `-fill`, `-weight` und `-sticky` — oder ein
Geometry-Manager-Verstoß aus Kapitel 6.

---

## 11.2 Die Wachstumskette

**Regel:** Soll ein Widget mit dem Fenster mitwachsen, muss **jede Ebene**
zwischen `.` (Toplevel) und diesem Widget den Zusatzplatz weiterreichen.

Beispiel Explorer-artiges Fenster:

```
.  (Toplevel)
└── .body          pack -fill both -expand 1
    └── .main      grid rowconfigure 0 -weight 1
        ├── .main.tree    grid sticky ns
        └── .main.detail  grid sticky nsew  + columnconfigure 1 -weight 1
```

Was passiert beim Vergrößern?

1. Das Toplevel wird größer
2. `.body` bekommt Platz, weil `pack -expand 1 -fill both`
3. `.main` füllt `.body`, weil `grid` mit `rowconfigure -weight 1`
4. `.main.detail` füllt die Zelle, weil `sticky nsew` **und** `columnconfigure 1 -weight 1`

Bricht die Kette an **einer** Stelle, stoppt das Wachstum — der Rest des
Platzes bleibt leer oder das Widget bleibt in der Ecke kleben.

```tcl
# Minimalgerüst mit vollständiger Kette
ttk::frame .body
pack .body -fill both -expand 1

ttk::frame .body.main
grid .body.main -row 0 -column 0 -sticky nsew
grid rowconfigure    .body 0 -weight 1
grid columnconfigure .body 0 -weight 1

ttk::treeview .body.main.tree
text .body.main.detail -wrap word -yscrollcommand {.body.main.sb set}
ttk::scrollbar .body.main.sb -orient vertical -command {.body.main.detail yview}

grid .body.main.tree   -row 0 -column 0 -sticky ns
grid .body.main.sb     -row 0 -column 1 -sticky ns
grid .body.main.detail -row 0 -column 2 -sticky nsew
grid columnconfigure .body.main 2 -weight 1
grid rowconfigure    .body.main 0 -weight 1
```

**Merksatz:** `expand`/`weight` verteilt Platz; `fill`/`sticky` lässt das
Widget den Platz auch **nutzen**. Beides gehört zusammen.

---

## 11.3 Mindestgrößen — Fenster und Zellen

### Fenster

```tcl
wm minsize . 640 400
wm geometry . 900x600
```

`minsize` verhindert, dass der Nutzer das Fenster unbenutzbar klein zieht.
Die Werte sollten aus dem **Layout** kommen: kleinstes noch lesbares
Formular, nicht willkürliche Pixel.

### Grid-Zellen

```tcl
grid columnconfigure .form 0 -minsize 120   ;# Label-Spalte
grid columnconfigure .form 1 -weight 1 -minsize 200
```

### Feste Seitenleiste

Wie in Kapitel 10.3: `pack propagate .sidebar 0` mit fester `-width` — die
Leiste bleibt schmal, der Rest wächst.

---

## 11.4 Propagation bewusst steuern

Standardmäßig passen sich Container an ihre Kinder an (`propagate 1`).
Das ist gut für Toolbars (Höhe folgt dem Inhalt), schlecht wenn man eine
**feste** Breite erzwingen will.

| Ziel | Mittel |
|------|--------|
| Toolbar-Höhe = Inhalt | propagation an (Default) |
| Sidebar exakt 200 px | `pack propagate .sidebar 0` + `-width 200` |
| Formularfeld soll Zelle füllen | `sticky ew` + `columnconfigure -weight` |

**Falle:** `propagate 0` am falschen Frame — das Formular kann nicht
schrumpfen, obwohl das Fenster kleiner wird. Dann hilft `wm minsize` oder
ein übergeordnetes `weight`.

---

## 11.5 Notebook, Panedwindow und Resize

### `ttk::notebook`

Jeder Reiter-Inhalt ist ein eigener Frame. **Pro Tab** die Wachstumskette
prüfen — ein Tab mit leerem `grid weight` wächst nicht mit, wenn der
Nutzer den Reiter maximiert.

```tcl
ttk::notebook .nb
ttk::frame .nb.general
ttk::frame .nb.advanced
.nb add .nb.general -text "General"
.nb add .nb.advanced -text "Advanced"

grid .nb.general.e -row 0 -column 1 -sticky ew
grid columnconfigure .nb.general 1 -weight 1
```

### `ttk::panedwindow`

Sashes geben dem Nutzer Kontrolle über Verhältnisse. Beim ersten Start
Position setzen, aber nicht bei jedem Resize überschreiben:

```tcl
ttk::panedwindow .p -orient horizontal
# … Widgets hinzufügen …
after idle { .p sashpos 0 220 }   ;# einmalig nach dem ersten Layout
```

---

## 11.6 HiDPI und Skalierung (Überblick)

Tk skaliert nicht automatisch wie moderne Web-Frameworks.

- **Schrift in Punkten** (`font create … -size 11`) statt Pixel-Hacks
  (Kapitel 25)
- `tk scaling` ändert die Umrechnung tk↔Pixel — vorsichtig einsetzen, nicht
  als Ersatz für gutes Layout
- Feste Pixelmaße für Icons und Ränder altern auf hochauflösenden Displays
  winzig wirken — lieber wenige feste Werte, mehr `padding` über Styles
  (Kapitel 24)

Responsive Layout und HiDPI sind verwandt, aber getrennte Probleme: erst
die Kette, dann die Schriftgröße.

---

## 11.7 Anti-Pattern-Katalog

| Symptom | Typische Ursache | Abhilfe |
|---------|------------------|---------|
| Leerer Rand, Widget klein in der Mitte | `-expand` ohne `-fill` / ohne `sticky` | `fill both` / `sticky nsew` |
| Hauptbereich wächst nicht | `.main` ohne `pack -expand` | Kette von `.` abwärts prüfen |
| Spalte bleibt schmal | keine `columnconfigure -weight` | `weight 1` auf wachsender Spalte |
| Alles überlappt | `pack` und `grid` im selben Parent | einen Manager pro Frame (Kap. 6) |
| Inhalt abgeschnitten, keine Scrollbar | fester Frame, kein scrollutil/Canvas | Kap. 10.2 |
| Fenster auf 200×100 zerlegbar | kein `wm minsize` | sinnvolle Untergrenze setzen |
| Nach Tab-Wechsel Layout kaputt | Tab-Inhalt ohne `update idletasks` | nach Aufbau Tab neu messen |

---

## 11.8 Resize-Test — sieben Schritte

Vor dem Ausliefern das Fenster **systematisch** durchspielen:

1. Startgröße — sieht alles aus wie geplant?
2. Auf **Halbe Bildschirmbreite** ziehen — noch lesbar?
3. Auf `wm minsize` ziehen — nichts abgeschnitten?
4. Maximiert / sehr groß — wächst der **richtige** Bereich, nicht nur Rand?
5. Nur Höhe / nur Breite ändern — keine Überlappung?
6. Notebook: **jeder** Reiter einzeln testen
7. Tastatur: Tab-Reihenfolge noch sinnvoll bei schmalem Fenster? (Kap. 23)

Diese Liste ergänzt die Sechs-Punkte-Checkliste aus Kapitel 10.4 und den
Layout-Teil in Anhang D.

---

## Zusammenfassung

- Responsives Desktop-Layout in Tk = durchgängige **Wachstumskette**
  (`expand`/`weight` **und** `fill`/`sticky`).
- `wm minsize` und `grid -minsize` schützen Lesbarkeit; `propagate` steuert
  feste vs. flexible Bereiche.
- Notebook und Panedwindow brauchen **pro Bereich** eigene Layout-Regeln.
- Anti-Pattern-Tabelle und Sieben-Schritte-Resize-Test vor Release.

Als Nächstes zeigt Kapitel 12, wie ganze Anwendungstypen (Explorer,
Editor, Einstellungen) aus diesen Bausteinen zusammengesetzt werden.
