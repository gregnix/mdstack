# Vorwort

*Stand: 2026-06-16*

Dieses Buch handelt von einer einzigen Tätigkeit: dem Bauen von
Benutzeroberflächen mit Tcl/Tk. Nicht von der Sprache Tcl im Allgemeinen,
nicht von Datenbanken, nicht von Build-Systemen — sondern von Fenstern,
Widgets, Layout, Ereignissen und davon, wie aus diesen Teilen eine
Anwendung wird, die ein Mensch bedienen kann.

## Warum noch ein Tk-Buch

Tk ist alt, stabil und unterschätzt. Viele Texte behandeln es als
Nebenschauplatz der Sprache Tcl oder als Sammlung von Rezepten. Dieses
Buch geht den umgekehrten Weg: Es nimmt die Oberfläche ernst und erklärt
das *Modell* dahinter, bevor es Befehle aufzählt. Wer das Modell versteht,
braucht die meisten Rezepte nicht mehr.

Dieses Buch geht einen Schritt weiter als viele Tcl/Tk-Texte: Es verbindet
**Technik und Gestaltung**. Wer nur versteht, wie `pack` und `grid` funktionieren,
baut Oberflächen, die korrekt laufen — aber schwer zu bedienen oder inkonsistent
wirken. Deshalb gibt es neben dem Tk-Modell Kapitel zu guten GUIs, Desktop-Mustern,
Human Interface Guidelines und einem praktischen Designsystem für Ttk.

Die Leitlinie ist dieselbe wie in den Schwesterbänden dieser Reihe:
**keine Magie, keine stillen Notlösungen.** Tk verhält sich erklärbar.
Wo etwas „nicht funktioniert", liegt fast immer eine verletzte Regel
zugrunde — zwei Geometry-Manager im selben Eltern-Widget, ein fehlendes
`columnconfigure -weight`, eine blockierte Event-Schleife. Das Buch macht
diese Regeln sichtbar, statt sie hinter Faustregeln zu verstecken.

## Für wen dieses Buch geschrieben ist

- Programmierer mit Vorkenntnissen (egal aus welcher Sprache), die
  Desktop-Oberflächen mit Tcl/Tk bauen wollen
- Tcl-Entwickler, die GUI-Code schreiben, aber das Layout-Verhalten
  oder den Event-Loop nie ganz durchschaut haben
- Entwickler, die von einem Web- oder Retained-Mode-Denken kommen und
  sich am Tk-Modell die Zähne ausbeißen

Was nicht vorausgesetzt, aber hilfreich ist: ein Grundverständnis von
Tcl selbst (Substitution, `proc`, `namespace`). Wo Tcl-Konzepte für die
Oberfläche zentral werden — etwa `trace` für Variablen-Bindung oder
TclOO für Megawidgets — werden sie im Buch eingeführt.

## Was dieses Buch nicht ist

- Kein Tcl-Sprachkurs. Dafür gibt es eigene Werke.
- Kein Datenbank-Buch. Datenanzeige ja (Treeview, Bindung), SQL nein.
- Keine Paket-/Build-Fibel. Verteilung wird angerissen (Kapitel 34),
  nicht erschöpfend behandelt.
- Kein Katalog jedes einzelnen Widget-Options-Flags. Das leistet die
  Manpage besser; das Buch erklärt, *wann* und *warum*.
- Kein reines UX-Theoriebuch ohne Code. Gestaltungsregeln werden immer mit
  Tcl/Tk-Beispielen und Checklisten verknüpft (Kap. 5, 36–38, Anhänge D–E).

## Konventionen

- **Sprache:** Fließtext Deutsch, Code Englisch. Bezeichner, Kommentare
  und Zeichenketten im Code sind englisch.
- **Tcl/Tk-Version:** Der Fokus liegt auf Tcl/Tk 9. Wo 8.6 sich relevant
  unterscheidet, steht ein Hinweis.
- **Widget-Satz:** Beispiele nutzen Ttk, wo Ttk ein Widget anbietet, und
  classic Tk, wo nur classic es anbietet (`text`, `canvas`, `listbox`,
  `menu`). Kapitel 4 begründet diese Haltung.
- **Code-Beispiele** sind lauffähig gedacht. Vollständige Programme sind
  als solche erkennbar; Ausschnitte zeigen nur das Relevante.

## Aufbau

Die Teile folgen dem Weg, den eine Oberfläche beim Entstehen nimmt:

1. **Grundlagen** — Modell, erstes Fenster, Widgets, classic/Ttk (Kap. 1–4)
2. **GUI-Grundsätze** — was gute Oberflächen ausmacht, *bevor* Layout-Details (Kap. 5)
3. **Layout** — Geometry Manager, responsive Verhalten, Desktop-Muster (Kap. 6–12)
4. **Kern-Widgets** — die einzelnen Bausteine (Kap. 13–18)
5. **Interaktion** — Event-Loop, Bindings, Menüs, Dialoge, Tastatur (Kap. 19–23)
6. **Darstellung** — Theming, Schriften, Canvas, ttk-Style im Detail (Kap. 24–27)
7. **Daten in der UI** — Treeview, Bindung, UI/Logik-Trennung (Kap. 28–30)
8. **Praxis** — Struktur, Schichtenarchitektur, i18n, Test, Verteilung, Fallstudie (Kap. 31–35)
9. **GUI-Design** — Hierarchie, HIG, Designsystem (Kap. 36–38)

Die Anhänge sind Nachschlagewerk — inklusive Designsystem (E) und Referenz-Layout (F).

Man kann linear lesen oder gezielt springen — das Inhaltsverzeichnis
verweist auf jeden Abschnitt einzeln.
