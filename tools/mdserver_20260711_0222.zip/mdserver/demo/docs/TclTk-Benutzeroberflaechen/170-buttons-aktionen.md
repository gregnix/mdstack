# Buttons und Aktionen

*Stand: 2026-05-29*

## Einführung

Der Button ist scheinbar das einfachste Widget — und versteckt doch zwei
echte Fallen: *wann* sein `-command` ausgewertet wird (ein klassischer
Tcl-Quoting-Fehler) und wie man Aktionen so organisiert, dass sie an
Button, Menü und Tastatur gleichzeitig hängen, ohne dreimal geschrieben
zu werden. Dieses Kapitel behandelt beides und das Zustands-Handling.

---

## 17.1 `-command` und der Zeitpunkt der Auswertung

Ein Button führt bei Klick seinen `-command` aus:

```tcl
ttk::button .ok -text "OK" -command {speichern}
```

Die Falle steckt in der Substitution (Kapitel 1). Wer Werte in den
`-command` einbaut, muss aufpassen, *wann* sie aufgelöst werden:

```tcl
# FALSCH -- $datei wird sofort bei der Button-Erzeugung aufgelöst
set datei "report.txt"
ttk::button .b -command "oeffne $datei"
set datei "anders.txt"        ;# zu spät -- der Button kennt noch "report.txt"
```

Mit `"..."` (Anführungszeichen) substituiert Tcl `$datei` schon beim
Erzeugen des Buttons — der spätere Wert kommt nie an. Es gibt zwei saubere
Lösungen, je nach Absicht:

```tcl
# (a) Wert JETZT festschreiben -- bewusst, mit list:
ttk::button .b -command [list oeffne $datei]

# (b) Wert ERST BEIM KLICK auflösen -- mit {} und globaler/Namespace-Variable:
ttk::button .b -command {oeffne $::datei}
```

Variante (a) bindet den aktuellen Wert fest ein (über `list`, das korrekt
quotet). Variante (b) verzögert die Auflösung bis zum Klick, braucht die
Variable dann aber im richtigen Scope. Die Wahl hängt davon ab, ob der
Wert zum Erzeugungszeitpunkt oder zum Klickzeitpunkt gelten soll — und
genau diese Frage löst die meisten „mein Button macht das Falsche"-Fälle.

Der häufigste Spezialfall ist die Schleife, in der jeder Button einen
anderen Wert kapseln soll:

```tcl
# FALSCH -- alle Buttons rufen am Ende mit dem letzten i auf
for {set i 0} {$i < 3} {incr i} {
    ttk::button .b$i -command {handle $i}   ;# $i erst beim Klick -> immer 2
    pack .b$i
}

# RICHTIG -- den aktuellen Wert pro Button festschreiben:
for {set i 0} {$i < 3} {incr i} {
    ttk::button .b$i -command [list handle $i]
    pack .b$i
}
```

---

## 17.2 `-state`, `disabled`, `default`

Ein Button kann aktiv oder gesperrt sein. Bei Ttk steuert man das über
**Zustände** mit `state`:

```tcl
.ok state disabled       ;# sperren (grau, nicht klickbar)
.ok state !disabled      ;# wieder freigeben
.ok instate disabled     ;# abfragen -> 0/1
```

(Bei classic-Buttons geht es über `-state normal|disabled`; Ttk nutzt das
allgemeinere Zustands-Modell, das auch Validierung und Theming trägt,
Kapitel 24.)

Ein Dialog hat oft einen **Default-Button**, der auf `<Return>` reagiert
und optisch hervorgehoben ist:

```tcl
ttk::button .ok -text "OK" -default active -command {schliessen ok}
bind . <Return> {.ok invoke}
```

`.ok invoke` löst den Button programmgesteuert aus — als hätte man
geklickt. Das ist auch der saubere Weg, einen Button aus Code heraus zu
„drücken", statt seinen `-command` direkt aufzurufen (denn `invoke`
respektiert den `disabled`-Zustand).

---

## 17.3 Aktionen zentral halten — ein Aktions-Pattern

Dieselbe Aktion „Speichern" soll oft an mehreren Stellen hängen: am
Toolbar-Button, im Datei-Menü, auf `Strg+S`. Wer den `-command` dreimal
schreibt, pflegt ihn dreimal. Besser ist es, die Aktion **einmal** als
Prozedur zu definieren und überall nur darauf zu verweisen:

```tcl
# Aktion einmal definieren
proc action::save {} {
    if {[dataIsValid]} {
        saveToFile
        set ::statusText "Gespeichert"
    } else {
        set ::statusText "Nichts zu speichern"
    }
}

# überall darauf verweisen
ttk::button .toolbar.save -text "Speichern" -command action::save
.menu.file add command -label "Speichern" -command action::save -accelerator "Ctrl+S"
bind . <Control-s> {action::save}
```

Das hält die Logik an einer Stelle und die Oberflächen-Elemente schlank.
Für größere Anwendungen lohnt eine kleine **Aktions-Registry** — ein
`dict`, das Aktionsnamen auf Beschriftung, Befehl und Zustand abbildet —,
sodass Button, Menü und Tastatur aus derselben Quelle gespeist werden und
ein zentrales „Aktion X sperren" alle drei zugleich erfasst. Das ist ein
Architektur-Thema und wird in Teil 7 (Kapitel 31) vertieft.

---

## 17.4 Tastatur-Beschleuniger an Buttons koppeln

Ein `-accelerator` an einem Menüeintrag (Kapitel 21) ist **nur
Beschriftung** — er zeigt das Kürzel an, löst aber nichts aus. Die
tatsächliche Verbindung stellt ein `bind` her:

```tcl
.menu.file add command -label "Speichern" -accelerator "Ctrl+S" \
    -command action::save
bind . <Control-s> {action::save}     ;# das macht das Kürzel erst wirksam
```

Beides gehört zusammen: Der `-accelerator` informiert den Nutzer, das
`bind` führt aus. Vergisst man das `bind`, steht das Kürzel im Menü,
funktioniert aber nicht — eine häufige, leicht übersehene Lücke. Mehr zu
Bindings und plattformabhängigen Modifizierern (`Control` gegen
`Command`) in Kapitel 20 und 21.

---

## Zusammenfassung

- `-command` mit `"..."` löst sofort auf; für „Wert jetzt festschreiben"
  `[list …]`, für „erst beim Klick" `{…}` mit globaler/Namespace-Variable.
  In Schleifen `[list handle $i]`.
- Ttk-Buttons sperrt/prüft man über `state disabled`/`instate`;
  `invoke` löst programmgesteuert aus und respektiert den Zustand.
- Aktionen einmal als Prozedur definieren und von Button, Menü und
  Tastatur darauf verweisen — nicht mehrfach ausschreiben.
- `-accelerator` ist nur Anzeige; die Wirkung kommt vom `bind`.

Damit sind die einzelnen interaktiven Widgets behandelt. Das letzte
Kapitel von Teil 3 widmet sich den Behältern, die sie zusammenhalten:
den Container-Widgets.
