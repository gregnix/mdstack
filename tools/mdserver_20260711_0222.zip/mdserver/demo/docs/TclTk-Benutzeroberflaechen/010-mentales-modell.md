# Was Tk ist — das mentale Modell

*Stand: 2026-05-29*

## Einführung

Die meisten Schwierigkeiten mit Tk entstehen nicht an einzelnen
Befehlen, sondern an einem falschen Bild davon, *was* Tk eigentlich ist.
Wer aus der Web-Welt kommt, sucht ein DOM. Wer aus Qt oder Swing kommt,
sucht Objekte mit Methoden und Konstruktoren. Beides gibt es in Tk nicht
in der erwarteten Form — und solange man danach sucht, wirkt Tk
unberechenbar.

Dieses Kapitel baut das richtige Bild auf. Es nennt fast keine
Optionen und kein einziges Layout. Es klärt nur, womit man es zu tun
hat: ein Baum benannter Widgets, von denen jedes zugleich ein Befehl
ist, gesteuert über Zeichenketten. Wer das verinnerlicht, liest den Rest
des Buches als Konkretisierung — nicht als Sammlung von Sonderfällen.

---

## 1.1 Tk in einem Absatz

Tk ist eine Bibliothek, die zu Tcl eine Reihe von **Befehlen** für
grafische Oberflächen hinzufügt. Es gibt keinen separaten Sprachkern,
keine eigene Syntax: `button`, `pack`, `bind` sind gewöhnliche
Tcl-Befehle, genau wie `set` oder `proc`. Eine Tk-Oberfläche ist deshalb
nichts anderes als ein Tcl-Skript, das eine bestimmte Sorte Befehle
aufruft. Das ist der Grund, warum sich GUI-Code in Tcl so beiläufig
schreiben lässt — und auch der Grund, warum dieselben Tcl-Regeln zu
Substitution und Quoting hier weiter gelten und manchmal überraschen.

---

## 1.2 Widgets sind Befehle, keine Objekte im fremden Sinn

In objektorientierten Toolkits erzeugt man ein Objekt und ruft darauf
Methoden auf:

```text
JButton b = new JButton("OK");   // Java
b.setEnabled(false);
```

In Tk erzeugt ein **Befehl** ein Widget — und legt dabei einen *neuen
Befehl* an, der genauso heißt wie der Widget-Pfadname:

```tcl
button .b -text "OK"     ;# erzeugt das Widget UND den Befehl ".b"
.b configure -state disabled
```

`.b` ist danach ein vollwertiger Befehl. Was bei anderen Toolkits
Methodenaufrufe sind, sind hier Unterbefehle dieses Widget-Befehls:

```tcl
.b configure -text "Abbrechen"   ;# Eigenschaft ändern
.b cget -text                    ;# Eigenschaft lesen
.b invoke                        ;# auslösen, als hätte man geklickt
.b cget -state                   ;# -> disabled
```

Das ist kein kosmetischer Unterschied. Es bedeutet:

- Ein Widget existiert genau so lange, wie sein Befehl existiert. Wird
  der Befehl gelöscht (`destroy .b` oder `rename .b {}`), ist das Widget
  weg.
- Man kann einen Widget-Befehl wie jeden anderen Befehl weiterreichen,
  in einer Variablen halten, in einem `dict` ablegen.
- Es gibt keinen verborgenen Objektzustand jenseits der Optionen. Alles,
  was ein Widget „weiß", steht in seinen Optionen und lässt sich mit
  `configure`/`cget` lesen und schreiben.

Ttk verschiebt diese Sicht nicht. Ein `ttk::button .b` legt ebenso einen
Befehl `.b` an; es kommt nur ein anderer Widget-Satz dahinter zum
Einsatz (Kapitel 4).

---

## 1.3 Der Widget-Baum und der Pfadname

Tk-Widgets bilden einen **Baum**, und der Name eines Widgets *ist* seine
Position im Baum. Der Punkt `.` ist die Wurzel — das Hauptfenster.
Ein Kind heißt wie sein Elter plus ein weiterer Punkt-getrennter
Bestandteil:

```tcl
.                 ;# das Hauptfenster (root)
.toolbar          ;# ein Kind von .
.toolbar.save     ;# ein Kind von .toolbar
.dialog           ;# ein weiteres Toplevel-Fenster (Kind von .)
.dialog.ok        ;# ein Kind von .dialog
```

Der Pfadname ist also keine reine Konvention, sondern die
**Eltern-Kind-Beziehung selbst**. Daraus folgt unmittelbar:

- Das Elter muss existieren, bevor das Kind erzeugt wird. `.toolbar.save`
  lässt sich nicht anlegen, solange es `.toolbar` nicht gibt.
- Zerstört man ein Widget, verschwinden alle Nachkommen mit. `destroy
  .toolbar` nimmt `.toolbar.save` und alles darunter mit.
- Der Name codiert die Hierarchie für den Menschen lesbar. Ein Blick auf
  `.editor.statusbar.position` sagt, wo das Widget sitzt.

Eine wichtige Feinheit: Der Baum aus Pfadnamen ist die **Container-Hierarchie**.
Sie sagt noch nichts darüber, *wo* ein Widget auf dem Bildschirm landet
oder wie groß es ist. Das entscheidet ein Geometry Manager (Teil 2), und
der kann ein Widget durchaus in einem anderen Elter platzieren, als der
Name vermuten lässt — eine Quelle subtiler Fehler, auf die Kapitel 6
zurückkommt. Für den Anfang gilt die einfache Regel: Pfadname = wo es im
Baum hängt; Geometry Manager = wo und wie groß es erscheint.

### Namen müssen klein anfangen

Jeder Pfad-Bestandteil nach einem Punkt muss mit einem Kleinbuchstaben
oder einer Ziffer beginnen — Großbuchstaben am Anfang sind reserviert
(sie kennzeichnen Widget-*Klassen*). `.Save` ist kein gültiger
Widget-Pfad, `.save` schon.

---

## 1.4 Was Tk *nicht* ist

Ein paar bewusste Abgrenzungen ersparen später Enttäuschungen.

**Tk ist kein Retained-Mode-Zeichensystem.** Außer beim `canvas` (Kapitel
26) verwaltet man keine Zeichenliste, die Tk immer wieder neu malt. Man
beschreibt Widgets und ihr Layout; das Neuzeichnen erledigt Tk im
Hintergrund über den [Event-Loop]{.index}. Man ruft also nicht „zeichne jetzt neu"
auf — man ändert eine Option, und das Redraw passiert von selbst, sobald
der Event-Loop dran ist (Kapitel 19).

**Tk ist kein DOM.** Es gibt keine CSS-artige Vererbung von Aussehen
über den Baum, keine Selektoren, kein Reflow nach Web-Regeln. Aussehen
steuert man über Optionen, die Option-Datenbank (Kapitel 3) und — bei
Ttk — über Styles (Kapitel 24). Layout steuern die Geometry Manager,
nicht ein Box-Modell.

**Tk ist nicht nebenläufig in der Oberfläche.** Es gibt genau einen
Event-Loop, der Klicks, Tastendruck, Timer und Neuzeichnen abarbeitet.
Solange eigener Code läuft, läuft der Loop nicht — und die Oberfläche
„friert ein". Das ist kein Bug, sondern das Modell; Kapitel 19 zeigt, wie
man lange Arbeit verträglich macht.

**Tk modelliert kein MVC.** Es zwingt zu keiner Trennung von Daten und
Anzeige. Diese Trennung ist möglich und sinnvoll (Kapitel 30), aber sie
ist Disziplin des Entwicklers, nicht eine Eigenschaft des Toolkits.

---

## 1.5 classic Tk und Ttk — zwei Widget-Sätze, ein Baum

Tk bringt heute zwei Familien von Widgets mit:

- **classic Tk** — die ursprünglichen Widgets: `button`, `label`,
  `entry`, `frame`, dazu die, die es nur hier gibt: `text`, `canvas`,
  `listbox`, `menu`.
- **Ttk** (Themed Tk, Namespace `ttk::`) — neuere, vom System-Theme
  gestaltete Varianten: `ttk::button`, `ttk::entry`, `ttk::frame`,
  `ttk::notebook`, `ttk::treeview` und andere.

Beide leben im **selben Widget-Baum** und mischen sich technisch
problemlos: Ein `ttk::frame` kann einen classic `text` enthalten, ein
classic `frame` einen `ttk::button`. Der Unterschied liegt im Aussehen
(Ttk folgt dem Systemstil) und darin, *wie* man das Aussehen steuert
(classic über Optionen wie `-bg`/`-fg`, Ttk über Styles). Kapitel 4
trifft die Entscheidung, wann man was nimmt; bis dahin genügt zu wissen,
dass es beide gibt und sie sich nicht ausschließen.

Eine typische Stolperfalle vorweg: classic-spezifische Optionen wie
`-bg`, `-fg`, `-relief` existieren bei Ttk-Widgets oft *nicht*, weil das
Theme darüber entscheidet. `ttk::button .b -bg red` ist ein Fehler, kein
roter Knopf. Wer das Modell kennt, sucht den Fehler nicht beim Widget,
sondern bei der Erwartung.

---

## 1.6 Was dieses Buch voraussetzt und was nicht

Vorausgesetzt wird Programmiererfahrung und ein Grundgefühl für Tcl:
dass alles eine Zeichenkette ist, wie Substitution mit `$` und `[...]`
funktioniert, was `proc` und `namespace` sind. Wer hier unsicher ist,
findet das in einem Tcl-Grundlagenwerk; dieses Buch wiederholt es nicht.

Nicht vorausgesetzt wird Tk-Vorwissen. Die GUI-Konzepte — Widget-Baum,
Geometry Management, Event-Loop, Bindings, Styles — werden vollständig
aufgebaut. Auch die wenigen Tcl-Mechanismen, die für Oberflächen zentral
sind, aber über die Grundlagen hinausgehen, führt das Buch dort ein, wo
sie gebraucht werden: `trace` bei der Variablen-Bindung (Kapitel 29),
TclOO bei Megawidgets (Kapitel 31).

### Was Sie nach diesem Kapitel mitnehmen sollten

- Ein Widget ist ein Befehl; sein Pfadname ist seine Position im Baum.
- `configure`/`cget` sind das, was anderswo Setter/Getter sind; es gibt
  keinen verborgenen Zustand jenseits der Optionen.
- Container-Hierarchie (Pfadname) und Bildschirm-Layout (Geometry
  Manager) sind zwei verschiedene Dinge.
- Es gibt einen Event-Loop und zwei Widget-Sätze; beides ist Teil des
  Modells, nicht Beiwerk.

Mit diesem Bild im Kopf erzeugt Kapitel 2 das erste echte Fenster — und
zeigt, warum ein Tk-Programm ohne laufenden Event-Loop gar nichts tut.
