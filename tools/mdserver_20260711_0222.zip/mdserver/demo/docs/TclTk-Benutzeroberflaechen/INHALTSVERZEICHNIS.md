# Inhaltsverzeichnis

*Stand: 2026-06-16*

[Vorwort](000-vorwort.md)

---

## Teil 1 — Grundlagen (Kap. 1–4)

### [Kapitel 1: Was Tk ist — das mentale Modell](010-mentales-modell.md)
### [Kapitel 2: Das erste Fenster](020-erstes-fenster.md)
### [Kapitel 3: Widgets erzeugen, konfigurieren, abfragen](030-widgets-erzeugen.md)
### [Kapitel 4: classic Tk oder Ttk — die Entscheidung](040-classic-vs-ttk.md)

---

## Teil 1b — GUI-Grundsätze (Kap. 5)

### [Kapitel 5: Was macht eine gute GUI aus?](050-gute-gui-grundsaetze.md)

- 5.1 Einfachheit und Aufgabenfokus
- 5.2 Konsistenz
- 5.3 Vorhersehbarkeit
- 5.4 Informationsdichte
- 5.5 Farbe und visueller Lärm
- 5.6 Tastatur und Maus
- **5.8 Warum sehen viele Tk-Programme „alt“ aus?** *neu (Phase 5)*
  - 5.8.1–5.8.8 Anti-Pattern-Katalog (Abstände, Gruppierung, Farben, …)
  - 5.8.9 Das Standardgerüst (Anhang F)
  - 5.8.10 Kurzdiagnose
- 5.9 Checkliste — erster Entwurf *(bisher 5.7)*

---

## Teil 2 — Layout (Kap. 6–12)

### [Kapitel 6: Das Geometry-Management-Modell](060-geometry-modell.md)

### [Kapitel 7: pack — der Stapler](070-pack.md)

### [Kapitel 8: grid — die Tabelle](080-grid.md)

### [Kapitel 9: place — der begründete Ausnahmefall](090-place.md)

### [Kapitel 10: Layout-Patterns für echte Fenster](100-layout-patterns.md)

### [Kapitel 11: Responsives Desktop-Layout](110-responsive-layout.md)

- 11.1 Das Problem der „Designer-Größe"
- 11.2 Die Wachstumskette
- 11.3 Mindestgrößen
- 11.4 Propagation
- 11.5 Notebook und Panedwindow
- 11.6 HiDPI (Überblick)
- 11.7 Anti-Pattern-Katalog
- 11.8 Resize-Test

### [Kapitel 12: Desktop-Patterns](120-desktop-patterns.md)

- 12.1 Skizze → Baum → Manager
- 12.2 Explorer (Master-Detail)
- 12.3 Editor
- 12.4 Einstellungen (Notebook + Formular)
- 12.5 Assistent (Wizard)
- 12.6 Modales Suchfenster
- 12.7 Panedwindow / Sidebar
- 12.8 Pattern-Vergleich
- 12.9 Übung

---

## Teil 3 — Die Kern-Widgets (Kap. 13–18)

### [Kapitel 13: Beschriften und Anzeigen](130-label-anzeige.md)
### [Kapitel 14: Eingabe und Validierung](140-eingabe-validierung.md)
### [Kapitel 15: Auswahl-Widgets](150-auswahl.md)
### [Kapitel 16: Das Text-Widget](160-text-widget.md)
### [Kapitel 17: Buttons und Aktionen](170-buttons-aktionen.md)
### [Kapitel 18: Container-Widgets](180-container.md)

---

## Teil 4 — Interaktion (Kap. 19–23)

### [Kapitel 19: Der Event-Loop verstehen](190-event-loop.md)
### [Kapitel 20: Bindings und virtuelle Events](200-bindings.md)
### [Kapitel 21: Menüs](210-menues.md)
### [Kapitel 22: Dialoge und Toplevels](220-dialoge-toplevels.md)
### [Kapitel 23: Fokus, Tastatur, Bedienbarkeit](230-fokus-tastatur.md)

---

## Teil 5 — Darstellung und Stil (Kap. 24–27)

### [Kapitel 24: Ttk-Theming und Styles (Einstieg)](240-ttk-theming.md)

### [Kapitel 25: Schriften, Farben, Bilder](250-schrift-farbe-bild.md)

### [Kapitel 26: Der Canvas](260-canvas.md)

### [Kapitel 27: ttk::style im Detail — Themes und Layouts](270-ttk-style-vertiefung.md)

---

## Teil 6 — Daten in der Oberfläche (Kap. 28–30)

### [Kapitel 28: Tabellen und Bäume](280-treeview.md)
### [Kapitel 29: Variablen-Bindung als Klebstoff](290-variablen-bindung.md)
### [Kapitel 30: UI und Logik trennen](300-ui-und-logik.md)

---

## Teil 7 — Praxis (Kap. 31–35)

### [Kapitel 31: Eine Anwendung strukturieren](310-anwendung-strukturieren.md)

- 31.1 Vom Skript zum Modul
- 31.2 Megawidgets mit TclOO
- 31.3 Namespaces für Oberflächen-Komponenten
- 31.4 Ein tragfähiges Projektlayout
- **31.5 Schichten: View, Application, Services** *neu (aus Entwurf 27.5)*

### [Kapitel 32: Internationalisierung](320-i18n.md)
### [Kapitel 33: Oberflächen testen](330-gui-testen.md)
### [Kapitel 34: Eine GUI-Anwendung verteilen](340-verteilen.md)
### [Kapitel 35: Fallstudie — eine vollständige kleine Anwendung](350-fallstudie.md)

- 35.5 Desktop-Pattern (Explorer-Editor)
- 35.6 Designsystem angewendet (`::ui::theme::init`)
- 35.7 Release-Checkliste (Resize, Tastatur, Anhang D)

---

## Teil 8 — GUI-Design und UX (Kap. 36–38)

### [Kapitel 36: Visuelle Hierarchie und Weißraum](360-visuelle-hierarchie.md)
### [Kapitel 37: Human Interface Guidelines — praxisnah](370-human-interface-guidelines.md)
### [Kapitel 38: Designsystem für Tcl/Tk](380-designsystem-tcltk.md)

---

## Anhänge

| Anhang | Datei | Status |
|--------|-------|--------|
| A | [Widget-Übersicht](800-anhang-widget-uebersicht.md) | bestehend |
| B | [Glossar](810-anhang-glossar.md) | bestehend |
| C | [Häufige Fehler](820-anhang-fehler.md) | bestehend |
| D | [Checkliste gute Tk-Oberflächen](830-anhang-checkliste.md) | erweitert |
| E | [Designsystem — Kurzreferenz](840-anhang-designsystem.md) | neu |
| F | [Referenz-Layout (Widget-Baum)](850-anhang-layout-referenz.md) | neu |

---

**Gesamtumfang (Ziel):** 38 Kapitel (8 Teile) + 6 Anhänge

**Empfohlene Lesepfade:**

| Profil | Reihenfolge |
|--------|-------------|
| GUI-Einsteiger | 1 → **5** → 6–12 → 3 → 13+ → 36–38 |
| Tk-Kenner | 6, 11, 19, 31.5, 27, 12 |
| Vor Release | Anhang D + E + Kap. 11.8 + 23 |
