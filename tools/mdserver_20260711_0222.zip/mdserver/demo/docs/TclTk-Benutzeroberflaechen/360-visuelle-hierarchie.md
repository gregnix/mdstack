# Visuelle Hierarchie und Weißraum

*Stand: 2026-06-16*

## Einführung

Kapitel 5 hat die Grundsätze benannt; Kapitel 24–27 zeigen, wie Ttk Styles
setzt. Dieses Kapitel verbindet beides: **wie das Auge führt** und **wie
Abstand Bedeutung schafft** — konkret für Tcl/Tk-Oberflächen.

**Voraussetzung:** Kapitel 5, 24–25 (Styles, Fonts).  
**Verweist auf:** Kapitel 37 (HIG), Anhang E (Designsystem).

---

## 36.1 Hierarchie: Größe, Gewicht, Farbe

Das Auge erfasst zuerst das **Größte, Dunkelste, Kontrastreichste**.

| Ebene | Typisch in Tk |
|-------|----------------|
| Fenstertitel / Hauptüberschrift | `Header.TLabel`, 14–16 pt bold |
| Abschnittsüberschrift | `Heading.TLabel`, 12 pt bold |
| Fließtext / Labels | `TLabel`, 11 pt |
| Hinweise / deaktiviert | kleiner oder `foreground` muted |

```tcl
ttk::style configure Header.TLabel  -font {DejaVu Sans 16 bold}
ttk::style configure Heading.TLabel -font {DejaVu Sans 12 bold}
ttk::style configure Hint.TLabel    -foreground "#6b7280"
```

**Eine dominante Aktion** pro Bereich: ein `Primary.TButton`, Rest Standard
oder Toolbutton (Kapitel 24.7).

> **Schlecht:** Überschrift, Body-Text und Button-Label alle 11 pt normal.  
> **Besser:** Drei Stufen — Header, Labels, ein farbiger Primary-Button.

---

## 36.2 Weißraum statt Rahmenwüste

Gruppen können durch **Abstand** oder durch **Rahmen** getrennt werden.
Rahmen überall erzeugen „Kästchen-Salat".

- Einheitliches **padding** auf Frames: `{8 8}` oder `{12 12}` (Anhang E)
- `labelframe` nur, wenn die Gruppe einen **Namen** braucht („Verbindung",
  „Erweitert")
- Zwischen Sektionen **16 px** statt zusätzlichem Rand um jede Zeile

```tcl
ttk::frame .form -padding 12
ttk::labelframe .form.server -text "Server" -padding 8
grid .form.server -row 0 -column 0 -sticky ew -pady {0 12}
```

Leerer Raum ist kein verschwendeter Platz — er ist **Struktur**.

---

## 36.3 Ausrichtung und Raster

Formulare wirken ruhiger, wenn Labels **einer Kante** folgen und Eingaben
einer anderen:

```tcl
# Labels rechtsbündig, Spalte 0 fest
grid $f.lblHost -row 0 -column 0 -sticky e -padx {0 8}
grid $f.entHost -row 0 -column 1 -sticky ew
grid columnconfigure $f 0 -minsize 100
grid columnconfigure $f 1 -weight 1
```

**Baseline-Raster:** alle Labels in Spalte 0, alle Eingaben in Spalte 1 —
nicht jede Zeile ein anderes Layout (Kapitel 8.5).

Toolbar-Icons: gleiche **Höhe** und gleicher horizontaler Abstand (`pack
padx 4`).

---

## 36.4 Icons und Text

| Kontext | Empfehlung |
|---------|------------|
| Toolbar | Icon-only möglich — **Tooltip** oder `tooltip`-Paket Pflicht |
| Buttons mit unklarer Metapher | Icon **und** Text |
| Menü | Text + optional Icon links |

Tk: `ttk::button -text "Open" -image $img -compound left` (Kapitel 13,
Bilder Kap. 25). Icon-only ohne Erklärung ist ein Verständnis-Test, den
die meisten Nutzer nicht bestehen wollen.

---

## 36.5 Galerie: vorher und nachher

Vier typische Situationen — jeweils **Schlecht** und **Besser**. Die Skizzen
reichen für Druck und Lernen; für Präsentationen eignen sich Screenshots
aus derselben App im Theme `clam` mit Anhang E (gleiche Fenstergröße pro Paar).

Technische Umsetzung: Kapitel 12.4 (Einstellungen), 27.7 (Primary-Button),
Anhang E.4–E.5.

*Ziel-Kap. nach Weg C: 36.5*

---

### 36.5.1 Dialog-Buttons

**Schlecht** — alle Buttons gleich groß, gleich laut, Reihenfolge willkürlich;
der Nutzer muss lesen statt scannen:

```
┌─ Datei speichern ─────────────────────┐
│  Pfad: [________________________]    │
│                                      │
│  [ Hilfe ] [ Abbrechen ] [ Speichern ] [ Übernehmen ] │
└──────────────────────────────────────┘
```

Probleme: vier gleichwertige Aktionen; **Speichern** nicht hervorgehoben;
**Hilfe** gehört nicht in die Buttonleiste; Reihenfolge nicht plattformüblich.

**Besser** — eine Primäraktion, Sekundäres zurückhaltend, seltene Aktionen
anderswo:

```
┌─ Datei speichern ─────────────────────┐
│  Pfad: [________________________]    │
│                                      │
│              [ Abbrechen ]  [■ Speichern ■] │
└──────────────────────────────────────┘
```

```tcl
ttk::frame $dlg.btns
ttk::button $dlg.btns.cancel -text "Abbrechen" -command [list destroy $dlg]
ttk::button $dlg.btns.save   -text "Speichern" -style Primary.TButton \
    -command [list app::saveAndClose $dlg]
pack $dlg.btns.save   -side right -padx {4 0}
pack $dlg.btns.cancel -side right
# Hilfe: F1 oder Menü Hilfe — nicht neben OK
```

**Merksatz:** Pro Dialog höchstens ein `Primary.TButton` (Anhang E.4).

---

### 36.5.2 Formular-Layout

**Schlecht** — Labels und Felder pro Zeile anders ausgerichtet, keine feste
Spalte, enge Abstände:

```
Name:     [________________]
          E-Mail:
[_______________________________]
Telefon: [________]  Fax: [________]
```

Probleme: Auge findet keine vertikale Kante; zweite Zeile wirkt „eingerückt
ohne Grund"; Fax-Zeile bricht das Raster.

**Besser** — Zwei-Spalten-Grid, Labels rechtsbündig Spalte 0, Eingaben Spalte 1:

```
        Name:  [________________________]
      E-Mail:  [________________________]
     Telefon:  [________________________]
```

```tcl
set f [ttk::frame $parent.form -padding 12]
foreach {row label widget} {
    0 Name     $f.entName
    1 E-Mail   $f.entMail
    2 Telefon  $f.entPhone
} {
    ttk::label $f.lbl$row -text $label
    grid $f.lbl$row -row $row -column 0 -sticky e -padx {0 8} -pady 4
    grid $widget    -row $row -column 1 -sticky ew -pady 4
}
grid columnconfigure $f 0 -minsize 80
grid columnconfigure $f 1 -weight 1
```

Siehe § 32.3 und Anhang E.5.

---

### 36.5.3 Toolbar

**Schlecht** — Textlänge variiert, classic und Ttk gemischt, keine Gruppen:

```
[Neu][Öffnen][Speichern unter...][Drucken][Ausschneiden][Kopieren][Einfügen][?]
```

Probleme: unterschiedliche Button-Breiten; „Speichern unter..." bricht die
Zeile; Mischung `button`/`ttk::button` → unterschiedliche Höhen; alles eine
Wurst.

**Besser** — einheitliche Toolbuttons, Trenner, Gruppen nach Aufgabe:

```
[📄][📂] | [💾] | [✂][📋][📌] | [🔍]
  neu/öff    speichern  clipboard    suche
```

```tcl
ttk::frame .toolbar -padding {4 4}
set ::tb::n 0
proc tb::sep {} {
    ttk::separator .toolbar.s[incr ::tb::n] -orient vertical
    pack .toolbar.s$::tb::n -side left -fill y -padx 4
}
proc tb::btn {name} {
    ttk::button .toolbar.$name -style Toolbutton -width 3
    pack .toolbar.$name -side left -padx 2
}
foreach b {new open} { tb::btn $b }
tb::sep
tb::btn save
pack .toolbar -side top -fill x
# Icon-only: Tooltip-Paket oder <Enter>-Binding mit Hilfetext
```

Seltene Aktionen (**Drucken**, **Speichern unter**) ins Menü **Datei** —
nicht in die Toolbar (Kapitel 12.3, 37.2 Hick's Law).

---

### 36.5.4 Einstellungen

**Schlecht** — eine scrolllose Liste mit 25 Checkboxen und Eingaben:

```
☐ Option A    ☐ Option B    ☐ Option C
☐ Option D    Host: [_______]
☐ Option E    Port: [_______]
… (weitere 18 Zeilen)
```

Probleme: keine thematische Gruppierung; Netzwerk mitten zwischen Checkboxen;
Nutzer verliert Überblick (Miller: 7±2).

**Besser** — Notebook mit benannten Reitern, pro Reiter 5–7 verwandte Optionen:

```
┌─ [ Allgemein ] [ Verbindung ] [ Erweitert ] ─────────┐
│  Sprache:     [ Deutsch ▼ ]                          │
│  Start mit:   (•) Letzte Datei  ( ) Leere Notiz      │
│                                                      │
│                              [ Abbrechen ] [ OK ]    │
└──────────────────────────────────────────────────────┘
```

```tcl
ttk::notebook $dlg.nb
ttk::frame $dlg.nb.general -padding 12
ttk::frame $dlg.nb.net     -padding 12
$dlg.nb add $dlg.nb.general -text "Allgemein"
$dlg.nb add $dlg.nb.net     -text "Verbindung"
# Pro Reiter eigenes grid; wm minsize groß genug für schmalsten Reiter
```

Pattern **Einstellungsdialog** — Kapitel 12.4.

---

### 36.5.5 Galerie selbst nutzen

Vor dem Release einer neuen Oberfläche:

1. Screenshot oder ASCII-Skizze der **aktuellen** Version anfertigen.
2. Gegen die vier Muster oben prüfen — trifft mindestens eines zu?
3. Verbesserte Skizze entwerfen, **dann** Code anpassen.

Optional: Ordner `images/galerie-36/` mit `dialog-bad.png` / `dialog-good.png`
für die PDF-Ausgabe (Phase 5c).

---

## Zusammenfassung

- Hierarchie über Font-Stufen und **einen** Akzent-Button pro Bereich.
- Weißraum (`padding`, `pady`) trennt Gruppen — sparsam `labelframe`.
- Formulare: festes Label-Raster; Icons nie ohne Beschriftung oder Tooltip.
- Vorher/Nachher-Galerie (§ 32.5): vier ausgearbeitete Paare — Dialog, Formular, Toolbar, Einstellungen.

Kapitel 37 übersetzt allgemeine **Usability-Regeln** (Fitts, Hick, Nielsen)
in dieselbe Tk-Praxis.
