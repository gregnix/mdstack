# Beschriften und Anzeigen

*Stand: 2026-05-29*

## Einführung

Die einfachsten Widgets zeigen Text oder Bild an, ohne Eingabe
entgegenzunehmen: `label`, `ttk::label` und `message`. Sie sind schnell
erklärt — aber zwei Dinge lohnen die Aufmerksamkeit: das Zusammenspiel
von Text und Bild über `-compound` und die dynamische Anzeige über
`-textvariable`, die ohne eine Zeile Update-Code auskommt.

---

## 13.1 `label` / `ttk::label`

Ein Label zeigt eine kurze Beschriftung:

```tcl
ttk::label .l -text "Name:"
pack .l
```

Nach der Default-Haltung aus Kapitel 4 nimmt man `ttk::label`. Den Text
ändert man wie jede Option per `configure`:

```tcl
.l configure -text "Vorname:"
```

`-anchor` steuert die Ausrichtung des Textes *innerhalb* des Labels, wenn
das Label breiter ist als sein Inhalt (was bei `-sticky we` im Grid oft
der Fall ist):

```tcl
ttk::label .l -text "Name:" -anchor w   ;# linksbündig im zugewiesenen Platz
```

Ohne `-anchor w` zentriert ein in der Breite gefülltes Label seinen Text —
ein häufiger Grund für „warum steht meine Beschriftung in der Mitte".

---

## 13.2 Text, Bild, beides (`-compound`)

Ein Label (und ebenso ein Button) kann Text *und* Bild zeigen.
`-compound` legt fest, wie beide zueinander stehen:

```tcl
image create photo icon -file disk.png
ttk::label .l -text "Speichern" -image icon -compound left
```

Werte für `-compound`: `left`, `right`, `top`, `bottom`, `center`, `none`
(nur Bild, falls vorhanden) und `text` (nur Text). Ohne `-compound` und
mit gesetztem `-image` zeigt das Widget *nur* das Bild — der Text wird
ignoriert. Wer beides will, muss `-compound` setzen; das ist die
häufigste Überraschung bei Icon-Beschriftungen.

(Zur Erzeugung und Skalierung von `photo`-Images mehr in Kapitel 25.)

---

## 13.3 `message` und Zeilenumbruch

`label` bricht Text nicht automatisch um — ein langer Text wird zu einer
sehr breiten Zeile. Für mehrzeiligen, automatisch umbrochenen Fließtext
gibt es zwei Wege.

Das classic-Widget **`message`** bricht nach einer Vorgabe um:

```tcl
message .m -text "Ein längerer Hinweistext, der automatisch
auf mehrere Zeilen umbrochen wird." -width 300 -aspect 200
pack .m
```

`-width` (in Pixeln) oder `-aspect` (Verhältnis Breite:Höhe) steuern den
Umbruch. `message` ist classic; es gibt kein Ttk-Pendant.

Für die Ttk-Welt nutzt man ein `ttk::label` mit `-wraplength` (Umbruch
ab dieser Pixelbreite):

```tcl
ttk::label .m -text "Ein längerer Hinweistext ..." -wraplength 300 -justify left
pack .m -fill x
```

`-wraplength` ist meist die praktischere Wahl, weil es bei den
Ttk-Widgets bleibt und sich mit `-justify` kombinieren lässt.

---

## 13.4 Dynamischer Text über `-textvariable`

Statt bei jeder Änderung `.l configure -text …` aufzurufen, kann man ein
Label an eine **Variable** koppeln. Ändert sich die Variable, ändert sich
die Anzeige — automatisch, über Tks Variablen-Bindung (Kapitel 29):

```tcl
ttk::label .status -textvariable ::statusText -anchor w
pack .status -fill x

set ::statusText "Bereit"          ;# Anzeige wird "Bereit"
set ::statusText "12 Einträge"     ;# Anzeige wechselt von selbst
```

Das ist mehr als Bequemlichkeit: Es entkoppelt Anzeige und Logik. Der
Code, der den Status setzt, muss das anzeigende Widget nicht kennen — er
schreibt nur in die Variable. Mehrere Labels können dieselbe Variable
spiegeln; alle aktualisieren sich gemeinsam.

Zwei Hinweise. Erstens: Die Variable muss im richtigen Geltungsbereich
liegen. Im globalen Code ist `::statusText` (oder eine Namespace-Variable)
der sichere Weg, weil das Label die Variable global auflöst, nicht im
lokalen Prozedur-Scope. Zweitens schließen sich `-text` und
`-textvariable` gegenseitig aus: Ist `-textvariable` gesetzt, gewinnt der
Variablenwert; ein zusätzliches `-text` wird beim nächsten Schreiben der
Variable überschrieben.

---

## Zusammenfassung

- `ttk::label` ist der Standard; `-anchor w` verhindert zentrierten Text
  in gefüllten Labels.
- `-compound` kombiniert Text und Bild; ohne es zeigt ein Label mit
  `-image` nur das Bild.
- Mehrzeiliger Fließtext: classic `message` (`-width`/`-aspect`) oder
  `ttk::label -wraplength`.
- `-textvariable` koppelt die Anzeige an eine Variable und entkoppelt so
  Anzeige von Logik — meist besser als wiederholtes `configure -text`.

Anzeige allein macht noch keine Anwendung. Das nächste Kapitel nimmt
Eingaben entgegen — und zeigt, wie man sie sauber validiert, ohne in
Magie zu verfallen.
