# Der Canvas

*Stand: 2026-05-29*

## Einführung

Der `canvas` ist Tks freie Zeichenfläche — und das einzige Widget mit
einem **Retained-Mode**-Modell (Kapitel 1): Man erzeugt Items, die der
Canvas verwaltet und selbständig neu zeichnet. Damit baut man Diagramme,
benutzerdefinierte Widgets, interaktive Grafiken und alles, wofür die
fertigen Widgets nicht reichen. Der Canvas ist classic (kein Ttk-Pendant)
und steuert sein Aussehen über Optionen. Dieses Kapitel zeigt Items,
Tags, Scrolling und ein einfaches eigenes Widget.

---

## 26.1 Items, Tags und das Koordinatensystem

Anders als bei normalen Widgets zeichnet man auf den Canvas nicht direkt,
sondern erzeugt **Items**, die er behält und verwaltet:

```tcl
canvas .c -width 400 -height 300 -background white
pack .c -fill both -expand 1

.c create line      10 10 100 100 -fill blue -width 2
.c create rectangle 50 50 150 120 -outline black -fill "#e0e0e0"
.c create oval      120 40 200 100 -fill orange
.c create text      200 150 -text "Hallo" -font H1 -anchor center
.c create polygon   {250 50 300 100 250 100} -fill green
```

Jedes `create` liefert eine **Item-ID** (eine Zahl) zurück, über die man
das Item später anspricht:

```tcl
set id [.c create rectangle 10 10 60 40 -fill red]
.c itemconfigure $id -fill blue      ;# Eigenschaft ändern
.c coords $id 10 10 80 50            ;# Position/Größe ändern
.c move $id 20 0                     ;# verschieben (relativ)
.c delete $id                        ;# entfernen
```

Das **Koordinatensystem** hat seinen Ursprung oben links; x wächst nach
rechts, y nach unten. Koordinaten sind Punkte im Canvas-Raum — nicht
unbedingt sichtbare Pixel, sobald gescrollt wird (Abschnitt 23.2).

**Tags** sind benannte Gruppen über Items — wie im Text-Widget
(Kapitel 16), aber für Grafik. Ein Item kann mehrere Tags tragen; ein
Befehl auf einen Tag wirkt auf alle Items mit diesem Tag:

```tcl
.c create rectangle 10 10 60 40 -fill red -tags {box auswahl}
.c create oval      80 10 130 40 -fill red -tags {box}
.c itemconfigure box -fill yellow    ;# alle "box"-Items werden gelb
.c delete auswahl                    ;# alle "auswahl"-Items weg
```

Tags sind der Schlüssel zu wartbarem Canvas-Code: Man adressiert Gruppen
logisch (`alleKnoten`, `gitterlinien`), statt sich einzelne IDs zu merken.

---

## 26.2 Scrollregion und Scrolling

Ein Canvas kann größer sein als sein sichtbarer Bereich. Die
**Scrollregion** legt fest, welcher Koordinatenbereich überhaupt
erreichbar ist:

```tcl
canvas .c -scrollregion {0 0 2000 1500} \
    -xscrollcommand {.hsb set} -yscrollcommand {.vsb set}
ttk::scrollbar .vsb -orient vertical   -command {.c yview}
ttk::scrollbar .hsb -orient horizontal -command {.c xview}
grid .c   -row 0 -column 0 -sticky nsew
grid .vsb -row 0 -column 1 -sticky ns
grid .hsb -row 1 -column 0 -sticky we
grid rowconfigure    . 0 -weight 1
grid columnconfigure . 0 -weight 1
```

Oft kennt man die Ausdehnung erst, nachdem alle Items gezeichnet sind.
Dann setzt man die Scrollregion auf die Bounding-Box *aller* Items:

```tcl
.c configure -scrollregion [.c bbox all]
```

`bbox all` liefert das umschließende Rechteck aller Items — der bequemste
Weg, die Scrollregion automatisch passend zu machen (und nach jeder
größeren Änderung zu erneuern).

Beim Scrollen weichen **Fenster-Koordinaten** (wo die Maus im sichtbaren
Bereich ist) und **Canvas-Koordinaten** (wo das im Canvas-Raum liegt)
voneinander ab. Wer auf einen Mausklick ein Item an der richtigen Stelle
erzeugen will, muss umrechnen:

```tcl
bind .c <Button-1> {
    set cx [.c canvasx %x]      ;# Fenster-x -> Canvas-x
    set cy [.c canvasy %y]
    .c create oval [expr {$cx-3}] [expr {$cy-3}] [expr {$cx+3}] [expr {$cy+3}] -fill black
}
```

`canvasx`/`canvasy` rechnen die Maus-Koordinaten (`%x`/`%y`, Kapitel 20)
in den Canvas-Raum um. Diese Umrechnung zu vergessen ist der häufigste
Canvas-Fehler bei scrollbaren Flächen — die Items landen dann beim
falschen Versatz.

---

## 26.3 Items interaktiv machen (Binding auf Tags)

Wie das Text-Widget erlaubt der Canvas **Bindings auf Tags** (oder
IDs): Ein Ereignis feuert, wenn es über einem getaggten Item passiert.
So werden gezeichnete Elemente anklickbar:

```tcl
.c create rectangle 10 10 80 50 -fill steelblue -tags knopf
.c create text 45 30 -text "OK" -fill white -tags knopf

.c bind knopf <Button-1> {puts "Knopf geklickt"}
.c bind knopf <Enter> {.c configure -cursor hand2}
.c bind knopf <Leave> {.c configure -cursor ""}
```

`.c bind` (das Binding *am Canvas* für einen Item-Tag) ist zu
unterscheiden von `bind .c` (ein Binding für das Canvas-Widget als
Ganzes). Ersteres reagiert auf einzelne Items, letzteres auf das ganze
Widget. Mit Item-Bindings baut man interaktive Diagramme, verschiebbare
Knoten oder eben eigene Schaltflächen — alles aus Grafik-Items
zusammengesetzt.

Ein verschiebbares Item entsteht aus drei Bindings (Drücken, Ziehen,
Loslassen), die die Differenz der Mausbewegung auf das Item anwenden:

```tcl
.c bind ziehbar <Button-1>        {set ::dragX %x; set ::dragY %y}
.c bind ziehbar <B1-Motion> {
    .c move current [expr {%x-$::dragX}] [expr {%y-$::dragY}]
    set ::dragX %x; set ::dragY %y
}
```

`current` ist ein eingebauter Tag für das Item unter der Maus — praktisch,
um „das gerade angefasste" Item anzusprechen.

---

## 26.4 Ein einfaches eigenes Widget auf Canvas-Basis

Der Canvas ist der übliche Unterbau für **eigene Widgets**, die es in Tk
nicht gibt — eine Ampel, ein Tacho, ein kleines Diagramm. Das Muster:
einen Canvas erzeugen, die Items zeichnen, und das Aktualisieren in eine
Prozedur kapseln, die nur die `itemconfigure`/`coords` der vorhandenen
Items anpasst (statt alles neu zu zeichnen):

```tcl
proc ampel {path} {
    canvas $path -width 60 -height 160 -background "#333" -highlightthickness 0
    $path create oval 10 10  50 50  -fill "#400" -tags rot
    $path create oval 10 60  50 100 -fill "#440" -tags gelb
    $path create oval 10 110 50 150 -fill "#040" -tags gruen
    return $path
}

proc ampelSetze {path zustand} {
    # alle dunkel ...
    $path itemconfigure rot   -fill "#400"
    $path itemconfigure gelb  -fill "#440"
    $path itemconfigure gruen -fill "#040"
    # ... die aktive Lampe hell
    switch $zustand {
        rot   {$path itemconfigure rot   -fill "#f00"}
        gelb  {$path itemconfigure gelb  -fill "#ff0"}
        gruen {$path itemconfigure gruen -fill "#0f0"}
    }
}

ampel .a
pack .a
ampelSetze .a gruen
```

Das ist die Keimzelle eines Megawidgets (Kapitel 31): Zustand und
Darstellung in Prozeduren gekapselt, der Canvas als Zeichenunterbau. Für
ein echtes wiederverwendbares Widget gießt man das in eine TclOO-Klasse —
aber das Prinzip bleibt: Items einmal zeichnen, danach nur ihre
Eigenschaften aktualisieren.

---

## Zusammenfassung

- Der Canvas ist Retained-Mode: man erzeugt Items (`create line/rectangle/
  oval/text/polygon/image/window`), die er verwaltet; jede `create` gibt
  eine ID zurück.
- Tags gruppieren Items logisch; ein Befehl auf einen Tag wirkt auf alle
  Items damit.
- Scrollregion über `-scrollregion` oder `bbox all`; beim Scrollen
  Maus-Koordinaten mit `canvasx`/`canvasy` umrechnen.
- `.c bind tag event` macht Items interaktiv (≠ `bind .c`); `current` ist
  das Item unter der Maus.
- Eigene Widgets baut man, indem man Items einmal zeichnet und in
  Prozeduren nur noch aktualisiert — die Basis für Megawidgets.

Damit ist Teil 5 abgeschlossen — die Oberfläche sieht aus, wie sie soll.
Teil 6 wendet sich den Daten zu, die sie zeigt: Tabellen und Bäume,
Variablen-Bindung und die Trennung von UI und Logik.
