# Migration nach bookkit

**Status: migriert** (2026-07-07). 45 Kapitel flach, Build mit bookkit OK.

## Bauen

```bash
cd ..   # 00Books/
tclsh bookkit/tools/book-build.tcl TclTk-Benutzeroberflaechen/ -number
```

Ausgabe: `TclTk-Benutzeroberflaechen.pdf` / `.html` in `00Books/`.

`examples/` bleibt unveraendert (nicht Teil von `chapters`).

## Migration (archiv)

Einmalig mit `migrate-to-bookkit.tcl -apply`. Skript bleibt zur Dokumentation.

## Mapping (Auszug)

| Alt | Neu |
|-----|-----|
| `VORWORT.md` | `000-vorwort.md` |
| `100-grundlagen/kapitel-01-…` | `010-mentales-modell.md` |
| `550-gui-design/kapitel-36-…` | `360-visuelle-hierarchie.md` |
| `900-anhaenge/anhang-f-…` | `850-anhang-layout-referenz.md` |

Lesereihenfolge folgt `INHALTSVERZEICHNIS.md` (Teil 8 nach Teil 7, nicht Ordnernummer 550).

`INHALTSVERZEICHNIS.md` verweist noch auf alte Pfade — nach Migration gegenlesen.
