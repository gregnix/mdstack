# classic Tk oder Ttk — die Entscheidung

*Stand: 2026-05-29*

## Einführung

Kapitel 1 hat die zwei Widget-Sätze vorgestellt: classic Tk und Ttk.
Dieses Kapitel beantwortet die praktische Frage, die sich bei jedem neuen
Widget stellt — welchen nehme ich? Die Antwort ist nicht „immer Ttk" und
auch nicht „Geschmackssache", sondern folgt wenigen klaren Regeln, die
sich aus dem unterschiedlichen Aufbau beider Sätze ergeben.

---

## 4.1 Warum es zwei Sätze gibt

classic Tk ist der ursprüngliche Satz. Sein Aussehen wird direkt über
Optionen gesteuert: `-background`, `-foreground`, `-relief`, `-borderwidth`.
Das ist einfach und durchschaubar, sieht aber auf jeder Plattform
gleich (und damit überall ein bisschen fremd) aus.

Ttk (Themed Tk) kam später hinzu, um zwei Dinge zu lösen: ein Aussehen,
das sich dem **System-Theme** anpasst, und eine saubere Trennung von
*Aussehen* und *Verhalten*. Deshalb steuert man bei Ttk das Aussehen
nicht mehr über Einzeloptionen am Widget, sondern über **Styles**
(Kapitel 24). Das ist mächtiger, aber auch der Grund, warum vertraute
classic-Optionen an Ttk-Widgets fehlen.

---

## 4.2 Was Ttk besser macht — und was es weglässt

**Besser:** Ttk-Widgets übernehmen das Erscheinungsbild des Systems
(unter Windows, macOS, Linux jeweils nativ-näher), bringen Zustände wie
`active`, `disabled`, `readonly` als Theme-gesteuerte Darstellung mit und
sehen in Summe moderner und konsistenter aus. Für Buttons, Entries,
Comboboxen, Reiter (`notebook`), Fortschrittsbalken und Tabellen
(`treeview`) ist Ttk fast immer die richtige Wahl.

**Weggelassen:** Die direkten Aussehen-Optionen. Ein
`ttk::button -background red` ist *kein* roter Knopf — die Option
existiert dort nicht, weil das Theme über die Farbe entscheidet. Wer die
Farbe wirklich ändern will, geht über einen Style (Kapitel 24). Das ist
keine Schikane, sondern die konsequente Trennung: Verhalten am Widget,
Aussehen im Style.

> **Stolperfalle:** `-bg`, `-fg`, `-relief`, `-borderwidth` und
> `-highlightthickness` sind classic-Optionen. An Ttk-Widgets führen sie
> zu „unknown option"-Fehlern. Wer einen solchen Fehler sieht, hat meist
> ein classic-Muster auf ein Ttk-Widget angewandt.

---

## 4.3 Die Widgets, die es nur in classic gibt

Einige zentrale Widgets haben **kein** Ttk-Pendant — und werden es auch
nicht bekommen, weil ihr Inhalt nicht vom Theme bestimmt wird:

- **`text`** — der Mehrzweck-Texteditor (Kapitel 16)
- **`canvas`** — die Zeichenfläche (Kapitel 26)
- **`listbox`** — die einfache Listenauswahl (Kapitel 15)
- **`menu`** — Menüs jeder Art (Kapitel 21)
- **`toplevel`** — Fenster (es gibt zwar `ttk::frame`, aber Fenster
  selbst bleiben classic)

Diese vier bzw. fünf nutzt man ohne schlechtes Gewissen als classic-
Widgets — es gibt schlicht keine Alternative. Ihr Aussehen steuert man
weiter über Optionen, nicht über Styles.

---

## 4.4 Mischen mit Verstand

Beide Sätze leben im selben Baum und mischen sich technisch problemlos
(Kapitel 1). Ein `ttk::frame` kann einen classic `text` enthalten; ein
`ttk::notebook`-Reiter kann eine `listbox` beherbergen. Der einzige
sichtbare Bruch ist der **Hintergrund**: Ein classic-Widget mit
Standard-Grau in einem Ttk-Fenster, das vom Theme einen anderen
Hintergrund hat, fällt auf.

Dafür gibt es eine saubere Lösung: die Theme-Hintergrundfarbe auslesen
und dem classic-Widget zuweisen.

```tcl
# Theme-Hintergrund holen und auf ein classic-Widget anwenden
set bg [ttk::style lookup TFrame -background]
text .editor -background $bg -borderwidth 0 -highlightthickness 0
```

`ttk::style lookup` (Kapitel 24) liest einen Wert aus dem aktuellen
Theme. So fügt sich das classic-Widget optisch ein, ohne dass man feste
Farben rät, die beim Theme-Wechsel falsch würden.

---

## 4.5 Eine Empfehlung als Default-Haltung

Als tragfähige Grundregel:

1. **Gibt es ein Ttk-Widget, nimm Ttk.** Buttons, Labels, Entries,
   Comboboxen, Checkbuttons, Radiobuttons, Frames, Labelframes,
   Notebooks, Panedwindows, Progressbars, Treeviews, Scrollbars,
   Separatoren, Spinboxen, Scales.
2. **Gibt es keins, nimm classic** — bewusst und mit angepasstem
   Hintergrund: `text`, `canvas`, `listbox`, `menu`, `toplevel`.
3. **Aussehen ändern?** Bei Ttk über Styles (Kapitel 24), bei classic
   über Optionen. Niemals classic-Optionen am Ttk-Widget erwarten.

Diese Haltung hält den Code konsistent, lässt die Oberfläche systemnah
aussehen und vermeidet den häufigsten Anfängerfehler — den Versuch, ein
Ttk-Widget mit `-bg` einzufärben. Im Rest des Buches folgen die Beispiele
genau dieser Regel: Ttk, wo verfügbar; classic, wo nötig.

---

## Zusammenfassung

- Ttk steuert Aussehen über Styles, classic über Optionen; daher fehlen
  `-bg`/`-fg`/`-relief` an Ttk-Widgets.
- `text`, `canvas`, `listbox`, `menu`, `toplevel` haben kein Ttk-Pendant
  und bleiben classic.
- Beide Sätze mischen sich frei; der einzige Bruch ist der Hintergrund,
  lösbar über `ttk::style lookup`.
- Default-Haltung: Ttk, wo es existiert; sonst classic; Aussehen je nach
  Satz über Style oder Option.

Damit ist Teil 1 abgeschlossen: Modell, erstes Fenster, Widget-Handling
und Widget-Satz sind geklärt. Teil 2 wendet sich dem zu, woran die meisten
Tk-Oberflächen wirklich scheitern — dem Layout.
