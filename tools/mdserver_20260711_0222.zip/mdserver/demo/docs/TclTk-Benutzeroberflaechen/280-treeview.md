# Tabellen und Bäume

*Stand: 2026-05-29*

## Einführung

`ttk::treeview` ist Tks Widget für tabellarische und hierarchische Daten
— Dateilisten, Kategorien, Datensätze in Spalten. Es ist eines der
nützlichsten Ttk-Widgets, hat aber ein eigenes Modell aus Items, Spalten
und der besonderen Spalte `#0`. Dieses Kapitel zeigt es als Liste und als
Baum, klärt Auswahl und Aktualisierung und die wichtige Frage, wie man die
internen Item-IDs mit den eigenen Daten-IDs verbindet.

---

## 28.1 `ttk::treeview` als Liste und als Baum

Als reine **Tabelle** definiert man Spalten und zeigt nur die
Überschriften:

```tcl
ttk::treeview .tv -columns {name groesse datum} -show headings
pack .tv -fill both -expand 1

.tv heading name    -text "Name"
.tv heading groesse -text "Größe"
.tv heading datum   -text "Datum"

.tv insert {} end -values {"Dokument.txt" "12 KB" "2026-01-15"}
.tv insert {} end -values {"Bild.png"     "245 KB" "2026-01-14"}
```

`-show` steuert, was sichtbar ist: `headings` (nur Spaltenköpfe, also eine
Tabelle), `tree` (nur die Baumspalte `#0`) oder `{tree headings}` (beides,
der Default). Als **Baum** nutzt man `#0` und hängt Items aneinander:

```tcl
ttk::treeview .tv -show tree
set docs [.tv insert {} end -text "Dokumente" -open true]
set work [.tv insert $docs end -text "Arbeit"]
.tv insert $work end -text "Bericht.docx"
```

Das leere `{}` ist die **Wurzel** — `insert {} end` fügt auf oberster
Ebene ein, `insert $parent end` als Kind. Beides kombiniert (Baum *mit*
Spalten) ergibt einen Dateiexplorer-artigen Aufbau mit `-show {tree
headings}`, wobei `#0` die Hierarchie trägt und die definierten Spalten
die Datenfelder.

Die wichtige Unterscheidung: Die Spalte **`#0`** ist die Baumspalte
(angesprochen über `-text` und `-image`); die mit `-columns` definierten
Spalten sind Datenspalten (angesprochen über `-values` bzw. einzeln über
`set`).

---

## 28.2 Spalten, Überschriften, Sortierung

Spalten konfiguriert man über `column` (Breite, Dehnung, Ausrichtung) und
`heading` (Überschriftstext, Sortier-Callback):

```tcl
.tv column name    -width 200 -minwidth 100 -stretch true
.tv column groesse -width 80  -anchor e -stretch false
.tv heading name -text "Name" -command {sortiere .tv name 0}
```

`-stretch true` lässt eine Spalte beim Vergrößern des Fensters mitwachsen,
`-anchor e` richtet ihren Inhalt rechtsbündig aus (passend für Zahlen).
Mit `-displaycolumns` blendet man Spalten aus oder ordnet sie um, ohne die
Daten zu ändern.

**Sortierung** ist nicht eingebaut — man hängt sie an den
Überschrift-`-command`. Das Muster: die Item-Werte einsammeln, sortieren
und die Items per `move` neu anordnen:

```tcl
proc sortiere {tv spalte richtung} {
    set daten {}
    foreach id [$tv children {}] {
        lappend daten [list [$tv set $id $spalte] $id]
    }
    set daten [lsort -index 0 -dictionary \
        [expr {$richtung ? "" : "-decreasing"}] $daten]
    set i 0
    foreach paar $daten {
        $tv move [lindex $paar 1] {} $i
        incr i
    }
    # Klick-Richtung für den nächsten Aufruf umdrehen
    $tv heading $spalte -command [list sortiere $tv $spalte [expr {!$richtung}]]
}
```

`move` ordnet ein bestehendes Item um, ohne es neu zu erzeugen — schneller
und einfacher, als die Tabelle zu leeren und neu zu füllen.

---

## 28.3 Auswahl, Bearbeitung, Aktualisierung

Die aktuelle Auswahl liefert `selection` als Liste von **Item-IDs**; auf
Auswahländerung reagiert man über `<<TreeviewSelect>>`:

```tcl
bind .tv <<TreeviewSelect>> {
    set sel [.tv selection]
    if {[llength $sel]} {
        set id [lindex $sel 0]
        puts "Name: [.tv set $id name]"
    }
}
```

Einzelne Zellen ändert man mit `set`, ganze Items über `item`:

```tcl
.tv set $id groesse "20 KB"          ;# eine Spalte
.tv item $id -values {a b c}          ;# alle Datenspalten
.tv delete $id                        ;# Item (mit Kindern) löschen
.tv delete [.tv children {}]          ;# alles leeren
```

Für eine vollständige **Aktualisierung** leert man die Wurzel und füllt
neu — der gängige Weg nach einer Datenänderung:

```tcl
proc fuelle {tv daten} {
    $tv delete [$tv children {}]
    foreach zeile $daten {
        $tv insert {} end -values $zeile
    }
}
```

Tags wirken wie anderswo (Kapitel 16, 26) zur Gestaltung — etwa für
Zebra-Streifen, die das Lesen breiter Tabellen erleichtern:

```tcl
.tv tag configure ungerade -background "#f5f5f5"
.tv tag configure gerade   -background white
# beim Einfügen abwechselnd taggen:
.tv insert {} end -values $zeile -tags [expr {$i % 2 ? "ungerade" : "gerade"}]
```

---

## 28.4 Item-IDs gegen Daten-IDs — das Mapping

Hier liegt der konzeptionelle Kern. Der Treeview vergibt seine **eigenen
Item-IDs** (beim `insert` zurückgegeben), die nichts mit den IDs der
eigenen Daten (Datensatz-Nummer, Datenbank-Schlüssel) zu tun haben. Wer
auf eine Auswahl reagiert, hat die Treeview-ID — braucht aber die
Daten-ID. Die saubere Lösung ist ein **Mapping**:

```tcl
namespace eval view {
    variable itemMap     ;# Treeview-ItemID -> eigene Daten-ID
    array set itemMap {}
}

proc view::fuelle {tv daten} {
    variable itemMap
    array unset itemMap
    $tv delete [$tv children {}]
    foreach satz $daten {
        set itemId [$tv insert {} end -values [
            list [dict get $satz name] [dict get $satz email]]]
        set itemMap($itemId) [dict get $satz id]   ;# Verbindung merken
    }
}

proc view::gewaehlteId {tv} {
    variable itemMap
    set sel [$tv selection]
    if {$sel eq ""} {return ""}
    return $itemMap([lindex $sel 0])               ;# zurück zur Daten-ID
}
```

So bleibt die Anzeige (was im Treeview steht) sauber getrennt von der
Identität (welcher Datensatz das ist). Eine Alternative ist, dem `insert`
eine **eigene `-id`** mitzugeben, sodass Treeview-ID und Daten-ID
zusammenfallen — das geht, koppelt aber die Anzeige fest an die
Daten-Schlüssel und scheitert, sobald zwei Zeilen denselben Schlüssel
hätten oder die ID kein gültiger Treeview-Bezeichner ist. Das explizite
Mapping ist der robustere Weg und passt zur Trennung von UI und Daten, die
Kapitel 30 vertieft.

Wenn der Treeview für komplexere Tabellen — editierbare Zellen,
eingebettete Widgets, viele Spalten — nicht mehr reicht, ist das
Fremd-Paket **`tablelist`** (genauer `tablelist_tile` für das Ttk-nahe
Aussehen) die übliche Erweiterung. Es ist mächtiger, aber eine zusätzliche
Abhängigkeit — dieselbe Abwägung wie bei `scrollutil` und `mentry`
(Kapitel 10, 14).

---

## Zusammenfassung

- `ttk::treeview` zeigt Tabellen (`-show headings`) und Bäume
  (`-show tree`); `#0` ist die Baumspalte, `-columns` definiert
  Datenspalten.
- `column`/`heading` konfigurieren Breite, Dehnung, Ausrichtung,
  Überschrift; Sortierung hängt man an den Überschrift-`-command` und
  ordnet mit `move` um.
- `selection` liefert Item-IDs, `<<TreeviewSelect>>` meldet Änderungen;
  `set`/`item`/`delete` bearbeiten, Tags gestalten (Zebra).
- Treeview-Item-IDs sind nicht die eigenen Daten-IDs — ein explizites
  Mapping hält Anzeige und Identität getrennt. Für mehr als Listen/Bäume:
  `tablelist`.

Das nächste Kapitel zeigt den Mechanismus, der Daten und Anzeige
verbindet, ohne dass man bei jeder Änderung Widgets von Hand aktualisiert
— die Variablen-Bindung über `trace`.
