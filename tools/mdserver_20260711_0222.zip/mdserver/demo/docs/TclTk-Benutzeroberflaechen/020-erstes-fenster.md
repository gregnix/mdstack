# Das erste Fenster

*Stand: 2026-05-29*

## Einführung

Kapitel 1 hat das Modell geklärt. Dieses Kapitel macht es konkret: ein
laufendes Fenster, das kleinste sinnvolle Tk-Programm, und die Frage,
warum manche Tk-Skripte „nichts tun" und sich sofort beenden. Die
Antwort führt zum Event-Loop — dem Herzstück, das in Teil 4 vertieft
wird, hier aber schon gebraucht wird, um überhaupt ein Fenster auf dem
Schirm zu halten.

---

## 2.1 Das kleinste lauffähige Programm

Mit dem Interpreter `wish` genügt eine Zeile:

```tcl
button .hello -text "Hallo Tk" -command exit
pack .hello
```

`wish` startet, zeigt das Hauptfenster `.`, darin den Button, und wartet.
Ein Klick ruft `exit` auf und beendet das Programm.

Drei Dinge passieren hier, die zum Modell aus Kapitel 1 passen:

1. `button .hello …` erzeugt das Widget und den gleichnamigen Befehl.
2. `pack .hello` bittet einen Geometry Manager, das Widget sichtbar zu
   machen — *ohne* `pack` (oder `grid`/`place`) bleibt ein Widget
   unsichtbar, auch wenn es existiert.
3. `wish` hält danach den Event-Loop am Laufen, sodass Klicks ankommen.

Der zweite Punkt ist eine häufige Anfangsverwirrung: Ein Widget zu
erzeugen reicht nicht, es muss auch *gemanagt* werden. „Mein Button ist
weg" heißt fast immer „ich habe `pack`/`grid` vergessen", nicht „das
Widget existiert nicht".

---

## 2.2 `wm` — das Fenster beim Fenstermanager anmelden

Das Hauptfenster `.` ist ein **Toplevel** — ein echtes Fenster, das der
Fenstermanager des Betriebssystems kennt. Der Befehl `wm` (window
manager) steuert dessen Rahmen-Eigenschaften:

```tcl
wm title    . "Mein Programm"        ;# Titelzeile
wm geometry . 480x320+100+80         ;# Breite x Höhe + X + Y
wm minsize  . 320 240                ;# kleinste erlaubte Größe
wm iconphoto . $iconImage            ;# Fenster-Icon (Tk 8.6+)
```

`wm geometry` mit nur der Größe (`480x320`) lässt die Position offen;
mit nur Position (`+100+80`) bleibt die Größe automatisch. Setzt man gar
nichts, bestimmt Tk die Größe aus den enthaltenen Widgets (die
*requested size*, Kapitel 6).

Wichtig: `wm` gilt nur für Toplevels (`.` und mit `toplevel` erzeugte
Fenster), nicht für gewöhnliche Widgets im Inneren.

---

## 2.3 Der Event-Loop, ohne den nichts passiert

Hier wird sichtbar, warum Kapitel 1 den Event-Loop zum Teil des Modells
erklärt hat. Speichert man das obige Skript als `hello.tcl` und startet
es nicht mit `wish`, sondern aus einem normalen `tclsh`:

```tcl
package require Tk
button .hello -text "Hallo Tk" -command exit
pack .hello
```

… dann blitzt — je nach Plattform — das Fenster kurz auf und das
Programm endet sofort. Der Grund: `tclsh` arbeitet das Skript ab und
beendet sich, sobald es zu Ende ist. Niemand hält den Event-Loop am
Laufen.

`wish` macht im Kern genau einen Schritt zusätzlich: Nachdem das Skript
durchgelaufen ist, betritt es den Event-Loop und bleibt dort, bis das
Programm beendet wird. In `tclsh` muss man das selbst tun:

```tcl
package require Tk
button .hello -text "Hallo Tk" -command exit
pack .hello
vwait forever        ;# in den Event-Loop eintreten und dort bleiben
```

`vwait forever` blockiert, bis die Variable `forever` beschrieben wird —
was nie passiert. Praktisch heißt das: „arbeite ab jetzt Events ab".
Genau diese Schleife verteilt Klicks, Tastendruck, Timer (`after`) und
veranlasst das Neuzeichnen. Solange sie läuft, lebt die Oberfläche;
solange *eigener* Code läuft, steht sie still (Kapitel 19).

> **Merksatz:** Ein Tk-Programm besteht aus zwei Phasen — Aufbau (Skript
> läuft einmal durch) und Betrieb (Event-Loop verteilt Ereignisse).
> `wish` betritt die zweite Phase automatisch, `tclsh` nicht.

---

## 2.4 `wish` gegen `tclsh` mit `package require Tk`

Beide Wege führen zu einer Tk-Anwendung; die Unterschiede sind klein,
aber gut zu kennen:

| | `wish` | `tclsh` + `package require Tk` |
|---|---|---|
| Tk geladen | sofort | erst nach `package require Tk` |
| Hauptfenster `.` | existiert beim Start | entsteht mit `package require Tk` |
| Event-Loop am Ende | automatisch | selbst betreten (`vwait`) |
| Konsole | je nach Plattform | wie üblich |

Für ausgelieferte Programme ist die zweite Form oft die robustere: Ein
Skript, das mit `tclsh` startet und Tk explizit lädt, lässt sich auch in
Umgebungen verwenden, in denen kein `wish` im Pfad liegt — und es macht
die Abhängigkeit von Tk im Code sichtbar statt implizit.

Eine plattformübergreifende Eigenheit: Unter Windows blendet `wish` keine
Konsole ein, `tclsh` schon. Wer eine reine GUI-Anwendung ausliefert,
wählt den Interpreter entsprechend (Kapitel 34).

---

## 2.5 Sauber beenden

Es gibt mehr als einen Weg, eine Tk-Anwendung zu beenden, und sie sind
nicht gleichwertig.

```tcl
exit            ;# beendet den gesamten Prozess sofort
destroy .       ;# zerstört das Hauptfenster (und alle Kinder)
```

`exit` ist hart: Der Prozess endet, ohne dass laufende Aufräumarbeiten
garantiert sind. `destroy .` ist weicher: Es zerstört den Widget-Baum;
in `wish` endet damit auch der Event-Loop und das Programm läuft aus. Für
die meisten Anwendungen ist `destroy .` der sauberere Ausstieg, weil
`<Destroy>`-Bindings (Kapitel 20) noch feuern und so eigenes Aufräumen
möglich ist.

### Auf das Schließen-Kreuz reagieren

Klickt der Nutzer auf das Fenster-Schließkreuz, schickt der
Fenstermanager das Protokoll-Ereignis `WM_DELETE_WINDOW`. Standardmäßig
zerstört Tk daraufhin das Fenster. Will man vorher etwas tun — fragen, ob
ungespeicherte Änderungen verworfen werden sollen — fängt man das
Protokoll ab:

```tcl
wm protocol . WM_DELETE_WINDOW {
    if {[tk_messageBox -type yesno -message "Wirklich beenden?"] eq "yes"} {
        destroy .
    }
}
```

Setzt man einen eigenen Handler, übernimmt *er* die Verantwortung: Ohne
`destroy .` im Handler schließt sich das Fenster nicht mehr. Das ist kein
Sonderverhalten, sondern dieselbe Logik wie überall in Tk — wer einen
Callback überschreibt, ersetzt das Standardverhalten vollständig.

---

## Zusammenfassung

- Ein Widget muss erzeugt *und* von einem Geometry Manager verwaltet
  werden, sonst bleibt es unsichtbar.
- `wm` steuert Toplevel-Eigenschaften (Titel, Größe, Position, Icon).
- Tk arbeitet in zwei Phasen: Aufbau und Event-Loop. `wish` betritt den
  Loop automatisch, `tclsh` braucht `vwait`.
- `destroy .` ist der saubere Ausstieg; `WM_DELETE_WINDOW` lässt sich
  abfangen, übernimmt dann aber die volle Verantwortung fürs Schließen.

Das nächste Kapitel betrachtet Widgets genauer: wie man sie erzeugt,
konfiguriert und abfragt — und wie die Option-Datenbank Defaults zentral
vorgibt.
