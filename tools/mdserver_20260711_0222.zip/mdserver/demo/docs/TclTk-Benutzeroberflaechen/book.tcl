# book.tcl — Benutzeroberflaechen mit Tcl/Tk (bookkit-Format)
#
# Build (aus 00Books/):
#   tclsh bookkit/tools/book-build.tcl TclTk-Benutzeroberflaechen/ -number
#
# Vor Migration: tclsh migrate-to-bookkit.tcl -apply
#
# examples/ nicht in chapters.

set title     "Benutzeroberflaechen mit Tcl/Tk"
set author    ""
set subtitle  "Desktop-GUIs gestalten und bauen"
set date      "2026"
set lang      "de"
set titlePage 1

set tocTitle   "Inhaltsverzeichnis"
set indexTitle "Stichwortverzeichnis"

set chapters {
    000-vorwort.md
    010-mentales-modell.md
    020-erstes-fenster.md
    030-widgets-erzeugen.md
    040-classic-vs-ttk.md
    050-gute-gui-grundsaetze.md
    060-geometry-modell.md
    070-pack.md
    080-grid.md
    090-place.md
    100-layout-patterns.md
    110-responsive-layout.md
    120-desktop-patterns.md
    130-label-anzeige.md
    140-eingabe-validierung.md
    150-auswahl.md
    160-text-widget.md
    170-buttons-aktionen.md
    180-container.md
    190-event-loop.md
    200-bindings.md
    210-menues.md
    220-dialoge-toplevels.md
    230-fokus-tastatur.md
    240-ttk-theming.md
    250-schrift-farbe-bild.md
    260-canvas.md
    270-ttk-style-vertiefung.md
    280-treeview.md
    290-variablen-bindung.md
    300-ui-und-logik.md
    310-anwendung-strukturieren.md
    320-i18n.md
    330-gui-testen.md
    340-verteilen.md
    350-fallstudie.md
    360-visuelle-hierarchie.md
    370-human-interface-guidelines.md
    380-designsystem-tcltk.md
    800-anhang-widget-uebersicht.md
    810-anhang-glossar.md
    820-anhang-fehler.md
    830-anhang-checkliste.md
    840-anhang-designsystem.md
    850-anhang-layout-referenz.md
}
