#!/usr/bin/env bash
# Build the whole book into a single PDF using pandoc + xelatex.
#
# Assembly order:
#   1. VORWORT.md
#   2. all chapter files, sorted by chapter NUMBER (1..38) regardless of folder
#      (so Teil 9 / GUI-Design, ch. 36-38, lands at the end, not after ch. 5)
#   3. appendices A..F
#
# Requirements: pandoc and a LaTeX xelatex engine (texlive-xetex).
# Usage:  ./build-pdf.sh [output.pdf]

set -euo pipefail
cd "$(dirname "$0")"

OUT="${1:-TclTk-Benutzeroberflaechen.pdf}"
TITLE="Benutzeroberflächen mit Tcl/Tk"
AUTHOR="gregnix"
DATE="$(date +%Y-%m-%d)"

# --- dependency check ---
for tool in pandoc xelatex; do
  command -v "$tool" >/dev/null 2>&1 || {
    echo "FEHLER: '$tool' nicht gefunden. Bitte pandoc und texlive-xetex installieren." >&2
    exit 1
  }
done

# --- collect files in reading order ---
files=()
[ -f VORWORT.md ] && files+=(VORWORT.md)

# chapters sorted by numeric chapter number (kapitel-NN-...)
while IFS= read -r f; do files+=("$f"); done < <(
  find . -type f -name 'kapitel-*.md' -not -path '*/.git/*' \
    | sed -E 's|.*/kapitel-([0-9]+)-.*|\1 &|' \
    | sort -n -k1,1 \
    | cut -d' ' -f2-
)

# appendices A..F
while IFS= read -r f; do files+=("$f"); done < <(
  find . -type f -name 'anhang-*.md' -not -path '*/.git/*' | sort
)

echo "Stelle ${#files[@]} Dateien zusammen ..."
printf '  %s\n' "${files[@]}"

# --- build ---
# No --number-sections: headings already carry "Kapitel N:" / "Anhang X:".
pandoc "${files[@]}" \
  -o "$OUT" \
  --pdf-engine=xelatex \
  --from=gfm \
  --toc --toc-depth=2 \
  -V documentclass=report \
  -V lang=de-DE \
  -V papersize=a4 \
  -V geometry:margin=2.5cm \
  -V mainfont="DejaVu Serif" \
  -V sansfont="DejaVu Sans" \
  -V monofont="DejaVu Sans Mono" \
  -V colorlinks=true \
  -V linkcolor=blue \
  -V toccolor=black \
  --highlight-style=tango \
  --metadata title="$TITLE" \
  --metadata author="$AUTHOR" \
  --metadata date="$DATE"

echo "Fertig: $OUT"
