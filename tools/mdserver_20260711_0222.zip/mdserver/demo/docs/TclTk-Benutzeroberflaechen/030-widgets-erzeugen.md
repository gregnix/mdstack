# Widgets erzeugen, konfigurieren, abfragen

*Stand: 2026-05-29*

## Einführung

Kapitel 1 hat erklärt, dass ein Widget ein Befehl ist und sein Pfadname
seine Position im Baum. Dieses Kapitel macht daraus Handwerk: Wie erzeugt
man ein Widget, wie setzt und liest man seine Optionen, und wie gibt man
Voreinstellungen zentral vor, statt sie an jedem Widget zu wiederholen.
Diese vier Operationen — erzeugen, setzen, lesen, zentral vorgeben —
decken den größten Teil des täglichen Tk-Codes ab.

---

## 3.1 Der Erzeugungs-Befehl und der Widget-Befehl

Jeder Widget-Typ hat einen gleichnamigen **Erzeugungs-Befehl**, dessen
erstes Argument der gewünschte Pfadname ist:

```tcl
ttk::entry .name -width 30
```

Danach existieren zwei Dinge: das Widget im Baum und ein neuer Befehl
`.name`. Der Erzeugungs-Befehl (`ttk::entry`) gibt den Pfadnamen zurück —
nützlich, um ihn gleich weiterzureichen:

```tcl
pack [ttk::entry .name -width 30]
```

Der zurückgegebene Pfadname ist genau der, den man selbst vergeben hat;
`ttk::entry` „erfindet" keinen Namen. Wer Tk Namen erzeugen lassen will,
nutzt einen eindeutigen Zähler oder Tcls eigene Mechanismen — aber das
ist Komfort, kein Automatismus des Toolkits.

---

## 3.2 Optionen setzen — bei Erzeugung und mit `configure`

Optionen lassen sich bei der Erzeugung mitgeben oder später ändern. Beide
Wege nutzen dieselbe `-option wert`-Syntax:

```tcl
ttk::label .l -text "Name:" -anchor w     ;# bei Erzeugung
.l configure -text "Vorname:"             ;# später ändern
.l configure -text "Stadt:" -anchor e     ;# mehrere auf einmal
```

`configure` ist idempotent und jederzeit erlaubt, solange das Widget
existiert. Es gibt keinen Unterschied im Effekt zwischen „bei Erzeugung
gesetzt" und „später per configure gesetzt" — die Option hat danach
denselben Wert. Das passt zum Modell aus Kapitel 1: Ein Widget hat keinen
verborgenen Zustand jenseits seiner Optionen.

### Werte mit Sonderzeichen

Da Tcl-Substitution gilt, brauchen Werte mit Leerzeichen oder
Sonderzeichen Klammern oder Anführungszeichen wie überall in Tcl:

```tcl
.l configure -text "Vor- und Nachname"
.l configure -text {Pfad: C:\Temp}        ;# Backslash unverändert
```

Das ist keine Tk-Eigenheit, sondern die normale Quoting-Regel der
Sprache — ein häufiger Stolperstein für Umsteiger, die in GUI-Code andere
Regeln vermuten.

---

## 3.3 Optionen lesen — `cget` und die fünf Werte von `configure`

Den aktuellen Wert einer Option liefert `cget`:

```tcl
.l cget -text        ;# -> "Stadt:"
.name cget -width    ;# -> 30
```

`configure` *ohne* Wert verrät mehr. Mit einer einzelnen Option gibt es
fünf Felder zurück:

```tcl
.l configure -anchor
;# -> -anchor anchor Anchor center e
;#    Option  dbName  dbClass Default Aktuell
```

Die Felder sind: der Optionsname, ihr Name in der Option-Datenbank, ihre
Klasse dort, der Standardwert und der aktuelle Wert. Für den Alltag
genügt meist `cget`; die volle Form braucht man, wenn man wissen will, ob
ein Wert vom Default abweicht oder wie die Option in der Datenbank heißt
(Abschnitt 3.4).

Ganz ohne Argument listet `configure` *alle* Optionen — praktisch zum
Erkunden eines unbekannten Widgets:

```tcl
foreach spec [.name configure] {
    puts $spec
}
```

---

## 3.4 Die Option-Datenbank — Defaults zentral

Statt an jedem Widget `-font` und `-foreground` zu wiederholen, kann man
Voreinstellungen einmal in die **Option-Datenbank** legen. Tk wendet sie
auf neu erzeugte Widgets an, die die Option nicht explizit setzen:

```tcl
option add *Entry.font {Helvetica 11}
option add *Label.foreground gray30

ttk::entry .e     ;# erbt die Font-Voreinstellung
```

Das Muster ist `option add Pattern Wert ?Priorität?`. Das Pattern nutzt
die **Klasse** eines Widgets (großgeschrieben, daher `Entry`, nicht
`entry`) oder Instanznamen, mit `*` als Platzhalter über die Hierarchie:

```tcl
option add *foreground black        ;# alles
option add *Entry.foreground blue   ;# nur Entry-Klasse
option add *.dialog*foreground red  ;# alles unter einem .dialog
```

Zwei Einschränkungen sind wichtig. Erstens wirkt die Option-Datenbank
nur auf Optionen, die ein Widget aus ihr liest — viele **Ttk-Optionen
ignorieren sie**, weil dort das Style-System (Kapitel 24) zuständig ist.
Zweitens greift sie nur bei der **Erzeugung**: Wer nach dem `option add`
ein Widget anlegt, profitiert; bereits bestehende Widgets ändern sich
nicht. Die Datenbank ist also ein Werkzeug für classic-Tk-Defaults zu
Programmstart, nicht für dynamische Umgestaltung.

---

## 3.5 Widgets zerstören und der Lebenszyklus

`destroy` entfernt ein Widget und alle seine Nachkommen aus Baum und
Bildschirm und löscht die zugehörigen Befehle:

```tcl
destroy .dialog       ;# nimmt .dialog und alles darunter mit
```

Danach ist `.dialog` kein gültiger Befehl mehr; ein Aufruf wirft einen
Fehler. Bevor man auf ein womöglich zerstörtes Widget zugreift, prüft man
mit `winfo exists`:

```tcl
if {[winfo exists .dialog]} {
    .dialog.ok configure -state disabled
}
```

`winfo exists` fragt den Widget-Baum (existiert das Fenster?) und ist zu
unterscheiden von `info exists` (existiert eine *Variable*?). Beides
verwechselt man leicht; der Merksatz: `winfo` redet über Fenster, `info`
über Tcl-Innereien.

Der typische Lebenszyklus eines Widgets ist damit: erzeugen → mit einem
Geometry Manager sichtbar machen → über `configure` verändern und über
`cget`/Bindings abfragen → schließlich `destroy`. Dieser einfache,
durchschaubare Zyklus ist kein Zufall, sondern Ausdruck des Modells aus
Kapitel 1 — und der Grund, warum sich Tk-Code so gut introspektieren
lässt: Es gibt nichts Verstecktes zu inspizieren.

---

## Zusammenfassung

- Der Erzeugungs-Befehl legt Widget und gleichnamigen Befehl an und gibt
  den Pfadnamen zurück.
- `configure` setzt Optionen jederzeit; „bei Erzeugung" und „später" sind
  im Effekt gleich.
- `cget` liest einen Wert; `configure -option` liefert fünf Felder inkl.
  Default; `configure` ohne Argument listet alles.
- `option add` gibt classic-Defaults zentral vor — nur bei Erzeugung,
  meist nicht für Ttk.
- `destroy` beendet den Lebenszyklus; `winfo exists` prüft Fenster,
  `info exists` Variablen.

Kapitel 4 klärt die offene Frage aus dem Modell: Wann nimmt man classic
Tk, wann Ttk — und warum manche vertraute Option am Ttk-Widget fehlt.
