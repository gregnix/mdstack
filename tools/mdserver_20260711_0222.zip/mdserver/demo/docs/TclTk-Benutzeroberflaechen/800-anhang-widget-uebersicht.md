# Widget-Übersicht — classic gegen Ttk

*Stand: 2026-05-29*

Diese Übersicht zeigt für jedes gängige Widget, ob es eine Ttk-Variante
gibt und welcher Satz wann zu nehmen ist (Default-Haltung aus Kapitel 4:
Ttk, wo verfügbar; classic, wo nötig).

## Widgets mit Ttk-Variante (Ttk nehmen)

| classic | Ttk | Zweck | Kapitel |
|---|---|---|---|
| `button` | `ttk::button` | Schaltfläche | 14 |
| `label` | `ttk::label` | Beschriftung/Anzeige | 10 |
| `entry` | `ttk::entry` | einzeilige Eingabe | 11 |
| `frame` | `ttk::frame` | Container | 15 |
| `labelframe` | `ttk::labelframe` | umrandete Gruppe | 15 |
| `checkbutton` | `ttk::checkbutton` | Ja/Nein | 12 |
| `radiobutton` | `ttk::radiobutton` | eine aus mehreren | 12 |
| `scrollbar` | `ttk::scrollbar` | Bildlaufleiste | 9, 12 |
| `scale` | `ttk::scale` | Schieberegler | — |
| `spinbox` | `ttk::spinbox` | Zahleneingabe | 11 |
| — | `ttk::combobox` | Dropdown-Auswahl | 12 |
| — | `ttk::notebook` | Reiter | 15 |
| — | `ttk::panedwindow` | verschiebbare Teilung | 15 |
| — | `ttk::progressbar` | Fortschritt | — |
| — | `ttk::treeview` | Tabelle/Baum | 24 |
| — | `ttk::separator` | Trennlinie (s. Kap. 24) | 21 |
| — | `ttk::sizegrip` | Größenanfasser | — |

Die mit `—` in der classic-Spalte markierten Widgets gibt es **nur** in
Ttk (Combobox, Notebook, Panedwindow, Progressbar, Treeview, Separator,
Sizegrip).

## Widgets nur in classic (kein Ttk-Pendant)

| Widget | Zweck | Kapitel |
|---|---|---|
| `text` | mehrzeiliger Editor / Rich-Text | 13 |
| `canvas` | freie Zeichenfläche | 23 |
| `listbox` | einfache Listenauswahl | 12 |
| `menu` | Menüs (Leiste, Kontext) | 18 |
| `toplevel` | Fenster | 2, 19 |
| `message` | umbrochener statischer Text | 10 |

Diese nutzt man als classic-Widgets ohne Bedenken; ihr Aussehen steuert
man über Optionen, nicht über Styles. Für `text`/`canvas`/`listbox`
gleicht man den Hintergrund bei Bedarf mit `ttk::style lookup` an das Theme
an (Kapitel 4, 24).

## Aussehen ändern — wo was

| Satz | Aussehen ändern über | Beispiel |
|---|---|---|
| classic | Optionen am Widget | `-background`, `-foreground`, `-relief`, `-font` |
| Ttk | Styles | `ttk::style configure`/`map`, `-style` |

Der häufigste Fehler: classic-Optionen (`-bg`, `-fg`, `-relief`) an einem
Ttk-Widget — sie führen zu „unknown option" (Kapitel 4, 24).
