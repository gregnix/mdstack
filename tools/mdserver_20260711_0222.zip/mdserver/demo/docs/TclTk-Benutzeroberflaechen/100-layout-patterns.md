# Layout-Patterns für echte Fenster

*Stand: 2026-05-29*

## Einführung

Die Kapitel 7 bis 9 haben die drei Manager einzeln behandelt. Echte
Fenster entstehen aus ihrer Kombination — Frames als Container, in jedem
ein Manager. Dieses Kapitel zeigt die wiederkehrenden Muster: das
resizable Drei-Zonen-Fenster, scrollbare Inhalte (Tks bekannteste
Lücke), sinnvolle Mindestgrößen und eine Checkliste für Layout, das
mitwächst.

---

## 10.1 Das resizable Drei-Zonen-Fenster

Das Grundgerüst fast jeder Anwendung: Toolbar oben, Statusleiste unten,
ein mitwachsender Hauptbereich dazwischen. `pack` für den groben Aufbau,
`grid` (oder ein weiterer Frame) für den Inhalt von `.main`.

```tcl
# Ränder zuerst (Kapitel 7), Hauptbereich zuletzt
ttk::frame .toolbar
pack .toolbar -side top -fill x
ttk::label .status -anchor w -text "Bereit"
pack .status -side bottom -fill x
ttk::frame .main
pack .main -fill both -expand 1          ;# füllt den Rest, wächst mit

# Inhalt in .main -- eigener Manager, hier grid
ttk::treeview .main.tree
text .main.detail -wrap word
grid .main.tree   -row 0 -column 0 -sticky nsew
grid .main.detail -row 0 -column 1 -sticky nsew
grid columnconfigure .main 1 -weight 1   ;# Detailbereich wächst
grid rowconfigure    .main 0 -weight 1
```

Die `-expand 1` an `.main` und das Paar aus `-weight` und `-sticky nsew`
in `.main` sind das, was das Fenster wirklich mitwachsen lässt — beides
direkt aus dem Modell von Kapitel 6.

---

## 10.2 Scrollbare Inhalte

Hier zeigt sich eine bewusste Lücke in Tk: `ttk::frame` ist **nicht
scrollbar**. Widgets wie `text`, `canvas`, `listbox` und `ttk::treeview`
können scrollen (sie haben `-yscrollcommand`/`-xscrollcommand`), ein
gewöhnlicher Frame nicht. Will man eine beliebige Widget-Gruppe scrollbar
machen, gibt es zwei Wege.

**Der Canvas-Trick** — der klassische, abhängigkeitsfreie Weg: einen
Frame in einen `canvas` einbetten und den Canvas scrollen.

```tcl
canvas .c -yscrollcommand {.sb set} -highlightthickness 0
ttk::scrollbar .sb -orient vertical -command {.c yview}
pack .sb -side right -fill y
pack .c  -side left -fill both -expand 1

ttk::frame .c.inner
.c create window 0 0 -anchor nw -window .c.inner

# Inhalt in .c.inner packen/gridden ...
# Scrollregion nach dem Aufbau setzen:
update idletasks
.c configure -scrollregion [.c bbox all]
```

Der Knackpunkt ist die letzte Zeile: Die Scrollregion muss auf die
tatsächliche Inhaltsgröße gesetzt werden, und zwar *nach* `update
idletasks`, damit die Größen berechnet sind. Ändert sich der Inhalt,
wiederholt man das (oft an ein `<Configure>` des inneren Frames gebunden).

**Das scrollutil-Paket** nimmt diese Mechanik ab. Liegt es vor (es ist
Teil der verbreiteten Tk-Erweiterungen), ist `scrollutil::scrollarea`
bzw. `scrollutil::scrollableframe` deutlich weniger fehleranfällig als
der Handbau. Welcher Weg passt, hängt davon ab, ob man Fremdpakete
ausliefern will — der Canvas-Trick kommt mit Bordmitteln aus.

---

## 10.3 Mindestgrößen und Startgeometrie

Ein Fenster ohne Mindestgröße lässt sich auf null zusammenziehen, bis
nichts mehr lesbar ist. `wm minsize` setzt eine sinnvolle Untergrenze;
`wm geometry` eine Startgröße:

```tcl
wm minsize  . 480 320          ;# nicht kleiner als das
wm geometry . 800x560          ;# Startgröße (Position offen lassen)
```

Für feste Bereiche innerhalb des Fensters — etwa eine Seitenleiste, die
ihre Breite behalten soll — nutzt man nicht `place`, sondern den
Propagations-Schalter aus Kapitel 6:

```tcl
ttk::frame .sidebar -width 200
pack .sidebar -side left -fill y
pack propagate .sidebar 0      ;# behält 200px Breite, egal welcher Inhalt
```

So bleibt die Seitenleiste 200 Pixel breit, während der Rest mitwächst —
ohne ein einziges absolutes Pixelmaß im eigentlichen Layout.

---

## 10.4 Layout das mitwächst — Checkliste

Wenn ein Fenster „nicht richtig mitwächst", liegt es fast immer an einem
dieser Punkte. Die Liste der Reihe nach durchgehen:

1. **Hat der expandierende Bereich `-expand 1` (pack) bzw. `-weight`
   (grid)?** Ohne das bekommt er keinen Zusatzplatz.
2. **Hat er auch `-fill both` (pack) bzw. `-sticky nsew` (grid)?** Sonst
   bekommt die Zelle Platz, das Widget füllt ihn aber nicht.
3. **Ist das Gewicht/Expand über die ganze Kette gesetzt?** Wächst
   `.main` mit, aber `.main.detail` hat kein `columnconfigure -weight`,
   stoppt das Wachstum an dieser Stelle. Jede Ebene braucht ihre eigene
   Konfiguration.
4. **Genau ein Manager pro Frame?** `pack` und `grid` im selben Parent
   führen zu Hängern (Kapitel 6).
5. **Statusleiste/Toolbar vor dem Inhalt gepackt?** Sonst werden die
   Ränder beim Verkleinern abgeschnitten (Kapitel 7).
6. **Kein `place` für regulären Inhalt?** `place` wächst nicht mit
   (Kapitel 9).

Diese sechs Fragen lösen die überwiegende Mehrheit aller Layout-Probleme.
Sie sind kein Trick, sondern die direkte Anwendung des Modells aus
Kapitel 6 — weshalb sich das Investment in jenes Kapitel hier auszahlt.

---

Die nächsten beiden Kapitel bauen darauf auf: **Kapitel 11** behandelt responsives Verhalten beim Vergrößern und Verkleinern, **Kapitel 12** zeigt fertige Desktop-Patterns (Explorer, Editor, Einstellungen, Assistent). Ein vollständiges Referenz-Layout als Widget-Baum steht in **Anhang F**.

## Zusammenfassung

- Echte Fenster baut man aus Frames mit je einem Manager; das
  Drei-Zonen-Gerüst (Toolbar/Status/Main) trägt fast überall.
- Frames sind nicht scrollbar; scrollbaren Inhalt erzeugt der
  Canvas-Trick (Bordmittel) oder `scrollutil` (Fremdpaket).
- `wm minsize`/`wm geometry` für Fenstergrenzen; feste Innenbereiche über
  `pack/grid propagate $w 0`, nicht über `place`.
- Die Sechs-Punkte-Checkliste löst die meisten „wächst nicht mit"-Fälle.

Damit ist Teil 2 abgeschlossen — das Fundament für alles Weitere steht.
Teil 3 wendet sich den einzelnen Widgets zu, beginnend mit den einfachsten:
Beschriften und Anzeigen.
