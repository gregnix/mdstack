# Der Event-Loop verstehen

*Stand: 2026-05-29*

## Einführung

Kapitel 2 hat den Event-Loop eingeführt, um ein Fenster auf dem Schirm zu
halten. Jetzt geht es um sein Verhalten unter Last: Warum friert eine
Oberfläche ein, was genau tun `update` und `update idletasks`, wie teilt
man lange Arbeit in verträgliche Häppchen, und warum ist verschachteltes
`vwait` eine Falle. Dieses Kapitel ist die Voraussetzung für jede
Anwendung, die mehr tut als auf Klicks zu warten.

---

## 19.1 Warum die Oberfläche „einfriert"

Tk hat **einen** Event-Loop, der nacheinander Klicks, Tastendruck, Timer
und das Neuzeichnen abarbeitet. Solange ein eigener Callback läuft, läuft
der Loop *nicht* — er kann erst weiterarbeiten, wenn der Callback
zurückkehrt. Eine lange Schleife in einem Button-Befehl blockiert deshalb
die ganze Oberfläche:

```tcl
# Friert die GUI ein, solange die Schleife läuft
ttk::button .b -text "Rechnen" -command {
    for {set i 0} {$i < 100000000} {incr i} { berechne $i }
    # Erst danach reagiert das Fenster wieder
}
```

Während der Schleife kommen keine Klicks an, das Fenster wird nicht neu
gezeichnet, ein zweiter Klick stapelt sich. Das ist kein Bug, sondern die
direkte Folge des Ein-Loop-Modells aus Kapitel 1: Wer den Loop besetzt,
legt die Oberfläche lahm. Die Lösung ist nicht „mehr Threads", sondern
den Loop **freizugeben** — entweder per `update` (mit Vorsicht) oder
besser, indem man die Arbeit in Häppchen über `after` verteilt.

---

## 19.2 `update` gegen `update idletasks`

`update` betritt den Event-Loop **einmal** und arbeitet *alle* anstehenden
Events ab, bevor es zurückkehrt — Klicks, Tasten, Timer *und*
Neuzeichnen. `update idletasks` arbeitet nur die **Idle-Aufgaben** ab,
zu denen das Neuzeichnen gehört, **nicht** aber Eingabe-Events.

Dieser Unterschied ist sicherheitsrelevant. `update idletasks` ist
weitgehend harmlos: Es zwingt ein ausstehendes Neuzeichnen (etwa eines
Fortschrittsbalkens), ohne Eingaben zu verarbeiten.

```tcl
.progress configure -value $prozent
update idletasks       ;# Balken neu zeichnen, sonst nichts
```

`update` dagegen verarbeitet *Eingaben* — und das öffnet die
**Reentrancy-Falle**: Während `update` läuft, kann der Nutzer denselben
Button erneut klicken, und der Callback startet ein zweites Mal,
verschachtelt im ersten:

```tcl
# GEFÄHRLICH: zweiter Klick startet den Callback erneut, mitten im ersten
ttk::button .b -command {
    for {set i 0} {$i < 1000} {incr i} {
        doWork
        update            ;# .b ist hier wieder klickbar -> Reentrancy
    }
}
```

> **Regel:** Zum bloßen Neuzeichnen `update idletasks`. `update` nur, wenn
> man Eingaben wirklich verarbeiten will — und dann mit dem Bewusstsein,
> dass der laufende Code reentrant aufgerufen werden kann. Im Zweifel den
> auslösenden Button vorher per `state disabled` sperren.

---

## 19.3 `after` für Timer und Häppchen-Arbeit

`after` plant Code für später ein — als Timer (nach Millisekunden) oder
als Idle-Aufgabe:

```tcl
after 1000 {puts "eine Sekunde später"}      ;# Timer
after idle {updateDisplay}                    ;# wenn der Loop frei ist
set id [after 5000 {timeout}] ; after cancel $id   ;# planen und abbrechen
```

Werte gibt man über `[list …]` mit, damit sie korrekt eingebettet werden
(dieselbe Substitutionsregel wie beim Button-`-command`, Kapitel 17):

```tcl
after 1000 [list verarbeite $daten]
```

Der eigentliche Wert von `after` für reaktionsfähige Oberflächen ist das
**Aufteilen langer Arbeit**. Statt alles in einem blockierenden Durchlauf
zu erledigen, verarbeitet man ein Häppchen, gibt den Loop frei und plant
das nächste Häppchen ein:

```tcl
proc verarbeiteInHaeppchen {items index} {
    set ende [expr {min($index + 100, [llength $items])}]
    for {set i $index} {$i < $ende} {incr i} {
        verarbeite [lindex $items $i]
    }
    .progress configure -value [expr {100 * $ende / [llength $items]}]
    if {$ende < [llength $items]} {
        after 1 [list verarbeiteInHaeppchen $items $ende]   ;# Rest später
    } else {
        set ::statusText "Fertig"
    }
}
verarbeiteInHaeppchen $grosseListe 0
```

Zwischen den Häppchen läuft der Loop normal: Das Fenster bleibt bedienbar,
der Fortschrittsbalken aktualisiert sich, ein Abbrechen-Button reagiert.
Genau das leistet `update` nicht sauber — `after` ist der robustere Weg.

Ein Detail zur Vermeidung von **Idle-Starvation**: `after 0` reiht sich
in die Event-Queue ein, die *vor* der Idle-Queue verarbeitet wird. Eine
Schleife, die sich endlos mit `after 0` selbst nachplant, lässt
Idle-Aufgaben (Neuzeichnen!) nie zum Zug kommen. Die Trampolin-Technik
wechselt bewusst die Queues:

```tcl
proc dauerlauf {} {
    if {$::laeuft} {
        doSomething
        after idle [list after 0 dauerlauf]   ;# zwischen den Queues wechseln
    }
}
```

---

## 19.4 Lange Arbeit ohne Blockieren

Drei Wege, je nach Art der Arbeit:

1. **Rechenarbeit aufteilen** — die Häppchen-Technik aus 16.3. Bordmittel,
   kein zusätzlicher Mechanismus, voll kontrollierbar.
2. **I/O nicht-blockierend** — Dateien, Sockets und Pipes liest man über
   `chan event … readable` (bzw. `fileevent`) statt mit blockierendem
   `read`. Der Loop bleibt frei und ruft den Handler auf, sobald Daten da
   sind. (Vertieft in Teil 7 zum Thema Async-I/O.)
3. **Echte Parallelität** — für CPU-lastige Arbeit, die sich nicht gut
   aufteilen lässt, gibt es das Thread-Modell von Tcl (eigene
   Interpreter, Kommunikation über Message-Queues). Das ist ein größeres
   Thema und wird hier nur benannt; für die meisten Oberflächen reichen
   Häppchen und Event-I/O.

Über allem steht eine Warnung zu **verschachteltem `vwait`**: `vwait`
betritt den Event-Loop und kehrt erst zurück, wenn seine Bedingung erfüllt
ist. Ruft man `vwait` *innerhalb* eines Callbacks erneut auf, laufen die
beiden Aufrufe **nicht parallel** — der äußere kehrt nicht zurück, bevor
der innere zurückgekehrt ist. Daraus entstehen leicht Deadlocks, wenn man
versucht, asynchrone Vorgänge synchron aussehen zu lassen:

```tcl
# GEFÄHRLICH: vwait im Callback verschachtelt den Event-Loop
ttk::button .b -command {
    vwait ::ergebnis      ;# blockiert, bis ::ergebnis gesetzt wird -- im Loop
}
```

Der saubere Weg ist callback-basiert: Man startet den Vorgang und reagiert
auf sein Ergebnis in einem eigenen Handler, statt im Callback auf das
Ergebnis zu warten. (Coroutinen, in Teil 7 gestreift, bieten eine
elegantere Alternative, um sequenziell lesbaren Code ohne `vwait`-
Verschachtelung zu schreiben.)

---

## Zusammenfassung

- Tk hat einen Event-Loop; ein laufender Callback blockiert ihn und damit
  die ganze Oberfläche.
- `update idletasks` zeichnet neu (harmlos); `update` verarbeitet auch
  Eingaben und kann Callbacks reentrant auslösen.
- `after` plant Timer und Idle-Arbeit; lange Arbeit teilt man in Häppchen
  (`after 1 …`), die zwischen den Häppchen den Loop freigeben.
- `after 0`-Endlosschleifen verhungern die Idle-Queue → Trampolin-Technik.
- Verschachteltes `vwait` läuft nicht parallel und kann verklemmen; lange
  Arbeit löst man callback-basiert, nicht durch synchrones Warten.

Mit dem Loop im Griff geht es im nächsten Kapitel darum, wie Ereignisse
überhaupt zu Code finden — Bindings.
