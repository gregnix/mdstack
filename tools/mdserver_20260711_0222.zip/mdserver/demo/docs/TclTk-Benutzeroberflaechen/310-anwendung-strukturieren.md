# Eine Anwendung strukturieren

*Stand: 2026-05-29*

## Einführung

Die bisherigen Kapitel haben einzelne Bausteine behandelt. Eine echte
Anwendung besteht aus vielen davon, und ohne Struktur wird der Code
schnell zu einem einzigen langen Skript, in dem alles von allem abhängt.
Dieses Kapitel zeigt den Weg vom Skript zum Modul, wiederverwendbare
Komponenten als Megawidgets mit TclOO, die Rolle von Namespaces und ein
Projektlayout, das mitwächst.

---

## 31.1 Vom Skript zum Modul

Ein kleines Tk-Programm ist ein einziges Skript. Wächst es, trennt man
zuerst nach **Zuständigkeit** in Dateien — und lädt sie über `source`
oder, sauberer, als Pakete. Der erste Schritt ist fast immer die Trennung
aus Kapitel 30: Daten, Anzeige, Steuerung in eigene Dateien.

Statt loser `source`-Aufrufe nutzt man Tcls Modul-System. Ein Modul ist
eine Datei `name-version.tm` auf dem Modulpfad, die ein Paket
bereitstellt:

```tcl
# datei: myapp/view-1.0.tm
package require Tk
namespace eval view {
    namespace export build refresh
    proc build {parent} { ... }
    proc refresh {} { ... }
}
package provide view 1.0
```

Geladen wird es über `package require` — Tcl findet es auf dem Modulpfad:

```tcl
::tcl::tm::path add [file join [file dirname [info script]] modules]
package require view
```

Module sind `source` vorzuziehen, weil sie Versionierung, klare Namen und
Abhängigkeiten mitbringen — `package require view` sagt mehr als
`source view.tcl` und prüft, ob das Paket überhaupt da ist. Ein Detail
zur Disziplin: Nur **exportierte** Prozeduren (`namespace export`) sind
die öffentliche API; alles andere ist Implementierungsdetail und kann sich
ändern. Wer von außen eine nicht-exportierte Prozedur ruft, koppelt sich
an Internas.

---

## 31.2 Megawidgets mit TclOO

Ein **Megawidget** ist ein zusammengesetztes Widget, das sich nach außen
wie ein einzelnes verhält — eine Suchleiste aus Entry und Buttons, ein
Datumswähler, die Ampel aus Kapitel 26. TclOO (Tcls Objektsystem) ist der
saubere Weg, so etwas zu kapseln:

```tcl
oo::class create SearchBar {
    variable Frame Entry Callback

    constructor {parent onSearch} {
        set Frame [ttk::frame $parent.search]
        set Entry [ttk::entry $Frame.e]
        ttk::button $Frame.b -text "Suchen" -command [callback Search]
        pack $Entry -side left -fill x -expand 1
        pack $Frame.b -side left -padx {4 0}
        set Callback $onSearch
        bind $Entry <Return> [callback Search]
    }

    method Search {} {                       ;# privat (großgeschrieben)
        uplevel #0 [list {*}$Callback [$Entry get]]
    }
    method widget {} {return $Frame}          ;# öffentlich: das Frame
    method clear  {} {$Entry delete 0 end}
}

# Verwendung
set bar [SearchBar new . {apply {{text} {puts "Suche: $text"}}}]
pack [$bar widget] -fill x
$bar clear
```

Drei TclOO-Mechanismen tragen das. `variable` deklariert die
Instanzvariablen — sie sind in allen Methoden der Instanz sichtbar, aber
von außen unzugänglich (ein wichtiger Punkt: in TclOO sind mit `variable`
deklarierte Instanzvariablen ohne weiteres Zutun in den Methoden
verfügbar). `callback` (bzw. `[list [self] MethodName]`) erzeugt ein
Skript, das eine Methode aufruft — gebraucht für Bindings und `-command`.
Und die Konvention, **private** Methoden großzuschreiben (`Search`) und
öffentliche klein (`widget`, `clear`), hält die API erkennbar.

Das Megawidget kapselt seine inneren Widgets vollständig: Der Nutzer sieht
nur `widget`, `clear`, `search` — nicht das interne Frame-Entry-Button-
Geflecht. Das ist die Komponenten-Grenze, die größere Oberflächen
beherrschbar macht.

---

## 31.3 Namespaces für Oberflächen-Komponenten

Wo TclOO eine Klasse für *mehrfach instanziierte* Widgets ist, sind
Namespaces das Mittel für *einmalige* Komponenten und für die Schichten
aus Kapitel 30 — Modell, View, Controller, Aktionen. Sie gruppieren
Prozeduren und Variablen unter einem Präfix und trennen so die Bereiche:

```tcl
namespace eval app::model      { ... }
namespace eval app::view::main { ... }
namespace eval app::actions    { ... }
```

Ein Callback aus einem Namespace heraus braucht den vollen Pfad oder
`namespace code`, damit er später im richtigen Kontext läuft:

```tcl
namespace eval app::view {
    proc build {} {
        ttk::button .b -command [namespace code onClick]   ;# qualifiziert
    }
    proc onClick {} { ... }
}
```

`namespace code` bindet den Callback an den Namespace, sodass er auch dann
korrekt aufgelöst wird, wenn er aus einem ganz anderen Kontext (dem
Event-Loop) heraus aufgerufen wird — ohne das schlägt der Aufruf fehl,
weil `onClick` global gesucht würde. Das ist das Namespace-Gegenstück zur
Substitutionsfalle bei Bindings (Kapitel 20).

---

## 31.4 Ein tragfähiges Projektlayout

Ein Layout, das von klein bis mittelgroß trägt:

```
meine-app/
├── main.tcl              ← Einstiegspunkt: Pfade setzen, starten
├── lib/                  ← eigene Pakete/Module
│   ├── model/
│   ├── view/
│   └── actions/
├── msgs/                 ← Übersetzungen (Kapitel 32)
│   ├── de.msg
│   └── en.msg
├── assets/               ← Icons, Bilder
└── tests/                ← Tests (Kapitel 33)
```

Die `main.tcl` ist bewusst schlank: Sie setzt den Modulpfad, lädt die
Pakete, prüft Abhängigkeiten und startet — die eigentliche Logik liegt in
den Modulen.

```tcl
# main.tcl
set appDir [file dirname [info script]]
::tcl::tm::path add [file join $appDir lib]

# Abhängigkeiten beim Start prüfen -- Fehlen ist ein Fehler, keine Notlösung
if {[catch {package require Tk} err]} {
    puts stderr "Tk fehlt: $err"; exit 1
}
package require app::model
package require app::view
package require app::actions

app::view::build .
app::model::load
```

Das Prüfen der Abhängigkeiten zu Beginn — und das *Scheitern*, wenn etwas
fehlt — ist Ausdruck der „keine Magie"-Haltung: Eine fehlende Bibliothek
ist ein Fehler, der sich zeigen soll, kein Anlass für eine stille
Notlösung mit eingeschränkter Funktion. Beim Start, bevor die Oberfläche
steht, ist `tk_messageBox` oder `puts stderr` die richtige Meldung; später
die eigene Fehleranzeige.

---

## 31.5 Schichten: View, Application, Services

Kapitel 30 hat UI und Logik getrennt — MVC, virtuelle Events, Testbarkeit.
Kapitel 31.1–31.4 zeigen Module, Megawidgets und Verzeichnisse. Dieser
Abschnitt fügt die **horizontale Schichtung** hinzu: wer darf wen aufrufen,
und was gehört **nicht** in einen `-command`.

### 31.5.1 Drei Schichten (Minimum)

```
┌──────────────────────────────────────────┐
│  View (Tk-Widgets, Megawidgets)           │
│  - baut und aktualisiert die Anzeige      │
│  - kennt keine Dateipfade, kein SQL       │
└──────────────────┬───────────────────────┘
                   │ benannte Procs / <<Events>>
┌──────────────────▼───────────────────────┐
│  Application (Steuerung / Presenter)      │
│  - reagiert auf Nutzeraktionen            │
│  - hält Sitzungszustand (aktuelles Dok.)  │
│  - ruft Services auf, aktualisiert View   │
└──────────────────┬───────────────────────┘
                   │
┌──────────────────▼───────────────────────┐
│  Services (Persistenz, Netz, System)      │
│  - Datei lesen/schreiben, DB, HTTP        │
│  - kein package require Tk                │
└──────────────────────────────────────────┘
```

Das **Model** aus Kapitel 30 kann in Application und Services aufgeteilt
werden: reine Datenstrukturen und Regeln in `model`, I/O in `service`.
Wichtig ist die Richtung: View ruft nie `open` oder `sqlite3` direkt auf.

### 31.5.2 Was nicht in `-command` gehört

```tcl
# SCHLECHT — Logik und I/O im Widget-Callback
ttk::button .save -command {
    set f [tk_getSaveFile]
    set h [open $f w]
    puts $h [$text get 1.0 end]
    close $h
}

# BESSER — eine benannte Aktion
ttk::button .save -command [list app::actions::saveDocument]
```

`app::actions::saveDocument` öffnet den Dialog, ruft `service::file::write`
auf, setzt bei Erfolg den Status und feuert optional `event generate . <<Saved>>`.

### 31.5.3 Dateilayout (Beispiel)

Ergänzung zu 27.4:

```
meine-app/
├── main.tcl
├── lib/
│   ├── app-1.0.tm              ;# namespace app — Start, Wiring
│   ├── app::model-1.0.tm       ;# Daten, Validierung, kein Tk
│   ├── app::service::file-1.0.tm
│   ├── app::view::main-1.0.tm  ;# Fensteraufbau
│   └── app::actions-1.0.tm     ;# Nutzeraktionen
└── tests/
    ├── model.test.tcl
    └── service-file.test.tcl
```

`app::view::main` exportiert `build` und `setStatus`; `app::actions`
exportiert `saveDocument`, `openDocument`, … — das sind die einzigen
Einstiegspunkte, die Buttons und Menüs kennen.

### 31.5.4 Ablauf: „Speichern" (Schritt für Schritt)

1. Nutzer: Klick **Speichern** oder Strg+S (Kap. 17, 21)
2. View: `app::actions::saveDocument` (kein Dateizugriff)
3. Application: prüft „ungespeicherte Änderungen?", holt Pfad oder Dialog
4. Application: `set content [app::model::getDocumentText]`
5. Service: `app::service::file::write $path $content` → ok / Fehlermeldung
6. Application: bei ok `app::model::markClean`, `app::view::main::setStatus "Saved"`
7. Optional: `event generate . <<DocumentSaved>>` für andere Panels

Jeder Schritt ist einzeln testbar — Schritte 5–6 ohne GUI mit `tcltest`.

### 31.5.5 Services ohne Tk

```tcl
# app::service::file-1.0.tm — bewusst kein "package require Tk"
namespace eval app::service::file {
    namespace export read write
    proc read {path} { ... }
    proc write {path content} { ... }
}
package provide app::service::file 1.0
```

So bleiben Datei- und Netzlogik in CI und auf dem Server testbar, ohne
Display oder `xvfb-run`.

### 31.5.6 Grenzen des Modells

- Kleine Utilities (< 200 Zeilen) brauchen nicht drei Pakete — aber die
  **Disziplin** (kein I/O im Button) lohnt sich trotzdem.
- Megawidgets (27.2) sind **View**-Bausteine; sie rufen keine Services auf,
  höchstens einen übergebenen Callback.
- `trace` und `-textvariable` (Kap. 29) sind View↔Model-Klebstoff — die
  Application soll entscheiden, wann Traces gesetzt werden, nicht jedes
  Entry-Widget für sich.

## Zusammenfassung

- Vom Skript zum Modul: nach Zuständigkeit trennen, als `.tm`-Pakete
  laden (`package require`), nur Exportiertes als öffentliche API nutzen.
- Megawidgets mit TclOO kapseln zusammengesetzte Widgets; `variable` für
  Instanzzustand, `callback`/`[list [self] M]` für Bindings, private
  Methoden großschreiben.
- Namespaces gruppieren einmalige Komponenten und die MVC-Schichten;
  Callbacks mit `namespace code` qualifizieren.
- Schlanke `main.tcl` (Pfade, Laden, Start), Abhängigkeiten beim Start
  prüfen und bei Fehlen abbrechen — keine stillen Notlösungen.

Das nächste Kapitel macht die Oberfläche mehrsprachig, ohne sie
umzubauen — Internationalisierung mit msgcat.
