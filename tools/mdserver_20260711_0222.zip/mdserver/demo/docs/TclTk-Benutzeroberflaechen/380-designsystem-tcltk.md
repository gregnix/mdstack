# Designsystem für Tcl/Tk

*Stand: 2026-06-16*
*Kurzreferenz:* [Anhang E](../900-anhaenge/anhang-e-designsystem.md) (einseitige Tabelle)  

## Einführung

Ein **Designsystem** ist keine Luxus-Broschüre — es ist die Antwort auf die
Frage: *Welche Schrift, welcher Abstand, welche Farbe — jedes Mal?* Ohne
feste Werte driftet jede neue Dialogbox leicht ab, und die Anwendung wirkt
zusammengestückelt.

Dieses Kapitel definiert ein **minimales, praxistaugliches** System für
Ttk-Anwendungen. Es baut auf Kapitel 24 und 27 auf und wird beim App-Start
einmal aktiviert.

---

## 38.1 Design-Tokens

Tokens sind benannte Werte — im Code als Tcl-Variablen oder dict:

```tcl
namespace eval ::ui::token {
    variable space_xs 4
    variable space_sm 8
    variable space_md 12
    variable space_lg 16
    variable font_body  {DejaVu Sans 11}
    variable font_head  {DejaVu Sans 14 bold}
    variable font_small {DejaVu Sans 9}
    variable color_primary "#2563eb"
    variable color_danger  "#dc2626"
    variable color_muted   "#6b7280"
    variable color_bg      "#f5f5f5"
    variable min_button_w  80
}
```

| Token | Wert | Verwendung |
|-------|------|------------|
| `space_xs` | 4 px | Icon-Innenabstand |
| `space_sm` | 8 px | Frame-`padding`, Toolbar |
| `space_md` | 12 px | Formular-Rand, Button-`padding` |
| `space_lg` | 16 px | Zwischen Sektionen (`pady`) |
| `font_body` | 11 pt | Standard `configure . -font` |
| `font_head` | 14 pt bold | `Header.TLabel` |
| `color_primary` | #2563eb | `Primary.TButton` |
| `color_danger` | #dc2626 | `Danger.TButton` |
| `color_muted` | #6b7280 | Hinweise, deaktiviert |
| `min_button_w` | 80 px | `grid -minsize` oder `-width` in Zeichen |

Tokens **nicht** an jedem Widget neu erfinden — `::ui::theme::init` liest sie
einmal (Kap. 24.2).

---

## 38.2 Button-Hierarchie

| Stil | Style-Name | Wann |
|------|------------|------|
| Primär | `Primary.TButton` | **Eine** Hauptaktion pro Dialog/Ansicht |
| Standard | `TButton` | Normale Aktionen |
| Sekundär | `TButton` oder `Toolbutton.TButton` | Abbrechen, Zurück |
| Gefahr | `Danger.TButton` | Löschen, irreversibel |

```tcl
pack .dlg.cancel -side right -padx 4
pack .dlg.ok     -side right -style Primary.TButton
# Delete separat, links von OK mit Abstand — Fitts/Nielsen
```

---

## 38.3 Formulare

- **Zwei Spalten:** Label Spalte 0 (`sticky e`, `minsize 100`), Control Spalte 1
  (`sticky ew`, `weight 1`)
- **Pflichtfelder:** `*` im Label oder „(required)" — nicht nur rote Umrandung
- **Abstand Zeilen:** `pady 4` einheitlich
- **Breite Dialog:** `wm minsize` ~400 px für kurze Formulare

---

## 38.4 Dialog-Layouts

```
┌─────────────────────────────────┐
│  Titel / Kurztext               │
│  ┌───────────────────────────┐  │
│  │  Inhalt (grid / frame)     │  │
│  └───────────────────────────┘  │
│              [Cancel]  [  OK  ] │
└─────────────────────────────────┘
```

- Buttonleiste **unten**, `pack -side bottom` vor dem Inhalt oder nach
  dem Inhalt mit `pack` Reihenfolge beachten (Kap. 6)
- **Plattform:** unter Windows oft OK links von Cancel; unter macOS umgekehrt —
  `tk windowingsystem` wenn nötig (Kap. 18)

---

## 38.5 Container-Entscheidungsbaum

```
Mehrere gleichwertige Inhaltsbereiche sichtbar?
  JA → ttk::notebook
  NEIN → Nutzer soll Größenverhältnis ziehen?
    JA → ttk::panedwindow
    NEIN → Nur visuelle Gruppe mit Titel?
      JA → ttk::labelframe
      NEIN → ttk::frame
```

---

## 38.6 pack vs. grid — Kurzentscheidung

| Situation | Manager |
|-----------|---------|
| Toolbar, Status, Kopf/Fuß des Fensters | `pack` |
| Formular, Tabelle, gleichmäßiges Raster | `grid` |
| Overlay, freie Position | `place` (selten) |

**Zonen `pack`, Inhalt `grid`** — Standardgerüst Kap. 10, 11, Anhang F.

---

## 38.7 Referenz-Implementierung

```tcl
# ui-theme-1.0.tm (Auszug)
namespace eval ::ui::theme {
    namespace export init applyLight applyDark

    proc init {} {
        if {"myapp" ni [ttk::style theme names]} {
            ttk::style theme create myapp -parent clam
        }
        applyLight
        _defineStyles
    }

    proc _defineStyles {} {
        variable ::ui::token
        ttk::style configure . -font $::ui::token::font_body
        ttk::style configure TFrame -padding $::ui::token::space_sm
        ttk::style configure Header.TLabel -font $::ui::token::font_head
        ttk::style configure Primary.TButton -font {DejaVu Sans 11 bold}
        ttk::style map Primary.TButton -background \
            [list !disabled $::ui::token::color_primary active "#1d4ed8"]
        # Danger, Hint.TLabel …
    }
}
package provide ui::theme 1.0
```

In `main.tcl`: `package require ui::theme; ::ui::theme::init` **vor** dem
Aufbau der Oberfläche.

---

## 38.8 Pflege des Systems

- Tokens in **einer Datei** — Änderung der Primärfarbe an einer Stelle
- Neue Dialoge **kopieren kein** Ad-hoc-`padding` — sie nutzen Styles
- Bei neuen Widget-Typen: erst prüfen, ob bestehender Style reicht

---

## Zusammenfassung

- Design-Tokens verhindern Drift; `ui::theme::init` setzt sie in Ttk um.
- Button-Hierarchie, Formular-Raster und Dialog-Skelett sind wiederholbar.
- Container-Baum und pack/grid-Regel reduzieren Layout-Entscheidungen.
- Anhang E verdichtet die Tabellen auf eine Nachschlagseite.

Damit schließt Teil 550 (GUI-Design) die Lücke zwischen „Tk kann Layout"
und „die Anwendung wirkt professionell".
