# Changelog

## Version 0.3.2 (2026-03-14) -- Initial GitHub Release

### Neu

- **mdhtml 0.1** -- Markdown -> HTML Renderer (komplettiert Stack: HTML + PDF + Tk)
- **mdtheme 0.1** -- Theme-System fuer HTML, PDF und Tk (hell, dunkel, solarized)
- **tools/mdserver** -- HTTP/HTTPS Markdown Web Server (pure Tcl, kein Tk)

### Erweiterungen

- **mdpdf 0.2** -- klickbare Hyperlinks, `-pdfa`, `-userpassword`, `-ownerpassword`, `-theme`
- **mdtheme 0.1** -- `toCSS`, `toPdfOpts` fuer HTML- und PDF-Renderer


---

## Version 2.0.2 (March 2026) – DocIR Bridge

Bug-fixes & Test-Hygiene

### Bug-fixes

- **mdparser 0.2** -- `parseListBlock`: Nested-list-Bug behoben.
  Verschachtelte Listen mit gemischtem Typ (z.B. `1.` außen, `- ` innen)
  wurden als separate Blöcke geparst statt als Kindknoten.
  Ursache: Typ-Prüfung (ordered vs unordered) galt für alle Einrückungsebenen.
  Fix: Prüfung nur noch bei `lineIndent <= baseIndent` (Top-Level-Marker).

### Test-Verbesserungen

- **tests/basic.tcl** -- Core- und GUI-Tests sauber getrennt.
  stack-1 (headless): `mdstack`, `mdparser`, `mdmodel`, `mdhtml`.
  stack-2/3 (Tk-Guard): Viewer- und Editor-Module.
- **tests/all.tcl** -- Vierteilung A/B/C/D:
  A = Core/Parser (headless), B = Renderer (headless),
  C = GUI/Tk, D = PDF/Export.
  Neue Flags `--core`, `--gui`, `--pdf`.
  Bisher fehlende Tests ergänzt: `parser-tip700`, `parser-tip700-t2t3`,
  `validator`, `test-docir-md`.
- **tests/parser-inline-*.tcl** -- Variablennamen `pass`/`fail` auf
  `passed`/`failed` vereinheitlicht, `upvar`-Referenz korrigiert.
- **tests/test-docir-md.tcl** -- Zähler vereinheitlicht, `upvar 1` im
  test-proc ergänzt.
- **tests/validator.tcl** -- C2-Test sprachunabhängig (englisch/deutsch).

### Testergebnis

Headless (kein Tk): 445/445, 0 Fehler
Mit Tk: +21 GUI-Tests (466 gesamt)

### Release-Hygiene

- **README.md** -- Lizenz BSD→MIT korrigiert, `mdvalidator` und `docir-md`
  ergänzt, Testlauf-Anleitung mit Flags.
- **LICENSE** -- MIT (war bereits korrekt).



### docir-md-0.1.tm – NEW in lib/

Mapper: mdparser-AST → DocIR (Unified Intermediate Representation).

Enables the use of `docir-renderer-tk` from man-viewer for
Markdown documents without touching mdviewer.

**Supported Block Types:**

| mdparser | DocIR | Note |
|----------|-------|-----------|
| `document` | `doc_header` | meta from YAML-Frontmatter |
| `heading` | `heading` | level, anchor as id |
| `paragraph` | `paragraph` | |
| `code_block` | `pre` | kind=code, language |
| `list` (ul/ol) | `list` + `listItem` | kind=ul/ol |
| `blockquote` | `paragraph` | class=blockquote |
| `deflist` | `list` + `listItem` | kind=dl, term in meta |
| `table` | `pre` | kind=table (placeholder) |
| `hr` | `hr` | |
| `div` | — | inner blocks recursively |

**Inline Types:** text, strong, emphasis, inline_code → code,
link, image → text-placeholder, linebreak, footnote_ref.

**API:**
```tcl
package require docir-md 0.1
set ir [docir::md::map $ast]
```

**Tests:** 19 tests in `test/test-docir-md.tcl`

**Location:** `lib/docir-md-0.1.tm` (not vendors/ – mdstack-owned module)

---

## Version 2.0.1 (Maerz 2026) – Parser Refactoring + AST-Spec Alignment

### mdvalidator 0.1 – NEW (AST validator)

Validates AST nodes against spec v0.3. Two modes:

- Normal: Validates required fields, types, value ranges
- Strict (`-strict`): Additionally warns about unknown node types,
  empty text.value, empty anchors

Detects pre-phase-2 regressions: `type code` instead of `code_block`,
`inlines` instead of `content`, `type em` instead of `emphasis`, etc.

API:
- `mdvalidator::validate $ast ?-strict?` -- List of error strings
- `mdvalidator::report $ast ?-strict?` -- Formatted output

Tests: 42 (10 valid ASTs, 13 broken ASTs, 2 report, 2 strict,
9 real documents, 6 regression tests)

### mdparser 0.2.9 – YAML Frontmatter + Fenced Divs (Phase T2/T3)

**YAML Frontmatter (T2):**
- `---` at document start begins Frontmatter-Block
- Simple key-value parsing (not a full YAML parser)
- Closing with `---` or `...`
- Result in `meta`-Dict of Document-Root
- No effect on existing documents without frontmatter

**Fenced Divs (T3):**
- New Block-Node `div` with `class` and `blocks`
- Syntax: `::: {.class} ... :::` (also `::: .class` and `::: class`)
- Nesting supported (depth counting)
- Content is parsed recursively with `parseBlocks`
- Bare `:::` (without class) is still skipped

**Renderer Updates:**
- mdviewer: div renders inner blocks recursively
- mdpdf: div renders inner blocks with correct y-traversal
- mdmodel: div-search with recursion into inner blocks

**Tests:**
- New test file: `test/parser-tip700-t2t3.tcl` (39 tests)
  - A-F: YAML Frontmatter (18 tests: basics, multi-field, dots, empty, no-match)
  - G-L: Fenced Divs (18 tests: simple, multi-block, nested, variants, empty, bare)
  - M: Combination YAML + Div (3 tests)
- All 407 existing tests still green

### mdparser 0.2.8 – TIP 700 Support (Phase T1)

**Bracketed Spans (Pandoc/TIP 700):**
- New Inline-Node `span` with `class` and `content` (inline[])
- Syntax: `[text]{.class}` -- Pandoc's `bracketed_spans` Extension
- Nesting: `[[-code]{.lit} [code]{.arg}]{.optarg}`
- Recursive parsing via `findMatchingBracket` Helper
- TIP-700-Classes: .cmd, .sub, .lit, .optlit, .arg, .optarg, .optdot,
  .ins, .ccmd, .cargs, .ret

**Shortcut Reference Links:**
- Syntax: `[encoding]` (single brackets without following `(`, `[`, `{`)
- Lookup in reflinks-Dict; fallback to normal text
- No conflict with Bracketed Spans (prioritization: Link > Span > Shortcut)

**Renderer Updates:**
- mdviewer: span-rendering with .cmd/.sub/.lit -> bold, .arg/.optarg/.ins -> italic
- mdpdf: span in _inlinesToSegments and _inlinesToPlainText
- mdmodel: span in flattenInlines

**Tests:**
- New test file: `test/parser-tip700.tcl` (45 tests)
  - A: Simple Spans (8 tests: cmd, arg, sub, optlit, ccmd)
  - B: Multiple Spans in sequence (7 tests)
  - C: Nested Spans (8 tests)
  - D: Spans with Inline-Formatting (3 tests)
  - E: Distinction from Links (3 tests)
  - F-G: Shortcut Reference Links with/without Title (6 tests)
  - H: No match without reflink-definition (1 test)
  - I: TIP-700-Command syntax (4 tests)
  - J: Class variants (2 tests)
  - K: Shortcut next to normal Reflink (3 tests)
- All 362 existing tests still green

### mdparser 0.2.7 – Structural Refactoring

**Parser Architecture:**
Monolithic `parse` function (280 lines while-loop) split into modular dispatcher architecture:
- 11 `isXxx` recognition functions (pure regexp, no side effects)
- 10 `parseXxx` Block-Parsers (one block type each, upvar lines/i)
- `parseBlocks` Dispatcher (central loop, priority order)
- `parse` only orchestrates: Normalization, Pass 1, parseBlocks, Document-Assembly

Procedure count: 9 → 30. Line count: 750 → 871. No behavioral changes.

**Link label as inline[] (AST-Spec 5.5):**
- `label` is now `inline[]` instead of String for all Link types
- Markdown-Links: `[**bold** link](url)` → label is parsed by `parseInlines`
- Autolinks: `<https://...>`, `<user@host>`, bare URLs → label as `{type text value $url}`
- Reference Links: label is also parsed by `parseInlines`
- All 5 renderer locations updated (mdviewer, mdpdf, mdmodel)

**list_item Block Model (AST-Spec 4.5):**
- Items now have `type list_item` with `blocks` (list of Block-Nodes)
- Replaces previous `content` (inline[]) + `children` ([list])
- First block is always a `paragraph` with the Item-text
- Sub-lists are additional blocks in the same Item
- All 3 renderers updated (mdviewer, mdpdf, mdmodel)

**AST Field Names (Phase 1):**
13 field name changes across Parser, Renderer and Tests:
`inlines` → `content` (heading), `ordered` → `style`, `text` → `value` (inline),
`code` → `value` (inline_code), plus 9 more adjustments.

### mdviewer 0.3 – Renderer Updates

- Link-Rendering: `renderInlines` for Label instead of `$t insert end $label`
- Tag-Range-based Link-Styling (start/end indices)
- `inlinesToText`: recursive call for Link-Label
- List-Rendering: iterates over `item.blocks`, first paragraph inline, rest as blocks

### mdpdf 0.2 – Renderer Updates

- `_inlinesToSegments`: Link-Label processed as `inline[]`
- `_inlinesToPlainText`: Link-Label recursively resolved via Wrapper-Dict
- List-Rendering: reads first paragraph-block from `item.blocks`

### mdmodel 0.1 – Updates

- `flattenInlines`: Link-Label recursively resolved
- `find`: List-Items traversed via `blocks[0].content`

### Tests

- New test file: `test/parser-phase2.tcl` (~50 tests)
  - A: Link-Label as inline[] (8 tests: simple, bold, code, emphasis, autolink, bare, mailto, title)
  - B: list_item Block Model (10 tests: type, blocks, nested, ordered, task, no-children, multiline, strong, 3-levels)
  - C: parseBlocks Dispatcher (all 9 block types recognized)
  - D: Reference Links with formatted Label
- Updated tests: parser-nested-lists, parser-multiline-list, parser-reflinks, parser-inline-features
- New test helpers: `hasSubBlocks`, `getSubList`, `labelText`, `flatLabel`

### AST-Spec v0.2

Spec updated from v0.1 to v0.2 (doc/spec.md, 431 lines):

- Document Root: version, meta, reflinks documented
- New Block-Nodes: hr (4.7), image standalone (4.8), table (4.9), deflist (4.10)
- New Inline-Nodes: strike (5.6), linebreak (5.7), image inline (5.8)
- heading.anchor documented
- list_item.checked (Task Lists) documented
- Parser Contract extended: parseInlines, validate, supports, anchorize
- Renderer Rule: unknown Node types must be ignored

## Version 2.0 (Februar 2026) – pdf4tcllib Integration

### pdf4tcllib 0.1 – NEU

PDF extension library as single file (~1900 lines, 8 modules):
fonts, unicode, text, table, page, drawing, units, image.
Only dependency: pdf4tcl.

**Emoji Handling:**
- `preprocessBytes`: Replaces 4-byte UTF-8 Emojis at byte level,
  before Tcl 8.6 destroys them to U+FFFD.
- `readFile`: Reads UTF-8 files with automatic Emoji preprocessing.
- `_emojiFallback`: 40+ specific Emoji mappings
  (e.g. Grinning->`:-)`, Party->`(!)`, Thumbs Up->`(+1)`)
  plus range-based defaults for unknown Emojis.
- Works identically with Tcl 8.6 and 9.0.

**Unicode:**
- `sanitize`: 2-stage cleanup (String-Map + Catch-All).
  BMP symbols, Surrogate pairs (Tcl 8.6), direct codepoints (Tcl 9.0).
- Typographic quotes: U+201E/201C/201D -> `"`,
  U+201A/2018/2019 -> `'`.
- U+FFFD Fallback: Destroyed Emojis are displayed as `(?)`.

**Font Management:**
- `fontWidthFactor`: Helvetica-Oblique (0.58) and
  Helvetica-BoldOblique (0.64) registered. Fixes space loss
  at Italic->BoldItalic transitions.
- Automatic TTF search (DejaVu Sans) on Windows, Linux, macOS.

### mdpdf 0.2 – Migration to pdf4tcllib

- **NEW: `mdpdf::exportFile`** — Reads Markdown file binary with
  Emoji preprocessing and exports directly as PDF. Recommended API
  for files with Emojis and special characters.
- 1496 -> 1149 lines through delegation to pdf4tcllib.
- 6 Procs removed: `_loadTrueTypeFonts`, `_getFontName`,
  `_sanitizeForPdf`, `_textWidth`, `_wrapCodeLine`, `_getPageSize`.
- fontWidthFactor-Array removed (text::width instead).
- Option `-usettf` removed (automatic via fonts::hasTtf).
- New option: `-fontdir`.
- API: `export`, `exportFile`, `exportModel`, `configure`.

### mdhelp_pdf 0.3 – Migration to pdf4tcllib

- 1513 -> 627 lines through delegation to pdf4tcllib.
- API unchanged: `exportFromWidget`, `exportFromFile`.

### mdviewer 0.3 – Windows Bugfix

- `isAbsUrl`: Regex `*` -> `+` — Windows drive letters
  no longer recognized as URL schema.

### mdcontextmenu 0.1 – Restored

- Correct file (471 lines) restored.

### Tests

- 45/45 Emoji tests passed (Tcl 8.6.17 + 9.0.3 identical).
- `tests/test-emoji-sanitize.tcl`: preprocessBytes Unit-Tests.
- `tests/test-emoji-pdf.tcl`: PDF generation via exportFile.
- `tests/test-emoji.md`: Test document with 14 Unicode/Emoji sections.

### General

- Version mdstack-1.0 -> mdstack-2.0
- 13 -> 14 modules in lib/ + pdf4tcllib in vendors/tm/
- Demo restructured: Markdown in separate .md files (for Emoji support)

---

## Version 0.3.9 (Februar 2026) – Definition Lists

### mdparser 0.2.6 – Definition Lists

**Definition Lists:** New block type deflist for term/definition pairs in PHP Markdown Extra Format:

```markdown
Term
: Definition

Word
: Meaning 1
: Meaning 2
```

**AST Structure:** `{type deflist items {{term {inlines} termText "..." definitions {{inlines} ...}} ...}}`

**Features:**
- Multiple definitions per term (multiple `: ` lines)
- Connected entries (with and without blank lines)
- Inline formatting in Term and Definition (**bold**, *italic*, `code`, Links)
- Lookahead recognition: only when text line is followed by `: `
- Normal text with colon remains Paragraph

### mdviewer 0.3 – Definition List Rendering

**Rendering:** Term in **bold** (defterm tag), definitions with `—` Prefix and 30px indentation (`defdef`-Tag). Font size adjusts via setFontSize.

**Technical changes:**
- mdparser: 667 → 731 lines
- mdviewer: 945 → 976 lines
- New test file: `test/parser-deflist.tcl` (33 tests)
- New demo: `demo/mdviewer-deflist-demo.tcl`
- Complete test suite: 347 tests, 0 failures

---

## Version 0.3.8 (Februar 2026) – Multi-Line List Items

### mdparser 0.2.5 – Multi-Line List Items

**Multi-Line Items:** Continuation lines (indented, without marker) are appended to the current item's text. Works with flat, nested, ordered and task lists.

```markdown
- Long text spanning
  multiple lines.
  - Sub-Item after multi-line
- Next item
```

**Rules:**
- Continuation lines: 2+ spaces indentation, no list marker
- Blank line ends multi-line (no swallowing of code blocks))
- Continuation ends when sub-items (with marker) begin
- Inline formatting (**bold**, *italic*, `code`) works across line boundaries

**Technical changes:**
- mdparser: 650 → 667 lines
- lines collector accepts indented non-marker lines
- `parseListLines`: `seenSubItem`-flag separates continuation from sub-content
- New test file: `test/parser-multiline-list.tcl` (35 tests)
- New demo: `demo/mdviewer-multiline-list-demo.tcl`
- Complete test suite: 314 tests, 0 failures

---

## Version 0.3.7 (Februar 2026) – Nested Lists

### mdparser 0.2.4 – Nested Lists

**Nested Lists:** Lists can now be nested to arbitrary depth. Sub-Items are detected by indentation (2+ spaces) and stored as `children` field in Item-Dict. Supports: unordered in ordered, ordered in unordered, task lists nested, inline formatting on all levels.

**AST Extension:** Items with sub-lists contain `children` – a list of sub-list blocks:
```
{inlines {...} children {{type list ordered 0 items {...}}}}
```

**New Helper:** `parseListLines` groups collected lines recursively by indentation depth. Detects base indent of first line, Items at base level become direct items, more deeply indented lines → `children`.

### mdviewer 0.3 – Nested List Rendering

**Nested List Rendering:** `renderList` renders lists recursively with visual indentation via `list_d{N}` Tags (lmargin1/lmargin2). Bullet style changes per level: `• ◦ ▪ ▸`.

**Technical changes:**
- mdparser: 577 → 650 lines
- mdviewer: 916 → 945 lines
- New test file: `test/parser-nested-lists.tcl` (46 tests)
- New demo: `demo/mdviewer-nested-lists-demo.tcl`
- Complete test suite: 279 tests, 0 failures

---

## Version 0.3.6 (Februar 2026) – Reference Links

### mdparser 0.2.3 – Reference Links & Images

**Reference Links:** `[Text][ref]` with `[ref]: url "title"` definitions. Definitions are collected in the first pass and treated as invisible lines (do not appear as Paragraph). Case-insensitive lookup, first definition wins on duplicates.

**Collapsed References:** `[Text][]` uses the link text as reference key.

**Reference Images:** `![Alt][ref]` analogous to Reference Links.

**Recursive Reference Resolution:** Definitions from the outer document are also available in blockquotes. Clean save/restore mechanism of the `reflinks` namespace variable during recursive parse call.

**AST Extension:** Document-Node contains `reflinks` Dict with all definitions of the document (Key → url, title, label).

**Undefined References:** `[Text][unknown]` is passed through as Plain-Text (no Link-Node).

**Technical changes:**
- mdparser: 496 → 577 lines
- New namespace variable `reflinks` with `[dict create]` initial value
- Pass 1 (Definitions-Scan) before Pass 2 (Block-Parsing)
- `refDefLines` dict marks definition lines for skip
- Paragraph-Collector stops at definition-lines
- `parseInlines` accesses `reflinks` namespace variable
- New test file: `test/parser-reflinks.tcl` (42 tests)
- Complete test suite: 233 tests, 0 failures

---

## Version 0.3.5 (Februar 2026) – Formatierungs-Fixes

### mdviewer 0.3 – Blockquote and Table Formatting

**Blockquote Bold+Italic Fix:** `**bold**` Text in Blockquotes is now correctly displayed as **bold and italic**. The problem was that Tk does not always correctly interpret the font combination. Solution: using list syntax `[list $family $size bold italic]` for `strong_q` tag. Additionally the `quote_d0` tag removed from format tag ranges, so it can set the font properties.

**Table Formatting Fix:** Bold and italic are now correctly displayed in table cells. Text inside strong/em in tables gets both tags combined (`tablecell` + `strong_t`/`em_t`), so both the base tag (for background/monospace) and the format tag (for bold/italic) are active.

**Technical changes:**
- `setFontSize`: Table tags (`strong_t`, `em_t`, `strike_t`) are now also updated
- Tag priorities are ensured after blockquote and table rendering
- Text-Nodes within Format-Tags receive the Format-Tag directly on Insert
- `strong_q` uses list syntax: `[list $defaultFamily $size bold italic]`
- New test file: `demo/test-context-tags.tcl`

**Bugfixes:**
- Blockquotes: `**bold**` Text is now displayed bold and italic (instead of only italic)
- Tables: `**bold**` Text is now displayed bold and Monospace (instead of only Monospace)
- `quote_d0` tag is removed from format tag ranges so format tags can set font properties

---

## Version 0.3.4 (Februar 2026) – Inline-Features

### mdparser 0.2 – Neue Inline-Features

**Bare URL Autolinks:** `https://example.com` in running text is automatically recognized as a clickable link. Trailing punctuation is correctly separated. Also http:// is supported.

**Angle-Bracket Autolinks:** `<https://example.com>` and `<user@example.com>` are recognized as Link or mailto-Link.

**Heading Inline-Parsing:** `## Title with **bold** and \`code\`` now generates an inlines field in the heading block with parsed inline elements. The `text` field remains for backward compatibility (TOC, Anchor, mdpdf).

**Table Cell Inline-Parsing:** Table cells now contain parsed inlines. New fields in table block: `headerInlines` and `rowsInlines`. The fields `header` and `rows` remain as raw strings (backward compatibility with mdpdf).

### mdviewer 0.3 – Viewer Improvements

**Heading Rendering with Inlines:** Headings now display **bold**, *italic*, `code` and other inline formatting (instead of raw Markdown syntax).

**Table Rendering with Inlines:** Table cells now render inline formatting (**bold**, *italic*, `code`, Links, ~~strike~~). New helper: renderTableCell with alignment calculation based on plain text length.

**Context Tag System (Tk Font Workaround):** Tk text widget cannot combine fonts with overlapping tags – the higher-priority tag wins completely. Fix: context-dependent tags with predefined font combinations:
- Blockquote: `strong_q` → `{bold italic}`, `em_q` → `italic` (instead of bold which overrides italic)
- Table: `strong_t` → `FixedFont bold`, `em_t` → `FixedFont italic` (instead of bold which overrides italic)
- New State: `renderContext` ("normal" / "quote" / "table"), `tableBaseTag`

**Technical changes:**
- New test file: `test/parser-inline-features.tcl` (47 tests)
- Complete test suite: 191 tests, 0 failures
- Plain-Text-Collector now also stops at `<` and `http://`/`https://`
- mdviewer: 722 → 844 lines

---

## Version 0.3.3 (Februar 2026) – Parser Inline-Bugfixes

### mdparser 0.2 – Bugfixes

**BUG1: Backslash-Escape** – `\*`, `\``, `\~`, `\[` etc. are now treated as literal characters instead of being interpreted as markup. Supported escape characters: `* _ ` ~ [ ] ( ) \ ! # + - . { } |`

**BUG2: Bold+Italic (`***text***`)** – Is correctly parsed as `strong > em` instead of `*` + strong + `*`. Pattern order: `***` before `**` before `*`.

**BUG3: Double-Backtick Code** – ``` ``code `with` ticks`` ``` is parsed as a single code span. Uses string first instead of regex for robust matching.

**BUG4: Link/Image Title** – `[text](url "title")` und `![alt](img.png "title")` parse URL and title separately. Title is stored as title key in the dict. Uses regexp -indices for correct match length.

**Technical changes:**
- `parseInlines`: Strong/Em/Strike-Regex changed from `[^*]+` to `.+?` (non-greedy)
- `\\` added to Plain-Text Stop-Characters
- New test file: `test/parser-inline-fixes.tcl` (40 tests)
- Complete test suite: 144 tests, 0 failures

---

## Version 0.3.2 (Februar 2026) – mdpdf Phase 2 & 3 Features

### mdpdf 0.1 – Neue Features (Phase 2 & 3)

**Tabellen-Rendering (Phase 2):**
- ✅ Complete table support with header and body
- ✅ Automatic column width calculation based on content
- ✅ Alignment support (left, centered, right)
- ✅ Page break handling for large tables
- ✅ Helper functions: _stripMarkdown, _alignText for table cells

**Bilder als Block-Typ (Phase 2):**
- ✅ Support for image blocks (`image` block type)
- ✅ Path resolution relative to `-root` Option
- ✅ Fallback to alt text when image cannot be loaded
- ✅ Page break check before image rendering

**TrueType-Font-Support (Phase 3):**
- ✅ Automatic loading of DejaVu Sans fonts (if available)
- ✅ Support for Windows and Linux font paths
- ✅ Fallback to standard fonts when TrueType fonts not available
- ✅ New option -usettf to enable
- ✅ Unicode support without sanitization with TrueType fonts
- ✅ Functions: `_loadTrueTypeFonts`, `_getFontName`

**Header-Support (Phase 3):**
- ✅ Header rendering on every page
- ✅ Support for %p placeholder for page numbers
- ✅ Header is automatically inserted at all page breaks
- ✅ New function: `_writeHeader`
- ✅ Option `-header` for header text

**Bugfixes:**
- ✅ Table alignment fixed (right column stays within line))
- ✅ Table of contents now works correctly (uses text field from headings))
- ✅ Image rendering bug fixed (alt text displayed correctly))

**Technical Improvements:**
- All `_renderBlock` calls were updated to support `headerTemplate` and `useTTF` to support
- `_styleToFont` was extended to use TrueType fonts when available
- `_renderStyledLine` was updated to support TrueType fonts and skip unicode sanitization when TrueType fonts are used

**Note:**
- TOC page numbers are not yet implemented (requires two-phase export, planned for later))

---

## Version 0.3.1 (Februar 2026) – Cleanup + Phase 2 Features

### mdviewer 0.3 – Neue Features

**Anchor-Navigation (Phase 2.2):**
- Heading-Rendering setzt automatisch `anchor_*` Marks (aus Parser-AST)
- `gotoAnchor $path $anchor` → scrolls to heading, returns 1/0
- `anchors $path` → List of all available anchor names
- Internal #anchor links navigate automatically (no external callback needed)

**Fontsize-Steuerung (Phase 2.5):**
- `setFontSize $path $size` → passt alle Tags proportional an
- `-fontsize $size` als configure-Option
- Heading-Skalierung: h1=1.6x, h2=1.4x, h3=1.2x, h4=1.1x, h5/h6=1.0x
- Quote-Depth-Tags werden ebenfalls aktualisiert

**Table Rendering (Phase 2.4):**
- Maximum column width limited to 40 characters
- Overlong cells are truncated with ellipsis
- Minimum width remains at 3 characters

**Further Improvements:**
- `cget` extended with `-onclick` and `-fontsize`
- initTags uses consistent base fontsize (no more hardcodes)
- New demo: `demo/mdviewer-anchor-fontsize-demo.tcl`

### mdsearch 0.1 – NEU (Phase 3.1)

**Full-text search in Viewer:**
- `find $viewerPath $pattern` → case-insensitive search, returns match positions
- `next` / `prev` → Navigation with wrap-around
- `clearHighlight` → Remove highlights
- `count` / `current` → Match statistics (for "3/17" display)
- Yellow highlights (`#FFEB3B`), current match orange (`#FF9800`)
- Works with disabled Text-Widget (viewer state)
- New demo: `demo/mdsearch-demo.tcl`

### Vorzeige-App: mdviewer-app-v2.tcl

**Complete Markdown viewer application** (594 lines) with all mdstack 2.0 features:
- TOC-Navigation (PanedWindow, collapsible)
- Full-text search with search bar, ↑/↓-navigation, match counter
- Fontsize control (Spinbox + Ctrl+/−/0)
- PDF-Export (optional, if pdf4tcl available)
- Link handler: internal Anchor-Links, external Links (Browser), relative .md-Links
- Keyboard shortcuts for all functions
- Built-in welcome document
- Test file: `demo/test-complete.md` (17 sections)

### mdpdf 0.1 – Cleanup

**Architecture Restructuring – Segment-based Inline-Rendering:**
- Old System (`_renderInlines`): Returned literal text → Markdown markers visible in PDF, one font per line
- New System: AST-Inlines → `_inlinesToSegments` → `_wrapStyledSegments` → `_renderStyledLine` with font change per segment
- Styles: normal (Helvetica), bold (Helvetica-Bold), italic (Helvetica-Oblique), bolditalic (Helvetica-BoldOblique), code (Courier)
- Blockquotes: parentStyle "italic" → normal text italic, **bold** in Quote → bolditalic

**Removed dead code:**
- `_renderInlines` → replaced by `_inlinesToPlainText` (Headings, TOC) and `_inlinesToSegments` (Paragraphs, Lists)
- `_quoteFont` → no longer needed (segment system resolves quote italic directly)
- `_drawQuoteBars` → calls removed (no more `│`/`?` in PDF), Proc removed
- `_wrapText` → replaced by `_wrapStyledSegments` (style-aware wrapping)

**New Procs:**
- `_sanitizeForPdf` – Unicode → ASCII (Box-Drawing, Smart-Quotes, Bullets, Arrows etc.)
- `_inlinesToPlainText` – AST → plain text without markers
- `_styleToFont` – Style-Name → PDF-Font-Name
- `_inlinesToSegments` – AST → flat {text style} segments with nesting
- `_wrapStyledSegments` – Segments → wrapped lines (Space-Tracking between segments)
- `_renderStyledLine` – Render line with font change + sanitization

**Bugfixes:**
- Unicode characters (│, —, ", …) no longer appear as `?` in PDF
- Inline formatting (**bold**, *italic*, `code`) is actually rendered in PDF
- Nested styles (bold in italic Blockquote → bolditalic) work correctly
- Space handling between segments corrected ("avery" → "a very")

### mdviewer 0.3

**Blockquote Improvements:**
- Italic formatting in blockquotes works (Text-Nodes receive quote_d-Tag)
- Spacer-lines (`│\n`) between sub-blocks removed (Paragraphs already have `\n`)
- renderInlines checks quoteDepth and tags text nodes with qtag for correct font application

**Line savings:** mdpdf 932 → 858 lines (−74), including +30 Header docs

---

## Version 0.3 (Februar 2026)

### mdviewer 0.3

**Neue Features:**
- ✅ Italic formatting in blockquotes
- ✅ Improved blockquote display with visual quote bars (│)
- ✅ Support for nested blockquotes with correct indentation

**Changes:**
- Text within Blockquotes is now displayed in italic by default
- Quote bars (│) are shown for each nesting level
- Paragraphs within Blockquotes automatically receive italic formatting

**Bugfixes:**
- Multi-line blockquotes are now correctly rendered with line breaks
- Inline formatting (italic, bold) now works correctly within Blockquotes

---

## Version 0.2 (Februar 2026)

### mdviewer 0.2

**Neue Features:**
- Bild-Rendering (PNG, GIF, JPG)
- Bilder in Tabellen
- Box drawing for tables
- Blockquote-Rendering (mehrzeilig, verschachtelt)
- Hard Line Break Support
- Link Hover-Effekte (Unterstrichen bei Mouse-Over)
- `-onclick` Callback for all clicks

**Changes:**
- Migration to `ttk::frame` + `ttk::scrollbar` (Rulebook §3.1)
- Improved table display with dynamic column widths

---

## Version 0.1 (Februar 2026)

### mdpdf 0.1

**New Features:**
- PDF export for Markdown documents
- Support for all Block-Types (Headings, Paragraphs, Lists, Code, Blockquotes, HR)
- table of contents (TOC)
- Custom Footer with page numbers
- Various page sizes (A4, Letter)
- Unicode sanitization for PDF standard fonts
- Italic formatting in blockquotes
- Inline formatting (bold, italic, code) within Blockquotes

**Technical Details:**
- Uses pdf4tcl for PDF generation
- AST-based rendering logic
- Supports nested blockquotes with correct indentation
- Automatic page breaks
- Text wrapping with font width calculation

**Bugfixes:**
- Unicode characters are correctly replaced by ASCII equivalents (no more question marks)
- Blockquotes now render italic formatting correctly
- Quote bars (│) were removed from PDF export (only in Viewer)

---

## Version 0.1 (Februar 2026)

### mdparser 0.2

**New Features:**
- Tables (GFM)
- Blockquotes (multi-line, nested)
- Task Lists
- Standalone Images
- Inline Images
- Hard Line Breaks

---

## Version 0.1 (Februar 2026)

### mdstack 0.1

**New Features:**
- Orchestrator for stack management
- Editor/Preview integration
- Callback system (onchange, onmodified, onsave)

---

## Version 0.1 (Februar 2026)

### mdtext 0.1

**New Features:**
- Editor-Widget with Smart Return
- Tab-Indent
- Context menu integration
- Format operations (bold, italic, code, headings, lists, etc.)

---

## Version 0.1 (Februar 2026)

### mdmodel 0.1

**New Features:**
- AST → Document-Model conversion
- TOC generation
- Heading extraction
- Anchor generation
- Search in document
