# mdeditwidget

> ⚠️ **Legacy module** — use `mdstack` + `mdtext` + `mdviewer` for new projects.

## Purpose

`mdeditwidget` is a complete editor widget with toolbar and file functions.

---

## Migration

| Old (mdeditwidget) | New |
|--------------------|-----|
| Toolbar | → application |
| Editor | → `mdtext` |
| Preview | → `mdviewer` |
| Orchestration | → `mdstack` |
| File open/save | → application |

---

## Public API

```tcl
package require mdeditwidget 0.1

set w [mdeditwidget::create .mde]
mdeditwidget::loadFile $w "README.md"
mdeditwidget::saveFile $w
```
