# mdeditor

> ⚠️ **Legacy module** — use `mdtext` for new projects.

## Purpose

`mdeditor` is a simple editor widget for Markdown text.

---

## Migration to mdtext

```tcl
# OLD (mdeditor)
set ed [mdeditor::create .ed]
mdeditor::setContent $ed $text
set text [mdeditor::getContent $ed]

# NEW (mdtext)
set ed [mdtext::create .ed]
$ed set $text
set text [$ed get]
```

---

## Public API

```tcl
package require mdeditor 0.1

set ed [mdeditor::create $parent]
mdeditor::setContent   $ed $text
set text [mdeditor::getContent $ed]
set mod  [mdeditor::isModified $ed]
mdeditor::clearModified $ed
```
