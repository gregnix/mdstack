# GitHub-Repo komplett neu starten

## Situation

Repo hat alten Verlauf den du nicht öffentlich haben willst.
Ziel: sauberer initialer Commit mit Stand 0.3.2, kein alter Verlauf.

---

## Methode: Orphan-Branch (empfohlen)

Kein Löschen und Neu-Anlegen des Repos nötig.
GitHub-Settings (Issues, Stars, Description) bleiben erhalten.

```bash
cd ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x

# 1. Neuen verwaisten Branch erstellen (kein Eltern-Commit)
git checkout --orphan fresh

# 2. Alles stagen
git add -A

# 3. Initialer Commit
git commit -m "mdstack 0.3.2: Initial public release"

# 4. Main löschen (lokal)
git branch -D main

# 5. Fresh → main umbenennen
git branch -m fresh main

# 6. Force-Push (überschreibt alten Verlauf auf GitHub)
git push origin main --force

# 7. Tag setzen
git tag v0.3.2
git push origin v0.3.2
```

---

## Vorher: CHANGELOG.md ersetzen

Die neue `CHANGELOG.md` (aus outputs/) ins Repo kopieren:

```bash
cp outputs/CHANGELOG.md .
```

---

## Vorher: nogit/ sauber halten

Sicherstellen dass `.gitignore` `nogit/` ausschließt:

```bash
grep nogit .gitignore   # muss erscheinen
```

Falls nicht:
```bash
echo "nogit/" >> .gitignore
```

---

## Ergebnis

- GitHub zeigt 1 Commit: "mdstack 0.3.2: Initial public release"
- Kein alter Verlauf sichtbar
- Tag v0.3.2 zeigt auf diesen Commit
- `nogit/` bleibt lokal, kommt nicht ins Repo

---

## Danach: normaler Workflow

Alle folgenden Commits gehen ganz normal mit `git add` + `git commit` + `git push`.
