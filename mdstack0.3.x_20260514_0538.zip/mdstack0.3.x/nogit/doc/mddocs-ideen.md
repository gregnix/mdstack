# mddocs -- Ideen: Dokumentations-Server fuer Tcl

Stand: 2026-03-14
Status: Ideensammlung, kein Commitment

---

## Ausgangslage

`mdserver.tcl` (tools/mdserver in mdstack) ist ein einfacher
Markdown-Web-Server -- gut fuer lokale Dokumentation, aber ohne
Benutzer, Suche, Editieren oder Versionierung.

`mddocs` waere ein vollstaendiger Dokumentations-Server auf
Basis von mdstack -- aehnlich wie Gitea/Confluence, aber:
- pure Tcl, kein C, kein Java
- Markdown-nativ
- leichtgewichtig
- selbst gehostet

---

## Feature-Set

### Kern

| Feature | Beschreibung | Basis |
|---------|-------------|-------|
| Rendering | Markdown -> HTML on-the-fly | mdparser + mdhtml |
| Suche | Volltext ueber alle .md-Dateien | mdsearch |
| Themes | hell/dunkel/solarized + custom CSS | mdtheme |
| HTTP + HTTPS | TLS via tls-Paket | mdserver |
| Verzeichnis-Index | automatisch mit Titel aus H1 | mdserver |

### Editieren

- Markdown direkt im Browser bearbeiten
- Live-Preview (WebSocket)
- Speichern -> Git-Commit (automatisch)
- Konflikt-Erkennung bei gleichzeitiger Bearbeitung

### Versionierung

- Git als Backend -- jede Aenderung = Commit
- History anzeigen: wer hat wann was geaendert
- Diff-Ansicht zwischen Versionen
- Revert auf frueheren Stand

### Benutzerverwaltung

```
Gruppen:   admin / editor / reader
Rechte:    lesen / bearbeiten / loeschen / verwalten
Auth:      Session-Cookie (einfach) oder Basic Auth
Speicher:  SQLite (kein externer DB-Server noetig)
```

### Async

- Tcl Coroutinen fuer nicht-blockierende I/O
- `fconfigure -blocking 0` + `readable`-Event
- Kein Threading noetig
- WebSocket fuer Live-Preview

---

## Architektur

```
Browser
   |
httpserver-0.1.tm  (TclOO, async via Coroutine)
   |
+--------+--------+--------+--------+--------+
|        |        |        |        |        |
render  search  editor   auth    version
(mdhtml)(mdsearch)(save) (session)(git)
   |
mdparser-0.2 -> AST -> mdhtml-0.1 -> HTML
                    -> mdpdf-0.2  -> PDF (Export)
```

### httpserver als eigenes Modul

`mdserver.tcl` wird zu `httpserver-0.1.tm` -- ein allgemeiner
HTTP-Server mit Handler-Registrierung:

```tcl
package require httpserver 0.1

httpserver::route GET  {*.md}  mddocs::renderHandler
httpserver::route GET  {/search} mddocs::searchHandler
httpserver::route POST {*.md}  mddocs::saveHandler
httpserver::route GET  {*}     httpserver::staticHandler

httpserver::start --port 8080 --root /docs
```

### TclOO-Klassenstruktur

```
httpserver::Server
   |
   +-- httpserver::Request
   +-- httpserver::Response
   +-- httpserver::Router
   +-- httpserver::Session

mddocs::App (erbt von httpserver::Server)
   |
   +-- mddocs::Renderer   (mdparser + mdhtml)
   +-- mddocs::Search     (mdsearch)
   +-- mddocs::Editor     (WebSocket + Git)
   +-- mddocs::Auth       (SQLite Sessions)
   +-- mddocs::Version    (Git)
```

---

## WebSocket fuer Live-Preview

Browser sendet Markdown-Text, Server antwortet mit HTML:

```tcl
# Server-Seite
proc mddocs::wsHandler {chan msg} {
    set ast  [mdparser::parse $msg]
    set html [mdhtml::render $ast -theme hell]
    ws::send $chan $html
}
```

```javascript
// Browser-Seite
const ws = new WebSocket('ws://localhost:8080/preview');
editor.on('change', () => ws.send(editor.value));
ws.onmessage = (e) => preview.innerHTML = e.data;
```

---

## Versionierung mit Git

```tcl
# Speichern + Commit
proc mddocs::save {path content user msg} {
    writeFile $path $content
    exec git -C [docRoot] add $path
    exec git -C [docRoot] commit \
        -m "$msg" \
        --author "$user <$user@mddocs>"
}

# History
proc mddocs::history {path} {
    exec git -C [docRoot] log \
        --pretty=format:"%H|%ai|%an|%s" -- $path
}
```

---

## Benutzerverwaltung (SQLite)

```tcl
package require sqlite3

sqlite3 db mddocs.db

db eval {
    CREATE TABLE IF NOT EXISTS users (
        id       INTEGER PRIMARY KEY,
        name     TEXT UNIQUE,
        password TEXT,   -- bcrypt-Hash
        group_id INTEGER
    );
    CREATE TABLE IF NOT EXISTS groups (
        id   INTEGER PRIMARY KEY,
        name TEXT,       -- admin / editor / reader
        can_read   INTEGER DEFAULT 1,
        can_edit   INTEGER DEFAULT 0,
        can_delete INTEGER DEFAULT 0,
        can_admin  INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions (
        token    TEXT PRIMARY KEY,
        user_id  INTEGER,
        expires  INTEGER
    );
}
```

---

## Export

```tcl
# Einzelne Seite als PDF
mddocs::exportPdf /docs/api.md api.pdf

# Ganzes Verzeichnis als PDF (zusammengefuehrt)
mddocs::exportBook /docs/ handbuch.pdf
```

---

## Konfiguration (mddocs.conf)

```tcl
# mddocs.conf -- Tcl-Syntax
set cfg(port)     8080
set cfg(tlsport)  8443
set cfg(root)     /home/user/docs
set cfg(theme)    hell
set cfg(title)    "Meine Dokumentation"
set cfg(git)      1          ;# Git-Versionierung
set cfg(auth)     1          ;# Benutzer-Authentifizierung
set cfg(db)       mddocs.db
set cfg(cert)     server.crt
set cfg(key)      server.key
```

---

## Offene Fragen

- **WebSocket in Tcl**: `Tcllib websocket` oder eigene Implementation?
- **Passwort-Hashing**: `tcllib md5` reicht nicht -- `argon2` oder `bcrypt` braucht C-Extension
- **Concurrent Edits**: Locking-Strategie (File-Lock oder Git-Branch pro User)?
- **Volltextsuche**: `mdsearch` reicht fuer kleine Wikis -- fuer grosse Repos SQLite FTS5
- **Eigenes Repo**: `mddocs` als separates GitHub-Repo oder Teil von mdstack?

---

## Entwicklungsphasen

### Phase 1: httpserver-0.1.tm

Aus `mdserver.tcl` ein allgemeines TclOO-Framework extrahieren:
- `httpserver::Server`, `Request`, `Response`, `Router`
- Handler-Registrierung
- Async via Coroutine
- HTTPS

Aufwand: ~400 Zeilen

### Phase 2: mddocs Core

- Rendering (mdparser + mdhtml, bereits vorhanden)
- Suche (mdsearch, bereits vorhanden)
- Static Files
- Konfiguration

Aufwand: ~300 Zeilen

### Phase 3: Editor + WebSocket

- Markdown-Editor im Browser (CodeMirror oder textarea)
- WebSocket Live-Preview
- Speichern (mit Git-Commit)

Aufwand: ~400 Zeilen Tcl + ~200 Zeilen JS

### Phase 4: Auth + User

- SQLite-basierte Benutzerverwaltung
- Session-Cookies
- Gruppen und Rechte

Aufwand: ~300 Zeilen

### Phase 5: Versionierung

- Git-History anzeigen
- Diff-Ansicht
- Revert

Aufwand: ~200 Zeilen

---

## Abhaengigkeiten

| Paket | Zweck | Verfuegbarkeit |
|-------|-------|---------------|
| mdparser 0.2 | Markdown -> AST | mdstack |
| mdhtml 0.1 | AST -> HTML | mdstack |
| mdtheme 0.1 | CSS-Themes | mdstack |
| mdsearch 0.1 | Volltext | mdstack |
| mdpdf 0.2 | PDF-Export | mdstack |
| sqlite3 | Auth/Suche | Tcl-Standard |
| tls | HTTPS | apt install tcl-tls |
| Tcllib websocket | WebSocket | apt install tcllib |
| git | Versionierung | System |

Pure Tcl bis auf tls (C) und websocket (optional).

---

## Zeitplan (grob)

Vorbedingungen:
- mdstack 0.3.2 (Nested-List-Bug, Tk-Entkopplung)
- pdf4tcl 0.9.4.12 (Core-Erweiterungen)

Dann:
- Phase 1: httpserver (~1 Session)
- Phase 2: mddocs Core (~1 Session)
- Phase 3: Editor + WebSocket (~2 Sessions)
- Phase 4: Auth (~1 Session)
- Phase 5: Git (~1 Session)
