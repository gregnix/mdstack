# Übergabe -- Nächster Chat

Datum: 2026-03-14

---

## mdstack 0.3.3

```
git remote: https://github.com/gregnix/mdstack
Arbeitsverzeichnis: ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x/
```

**Erledigt heute (0.3.1 → 0.3.3):**

| Was | Datei(en) |
|-----|-----------|
| Nested-list-Bug in `parseListBlock` | `lib/mdparser-0.2.tm` |
| Test-Suite Vierteilung A/B/C/D, 445/445 headless | `tests/all.tcl`, `tests/basic.tcl`, 4 Testdateien |
| Lizenz MIT, README aktualisiert | `README.md` |
| `pkgIndex.tcl` im Root (zeigt auf `lib/` und `vendors/tm/`) | `pkgIndex.tcl` |
| Manuals `de/` und `en/` vollständig (20 Module je) | `doc/manuals/de/`, `doc/manuals/en/` |
| Demos: von 20 auf 12 reduziert | `demo/` |
| `mdeditor`, `mdeditwidget` aus `lib/` entfernt | — |
| mdviewer Link-Bug: `end` → `"end -1 chars"` bei link-Tags | `lib/mdviewer-0.3.tm` |
| mdviewer taskdone: kein `-overstrike` mehr | `lib/mdviewer-0.3.tm` |
| mdviewer-app-v2: HTML-Export (`Ctrl+H`), Help (`F1`) | `demo/mdviewer-app-v2.tcl` |
| mdviewer-app-v2: Anchor-Links korrigiert | `demo/mdviewer-app-v2.tcl` |
| `demo/help.md` neu | `demo/help.md` |
| CHANGELOG 0.3.1 → 0.3.3 | `CHANGELOG.md` |
| Abhängigkeits-Diagramm (SVG) | `nogit/doc/mdstack-dependencies.svg` |
| Bug-Doku: Link-Tags, taskdone | `nogit/doc/mdviewer-bugs-und-fixes.md` |

**Aktueller ZIP:** `mdstack0_3_x_20260314_2259.zip` (mit pkgIndex im Root)

**GitHub-Push (Orphan-Reset empfohlen — saubere History):**

```bash
cd ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x
git checkout --orphan fresh
git add -A
git commit -m "mdstack 0.3.3: fixes, manuals, pkgIndex, demos"
git branch -D main
git branch -m fresh main
git push origin main --force
git tag v0.3.3
git push origin v0.3.3
```

**Noch offen:**

- `mdpdf-0.2.tm` -- `-theme`-Option fehlt noch
- Hyperlinks im PDF prüfen: wirklich klickbar im Viewer?
- `mdhtml-0.1.tm` mit Testfällen absichern

**Nächste Entwicklung (0.3.4):**
- mdtheme: PDF-Farben (colorLink, colorCode) wenn pdf4tcl 0.9.4.12
- mdhtml: Syntax-Highlighting via `-highlighter`
- mdserver: favicon.ico

---

## pdf4tcl 0.9.4.11

```
git remote: https://github.com/gregnix/pdf4tcl
Arbeitsverzeichnis: ~/Project/2026/code/pdf/pdf4tcl0.9.4.11src/pdf4tcl/
```

**Push (noch ausstehend):**

```bash
tclsh 0.9.4.x/nogit/scripts/restore-pkg-symlinks.tcl
make
tclsh 0.9.4.x/nogit/scripts/sync-pdf4tcl.tcl
git add src/encrypt.tcl src/main.tcl src/prologue.tcl
git add tests/encrypt.test tests/tounicode.test tests/init.tcl
git add pkgIndex.tcl Makefile pdf4tcl.tcl ChangeLog
git add pdf4tcl.man pdf4tcl.html pdf4tcl.n
git add pdf4tcl.syntax pdf4tcl_h90.syntax .gitignore
git rm 0.9.4.x/doc/de/*.pdf 0.9.4.x/doc/en/*.pdf
git add 0.9.4.x/doc/en/pdf4tcl-graphics-and-colors.md
git commit -m "0.9.4.11: AES-128 encryption, _FindSRGBProfile TeX paths"
tclsh 0.9.4.x/nogit/scripts/make-release.tcl --check
tclsh 0.9.4.x/nogit/scripts/make-release.tcl
```

**Nächste Entwicklung (0.9.4.12):**
- Metadata-Synchronisation: Info-Dict = XMP (~30 Zeilen)
- DateTime-Validierung (~20 Zeilen)
- `roundedRect` und `getLineHeight` als Core-Methoden
- Theme-Farben für mdpdf (colorLink, colorCode, colorHeading)

---

## pdf4tcllib 0.1

```
Arbeitsverzeichnis: ~/Project/2026/code/markdown/pdf4tcllib/pdf4tcllib/
```

**Einpflegen:**

```
outputs/examples-updated.zip    -> examples/
outputs/06_font_sizes.tcl        -> examples/06_font_sizes.tcl
```

---

## man-viewer 0.1

```
git remote: https://github.com/gregnix/man-viewer
```

**Sofort:**
```bash
mv "nogit/doc/e n" nogit/doc/en
git add -A && git commit -m "fix: rename 'e n' to 'en'" && git push
```

**Nächste Entwicklung:**
- `ast2md-0.1.tm` in `man-viewer.tcl` integrieren (3 Änderungen, Spec in `nogit/doc/ast2md-integration.md`)

---

## Wichtige Fallstricke

- `file normalize ~/...` in Tcl 9: immer `$env(HOME)` verwenden
- `exec` in Tcl 9: stderr mit `2>@stdout` umleiten
- mdparser: `parseListBlock` bricht bei gemischten Listentypen nur noch auf Top-Level ab (seit 0.3.2)
- mdviewer: bei link-Tags immer `"end -1 chars"` statt `end` -- sonst leere Ranges, Klick ohne Wirkung
- mdparser: Tabellenfeld heisst `alignments`, Zellen in `headerInlines`/`rowsInlines`
- mdparser: Listentyp via `style unordered/ordered`, nicht boolean `ordered`
- urlDecode: nach `subst` immer `encoding convertfrom utf-8`
- mdserver-Tests aus `tools/mdserver/test/` starten
- `make release`: vorher `restore-pkg-symlinks.tcl`
