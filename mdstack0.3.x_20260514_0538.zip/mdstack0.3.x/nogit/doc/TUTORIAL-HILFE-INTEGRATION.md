# Tutorial: Hilfe in Tcl/Tk-Apps mit mdstack

Dieses Tutorial zeigt, wie man eine Markdown-basierte Hilfe in eine Tcl/Tk-Anwendung integriert.

## Ziel

Eine Hilfe-Funktion, die:
- Per F1 oder Menü aufrufbar ist
- Markdown schön formatiert anzeigt
- Ohne mdstack als Fallback Plain-Text zeigt

## Voraussetzungen

- Tcl/Tk 8.6+
- mdstack-2.0 (optional, für formatierte Anzeige)

---

## Schritt 1: Menü und Shortcut

Füge einen Hilfe-Menüeintrag und F1-Binding hinzu:

```tcl
# Menü erstellen
menu .menu -tearoff 0
. configure -menu .menu

menu .menu.help -tearoff 0
.menu add cascade -label "Hilfe" -menu .menu.help
.menu.help add command -label "Hilfe..." -command showHelp -accelerator "F1"
.menu.help add separator
.menu.help add command -label "Über..." -command showAbout

# F1-Shortcut
bind . <F1> showHelp
```

---

## Schritt 2: Hilfe-Text definieren

Definiere den Hilfe-Text als Markdown in einer Prozedur:

```tcl
proc getHelpText {} {
    return {# Meine App - Hilfe

## Übersicht

Beschreibung der Anwendung.

## Bedienung

### Hauptfunktionen

- **Funktion 1** - Beschreibung
- **Funktion 2** - Beschreibung

## Tastenkürzel

| Taste | Aktion |
|-------|--------|
| Ctrl+S | Speichern |
| Ctrl+Q | Beenden |
| F1 | Diese Hilfe |

## Konfiguration

Details zur Konfiguration...
}
}
```

**Tipp:** Der Hilfe-Text kann auch aus einer externen `.md`-Datei geladen werden:

```tcl
proc getHelpText {} {
    set helpFile [file join [file dirname [info script]] help.md]
    if {[file exists $helpFile]} {
        set f [open $helpFile r]
        set text [read $f]
        close $f
        return $text
    }
    return "# Hilfe\n\nHilfe-Datei nicht gefunden."
}
```

---

## Schritt 3: showHelp Prozedur

Die zentrale Prozedur, die das Hilfe-Fenster erstellt:

```tcl
proc showHelp {} {
    set w .help
    
    # Fenster existiert? Dann nur nach vorne bringen
    if {[winfo exists $w]} {
        raise $w
        focus $w
        return
    }
    
    # Neues Fenster erstellen
    toplevel $w
    wm title $w "Hilfe - Meine App"
    wm geometry $w 650x500
    
    # mdstack laden versuchen
    set useMdstack [loadMdstack]
    
    # Hilfe-Text holen
    set helpText [getHelpText]
    
    if {$useMdstack} {
        # Mit mdstack rendern (formatiert)
        renderWithMdstack $w $helpText
    } else {
        # Fallback: Plain-Text
        renderPlainText $w $helpText
    }
    
    # Schließen-Button
    ttk::frame $w.btns -padding 5
    pack $w.btns -fill x -side bottom
    ttk::button $w.btns.close -text "Schließen" -command [list destroy $w]
    pack $w.btns.close -side right
    
    # Escape schließt Fenster
    bind $w <Escape> [list destroy $w]
}
```

---

## Schritt 4: mdstack laden

Suche mdstack an verschiedenen Stellen:

```tcl
proc loadMdstack {} {
    # Mögliche Pfade für mdstack
    set scriptDir [file dirname [info script]]
    set searchPaths [list \
        [file join $scriptDir mdstack-2.0 lib] \
        [file join $scriptDir lib mdstack-2.0 lib] \
        [file join $scriptDir .. lib mdstack-2.0 lib] \
    ]
    
    # Suchen und zu tcl::tm::path hinzufügen
    foreach path $searchPaths {
        if {[file exists [file join $path mdparser-0.2.tm]]} {
            tcl::tm::path add $path
            break
        }
    }
    
    # Pakete laden versuchen
    if {[catch {package require mdparser 0.2}]} { return 0 }
    if {[catch {package require mdmodel 0.1}]}  { return 0 }
    if {[catch {package require mdviewer 0.3}]} { return 0 }
    
    return 1
}
```

---

## Schritt 5: Rendering-Funktionen

### Mit mdstack (formatiert)

```tcl
proc renderWithMdstack {w helpText} {
    # Viewer-Widget erstellen
    set viewer [mdviewer::create $w.viewer]
    pack $viewer -fill both -expand 1 -padx 10 -pady 10
    
    # Markdown parsen und rendern
    set ast [mdparser::parse $helpText]
    set doc [mdmodel::new $ast]
    mdviewer::renderModel $viewer $doc
}
```

**Wichtig:** Verwende `mdviewer::renderModel`, nicht `mdviewer::render`!

- `mdviewer::render` erwartet einen rohen AST
- `mdviewer::renderModel` erwartet ein doc-Objekt (von `mdmodel::new`)

### Fallback (Plain-Text)

```tcl
proc renderPlainText {w helpText} {
    ttk::frame $w.f -padding 10
    pack $w.f -fill both -expand 1
    
    text $w.f.txt -wrap word -font TkDefaultFont \
        -yscrollcommand "$w.f.sb set"
    ttk::scrollbar $w.f.sb -orient vertical -command "$w.f.txt yview"
    
    pack $w.f.sb -side right -fill y
    pack $w.f.txt -side left -fill both -expand 1
    
    $w.f.txt insert end $helpText
    $w.f.txt configure -state disabled
}
```

---

## Vollständiges Beispiel

Eine minimale App mit Hilfe-Integration:

```tcl
#!/usr/bin/env wish
# minimal-app-with-help.tcl

package require Tk 8.6

# === Hilfe-System ===

proc getHelpText {} {
    return {# Minimal App - Hilfe

## Übersicht

Eine minimale Tcl/Tk-Anwendung mit Markdown-Hilfe.

## Funktionen

- **Hilfe anzeigen** - F1 oder Menü
- **Beenden** - Ctrl+Q

## Über mdstack

Diese Hilfe wird mit **mdstack** gerendert:

1. `mdparser` - Markdown → AST
2. `mdmodel` - AST → Dokument-Model
3. `mdviewer` - Model → Tk Text-Widget
}
}

proc loadMdstack {} {
    set scriptDir [file dirname [info script]]
    foreach path [list \
        [file join $scriptDir mdstack-2.0 lib] \
        [file join $scriptDir lib mdstack-2.0 lib]] {
        if {[file exists [file join $path mdparser-0.2.tm]]} {
            tcl::tm::path add $path
            break
        }
    }
    
    if {[catch {package require mdparser 0.2}]} { return 0 }
    if {[catch {package require mdmodel 0.1}]}  { return 0 }
    if {[catch {package require mdviewer 0.3}]} { return 0 }
    return 1
}

proc showHelp {} {
    set w .help
    if {[winfo exists $w]} {
        raise $w
        return
    }
    
    toplevel $w
    wm title $w "Hilfe"
    wm geometry $w 600x450
    
    set helpText [getHelpText]
    
    if {[loadMdstack]} {
        set viewer [mdviewer::create $w.viewer]
        pack $viewer -fill both -expand 1 -padx 10 -pady 10
        
        set ast [mdparser::parse $helpText]
        set doc [mdmodel::new $ast]
        mdviewer::renderModel $viewer $doc
    } else {
        text $w.txt -wrap word
        pack $w.txt -fill both -expand 1 -padx 10 -pady 10
        $w.txt insert end $helpText
        $w.txt configure -state disabled
    }
    
    ttk::button $w.close -text "Schließen" -command [list destroy $w]
    pack $w.close -side bottom -pady 10
    
    bind $w <Escape> [list destroy $w]
}

# === Hauptanwendung ===

wm title . "Minimal App"
wm geometry . 400x300

menu .menu -tearoff 0
. configure -menu .menu

menu .menu.file -tearoff 0
.menu add cascade -label "Datei" -menu .menu.file
.menu.file add command -label "Beenden" -command exit -accelerator "Ctrl+Q"

menu .menu.help -tearoff 0
.menu add cascade -label "Hilfe" -menu .menu.help
.menu.help add command -label "Hilfe..." -command showHelp -accelerator "F1"

ttk::label .lbl -text "Drücke F1 für Hilfe" -font "TkDefaultFont 14"
pack .lbl -expand 1

bind . <F1> showHelp
bind . <Control-q> exit
```

---

## Verzeichnisstruktur

```
meine-app/
├── app.tcl              # Hauptanwendung
├── help.md              # Hilfe-Text (optional)
└── mdstack-2.0/         # mdstack Bibliothek
    └── lib/
        ├── mdparser-0.2.tm
        ├── mdmodel-0.1.tm
        ├── mdviewer-0.3.tm
        └── ...
```

---

## Tipps

### Link-Handling

mdviewer unterstützt klickbare Links. Registriere einen Handler:

```tcl
proc onLinkClick {url} {
    # URL im Browser öffnen
    if {$::tcl_platform(os) eq "Darwin"} {
        exec open $url &
    } elseif {$::tcl_platform(platform) eq "windows"} {
        exec cmd /c start $url &
    } else {
        catch {exec xdg-open $url &}
    }
}

# Bei Viewer-Erstellung:
set viewer [mdviewer::create $w.viewer -onlink onLinkClick]
```

### Hilfe-Datei extern laden

```tcl
proc getHelpText {} {
    set scriptDir [file dirname [info script]]
    set helpFile [file join $scriptDir help.md]
    
    if {[file exists $helpFile]} {
        set f [open $helpFile r]
        fconfigure $f -encoding utf-8
        set text [read $f]
        close $f
        return $text
    }
    
    # Fallback: eingebetteter Text
    return {# Hilfe

Hilfe-Datei nicht gefunden.
}
}
```

### Kontext-sensitive Hilfe

Verschiedene Hilfe-Seiten für verschiedene Bereiche:

```tcl
proc showHelp {{topic "main"}} {
    set helpTexts [dict create \
        main   {# Haupthilfe ...} \
        editor {# Editor-Hilfe ...} \
        config {# Konfigurations-Hilfe ...}]
    
    set text [dict get $helpTexts $topic]
    # ... Fenster erstellen und rendern
}

# Aufruf:
showHelp "editor"
```

---

## Zusammenfassung

1. **Menü + Shortcut** einrichten (F1)
2. **Hilfe-Text** als Markdown definieren oder aus Datei laden
3. **mdstack laden** mit Fallback-Prüfung
4. **Viewer erstellen** mit `mdviewer::create`
5. **Rendern** mit `mdparser::parse` → `mdmodel::new` → `mdviewer::renderModel`

Der Fallback auf Plain-Text stellt sicher, dass die Hilfe auch ohne mdstack funktioniert.
