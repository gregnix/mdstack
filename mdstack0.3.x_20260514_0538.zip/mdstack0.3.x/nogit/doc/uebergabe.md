# Übergabe -- Nächster Chat

Datum: 2026-03-14

---

## Projekte und Stand

### mdstack 0.3.1

```
git remote: https://github.com/gregnix/mdstack  (noch nicht gepusht)
Arbeitsverzeichnis: ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x/
```

**GitHub-Vorbereitung erledigt:**
- Version 0.3.1, saubere Struktur, `.gitignore` korrekt
- `nogit/` enthaelt interne Docs (nicht im Repo)
- `tests/` zusammengefuehrt (32 Tests)
- `CHANGELOG.md` nur 0.3.1-Eintrag

**Initialer GitHub-Commit:**

```bash
cd ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x
git init
git add -A
git commit -m "mdstack 0.3.1: Initial GitHub release"
git remote add origin https://github.com/gregnix/mdstack
git push -u origin main
```

**Noch offen:**
- `mdpdf-0.2.tm` -- `-theme`-Option fehlt noch (outputs/mdpdf-0.2.tm einpflegen)
- Hyperlinks im PDF prüfen: wirklich klickbar im Viewer?
- `mdhtml-0.1.tm` mit Testfällen absichern

**Nächste Entwicklung (0.3.2):**
- mdtheme: PDF-Farben (colorLink, colorCode) vollständig wenn pdf4tcl 0.9.4.12
- mdhtml: Syntax-Highlighting via `-highlighter` Option
- mdserver: favicon.ico Support

---

### mdstack tools/mdserver

```
tools/mdserver/mdserver.tcl     -- HTTP/HTTPS Server
tools/mdserver/mkcert.tcl       -- Zertifikat-Hilfsskript
tools/mdserver/test/test-mdserver.tcl  -- 47 Tests (alle grün)
tools/mdserver/mdserver-demo/   -- Demo-Site
```

**Funktioniert:**
- HTTP + HTTPS gleichzeitig
- `start.tcl --https` erzeugt Zertifikat automatisch via mkcert.tcl
- Zertifikat landet in `tools/mdserver/` (nicht in mdserver-demo/)
- `.gitignore`: `server.crt`, `server.key`

---

### pdf4tcl 0.9.4.11

```
git remote: https://github.com/gregnix/pdf4tcl
Arbeitsverzeichnis: ~/Project/2026/code/pdf/pdf4tcl0.9.4.11src/pdf4tcl/
Noch nicht gepusht: v0.9.4.7 bis v0.9.4.11
```

**Offene Aufgaben:**

```bash
tclsh 0.9.4.x/nogit/scripts/restore-pkg-symlinks.tcl
make
tclsh 0.9.4.x/nogit/scripts/sync-pdf4tcl.tcl
git add src/encrypt.tcl src/main.tcl src/prologue.tcl
git add tests/encrypt.test tests/tounicode.test tests/init.tcl
git add pkgIndex.tcl Makefile pdf4tcl.tcl ChangeLog
git add pdf4tcl.man pdf4tcl.html pdf4tcl.n
git add pdf4tcl.syntax pdf4tcl_h90.syntax .gitignore
git rm 0.9.4.x/doc/de/*.pdf 0.9.4.x/doc/en/*.pdf
git add 0.9.4.x/doc/en/pdf4tcl-graphics-and-colors.md
git commit -m "0.9.4.11: AES-128 encryption, _FindSRGBProfile TeX paths"
tclsh 0.9.4.x/nogit/scripts/make-release.tcl --check
tclsh 0.9.4.x/nogit/scripts/make-release.tcl
```

**Dateien einpflegen:**

```
outputs/regelbuch-pdf4tcl.md         -> 0.9.4.x/nogit/docs/de/
outputs/pdf4tcl-analyse.md           -> 0.9.4.x/nogit/docs/de/
outputs/tcl-pdf-ideen.md             -> 0.9.4.x/nogit/docs/de/
outputs/pdf4tcl.man                  -> pdf4tcl.man  (dann make doc)
outputs/ChangeLog                    -> ChangeLog
outputs/45a_pdfa_direct.tcl          -> 0.9.4.x/demo/
```

**Nächste Entwicklung (0.9.4.12):**
- Metadata-Synchronisation: Info-Dict = XMP (~30 Zeilen)
- DateTime-Validierung (~20 Zeilen)
- `roundedRect` als Core-Methode
- `getLineHeight` als Core-Methode
- Theme-Farben für mdpdf (colorLink, colorCode, colorHeading)

---

### pdf4tcllib 0.1

```
Arbeitsverzeichnis: ~/Project/2026/code/markdown/pdf4tcllib/pdf4tcllib/
(kein eigenes GitHub-Repo -- wartet noch)
```

**Dateien einpflegen:**

```
outputs/examples-updated.zip    -> examples/  (46 Demos)
outputs/06_font_sizes.tcl        -> examples/06_font_sizes.tcl
```

---

### man-viewer

```
git remote: https://github.com/gregnix/man-viewer
```

**Sofort:**

```bash
mv "nogit/doc/e n" nogit/doc/en
git add -A
git commit -m "fix: rename 'e n' to 'en'"
git push
```

**Nächste Entwicklung:**
- `ast2md-0.1.tm` fertigstellen (todo-ast2md.md in nogit)

---

## Übergreifende Ideen (nogit)

- **tcl-pdf-ideen.md** -- neue PDF-Library (ast2pdf, modularer Stack)
- **pdf4tcl-analyse.md** -- Roadmap 0.9.4.12 bis 1.0

---

## Wichtige Fallstricke

- `file normalize ~/...` in Tcl 9: immer `$env(HOME)` verwenden
- `exec` in Tcl 9: stderr mit `2>@stdout` umleiten
- `[const text]` in doctools: nur ein Wort, kein Leerzeichen
- rsync trailing slash: `file normalize` entfernt ihn -- `${from}/` explizit
- `make release`: vorher `restore-pkg-symlinks.tcl`
- mdparser: Tabellenfeld heisst `alignments`, Zellen in `headerInlines`/`rowsInlines`
- mdparser: Listentyp via `style unordered/ordered`, nicht boolean `ordered`
- urlDecode: nach `subst` immer `encoding convertfrom utf-8` -- sonst Bytes statt Zeichen
- mdserver Test: aus `tools/mdserver/test/` starten damit `../lib` aufgeloest wird
