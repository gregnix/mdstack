# Übergabe -- Nächster Chat

Datum: 2026-03-14

---

## Projekte und Stand

### mdstack 0.3.2

```
git remote: https://github.com/gregnix/mdstack
Arbeitsverzeichnis: ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x/
```

**Erledigt in dieser Session (P1–P4):**

| Priorität | Was | Datei(en) |
|-----------|-----|-----------|
| P1 | Nested-list-Bug: `parseListBlock` Typ-Prüfung nur bei Top-Level | `lib/mdparser-0.2.tm` |
| P2 | Tk-Entkopplung: Core/GUI in `basic.tcl` getrennt | `tests/basic.tcl` |
| P3 | Test-Suite Vierteilung A/B/C/D, fehlende Tests, Zählerfehler | `tests/all.tcl`, 4 Testdateien |
| P4 | Lizenz MIT konsistent, README aktualisiert | `README.md`, `CHANGELOG.md` |

**Testergebnis:**
- Headless: 445/445, 0 Fehler
- Mit Tk: +21 GUI-Tests (466 gesamt, 0 Fehler)

**Einpflegen (aus dieser Session):**

```
outputs/mdstack0_3_1_release_20260314.zip  -> entpacken nach mdstack-0.3.x/
```

Geänderte Dateien:
```
lib/mdparser-0.2.tm
tests/all.tcl
tests/basic.tcl
tests/parser-inline-features.tcl
tests/parser-inline-fixes.tcl
tests/test-docir-md.tcl
tests/validator.tcl
README.md
CHANGELOG.md
doc/manuals/mdparser.md
doc/manuals/mdvalidator.md   (neu)
doc/manuals/index.md
```

**GitHub-Push:**

```bash
cd ~/Project/2026/code/markdown/mdstack2/mdstack-0.3.x
git add lib/mdparser-0.2.tm
git add tests/all.tcl tests/basic.tcl
git add tests/parser-inline-features.tcl tests/parser-inline-fixes.tcl
git add tests/test-docir-md.tcl tests/validator.tcl
git add README.md CHANGELOG.md
git add doc/manuals/mdparser.md doc/manuals/mdvalidator.md doc/manuals/index.md
git commit -m "0.3.2: nested-list fix, test-suite cleanup, release hygiene"
git push
git tag v0.3.2
git push --tags
```

**Noch offen:**

- `mdpdf-0.2.tm` -- `-theme`-Option fehlt noch (outputs/mdpdf-0.2.tm einpflegen)
- Hyperlinks im PDF prüfen: wirklich klickbar im Viewer?
- `mdhtml-0.1.tm` mit Testfällen absichern
- `docir-md-0.1.tm` -- Manual `doc/manuals/docir-md.md` fehlt noch

**Nächste Entwicklung (0.3.3):**
- mdtheme: PDF-Farben (colorLink, colorCode) vollständig wenn pdf4tcl 0.9.4.12
- mdhtml: Syntax-Highlighting via `-highlighter` Option
- mdserver: favicon.ico Support

---

### mdstack tools/mdserver

Unverändert. 47 Tests alle grün.

---

### pdf4tcl 0.9.4.11

Gepusht. Nächste Entwicklung 0.9.4.12:
- Metadata-Synchronisation: Info-Dict = XMP (~30 Zeilen)
- DateTime-Validierung (~20 Zeilen)
- `roundedRect` als Core-Methode
- `getLineHeight` als Core-Methode
- Theme-Farben für mdpdf (colorLink, colorCode, colorHeading)

---

### man-viewer 0.1

Gepusht. `ast2md-0.1.tm` ist im Repo (301 Zeilen).

Noch offen:
- ast2md in `man-viewer.tcl` integrieren (3 Änderungen, Spec in
  `nogit/doc/ast2md-integration.md`)
- `nogit/doc/e n/` lokal umbenennen zu `nogit/doc/en/`

---

## Wichtige Fallstricke

- `file normalize ~/...` in Tcl 9: immer `$env(HOME)` verwenden
- `exec` in Tcl 9: stderr mit `2>@stdout` umleiten
- mdparser: `parseListBlock` bricht bei gemischten Listentypen nur noch
  auf Top-Level-Ebene ab (seit 0.3.2)
- Test-Zähler in assert-basierten Tests: `upvar` muss auf `passed`/`failed`
  zeigen, nicht auf lokale Variablen
- mdserver-Tests aus `tools/mdserver/test/` starten (damit `../lib` klappt)
